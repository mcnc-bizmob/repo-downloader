import { fileURLToPath, URL } from 'node:url'
import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vite.dev/config/
export default defineConfig(({ command, mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiBaseUrl = env.VITE_API_BASE_URL;
  const devServerPort = parseInt(env.VITE_DEV_SERVER_PORT) || 5173;

  return {
    plugins: [
      vue(),
    ],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url))
      }
    },
    server: {
      port: devServerPort,
      proxy: {
        // Mock 데이터: /mock/api/** -> public/mock/** 정적 파일 제공
        '/mock/api': {
          target: `http://localhost:${devServerPort}`,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/mock\/api/, '/mock') + '.json'
        },
        // 실제 서버: /api/** -> 환경별 서버로 전달
        '/api': {
          target: apiBaseUrl,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api/, '/api')
        }
      }
    }
  }
})
