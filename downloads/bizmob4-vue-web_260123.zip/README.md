# 📊bizMOB4 Web base

bizMOB4 웹 기반 프로젝트입니다.

## 🔧 환경 설정

- **Framework**: Vue 3 (Composition API)
- **Build Tool**: Vite (https://vitejs.dev/)
- **State Management**: Pinia (`stores/`)
- **Code Quality**: ESLint, Prettier
- **UI Framework**: Material Pro Starter Kit (`\materialpro-vuetify-v6-1\packages\vue3\starterkit`)
      + Horizontal Layout 제거
      + RTL Layout 제거

## 📁 디렉토리 구조

```
public/             # 정적 파일 (빌드 시 그대로 복사)
├── mock/           # API 응답 모킹 데이터
src/                # 소스코드 메인 디렉토리
├── assets/         # 이미지, 스타일 등 정적 리소스
├── bizMOB/         # 비즈몹
│   └── BzClass/    # BizMOB 유틸리티 클래스 (암호화, 다국어, 토큰 등)
│   └── i18n/       # 다국어 처리 시스템
│   └── Xross/      # BizMOB 네이티브 API 래퍼 클래스들
│   └── bizmob.d.ts # BizMOB TypeScript 타입 정의
├── components/     # 공통 컴포넌트 (Card 등)
├── config/         # 앱 설정
│   └── index.ts    # 환경변수 및 상수
├── layouts/        # 페이지 레이아웃 (Sidebar, Header, Footer)
├── plugins/        # Vue 플러그인
├── router/         # Vue Router 설정
├── stores/         # Pinia 스토어 (상태 관리)
├── types/          # TypeScript 타입 정의
├── views/          # 실제 페이지 화면들 (Dashboard, Sample Pages)
index.html          # 메인 HTML 템플릿
main.ts             # Vue 초기화 및 플러그인 등록
tsconfig.json       # TypeScript 컴파일러 설정 (전체 프로젝트)
tsconfig.app.json   # 앱 소스코드용 TypeScript 설정
tsconfig.node.json  # Node.js 환경용 TypeScript 설정 (Vite 설정 등)
vite.config.ts      # Vite 빌드 도구 설정 (프록시, 플러그인, 빌드 옵션)
package.json        # npm 패키지 정보 및 스크립트 정의
package-lock.json   # npm 패키지 정확한 버전 잠금 파일
.gitignore          # Git 추적 제외 파일 목록
```


## 📘 MaterialPro Starter Kit 사용 가이드

### 1. Vue 파일 구분

- **layouts/** → 기본 레이아웃 (Header, Sidebar, Footer 포함)
- **views/** → 실제 페이지 단위 화면 (Dashboard, Sample Page, 게시판 등) - 라우터에서 직접 매핑되는 페이지 단위 컴포넌트
- **components/** → 특정 페이지에서만 쓰는 일반 컴포넌트 (Card, Table, Form 등)
- **components/shared/** →  프로젝트 전역에서 재사용 가능한 공통 UI 컴포넌트

### 2. MaterialPro 기본 사용법

- MaterialPro 전용 **레이아웃 / 컴포넌트**를 활용해 화면을 구성
- `Vuetify`의 **v-btn, v-table, v-form** 등 기본 컴포넌트와 혼합 사용

예시:
```vue
<template>
  <UiParentCard title="이벤트 게시판"> <!-- MaterialPro에서 제공하는 커스텀 카드 컴포넌트 -->
    <v-btn color="primary">등록하기</v-btn>
    <v-table>
      <!-- Vuetify 기본 컴포넌트 -->
    </v-table>
  </UiParentCard>
</template>
```

### 3. 화면 구조 잡기

  1) **레이아웃 선택**

  - layouts/ 폴더의 기본 레이아웃을 그대로 사용 (FullLayout.vue, BlankLayout.vue)
  - 사이드바, 헤더, 푸터는 공통 처리

  2) **뷰 생성**

  - views/board/EventBoardList.vue 파일 생성 (목록 페이지)

  3) **라우터에 새 route 등록**

  - router/AuthRoutes.ts에서 로그인하지 않은 사용자도 접근 가능한 페이지 등록 (인증 관련 : 로그인, 회원가입, 비밀번호 찾기)
  - router/MainRoutes.ts에서 로그인한 사용자만 접근 가능한 페이지 등록 (실제 비즈니스 로직 페이지)

예시:
  ```MainRoutes.ts
  const MainRoutes = {
    path: '/main',
    meta: {
      requiresAuth: true
    },
    redirect: '/main',
    component: () => import('@/layouts/full/FullLayout.vue'),  // 기본 레이아웃
    children: [
      {
        name: 'Starter',
        path: '/',        //  /main/
        component: () => import('@/views/DSH/DSH0000.vue')
      },
      {
        name: 'Event Board List',
        path: '/board',   //  /main/board
        component: () => import('@/views/board/EventBoardList.vue')
      }
    ]
  };

  export default MainRoutes;
  ```

  4) **sidebarItem.ts에 메뉴/서브메뉴 추가** - src/layouts/full/sidebar/sidebarItems.ts
  ```ts
  {
    title: 'Event Board List',
    icon: 'Event-board',
    to: '/main/board'       // 라우터 path 기준 full path
  }
  ```

## 🚀 빠른 시작

### 1. 설치

```bash
npm install
```

### 2. 라이브러리 빌드

```bash
# 전체 빌드
npm run build
# 생성된 dist 폴더를 웹 서버에 업로드
```

### 3. 코드 품질 검사

```bash
# 린트 검사
npm run lint

# 린트 자동 수정
npm run lint:fix
```

### 4. 개발 서버 실행

```bash
npm run dev
```
