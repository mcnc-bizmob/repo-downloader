<script setup lang="ts">
import { RouterView } from 'vue-router';
import Sidebar from './sidebar/Sidebar.vue';
import Header from './header/Header.vue';
import { useAppStore } from '../../stores/appStore';

const appStore = useAppStore();
</script>

<template>
  <!-- LTR LAYOUT -->
  <v-locale-provider>
    <v-app
      :theme="appStore.theme"
      :class="[
          appStore.theme,
          appStore.isMiniSidebar ? 'mini-sidebar' : '',
          appStore.isHorizontalLayout ? 'horizontalLayout' : 'verticalLayout',
          appStore.isBorderCard ? 'cardBordered' : '',
          appStore.isInputBg ? 'inputWithbg' : ''
      ]"
    >
      <Header />
      <Sidebar />

      <v-main>
        <v-container fluid class="page-wrapper pb-sm-15 pb-10">
          <div class="maxWidth">
            <RouterView />
          </div>
        </v-container>
      </v-main>
    </v-app>
  </v-locale-provider>
</template>
