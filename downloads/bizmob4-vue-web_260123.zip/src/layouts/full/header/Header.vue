<script setup lang="ts">
import { ref, watch, computed } from "vue";
import { useAppStore } from "../../../stores/appStore";
import ProfileDD from "./ProfileDD.vue";
const appStore = useAppStore();

const priority = ref(0);

watch(priority, (newPriority) => {
  priority.value = newPriority;
});
</script>

<template>
  <v-app-bar
    elevation="5"
    :priority="priority"
    height="60"
    color="primary"
    class="main-head"
    id="top"
  >
    <v-btn
      class="hidden-md-and-down custom-hover-primary menu-toggle"
      size="small"
      icon
      color="primary"
      variant="text"
      @click.stop="appStore.toggleMiniSidebar(!appStore.isMiniSidebar)"
    >
      <Icon icon="solar:list-bold" height="22" />
    </v-btn>
    <v-btn
      class="hidden-lg-and-up"
      icon
      variant="text"
      @click.stop="appStore.toggleSidebar"
      size="small"
    >
      <Icon icon="solar:list-bold" height="22" />
    </v-btn>

    <v-spacer class="" />
    <!-- ---------------------------------------------- -->
    <!-- User Profile -->
    <!-- ---------------------------------------------- -->
    <div class="ms -2">
      <ProfileDD />
    </div>

  </v-app-bar>
</template>
