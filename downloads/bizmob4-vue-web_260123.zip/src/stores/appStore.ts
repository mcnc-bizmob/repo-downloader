// stores/appStore.ts
import { defineStore } from 'pinia';

// Pinia 스토어 정의
export const useAppStore = defineStore('app', {
  state: () => {
    return {
      theme: 'BLUE_THEME',
      isHorizontalLayout: false,
      isMiniSidebar: false,
      isBorderCard: false,
      isInputBg: true,
      isSidebar: true
    };
  },

  getters: {},

  actions: {
    toggleSidebar() {
        this.isSidebar = !this.isSidebar;
    },
    toggleMiniSidebar(payload: boolean) {
      this.isMiniSidebar = payload;
    }
  }
});
