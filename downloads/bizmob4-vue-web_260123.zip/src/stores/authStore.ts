import { defineStore } from 'pinia';
import { router } from '@/router';
import { httpService } from '@/services/httpService';
import { validateApiResponse } from '@/shared/utils/apiResponse';
export const useAuthStore = defineStore('auth', {
  state: () => ({
    // initialize state from local storage to enable user to stay logged in
    // @ts-ignore
    user: JSON.parse(localStorage.getItem('user')),
    returnUrl: null
  }),
  getters: {
    isAuthenticated: (state) => !!state.user
  },
  actions: {
    /**
     * 사용자 로그인
     * @param id 사용자 ID
     * @param pwd 비밀번호
     * @returns 로그인 성공 시 사용자 정보, 실패 시 에러
     */
    async login(id: string, pwd: string) {
      // 로그인 API 호출
      const response = await httpService.post({
        url: '/mock/api/login',
        body: { userId: id, password: pwd }
      });

      // API 응답 검증 (실패 시 자동으로 alert 표시)
      const validation = validateApiResponse(response);

      if (validation.result) {
        // 사용자 정보 저장
        this.user = validation.data;
        localStorage.setItem('user', JSON.stringify(validation.data));

        return { result: true, data: validation.data };
      } else {
        // 로그인 실패 시 에러 던지기
        throw new Error(validation.errorMessage);
      }
    },
    async signup(payload: { name: string; email: string; password: string }) {
      const response = await httpService.post({
        url: '/mock/api/signup',
        body: payload
      });

      const validation = validateApiResponse(response);

      if (validation.result) {
        this.user = validation.data;
        localStorage.setItem('user', JSON.stringify(validation.data));
        return { result: true, data: validation.data };
      } else {
        throw new Error(validation.errorMessage);
      }
    },
    logout() {
      this.user = null;
      localStorage.removeItem('user');
      router.push('/');
    }
  }
});
