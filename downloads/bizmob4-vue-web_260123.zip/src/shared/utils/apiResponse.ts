/**
 * API 응답 검증 결과
 */
interface ApiValidationResult {
  result: boolean;       // 성공 여부
  errorMessage: string;  // 에러 메시지
  errorCode: string;     // 에러 코드
  data: any;            // 응답 데이터
}

/**
 * API 응답 검증 옵션
 */
interface ValidationOptions {
  showAlert?: boolean;   // 에러 시 Alert 표시 여부 (기본값: true)
}

/**
 * 에러 Alert 표시
 * @param message 에러 메시지
 */
const showErrorAlert = (message: string) => {
  window.alert(message);
};

/**
 * API 응답 검증 함수
 * HTTP 상태코드와 비즈니스 로직 성공 여부를 모두 확인
 * @param response HTTP 응답 객체
 * @param options 검증 옵션 (showAlert: 에러 시 Alert 표시 여부)
 * @returns 검증 결과 객체
 */
export const validateApiResponse = (response: HttpRes, options: ValidationOptions = { showAlert: true }): ApiValidationResult => {
  // HTTP 상태코드와 비즈니스 로직 성공 여부 확인
  const isSuccess = response.ok && response.data?.result === true;
  const errorMessage = response.data?.resultMessage || 'Unknown error';
  const errorCode = response.data?.resultCode || '';
  
  // 실패 시 Alert 표시 (옵션에 따라)
  if (!isSuccess && options.showAlert) {
    showErrorAlert(errorMessage);
  }
  
  return {
    result: isSuccess,
    errorMessage,
    errorCode,
    data: response.data?.body || null
  };
};