// types/type.d.ts
// 프로젝트 전역에서 자동으로 사용할 수 있는 공통 타입 정의

/**
 * JSON 값을 나타내는 타입
 * - 문자열, 숫자, 불린, null, 배열, 객체를 포함
 * - 전역에서 import 없이 사용 가능
 */
declare type Json = { [key: string]: any };

/**
 * 객체의 키 타입 (문자열, 숫자, 심볼)
 * - 전역에서 import 없이 사용 가능
 */
declare type ObjectKey = string | number | symbol;

/**
 * 빈 객체 타입
 * - 전역에서 import 없이 사용 가능
 */
declare type EmptyObject = Record<string, never>;

/**
 * 옵셔널 콜백 함수 타입
 * - 전역에서 import 없이 사용 가능
 */
declare type OptionalCallback<T = void> = ((value: T) => void) | undefined;

/**
 * HTTP 요청 타입
 * - API 통신에 사용되는 기본 요청 구조
 * - 전역에서 import 없이 사용 가능
 */
declare type HttpReq<T = any> = {
  isLoading?: boolean;
  url: string;
  httpHeader?: Record<string, any>
  timeout?: number
  retries?: number
  param?: { [x: string]: string }
  body?: T
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH',
  /**
   * Mock data (json file name) for testing.
   */
  mockJson?: string
  /**
   * Error message mapping with respose code.
   */
  errorMessage?: ErrorMessage
  fileList?: any[]
}

/**
 * 에러 메시지 타입
 * - API 응답 코드와 연결된 에러 메시지 매핑
 * - 전역에서 import 없이 사용 가능
 */
declare type ErrorMessage = { [x: string]: ErrorMessageParam } | boolean | [string | string[], ErrorMessageParam][]

/**
 * 에러 메시지 파라미터 타입
 * - 에러 메시지의 상세 정보 구조
 * - 전역에서 import 없이 사용 가능
 */
declare type ErrorMessageParam = string | {
  title?: string
  msg: string
  buttonText?: string
}

/**
 * GET 요청 타입
 * - GET 메서드용 HTTP 요청 타입 (method, body, fileList 제외)
 * - 전역에서 import 없이 사용 가능
 */
declare type GetReq = Omit<HttpReq, 'method' | 'body' | 'fileList'>;

/**
 * Body가 포함된 요청 타입 (POST, PUT, PATCH, DELETE)
 * - method를 제외한 모든 HTTP 요청 필드 포함
 * - 전역에서 import 없이 사용 가능
 */
declare type BodyReq<T = any> = Omit<HttpReq<T>, 'method'>;

/**
 * POST 요청 타입 (기존 호환성 유지)
 * - BodyReq의 별칭
 * - 전역에서 import 없이 사용 가능
 */
declare type PostReq<T = any> = BodyReq<T>;

/**
 * PUT 요청 타입
 * - PUT 메서드용 HTTP 요청 타입 (method 제외)
 * - 전역에서 import 없이 사용 가능
 */
declare type PutReq<T = any> = BodyReq<T>;

/**
 * PATCH 요청 타입
 * - PATCH 메서드용 HTTP 요청 타입 (method 제외)
 * - 전역에서 import 없이 사용 가능
 */
declare type PatchReq<T = any> = BodyReq<T>;

/**
 * DELETE 요청 타입
 * - DELETE 메서드용 HTTP 요청 타입 (method 제외)
 * - 전역에서 import 없이 사용 가능
 */
declare type DeleteReq<T = any> = BodyReq<T>;

/**
 * HTTP 응답 타입
 * - API 통신에 사용되는 기본 응답 구조
 * - data는 제네릭으로 처리하여 프로젝트별/API별로 유연하게 사용
 * - 전역에서 import 없이 사용 가능
 */
declare type HttpRes<T = any> = {
  ok: boolean;
  status: number;
  statusText: string;
  data: T;
};

/**
 * 기본 HTTP 응답 타입 (제네릭 없이 사용 가능)
 * - 전역에서 import 없이 사용 가능
 */
declare type ApiHttpRes = HttpRes<Json>;

/**
 * vue3-apexcharts 모듈 타입 선언
 */
declare module 'vue3-apexcharts' {
  import { DefineComponent } from 'vue';
  const VueApexCharts: DefineComponent<any, any, any>;
  export default VueApexCharts;
}
