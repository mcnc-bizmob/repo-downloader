<script setup lang="ts">
import { ref } from 'vue';
import { httpService } from '@/services/httpService';

import BaseBreadcrumb from '@/components/shared/BaseBreadcrumb.vue';
import UiParentCard from '@/components/shared/UiParentCard.vue';

const page = ref({ title: 'Sample Page' });

// 헬스 체크
function checkHealth() {
  httpService.get({ url: '/v1/health' })
    .then(res => {
      //console.log('성공:', res);
    })
    .catch(err => {
      //console.error('실패:', err);
    });
}
</script>

<template>
  <BaseBreadcrumb :title="page.title"></BaseBreadcrumb>
  <v-row>
    <v-col cols="12" md="12">
      <UiParentCard title="헬스 체크" @click="checkHealth()"> GET</UiParentCard>
    </v-col>
  </v-row>
</template>