<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/authStore';
import { Form } from 'vee-validate';

import Logo from '@/components/shared/Logo.vue';

/*Social icons*/
import google from '@/assets/images/svgs/google-icon.svg';
import facebook from '@/assets/images/svgs/facebook-icon.svg';

const router = useRouter();
const checkbox = ref(false);
const valid = ref(false);
const show1 = ref(false);
const password = ref('admin123');
const username = ref('gdhong@mcnc.co.kr');
const passwordRules = ref([
  (v: string) => !!v || 'Password is required',
  (v: string) => (v && v.length <= 10) || 'Password must be less than 10 characters'
]);
const emailRules = ref([(v: string) => !!v || 'E-mail is required', (v: string) => /.+@.+\..+/.test(v) || 'E-mail must be valid']);

async function validate(values: any, { setErrors }: any) {
  const authStore = useAuthStore();
  try {
    await authStore.login(username.value, password.value);
    // 로그인 성공 시 대시보드로 이동
    router.push('/dashboard');
  } catch (error: any) {
    setErrors({ apiError: error.message });
  }
}
</script>

<template>
  <div class="pa-3">
    <v-row class="h-100vh mh-100 auth">
      <v-col cols="12" lg="5" xl="4" class="d-flex align-center justify-center bg-surface">
        <div class="mt-xl-0 mt-5 mw-100">
          <div class="auth-header pa-6">
            <div class="position-relative">
              <Logo />
            </div>
          </div>
          <h2 class="text-h3 font-weight-semibold mb-2">bizMOB4-web-base</h2>
          <div class="text-subtitle-1 mb-6">Your Admin Dashboard</div>
          <v-row class="d-flex mb-3">
            <v-col cols="6" sm="6" class="pr-2">
              <v-btn variant="outlined" size="large" class="border text-subtitle-1" block>
                <img :src="google" height="16" class="mr-2" alt="google" />
                <span class="d-sm-flex d-none mr-1">Sign in with</span>Google
              </v-btn>
            </v-col>
            <v-col cols="6" sm="6" class="pl-2">
              <v-btn variant="outlined" size="large" class="border text-subtitle-1" block>
                <img :src="facebook" width="25" height="25" class="mr-1" alt="facebook" />
                <span class="d-sm-flex d-none mr-1">Sign in with</span>FB
              </v-btn>
            </v-col>
          </v-row>
          <div class="d-flex align-center text-center mb-6">
            <div class="text-h6 w-100 px-5 font-weight-regular auth-divider position-relative">
              <span class="bg-surface px-5 py-3 position-relative">or sign in with</span>
            </div>
          </div>
          <Form @submit="validate" v-slot="{ errors, isSubmitting }" class="mt-5">
            <v-label class="text-subtitle-1 font-weight-semibold pb-2 text-lightText">Username</v-label>
            <VTextField v-model="username" :rules="emailRules" class="mb-8" required hide-details="auto"></VTextField>
            <v-label class="text-subtitle-1 font-weight-semibold pb-2 text-lightText">Password</v-label>
            <VTextField v-model="password" :rules="passwordRules" required hide-details="auto" type="password"
              class="pwdInput"></VTextField>
            <div class="d-flex flex-wrap align-center my-3 ml-n2">
              <v-checkbox v-model="checkbox" :rules="[(v: any) => !!v || 'You must agree to continue!']" required
                hide-details color="primary">
                <template v-slot:label class="">Remeber this Device</template>
              </v-checkbox>
              <div class="ml-sm-auto">
                <RouterLink to="" class="text-primary text-decoration-none text-body-1 opacity-1 font-weight-medium">
                  Forgot Password ?
                </RouterLink>
              </div>
            </div>
            <v-btn size="large" :loading="isSubmitting" color="primary" :disabled="valid" block type="submit" flat>Sign
              In</v-btn>
            <div v-if="errors.apiError" class="mt-2">
              <v-alert color="error">{{ errors.apiError }}</v-alert>
            </div>
          </Form>
          <h6 class="text-h6  text-medium-emphasis  d-flex align-center mt-6 font-weight-medium">
            New to MaterialPro?
            <v-btn class="pl-0 text-primary text-body-1 opacity-1 pl-2 font-weight-medium" height="auto"
              to="/login/register" variant="plain">Create an account</v-btn>
          </h6>
        </div>
      </v-col>
      <v-col cols="12" lg="7" xl="8" class="d-lg-flex align-center justify-center authentication position-relative">
        <div class="">
          <img src="@/assets/images/backgrounds/@login-bg.png" class="position-relative d-none d-lg-flex"
            alt="login-background" />
        </div>
      </v-col>
    </v-row>
  </div>
</template>