<script setup lang="ts">
import { ref } from 'vue';
import { useAuthStore } from '@/stores/authStore';

import Logo from '@/components/shared/Logo.vue';

/*Social icons*/
import google from '@/assets/images/svgs/google-icon.svg';
import facebook from '@/assets/images/svgs/facebook-icon.svg';

const authStore = useAuthStore();

const checkbox = ref(false);
const valid = ref(true);
const show1 = ref(false);
const password = ref('');
const email = ref('');
const fname = ref('');

const fnameRules = ref([
  (v: string) => !!v || 'Name is required',
  (v: string) => (v && v.length <= 10) || 'Name must be less than 10 characters'
]);
const emailRules = ref([(v: string) => !!v || 'E-mail is required', (v: string) => /.+@.+\..+/.test(v) || 'E-mail must be valid']);
const passwordRules = ref([
  (v: string) => !!v || 'Password is required',
  (v: string) => (v && v.length <= 10) || 'Password must be less than 10 characters'
]);

const handleSignup = async () => {
  try {
    await authStore.signup({
      name: fname.value,
      email: email.value,
      password: password.value
    });
  } catch (err) {
    console.error(err);
    alert('회원가입 중 오류 발생');
  }
};
</script>

<template>
  <div class="pa-3">
    <v-row class="h-100vh auth">
      <v-col cols="12" lg="5" xl="4" class="d-flex align-center justify-center bg-surface">
        <div class="mt-xl-0 mt-5 mw-100">
          <div class="auth-header pa-6">
            <div class="position-relative">
              <Logo />
            </div>
          </div>
          <h2 class="text-h3 textPrimary font-weight-semibold mb-2">Welcome to MaterialPro</h2>
          <div class="card-subtitle mb-6">Your Admin Dashboard</div>
          <v-row class="d-flex mb-6">
            <v-col cols="6" sm="6" class="pr-2">
              <v-btn variant="outlined" size="large" class="border text-subtitle-1" block>
                <img :src="google" height="20" class="mr-2" alt="google" />
                <span class="d-sm-flex d-none mr-1">Sign up with</span>Google
              </v-btn>
            </v-col>
            <v-col cols="6" sm="6" class="pl-2">
              <v-btn variant="outlined" size="large" class="border text-subtitle-1" block>
                <img :src="facebook" width="25" height="30" class="mr-1" alt="facebook" />
                <span class="d-sm-flex d-none mr-1">Sign up with</span>FB
              </v-btn>
            </v-col>
          </v-row>
          <div class="d-flex align-center text-center mb-6">
            <div class="text-h6 w-100 px-5 font-weight-regular auth-divider position-relative">
              <span class="bg-surface px-5 py-3 position-relative">or sign in with</span>
            </div>
          </div>
          <v-form ref="form" v-model="valid" lazy-validation action="/pages/boxedlogin" class="mt-5">
            <v-label class="text-subtitle-1 font-weight-medium pb-2">Name</v-label>
            <VTextField v-model="fname" :rules="fnameRules" required></VTextField>
            <v-label class="text-subtitle-1 font-weight-medium pb-2">Email Adddress</v-label>
            <VTextField v-model="email" :rules="emailRules" required></VTextField>
            <v-label class="text-subtitle-1 font-weight-medium pb-2">Password</v-label>
            <VTextField v-model="password" :counter="10" :rules="passwordRules" required variant="outlined"
              type="password" color="primary"></VTextField>
            <v-btn size="large" class="mt-2" color="primary" block flat @click.prevent="handleSignup">Sign Up</v-btn>
          </v-form>
          <h6 class="text-h6 text-medium-emphasis d-flex align-center mt-6">
            Already have an Account?
            <v-btn variant="plain" to="/login" class="text-primary text-body-1 opacity-1 pl-2">Sign In</v-btn>
          </h6>
        </div>
      </v-col>
      <v-col cols="12" lg="7" xl="8"
        class="d-none d-lg-flex align-center justify-center authentication position-relative">
        <div class="">
          <img src="@/assets/images/backgrounds/@login-bg.png" class="position-relative " alt="login-background" />
        </div>
      </v-col>
    </v-row>
  </div>
</template>