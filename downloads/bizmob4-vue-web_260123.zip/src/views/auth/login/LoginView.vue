<script setup lang="ts">
/* Login form */
import LoginFormCenter from '@/views/auth/components/LoginFormCenter.vue';
import LoginFormSide from '@/views/auth/components/LoginFormSide.vue';
</script>
<template>
  <LoginFormCenter />
</template>