<script setup lang="ts">
/* Login form */
import RegisterFormCenter from '@/views/auth/components/RegisterFormCenter.vue';
import RegisterFormSide from '@/views/auth/components/RegisterFormSide.vue';
</script>
<template>
  <RegisterFormCenter />
</template>