import axios, { type AxiosResponse } from 'axios';

// 공통 헤더 관리
let commonHeaders: Record<string, any> = {
  'Content-Type': 'application/json',
};

// Auth 토큰 설정 함수
export const setAuthToken = (token: string) => {
  if (token && token.trim()) {
    commonHeaders = {
      ...commonHeaders,
      'Authorization': `Bearer ${token}`,
    };
  }
};

// 공통 헤더 업데이트 함수
export const updateCommonHeaders = (headers: Record<string, any>) => {
  commonHeaders = {
    ...commonHeaders,
    ...headers,
  };
};

// 공통 헤더 초기화 함수
export const clearAuthToken = () => {
  const { Authorization, ...rest } = commonHeaders;
  commonHeaders = rest;
};

// 현재 Auth 토큰 상태 확인 함수
export const hasAuthToken = (): boolean => {
  return 'Authorization' in commonHeaders && !!commonHeaders.Authorization;
};

// 현재 공통 헤더 조회 함수 (디버깅용)
export const getCurrentHeaders = (): Record<string, any> => {
  return { ...commonHeaders };
};

// 공통 HTTP 요청 로직
const makeRequest = async (method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE', option: any): Promise<HttpRes> => {
  const finalHeaders = {
    ...commonHeaders,
    ...option.httpHeader,
  };

  try {
    const response: AxiosResponse = await axios({
      url: option.url,
      method: method,
      headers: finalHeaders,
      data: option.body,
      params: option.param,
      timeout: option.timeout,
    });

    // Axios 응답을 HttpRes 형태로 변환
    return {
      ok: response.status >= 200 && response.status < 300,
      status: response.status,
      statusText: response.statusText,
      data: response.data,
    } as HttpRes;
  } catch (error: any) {
    // 에러 응답도 HttpRes 형태로 변환
    if (error.response) {
      return {
        ok: false,
        status: error.response.status,
        statusText: error.response.statusText,
        data: error.response.data,
      } as HttpRes;
    }

    // 네트워크 에러 등의 경우
    return {
      ok: false,
      status: 0,
      statusText: error.message || 'Network Error',
      data: null,
    } as HttpRes;
  }
};

export const httpService = {
  /**
   * Get request
   */
  get: async (option: GetReq): Promise<HttpRes> => {
    return makeRequest('GET', option);
  },

  /**
   * Post request
   */
  post: async <T = any>(option: PostReq<T>): Promise<HttpRes> => {
    return makeRequest('POST', option);
  },

  /**
   * Put request
   */
  put: async <T = any>(option: PutReq<T>): Promise<HttpRes> => {
    return makeRequest('PUT', option);
  },

  /**
   * Patch request
   */
  patch: async <T = any>(option: PatchReq<T>): Promise<HttpRes> => {
    return makeRequest('PATCH', option);
  },

  /**
   * Delete request
   */
  delete: async <T = any>(option: DeleteReq<T>): Promise<HttpRes> => {
    return makeRequest('DELETE', option);
  },
};