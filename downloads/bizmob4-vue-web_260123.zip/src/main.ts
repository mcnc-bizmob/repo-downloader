import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import { router } from './router';
import { Icon } from '@iconify/vue';
import vuetify from './plugins/vuetify';
import '@/scss/style.scss';
import PerfectScrollbar from 'vue3-perfect-scrollbar';
import VueApexCharts from 'vue3-apexcharts';
import VueTablerIcons from 'vue-tabler-icons';
import 'vue3-carousel/dist/carousel.css';
import Maska from 'maska';


//LightBox
import VueEasyLightbox from 'vue-easy-lightbox';

//ScrollTop
import VueScrollTo from 'vue-scrollto';

const app = createApp(App);
app.use(router);
app.use(PerfectScrollbar);
app.use(createPinia());
app.use(VueTablerIcons);
app.use(Maska);
app.component('apexchart', VueApexCharts);
app.use(VueEasyLightbox);
app.use(VueScrollTo, {
  duration: 1000,
  easing: 'ease'
});
app.component('Icon', Icon);
app.use(vuetify).mount('#app');
