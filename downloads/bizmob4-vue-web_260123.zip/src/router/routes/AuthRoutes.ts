const AuthRoutes = {
  path: '/',
  component: () => import('@/layouts/blank/BlankLayout.vue'),
  meta: {
    requiresAuth: false
  },
  children: [
    {
      name: 'Login',
      path: 'login',
      component: () => import('@/views/auth/login/LoginView.vue')
    },
    {
      name: 'Register',
      path: 'login/register',
      component: () => import('@/views/auth/register/RegisterView.vue')
    }
  ]
};

export default AuthRoutes;
