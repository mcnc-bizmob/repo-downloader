<script setup>
const props = defineProps({
  title: String,
  breadcrumbs: Array,
  icon: String,
  text: String
});
</script>

<template>
  <div class="mt-3 mb-6">
    <div class="d-flex justify-space-between">
      <div class="d-flex py-0 align-center">
        <div>
          <h3 class="text-h5">{{ title }}</h3>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
.page-breadcrumb {
  .v-toolbar {
    background: transparent;
  }
}
</style>
