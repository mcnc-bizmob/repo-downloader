import CryptoJS from 'crypto-js';

/**
 * Pinia용 암호화 Storage 플러그인 (최적화)
 *
 * 핵심 기능:
 * - 환경변수로 암호화 여부 제어 (VITE_PINIA_ENCRYPTION_USE)
 * - AES 암호화/복호화
 * - JSON 안전 처리 ([object Object] 버그 방지)
 * - 암호화/평문 데이터 호환성 유지
 * - 개별 키 마이그레이션 (해당 키만 처리, 다른 storage 데이터 보호)
 */

// 암호화 관련 상수
const ENCRYPT_PREFIX = '__enc__';

/**
 * Storage 인터페이스 (pinia-plugin-persistedstate와 호환)
 */
interface StorageAdapter {
  getItem: (key: string) => string | null;
  setItem: (key: string, value: string) => void;
  removeItem: (key: string) => void;
}

/**
 * 안전한 JSON 직렬화
 */
const safeStringify = (data: any): string => {
  if (typeof data === 'string') return data;
  try {
    return JSON.stringify(data);
  } catch {
    return '{}';
  }
};

/**
 * 안전한 JSON 파싱
 */
const safeParse = (jsonString: string): any => {
  try {
    if (!jsonString || jsonString === 'null' || jsonString === 'undefined') {
      return null;
    }

    const parsed = JSON.parse(jsonString);

    // [object Object] 문제 감지 및 복구
    if (typeof parsed === 'object' && parsed !== null && parsed['0'] === '[' && parsed['1'] === 'o') {
      return {};
    }

    return parsed;
  } catch {
    return jsonString;
  }
};

/**
 * 복호화 함수
 */
const decryptData = (encryptedData: string, SECRET_KEY: string): string | null => {
  try {
    const decryptedData = CryptoJS.AES.decrypt(encryptedData, SECRET_KEY).toString(CryptoJS.enc.Utf8);
    return decryptedData || null;
  } catch {
    return null;
  }
};

/**
 * 단일 키 마이그레이션
 */
const migrateSingleKey = (
  storage: Storage,
  key: string,
  shouldEncrypt: boolean,
  secretKey: string,
  encryptFn: (data: string) => string
): string | null => {
  const data = storage.getItem(key);
  if (!data || !secretKey) return data;

  const isEncrypted = data.startsWith(ENCRYPT_PREFIX);
  if (isEncrypted === shouldEncrypt) return data;

  try {
    let converted: string;
    if (isEncrypted && !shouldEncrypt) {
      // 복호화
      const encrypted = data.replace(ENCRYPT_PREFIX, '');
      converted = decryptData(encrypted, secretKey) || '';
    } else {
      // 암호화
      converted = encryptFn(data);
    }

    storage.setItem(key, converted);
    return converted;
  } catch {
    return data;
  }
};

/**
 * 암호화 Storage 어댑터 생성 함수
 */
export const createCryptoStorage = (
  baseStorage: Storage,
  options: {
    encryptionKey?: string;
    useCrypto?: boolean;
  } = {}
): StorageAdapter => {
  const SECRET_KEY = options.encryptionKey ?? import.meta.env.VITE_PINIA_ENCRYPTION_KEY ?? '';
  const isCrypto = options.useCrypto ?? (SECRET_KEY && import.meta.env.VITE_PINIA_ENCRYPTION_USE === 'true');

  // 암호화 함수
  const encrypt = (data: string): string => {
    if (!isCrypto || !SECRET_KEY) return data;
    try {
      return ENCRYPT_PREFIX + CryptoJS.AES.encrypt(data, SECRET_KEY).toString();
    } catch (error) {
      console.error('Encryption failed:', error);
      return data;
    }
  };

  // 복호화 함수
  const decrypt = (data: string): string | null => {
    if (!data) return null;
    if (data.startsWith(ENCRYPT_PREFIX) && SECRET_KEY) {
      return decryptData(data.replace(ENCRYPT_PREFIX, ''), SECRET_KEY);
    }
    return data;
  };

  return {
    getItem: (key: string): string | null => {
      // 파이프라인: 마이그레이션 → 복호화 → JSON 처리
      const migrated = migrateSingleKey(baseStorage, key, isCrypto, SECRET_KEY, encrypt);
      if (!migrated) return null;

      const decrypted = decrypt(migrated);
      if (!decrypted) return null;

      try {
        return safeStringify(safeParse(decrypted));
      } catch (error) {
        console.error('JSON processing failed:', error);
        return null;
      }
    },

    setItem: (key: string, value: string): void => {
      const processed = safeStringify(value);
      baseStorage.setItem(key, encrypt(processed));
    },

    removeItem: (key: string): void => {
      baseStorage.removeItem(key);
    }
  };
};

/**
 * 암호화된 localStorage
 */
export const cryptoLocalStorage = createCryptoStorage(localStorage);

/**
 * 암호화된 sessionStorage
 */
export const cryptoSessionStorage = createCryptoStorage(sessionStorage);
