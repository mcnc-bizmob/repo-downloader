/** Ionic Vue 설정 및 초기화 */
import type { App, Plugin } from 'vue';
import { IonicVue, IonPage, IonHeader, IonContent, IonFooter, IonModal } from '@ionic/vue';

// 📌 Ionic CSS - 모듈 import 시점에 로드됨 (플러그인 등록과 무관)
// 이는 일반적인 방식으로, 대부분의 Vue 프로젝트에서 사용하는 패턴입니다.
import '@ionic/vue/css/core.css';
import '@ionic/vue/css/padding.css';
import '@ionic/vue/css/float-elements.css';
import '@ionic/vue/css/text-alignment.css';
import '@ionic/vue/css/text-transformation.css';
import '@ionic/vue/css/flex-utils.css';
import '@ionic/vue/css/display.css';
import '@ionic/vue/css/normalize.css';
import '@ionic/vue/css/structure.css';
import '@ionic/vue/css/typography.css';

/**
 * Ionic Vue 플러그인 정의
 * app.use(ionicPlugin) 형태로 사용 가능
 *
 * 💡 CSS vs JavaScript 로딩 시점:
 * - CSS: 모듈 import 시점에 즉시 로드 (위의 import 구문들)
 * - JavaScript: app.use() 호출 시점에 실행 (아래의 install 함수)
 */
export const ionicPlugin: Plugin = {
  install(app: App) {
    // Ionic Vue 플러그인 등록
    app.use(IonicVue, {
      swipeBackEnabled: false,
      innerHTMLTemplatesEnabled: true,
      mode: 'md', // Material Design 모드
    });

    // 전역 Ionic 컴포넌트 등록
    app
      .component('IonPage', IonPage)
      .component('IonHeader', IonHeader)
      .component('IonContent', IonContent)
      .component('IonFooter', IonFooter)
      .component('IonModal', IonModal);
  }
};
