/** bizMOB Initialize */
import type { App, Plugin } from 'vue';
import { Config } from '@bizMOB';

/**
 * bizMOB Vue 플러그인 정의
 * app.use(bizMOBPlugin) 형태로 사용 가능
 */
export const bizMOBPlugin: Plugin = {
  install(app: App) {
    // APP 환경 설정
    Config.setConfig('APP', 'App', {
      _bIsRelease: import.meta.env.MODE === 'production', // 릴리즈 여부
      _sAppKey: import.meta.env.VITE_APPLICATION_KEY, // App Key
    });

    // WEB APP 환경 설정
    Config.setConfig('WEB', 'App', {
      _bIsRelease: import.meta.env.MODE === 'production', // 릴리즈 여부
      _sAppKey: import.meta.env.VITE_APPLICATION_KEY, // App Key
    });

    // WEB 네트워크 설정
    Config.setConfig('WEB', 'Network', {
      _sBaseUrl: import.meta.env.BASE_URL, // Client Base url
      _sApiContext: import.meta.env.VITE_SERVER_CONTEXT, // 서버 Context
      _sProxContext: import.meta.env.VITE_PROXY_CONTEXT, // 프록시 Context
      _bIsProxy: import.meta.env.VITE_PROXY === 'on', // 프록시 사용 여부
      _bIsCrypto: import.meta.env.VITE_WEB_ENCRYPTION_USE === 'true', // 암호화 사용 여부
    });

    // 향후 Vue 앱에 bizMOB 관련 플러그인이나 설정이 필요한 경우
    // app.use(SomeBizMOBPlugin);
    // app.provide('bizMOB', someBizMOBInstance);
  }
};
