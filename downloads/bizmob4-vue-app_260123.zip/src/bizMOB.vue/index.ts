// src/bizMOB.vue/index.ts

// ========================================
// 통합 컴포저블 Export (유일한 공개 API)
// ========================================

export { useApp } from './composables/useApp';
export { i18n } from './composables/useApp.i18n';

// ========================================
// Stores Export
// ========================================

export { useLoadingStore } from './stores/useLoadingStore';
export { useAppStore } from './stores/useAppStore';

// ========================================
// Plugins Export
// ========================================

export { ionicPlugin } from './plugins/ionic.plugin';
export { bizMOBPlugin } from './plugins/bizmob.plugin';

// ========================================
// Storage Plugins Export
// ========================================

export { createCryptoStorage, cryptoLocalStorage, cryptoSessionStorage } from './plugins/crypto-storage.plugin';

// ========================================
// Types Export (향후 추가 예정)
// ========================================

// export type * from './types/navigation.d'
// export type * from './types/modal.d'
// export type * from './types/alert.d'
// export type * from './types/loading.d'
// export type * from './types/storage.d'

/**
 * @fileoverview bizMOB.vue 라이브러리 메인 Export 파일
 *
 * **통합 API 사용법:**
 *
 * ```typescript
 * // ===== 기본 사용법 =====
 * import { useApp } from '@bizMOB/vue';
 *
 * const { alert, toast, openMenu, openActionSheet } = useApp();
 *
 * // Alert 사용
 * await alert('저장되었습니다');
 * const confirmed = await alert('정말 삭제하시겠습니까?');
 *
 * // Toast 사용
 * await toast('파일 업로드 완료');
 * await toast({
 *   message: '에러가 발생했습니다',
 *   color: 'danger',
 *   duration: 3000
 * });
 *
 * // Menu 사용
 * await openMenu();
 * await toggleMenu('sidebar');
 *
 * // ActionSheet 사용
 * const result = await openActionSheet([
 *   { text: '편집', value: 'edit' },
 *   { text: '삭제', value: 'delete', role: 'destructive' },
 *   { text: '취소', role: 'cancel' }
 * ]);
 *
 *
 * // ===== Vue 컴포넌트에서 사용 =====
 * <script setup lang="ts">
 * import { useApp } from '@bizMOB/vue';
 *
 * const { alert, toast, openMenu, openActionSheet } = useApp();
 *
 * const handleSave = async () => {
 *   // 저장 로직...
 *   await toast('저장되었습니다');
 * };
 *
 * const handleDelete = async () => {
 *   const confirmed = await alert('정말 삭제하시겠습니까?');
 *   if (confirmed) {
 *     // 삭제 로직...
 *     await toast('삭제되었습니다');
 *   }
 * };
 *
 * const handleOptions = async () => {
 *   const result = await openActionSheet([
 *     { text: '편집', value: 'edit' },
 *     { text: '공유', value: 'share' },
 *     { text: '삭제', value: 'delete', role: 'destructive' }
 *   ]);
 *
 *   if (result.value === 'edit') {
 *     // 편집 로직
 *   } else if (result.value === 'share') {
 *     // 공유 로직
 *   } else if (result.value === 'delete') {
 *     // 삭제 로직
 *   }
 * };
 * </script>
 *
 * <template>
 *   <div>
 *     <ion-button @click="handleSave">저장</ion-button>
 *     <ion-button @click="handleDelete">삭제</ion-button>
 *     <ion-button @click="handleOptions">옵션</ion-button>
 *   </div>
 * </template>
 *
 *
 * // ===== 줄바꿈 지원 =====
 * const { alert, toast, openActionSheet } = useApp();
 *
 * // Alert에서 줄바꿈 사용
 * await alert('첫 번째 줄\n두 번째 줄');
 *
 * // Toast에서 줄바꿈 사용
 * await toast('업로드 중\n잠시 기다려주세요');
 *
 * // ActionSheet 버튼에서 줄바꿈 사용
 * await openActionSheet([
 *   { text: '상세 보기\n전체 정보', value: 'detail' },
 *   { text: '간단 보기\n요약만', value: 'summary' }
 * ]);
 * ```
 */
