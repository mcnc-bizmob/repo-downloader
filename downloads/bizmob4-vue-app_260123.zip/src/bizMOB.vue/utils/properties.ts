// stores/project/utils/properties.ts

import { Properties } from '@bizMOB';

/**
 * Properties 어댑터 - bizMOB Properties API와 localStorage 폴백 제공
 *
 * bizMOB.Properties 실제 사용법:
 * - get: bizMOB.Properties.get({ "_sKey": "name" })
 * - set: bizMOB.Properties.set({ "_sKey": "name", "_vValue": "bizMOB" })
 * - remove: bizMOB.Properties.remove({ "_sKey": "name" })
 */
export const propertiesAdapter = {
  getItem(key: string): string | null {
    try {
      // TypeScript Properties 클래스 사용 (bizMOB 환경) - string으로 저장/조회
      const value = Properties.get({ _sKey: key });
      return value || null;
    } catch {
      // 개발 환경 폴백: localStorage 사용
      try {
        const value = localStorage.getItem(`properties_${key}`);
        return value;
      } catch {
        return null;
      }
    }
  },

  setItem(key: string, value: string): void {
    try {
      // TypeScript Properties 클래스 사용 (bizMOB 환경) - string으로 저장
      Properties.set({ _sKey: key, _vValue: value });
    } catch {
      // 개발 환경 폴백: localStorage 사용
      localStorage.setItem(`properties_${key}`, value);
    }
  },

  removeItem(key: string): void {
    try {
      // TypeScript Properties 클래스 사용 (bizMOB 환경)
      Properties.remove({ _sKey: key });
    } catch {
      // 개발 환경 폴백: localStorage 사용
      localStorage.removeItem(`properties_${key}`);
    }
  }
};
