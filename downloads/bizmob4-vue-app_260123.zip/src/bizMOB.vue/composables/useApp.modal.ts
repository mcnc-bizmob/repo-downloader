/**
 * @namespace useModal
 * @description
 * Ionic Modal 컴포저블 (Stack 기반 관리)
 *
 * **주요 기능:**
 * - Ionic modalController 활용한 Modal 표시/닫기
 * - willPresent/didDismiss 생명주기 기반 Stack 자동 관리
 * - 중첩 Modal 지원
 * - Bottom Modal 지원
 * - ion-modal 태그 사용 지원
 *
 * @returns {Object} Modal을 제어하는 API 객체
 * @property {function(component, options?, modalType?): Promise<ModalResult>} openModal Modal 열기
 * @property {function(result, data?): void} closeModal 현재 활성 Modal 닫기
 * @property {function(): ModalStackItem | null} getTopModal 최상단 Modal 반환 (backButton에서 사용)
 *
 * @remarks
 * Overlay focus 관리:
 * - ionicFocusManager.ts 파일에서 withModalFocus를 사용해서 단순 포커스 제거 (aria-hidden 경고 방지)
 *
 * @remarks
 * Stack 관리:
 * - willPresent에서 Stack 등록
 * - didDismiss에서 Stack 제거
 * - 중첩 Modal 지원 (후입선출 구조)
 *
 * @remarks
 * 백버튼 처리(./useApp.backButton.ts 에서 통합 관리):
 * - Modal Stack 정보를 backButton 컴포저블에 제공 (getTopModal)
 * - 백버튼 핸들러는 Modal Stack에서 관리 (ModalStackItem에 포함)
 * - 단방향 의존성: Modal → BackButton (Modal은 정보 제공만, BackButton이 핸들러 관리)
 *
 * @remarks
 * 백버튼 통합 패턴 (Popover에서도 동일 적용):
 * ```typescript
 * // 1. useApp.modal.ts (정보 제공자 역할)
 * interface ModalStackItem {
 *   element: HTMLIonModalElement;
 *   id: string;
 *   component?: any;
 *   createdAt: Date;
 *   // 백버튼 핸들러 정보 (Modal Stack에서 관리)
 *   hasBackHandler: boolean;
 *   backHandler?: () => boolean | void | Promise<boolean | void>;
 * }
 *
 * export function useModal() {
 *   return {
 *     // Modal 관리 기능
 *     openModal, closeModal, registerModal,
 *     // BackButton용 정보 제공 함수들
 *     getModalStack,  // 전체 Stack 정보 조회
 *     getTopModal     // 최상단 Modal 조회 (현재 활성 Modal)
 *   };
 * }
 *
 * // 2. useApp.backButton.ts (백버튼 처리자 역할)
 * export function onModalBack(handler: BackButtonHandler): void {
 *   const topModal = getTopModal();
 *   if (topModal) {
 *     // Modal Stack Item에 직접 핸들러 저장
 *     topModal.hasBackHandler = true;
 *     topModal.backHandler = handler;
 *
 *     onUnmounted(() => {
 *       topModal.hasBackHandler = false;
 *       topModal.backHandler = undefined;
 *     });
 *   }
 * }
 *
 * // 10단계 백버튼 처리에서 호출
 * async function executeModalCustomBackHandler(): Promise<boolean | null> {
 *   const topModal = getTopModal();
 *   if (!topModal || !topModal.hasBackHandler || !topModal.backHandler) {
 *     return null;
 *   }
 *   const result = await topModal.backHandler();
 *   return result !== false;
 * }
 *
 * // 3. useApp.ts (통합 API 제공)
 * export function useApp() {
 *   return {
 *     openModal, closeModal,
 *     onModalBack,  // ← Modal 내부에서 사용
 *   };
 * }
 *
 * // 4. Modal 내부 컴포넌트에서 사용
 * const { onModalBack, confirm } = useApp();
 * onMounted(() => {
 *   onModalBack(async () => {
 *     if (isChanged) {
 *       const confirmed = await confirm('저장하지 않고 나가시겠습니까?');
 *       return confirmed;
 *     }
 *     return true;
 *   });
 * });
 * ```
 *
 * @example
 * <caption><b>Modal 내부에서 백버튼 핸들러 사용법 (onModalBack - 추가 예시)</b></caption>
 * ```typescript
 * // 복잡한 검증이 필요한 Modal
 * const { onModalBack, confirm, alert } = useApp();
 *
 * onMounted(() => {
 *   onModalBack(async () => {
 *     // 1. 필수 입력값 체크
 *     if (!form.value.name || !form.value.email) {
 *       await alert('필수 입력값을 채워주세요.');
 *       return false; // Modal 유지
 *     }
 *
 *     // 2. 저장되지 않은 변경사항 체크
 *     if (hasUnsavedChanges()) {
 *       const result = await confirm({
 *         title: '확인',
 *         message: '저장하지 않은 변경사항이 있습니다.',
 *         buttons: [
 *           { text: '취소', role: 'cancel' },
 *           { text: '저장하고 나가기', handler: () => 'save' },
 *           { text: '저장 안하고 나가기', handler: () => 'discard' }
 *         ]
 *       });
 *
 *       if (result === 'save') {
 *         await saveData();
 *         return true;
 *       } else if (result === 'discard') {
 *         return true;
 *       } else {
 *         return false; // 취소
 *       }
 *     }
 *
 *     return true; // 변경사항 없으면 바로 닫기
 *   });
 * });
 * ```
 *
 * @example
 * <caption><b>openModal/closeModal 사용법</b></caption>
 * ```typescript
 * import { useApp } from '@bizMOB/vue';
 *
 * const { openModal, closeModal } = useApp();
 *
 * // 모달 열기 (Default 옵션)
 * // showBackdrop: true
 * // backdropDismiss: true
 * // enableHandleClick: true
 * // cssClass: []
 * // modalType: 'modal' (기본값, 3번째 파라미터에서 설정)
 *
 * // 모달 타입(modalType)이 sheet인 경우 추가 Default 옵션
 * // initialBreakpoint: 1
 * // breakpoints: [0, 1]
 * // showHandle: true
 *
 * // modal 열기 (기본 타입 - 'modal')
 * const result = await openModal(MyComponent, {
 *   props: { data: myData },
 *   cssClass: ['full-size'],
 *   showBackdrop: true,
 *   backdropDismiss: true
 * });
 *
 * // sheet modal 열기 (3번째 파라미터로 modalType 지정)
 * const result = await openModal(MyComponent, {
 *   props: { data: myData },
 *   cssClass: ['full-size'],
 *   initialBreakpoint: 0.8,
 *   breakpoints: [0, 0.5, 0.8, 1],
 *   showHandle: true
 * }, 'sheet');
 *
 * if (result.result) {
 *   console.log('성공:', result.data);
 * }
 *
 * // modal 닫기
 * closeModal(true, { foo: 'bar' });
 * ```
 */

import { modalController, type ModalOptions as IonicModalOptions } from '@ionic/vue';
import { ref, type Ref } from 'vue';
import { withModalFocus } from '../utils/ionicFocusManager';

// ========================================
// 타입 정의
// ========================================

/**
 * Modal Stack 항목 인터페이스
 */
interface ModalStackItem {
  element: HTMLIonModalElement;
  id: string;
  component?: any;
  createdAt: Date;
  // 백버튼 핸들러 정보 (Modal Stack에서 관리)
  hasBackHandler: boolean;
  backHandler?: () => boolean | void | Promise<boolean | void>;
}

/**
 * Modal 옵션 설정 인터페이스 (Ionic Modal 옵션만)
 */
interface ModalOptionsConfig {
  props?: Record<string, any>;
  cssClass?: string | string[];
  showBackdrop?: boolean;
  backdropDismiss?: boolean;
  enableHandleClick?: boolean;
  animated?: boolean;
  // Sheet Modal 전용 옵션
  initialBreakpoint?: number;
  breakpoints?: number[];
  showHandle?: boolean;
  handle?: boolean;
}

/**
 * Modal 타입 정의
 */
type ModalType = 'modal' | 'sheet';

/**
 * Modal 결과 인터페이스
 */
interface ModalResult {
  result: boolean;
  data?: any;
}

// ========================================
// 상태 관리
// ========================================

/**
 * Modal Stack (후입선출 구조)
 */
const modalStack: Ref<ModalStackItem[]> = ref<ModalStackItem[]>([]);

/**
 * 고유 ID 생성기
 */
let modalIdCounter = 0;
function generateModalId(): string {
  return `modal-${++modalIdCounter}-${Date.now()}`;
}

// ========================================
// Stack 관리 함수들
// ========================================

/**
 * Stack에 Modal 추가
 */
function addToStack(modal: HTMLIonModalElement, component?: any): void {
  const stackItem: ModalStackItem = {
    element: modal,
    id: generateModalId(),
    component,
    createdAt: new Date(),
    hasBackHandler: false,
    backHandler: undefined
  };

  modalStack.value.push(stackItem);
}

/**
 * Stack에서 Modal 제거
 */
function removeFromStack(modal: HTMLIonModalElement): void {
  const index = modalStack.value.findIndex(item => item.element === modal);
  if (index > -1) {
    modalStack.value.splice(index, 1);
  }
}

/**
 * 최상단 Modal 반환 (현재 활성 Modal)
 */
function getTopModal(): ModalStackItem | null {
  return modalStack.value.length > 0
    ? modalStack.value[modalStack.value.length - 1]
    : null;
}

// ========================================
// 옵션 처리 함수들
// ========================================

/**
 * Modal 타입별 기본 설정 적용
 */
function applyModalTypeDefaults(options: ModalOptionsConfig, modalType: ModalType): ModalOptionsConfig {
  const baseOptions = {
    showBackdrop: true,
    backdropDismiss: true,
    enableHandleClick: true,
    animated: true,
    cssClass: [],
    ...options
  };

  // Sheet Modal인 경우 추가 기본값 적용
  if (modalType === 'sheet') {
    return {
      ...baseOptions,
      initialBreakpoint: options.initialBreakpoint ?? 1,
      breakpoints: options.breakpoints ?? [0, 1],
      showHandle: options.showHandle ?? true,
      handle: options.handle ?? true
    };
  }

  return baseOptions;
}

/**
 * Ionic Modal 설정 객체 생성
 */
function createIonicModalConfig(
  component: any,
  options: ModalOptionsConfig,
  modalType: ModalType
): IonicModalOptions {
  const config: IonicModalOptions = {
    component,
    animated: options.animated,
    showBackdrop: options.showBackdrop,
    backdropDismiss: options.backdropDismiss
  };

  // 컴포넌트 Props 설정
  if (options.props) {
    config.componentProps = options.props;
  }

  // CSS 클래스 설정
  if (options.cssClass) {
    if (Array.isArray(options.cssClass)) {
      config.cssClass = options.cssClass.join(' ');
    } else {
      config.cssClass = options.cssClass;
    }
  }

  // Sheet Modal 전용 설정
  if (modalType === 'sheet') {
    config.initialBreakpoint = options.initialBreakpoint;
    config.breakpoints = options.breakpoints;
    config.showBackdrop = options.showBackdrop ?? false; // Sheet는 기본적으로 backdrop 없음
    config.handle = options.handle ?? options.showHandle;
  }

  return config;
}

// ========================================
// 메인 컴포저블 함수
// ========================================

export function useModal() {
  /**
   * Modal 열기
   * @param component Vue 컴포넌트
   * @param options Modal 옵션 (Ionic Modal 옵션)
   * @param modalType Modal 타입 ('modal' | 'sheet', 기본값: 'modal')
   * @returns Promise<ModalResult> Modal 결과
   */
  async function openModal(
    component: any,
    options: ModalOptionsConfig = {},
    modalType: ModalType = 'modal'
  ): Promise<ModalResult> {
    try {
      // 옵션에 기본값 적용
      const finalOptions = applyModalTypeDefaults(options, modalType);

      // Ionic Modal 설정 생성
      const modalConfig = createIonicModalConfig(component, finalOptions, modalType);

      // Modal 생성 (단순 포커스 제거만)
      const modal = await withModalFocus(
        modalController.create(modalConfig),
        { debug: false }
      );

      // Stack 등록
      addToStack(modal, component);
      // Modal 표시
      await modal.present();

      // 사용자 응답 대기
      const { role, data } = await modal.onDidDismiss().then((msg) => {
        removeFromStack(modal);
        return msg;
      });

      // 결과 처리
      return {
        result: role !== 'backdrop' && role !== null,
        data
      };

    } catch (error) {
      console.error('[useModal] Modal 열기 실패:', error);
      return { result: false };
    }
  }

  /**
   * 현재 활성 Modal 닫기
   * @param result 결과값 (기본값: true)
   * @param data 전달할 데이터
   */
  function closeModal(result: boolean = true, data?: any): void {
    const topModal = getTopModal();

    if (!topModal) {
      console.warn('[useModal] 닫을 Modal이 없습니다.');
      return;
    }

    try {
      topModal.element.dismiss(data, result ? 'confirm' : 'cancel');
    } catch (error) {
      console.error('[useModal] Modal 닫기 실패:', error);
    }
  }

  return {
    // Modal 관리 기능
    openModal,
    closeModal,

    // BackButton용 정보 제공 함수
    getTopModal
  };
}
