/**
 * @fileoverview useApp.backButton.ts - 통합 백버튼 처리 시스템
 * @author bizMOB Development Team
 * @version 1.0.0
 * @since 2025-01-27
 * @module useBackButton
 *
 * @namespace useBackButton
 * @description
 * Vue Router Guard 기반의 통합 백버튼 처리 시스템
 *
 * **주요 기능:**
 * @feature {Router} Vue Router Guard - Vue Router beforeEach guard 기반의 백버튼 처리
 * @feature {Chain} 9단계 처리 체인 - Overlay(8단계) + Page(1단계) 백버튼 처리 체인
 * @feature {Stack} 핸들러 관리 - Stack 기반 핸들러 관리 (Modal/Popover Stack 연동)
 * @feature {Lifecycle} 자동 생명주기 - 자동 생명주기 관리 (Vue 생명주기 연동)
 * @feature {Component} 독립적 핸들러 - Component별 독립적 핸들러 등록 시스템
 * @feature {Browser} 브라우저 백버튼 - 브라우저 뒤로가기 완벽 지원 (모바일 웹)
 * @feature {History} History API - History pop state 감지 및 처리
 *
 * **9단계 백버튼 처리 체인:**
 * @chain {Step1} Loading 체크 - Loading 상태일 때 백버튼 차단
 * @chain {Step2} Alert 체크 - Alert 표시 중일 때 preventBackButton 확인
 * @chain {Step3} ActionSheet 체크 - ActionSheet 표시 중일 때 preventBackButton 확인
 * @chain {Step4} Popover 커스텀 핸들러 - Popover 컴포넌트별 사용자 정의 처리
 * @chain {Step5} Popover 기본 닫기 - Popover Stack에서 최상위 Popover 닫기
 * @chain {Step6} Modal 커스텀 핸들러 - Modal 컴포넌트별 사용자 정의 처리
 * @chain {Step7} Modal 기본 닫기 - Modal Stack에서 최상위 Modal 닫기
 * @chain {Step8} Menu 닫기 - 열린 Menu가 있으면 닫기
 * @chain {Step9} Page 커스텀 핸들러 - Page 컴포넌트별 사용자 정의 처리 후 기본 네비게이션
 * ```
 * 1. Loading 체크 → 2. Alert 체크 (preventBackButton) → 3. ActionSheet 체크 (preventBackButton)
 * → 4. Popover 커스텀 핸들러 → 5. Popover 기본 닫기 → 6. Modal 커스텀 핸들러
 * → 7. Modal 기본 닫기 → 8. Menu 닫기 → 9. Page 커스텀 핸들러 + 기본 네비게이션
 * ```
 *
 * **API 구조:**
 * @interface UseBackButtonReturn
 * @returns {object} useBackButton composable 반환 객체
 * ```typescript
 * export function useBackButton() {
 *   return {
 *     // 핸들러 등록 API (3개)
 *     onPageBack,    // @method Page 백버튼 핸들러 등록 (route 기반)
 *     onModalBack,   // @method Modal 백버튼 핸들러 등록 (Stack Item에 저장)
 *     onPopoverBack, // @method Popover 백버튼 핸들러 등록 (Stack Item에 저장)
 *
 *     // 핸들러 관리 API (2개)
 *     offBack,       // @method 핸들러 수동 해제
 *     clearAllBack,  // @method 핸들러 일괄 초기화
 *   };
 * }
 * ```
 *
 * **구현 방식:**
 * @implementation {RouterGuard} Vue Router beforeEach guard를 통한 뒤로가기 인터셉트
 * @implementation {HistoryAPI} History API의 pop state 감지로 브라우저 뒤로가기 구분
 * @implementation {OverlayCheck} Ionic Controller를 통한 활성 Overlay 컴포넌트 체크
 * @implementation {HandlerChain} 우선순위별 핸들러 체인 실행 (Overlay → Page)
 * @implementation {AutoCleanup} 핸들러 처리 후 자동 정리 및 네비게이션 재실행
 *
 * **Stack 기반 핸들러 관리 패턴:**
 * @pattern {Stack} Modal/Popover 핸들러는 각각의 Stack Item에 직접 저장
 * @pattern {Dependency} 단방향 의존성: Modal/Popover → BackButton (정보 제공만)
 * @pattern {Query} BackButton에서 getTopModal(), getTopPopover()로 현재 활성 Overlay 조회
 * @pattern {Management} Stack Item의 hasBackHandler, backHandler 필드로 핸들러 관리
 *
 * **자동 생명주기 관리:**
 * @lifecycle {Modal} Modal/Popover: 핸들러가 true 반환시 자동 해제
 * @lifecycle {Page} Page: 핸들러 실행 후 자동 해제 (일회성 처리)
 * @lifecycle {Auto} 개발자는 핸들러 함수만 전달하면 자동으로 생명주기 처리
 *
 * @example Page 컴포넌트에서 앱 종료 처리 사용법
 * ```typescript
 * // 루트 페이지에서 백버튼 시 앱 종료 처리
 * import { useApp } from '@bizMOB/vue';
 * import { App } from '@bizMOB';
 * import { onIonViewWillEnter } from '@ionic/vue';
 *
 * const { onPageBack } = useApp();
 *
 * onIonViewWillEnter(() => {
 *   onPageBack(async () => {
 *     const confirmed = await confirm('앱을 종료하시겠습니까?');
 *     if (confirmed) {
 *       await App.exit({ _sType: 'kill' });
 *     }
 *     return false; // 항상 기본 처리 차단 (앱 종료 또는 취소)
 *   });
 * });
 * ```
 *
 * @example Page 컴포넌트에서 일반 저장 확인 사용법
 * ```typescript
 * // 일반 페이지에서 저장 확인 후 뒤로가기
 * import { useApp } from '@bizMOB/vue';
 * import { onIonViewWillEnter } from '@ionic/vue';
 *
 * const { onPageBack } = useApp();
 *
 * onIonViewWillEnter(() => {
 *   onPageBack(async () => {
 *     if (hasUnsavedChanges) {
 *       const confirmed = await confirm('저장하지 않고 나가시겠습니까?');
 *       return confirmed; // boolean 값 직접 반환
 *     }
 *     return true; // 변경사항 없으면 기본 처리 진행
 *   });
 * });
 * ```
 * @example Modal 컴포넌트에서 사용법
 * ```typescript
 * // Modal 컴포넌트에서 백버튼 처리
 * import { useApp } from '@bizMOB/vue';
 * import { onMounted } from 'vue';
 *
 * const { onModalBack } = useApp();
 *
 * onMounted(() => {
 *   onModalBack(async () => {
 *     if (isFormDirty) {
 *       const confirmed = await confirm('변경사항을 저장하지 않고 닫으시겠습니까?');
 *       return confirmed; // 확인 결과를 직접 반환
 *     }
 *     return true; // 변경사항 없으면 기본 처리 진행
 *   });
 * });
 * ```
 *
 * @example Popover 컴포넌트에서 사용법
 * ```typescript
 * // Popover 컴포넌트에서 백버튼 처리
 * import { useApp } from '@bizMOB/vue';
 * import { onMounted } from 'vue';
 *
 * const { onPopoverBack } = useApp();
 *
 * onMounted(() => {
 *   onPopoverBack(async () => {
 *     // Select 컴포넌트에서 선택 상태 저장
 *     await saveSelectionState();
 *     return true; // 후처리 완료 후 기본 닫기 진행
 *   });
 * });
 * ```
 *
 * **핸들러 함수 타입:**
 * @typedef {Function} BackButtonHandler
 * @returns {boolean|Promise<boolean>} 처리 결과
 * @description 백버튼 핸들러 함수 타입 정의
 * ```typescript
 * type BackButtonHandler = () => boolean | Promise<boolean>;
 *
 * // 반환값 (필수):
 * // @returns {boolean} true: 기본 처리 진행 (Page는 네비게이션, Modal/Popover는 닫기)
 * // @returns {boolean} false: 백버튼 동작 차단
 * //
 * // ✅ 장점: return 누락시 TypeScript 컴파일 오류로 실수 방지
 * // ✅ 의도 명확화: 모든 경우에 개발자의 의도가 명시됨
 * // ✅ 일관된 동작: 모든 핸들러에서 동일한 패턴 사용
 * ```
 *
 * **처리 방식:**
 * @process {Router} Vue Router Guard 기반으로 뒤로가기 인터셉트
 * @process {History} History API pop state 감지로 브라우저/프로그래밍 뒤로가기 구분
 * @process {Chain} 우선순위별 체인 실행: Overlay(1-8) → Page(9)
 * @process {Auto} 핸들러 처리 후 자동 정리 및 네비게이션 재실행
 *
 * @summary 이 모듈은 Vue Router Guard를 기반으로 한 백버튼 처리 시스템으로,
 *          브라우저 뒤로가기와 Ionic Overlay 컴포넌트를 완벽하게 처리합니다.
 * @see {@link useApp} 메인 useApp composable
 * @see {@link useModal} Modal Stack 관리
 * @see {@link usePopover} Popover Stack 관리
 * @see {@link useRouter} 라우터 네비게이션
 */

import { onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { getActiveAlert, getActiveAlertBackButtonSetting } from './useApp.alert';
import { getActiveActionSheet, getActiveActionSheetBackButtonSetting } from './useApp.actionSheet';
import { closeLatestMenu, getActiveMenus } from './useApp.menu';
import { useModal } from './useApp.modal';
import { usePopover } from './useApp.popover';
import { useAppLoading } from './useApp.loading';

// 백버튼 핸들러 함수 타입
type BackButtonHandler = () => boolean | Promise<boolean>;

// 오버레이 컴포넌트 타입
interface OverlayComponents {
  isLoading: boolean;
  alert: HTMLIonAlertElement | null;
  actionSheet: HTMLIonActionSheetElement | null;
  isPopover: boolean;
  isModal: boolean;
  isMenuOpen: boolean;
}

interface OverlayCheckResult {
  result: boolean;
  components: OverlayComponents;
}

// 전역 상태 관리
const globalBackButtonState = {
  pageBackHandlers: new Map<string, BackButtonHandler>(),
  initialized: false,
};

/**
 * 통합 백버튼 처리 시스템
 */
export function useBackButton() {
  const router = useRouter();
  const { getTopModal } = useModal();
  const { getTopPopover } = usePopover();
  const { isLoading } = useAppLoading();

  /**
   * 오버레이 컴포넌트 상태 체크
   */
  const checkOverlayComponent = (): OverlayCheckResult => {
    const modal = getTopModal();
    const popover = getTopPopover();
    const alert = getActiveAlert();
    const actionSheet = getActiveActionSheet();
    const activeMenus = getActiveMenus();
    const isMenuOpen = activeMenus.length > 0;

    return {
      result: !!(isLoading.value || alert || actionSheet || popover || modal || isMenuOpen),
      components: {
        isLoading: isLoading.value,
        alert: alert || null,
        actionSheet: actionSheet || null,
        isModal: !!modal,
        isPopover: !!popover,
        isMenuOpen
      }
    };
  };

  /**
   * 오버레이 컴포넌트 히스토리 백버튼 처리 (Step1 ~ Step8)
   *
   * @chain {Step1} Loading 체크 - Loading 상태일 때 백버튼 차단
   * @chain {Step2} Alert 체크 - Alert 표시 중일 때 preventBackButton 확인
   * @chain {Step3} ActionSheet 체크 - ActionSheet 표시 중일 때 preventBackButton 확인
   * @chain {Step4} Popover 커스텀 핸들러 - Popover 컴포넌트별 사용자 정의 처리
   * @chain {Step5} Popover 기본 닫기 - Popover Stack에서 최상위 Popover 닫기
   * @chain {Step6} Modal 커스텀 핸들러 - Modal 컴포넌트별 사용자 정의 처리
   * @chain {Step7} Modal 기본 닫기 - Modal Stack에서 최상위 Modal 닫기
   * @chain {Step8} Menu 닫기 - 열린 Menu가 있으면 닫기
   *
   * @returns {Promise<boolean>} true: 오버레이가 처리됨, false: 처리되지 않음
   */
  const handleOverlayComponentBack = async (overlayComponents: OverlayComponents): Promise<boolean> => {
    // Step1: Loading 체크 - Loading 상태일 때 백버튼 차단
    if (overlayComponents.isLoading) {
      // Loading 중에는 백버튼 동작 차단 (아무 동작 안함)
      return true; // 처리됨 (차단)
    }

    // Step2: Alert 체크 - Alert 표시 중일 때 preventBackButton 확인
    if (overlayComponents.alert) {
      const { enabled: preventBackButton, alert } = getActiveAlertBackButtonSetting();
      if (alert && !preventBackButton) {
        // preventBackButton이 false면 Alert 닫기
        await alert.dismiss();
      }
      // preventBackButton이 true면 아무 동작 안함 (차단)
      return true; // 처리됨
    }

    // Step3: ActionSheet 체크 - ActionSheet 표시 중일 때 preventBackButton 확인
    if (overlayComponents.actionSheet) {
      const { enabled: preventBackButton, actionSheet } = getActiveActionSheetBackButtonSetting();
      if (actionSheet && !preventBackButton) {
        // preventBackButton이 false면 ActionSheet 닫기
        await actionSheet.dismiss();
      }
      // preventBackButton이 true면 아무 동작 안함 (차단)
      return true; // 처리됨
    }

    // Step4: Popover 커스텀 핸들러
    const topPopover = getTopPopover();
    if (topPopover && topPopover.hasBackHandler && topPopover.backHandler) {
      const result = await topPopover.backHandler();
      // 핸들러가 true를 반환하면 Popover 닫기 및 핸들러 해제
      if (result === true) {
        await topPopover.element.dismiss();
        topPopover.hasBackHandler = false;
        topPopover.backHandler = undefined;
      }
      // false를 반환하면 핸들러 유지 (오버레이도 유지)
      return true; // 처리됨
    }

    // Step5: Popover 기본 닫기
    if (topPopover) {
      await topPopover.element.dismiss();
      return true; // 처리됨
    }

    // Step6: Modal 커스텀 핸들러
    const topModal = getTopModal();
    if (topModal && topModal.hasBackHandler && topModal.backHandler) {
      const result = await topModal.backHandler();
      // 핸들러가 true를 반환하면 Modal 닫기 및 핸들러 해제
      if (result === true) {
        await topModal.element.dismiss();
        topModal.hasBackHandler = false;
        topModal.backHandler = undefined;
      }
      // false를 반환하면 핸들러 유지 (오버레이도 유지)
      return true; // 처리됨
    }

    // Step7: Modal 기본 닫기
    if (topModal) {
      await topModal.element.dismiss();
      return true; // 처리됨
    }

    // Step8: Menu 닫기
    if (overlayComponents.isMenuOpen) {
      await closeLatestMenu();
      return true; // 처리됨
    }

    // 처리할 오버레이가 없음
    return false;
  };

  /**
   * Page 백버튼 핸들러 존재 여부 확인
   */
  const checkPageBackEventHandler = (currentPath: string): boolean => {
    return globalBackButtonState.pageBackHandlers.has(currentPath);
  };

  /**
   * Page 백버튼 핸들러 처리 (Step9)
   *
   * @returns {Promise<boolean>} true: 기본 네비게이션 진행, false: 백버튼 동작 차단
   */
  const handlePageHistoryBack = async (): Promise<boolean> => {
    const currentPath = router.currentRoute.value.path;
    const handler = globalBackButtonState.pageBackHandlers.get(currentPath);

    if (!handler) {
      return true; // 핸들러가 없으면 기본 네비게이션 진행
    }

    try {
      const result = await handler();
      return result !== false; // 명시적으로 false가 아니면 true로 처리
    } catch (error) {
      console.error('[useBackButton] Page 백버튼 핸들러 실행 오류:', error);
      return false; // 에러 발생시 안전하게 페이지 유지
    }
  };

  /**
   * 전역 Router Guard 설정 (한 번만 실행)
   */
  const setupGlobalRouterGuard = () => {
    if (globalBackButtonState.initialized) return;
    globalBackButtonState.initialized = true;

    // History pop state 감지를 위한 리스너 설정
    let navigationInfo: any = null;
    router.options.history.listen((to, from, info) => {
      navigationInfo = info;
    });

    // Router Guard로 백버튼 처리
    router.beforeEach(async (to, from) => {
      if (navigationInfo?.type === 'pop') {
        navigationInfo = null;

        // 뒤로가기 네비게이션 감지
        const currentPath = router.currentRoute.value.path;
        const overlayComp = checkOverlayComponent();
        const isPageBack = checkPageBackEventHandler(currentPath);

        if (overlayComp.result) {
          // Overlay 컴포넌트 처리 (Step1 ~ Step8)
          handleOverlayComponentBack(overlayComp.components);
          return false; // URL 원복
        }
        else if (isPageBack) {
          // Page 핸들러 처리 (Step9)
          handlePageHistoryBack().then((result) => {
            if (result) {
              // 핸들러가 true 반환시 핸들러 제거 후 네비게이션 재실행
              globalBackButtonState.pageBackHandlers.delete(currentPath);
              router.back();
            }
          });
          return false; // URL 원복
        }
        else {
          return true; // 정상 진행
        }
      }
      else {
        return true; // forward/replace 네비게이션은 정상 진행
      }
    });
  };

  /**
   * Page 백버튼 핸들러 등록
   * 핸들러는 실행 후 자동으로 제거됨 (일회성)
   */
  const onPageBack = (handler: BackButtonHandler): void => {
    const currentPath = router.currentRoute.value.path;
    globalBackButtonState.pageBackHandlers.set(currentPath, handler);
  };

  /**
   * Modal 백버튼 핸들러 등록
   * 핸들러가 true 반환시 자동으로 해제됨
   */
  const onModalBack = (handler: BackButtonHandler): void => {
    const topModal = getTopModal();
    if (topModal) {
      topModal.hasBackHandler = true;
      topModal.backHandler = handler;
    }
  };

  /**
   * Popover 백버튼 핸들러 등록
   * 핸들러가 true 반환시 자동으로 해제됨
   */
  const onPopoverBack = (handler: BackButtonHandler): void => {
    const topPopover = getTopPopover();

    console.log('>>>>>>>>>>>', topPopover);

    if (topPopover) {
      topPopover.hasBackHandler = true;
      topPopover.backHandler = handler;
    }
  };  /**
   * 핸들러 수동 해제
   */
  const offBack = (type: 'page' | 'modal' | 'popover', path?: string): void => {
    switch (type) {
      case 'page':
        if (path) {
          globalBackButtonState.pageBackHandlers.delete(path);
        }
        break;
      case 'modal':
        const topModal = getTopModal();
        if (topModal) {
          topModal.hasBackHandler = false;
          topModal.backHandler = undefined;
        }
        break;
      case 'popover':
        const topPopover = getTopPopover();
        if (topPopover) {
          topPopover.hasBackHandler = false;
          topPopover.backHandler = undefined;
        }
        break;
    }
  };

  /**
   * 모든 핸들러 일괄 초기화
   */
  const clearAllBack = (): void => {
    // Page 핸들러 모두 제거
    globalBackButtonState.pageBackHandlers.clear();

    // 활성 Modal 핸들러 제거
    const topModal = getTopModal();
    if (topModal) {
      topModal.hasBackHandler = false;
      topModal.backHandler = undefined;
    }

    // 활성 Popover 핸들러 제거
    const topPopover = getTopPopover();
    if (topPopover) {
      topPopover.hasBackHandler = false;
      topPopover.backHandler = undefined;
    }
  };

  // 컴포넌트 마운트시 Router Guard 초기화
  onMounted(() => {
    setupGlobalRouterGuard();
  });

  return {
    // 핸들러 등록 API
    onPageBack,
    onModalBack,
    onPopoverBack,

    // 핸들러 관리 API
    offBack,
    clearAllBack,
  };
}
