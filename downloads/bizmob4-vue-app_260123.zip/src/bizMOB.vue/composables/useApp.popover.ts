/**
 * @namespace usePopover
 * @description
 * Ionic Popover 컴포저블
 *
 * **주요 기능:**
 * - Ionic popoverController 활용한 Popover 표시/닫기
 * - Stack 기반 중첩 Popover 관리 (후입선출 구조)
 * - 백버튼 연동을 위한 Stack 정보 제공
 * - ionicFocusManager를 통한 단순 포커스 제거 (aria-hidden 경고 방지)
 *
 * @returns {Object} Popover를 제어하는 API 객체
 * @property {function(component, options?): Promise<PopoverResult>} openPopover Popover 열기
 * @property {function(result?, data?): void} closePopover 현재 활성 Popover 닫기
 * @property {function(): PopoverStackItem | null} getTopPopover 최상단 Popover 반환 (backButton에서 사용)
 *
 * @remarks
 * **Stack 관리:**
 * - openPopover 호출 시 Stack에 자동 등록
 * - onDidDismiss 콜백에서 Stack에서 자동 제거
 * - 중첩 Popover 지원 (후입선출 구조)
 *
 * @remarks
 * **백버튼 처리(./useApp.backButton.ts 에서 통합 관리):**
 * - getTopPopover()를 통해 현재 활성 Popover 정보 제공
 * - 백버튼 핸들러는 PopoverStackItem에서 관리
 * - 단방향 의존성: Popover → BackButton (정보 제공만)
 *
 * @example
 * <caption><b>기본 Popover 사용법</b></caption>
 * ```typescript
 * import { usePopover } from '@bizMOB/vue';
 * import MyPopoverComponent from './MyPopoverComponent.vue';
 *
 * const { openPopover, closePopover } = usePopover();
 *
 * // 1. 기본 Popover 열기
 * const result = await openPopover(MyPopoverComponent);
 * if (result.result) {
 *   console.log('Popover에서 확인됨:', result.data);
 * }
 *
 * // 2. 옵션과 함께 Popover 열기
 * const result = await openPopover(MyPopoverComponent, {
 *   event: clickEvent,           // 클릭 이벤트 (위치 결정용)
 *   props: {                     // 컴포넌트에 전달할 props
 *     title: '메뉴 선택',
 *     items: menuItems
 *   },
 *   side: 'top',                 // 표시 위치
 *   alignment: 'center',         // 정렬
 *   size: 'auto',               // 크기
 *   showBackdrop: true,         // 배경 표시
 *   backdropDismiss: false      // 배경 클릭으로 닫기 비활성화
 * });
 *
 * // 3. 프로그래밍 방식으로 Popover 닫기
 * closePopover(true, { selectedItem: 'item1' });
 * ```
 *
 * @example
 * <caption><b>Popover 컴포넌트 내부에서 사용</b></caption>
 * ```typescript
 * // MyPopoverComponent.vue
 * <template>
 *   <ion-list>
 *     <ion-item @click="selectItem('item1')">
 *       <ion-label>항목 1</ion-label>
 *     </ion-item>
 *     <ion-item @click="selectItem('item2')">
 *       <ion-label>항목 2</ion-label>
 *     </ion-item>
 *   </ion-list>
 * </template>
 *
 * <script setup lang="ts">
 * import { usePopover } from '@bizMOB/vue';
 *
 * const { closePopover } = usePopover();
 *
 * const selectItem = (item: string) => {
 *   // 선택된 항목과 함께 Popover 닫기
 *   closePopover(true, { selectedItem: item });
 * };
 * </script>
 * ```
 *
 * @example
 * <caption><b>중첩 Popover 사용</b></caption>
 * ```typescript
 * import { usePopover } from '@bizMOB/vue';
 * import MainMenuComponent from './MainMenuComponent.vue';
 * import SubMenuComponent from './SubMenuComponent.vue';
 *
 * const { openPopover } = usePopover();
 *
 * // 메인 메뉴 열기
 * const mainResult = await openPopover(MainMenuComponent, {
 *   event: clickEvent
 * });
 *
 * // 서브 메뉴 열기 (메인 메뉴 위에 표시)
 * const subResult = await openPopover(SubMenuComponent, {
 *   event: clickEvent,
 *   side: 'end'
 * });
 *
 * // Stack 구조로 관리되어 나중에 열린 것부터 닫힘
 * ```
 */

import { popoverController } from '@ionic/vue';
import { ref, type Ref } from 'vue';
import { withPopoverFocus } from '../utils/ionicFocusManager';

// ========================================
// 타입 정의
// ========================================

/**
 * Popover Stack 항목 인터페이스
 */
interface PopoverStackItem {
  element: HTMLIonPopoverElement;
  id: string;
  component?: any;
  createdAt: Date;
  // 백버튼 핸들러 정보 (Popover Stack에서 관리)
  hasBackHandler: boolean;
  backHandler?: () => boolean | void | Promise<boolean | void>;
}

/**
 * Popover 결과 인터페이스
 */
interface PopoverResult {
  result: boolean;
  data?: any;
}

/**
 * Popover Stack 타입
 */
type PopoverStack = PopoverStackItem[];

// ========================================
// 상태 관리
// ========================================

/**
 * Popover Stack (후입선출 구조)
 */
const popoverStack: Ref<PopoverStack> = ref<PopoverStackItem[]>([]);

/**
 * 고유 ID 생성기
 */
let popoverIdCounter = 0;
function generatePopoverId(): string {
  return `popover-${++popoverIdCounter}-${Date.now()}`;
}

// ========================================
// Stack 관리 함수들
// ========================================

/**
 * Stack에 Popover 추가
 */
function addToStack(popover: HTMLIonPopoverElement, component?: any): void {
  const stackItem: PopoverStackItem = {
    element: popover,
    id: generatePopoverId(),
    component,
    createdAt: new Date(),
    hasBackHandler: false,
    backHandler: undefined
  };

  popoverStack.value.push(stackItem);
}

/**
 * Stack에서 Popover 제거
 */
function removeFromStack(popover: HTMLIonPopoverElement): void {
  const index = popoverStack.value.findIndex(item => item.element === popover);
  if (index > -1) {
    popoverStack.value.splice(index, 1);
  }
}

/**
 * 최상단 Popover 반환 (현재 활성 Popover)
 */
function getTopPopover(): PopoverStackItem | null {
  return popoverStack.value.length > 0
    ? popoverStack.value[popoverStack.value.length - 1]
    : null;
}

// ========================================
// 메인 컴포저블 함수
// ========================================

export function usePopover() {
  /**
   * Popover 열기
   * @param component Vue 컴포넌트
   * @param options Popover 옵션 (event, props, 위치 설정 등)
   * @returns Promise<PopoverResult>
   */
  async function openPopover(
    component: any,
    options: any = {}
  ): Promise<PopoverResult> {
    try {
      // 기본 설정 적용
      const popoverOptions = {
        component,
        showBackdrop: false,     // Popover는 보통 backdrop 없음
        backdropDismiss: true,
        animated: true,
        reference: 'trigger',    // 트리거 요소 기준
        side: 'bottom',          // 아래쪽 표시
        alignment: 'start',      // 시작점 정렬
        size: 'cover',           // 트리거 너비와 동일
        dismissOnSelect: true,   // 선택시 자동 닫기
        arrow: false,            // Popover는 화살표 없음
        keyboardClose: true,     // ESC로 닫기
        ...options,
        // props는 별도로 처리
        componentProps: options.props || {},
      };

      // event가 있으면 제거 (popoverController 옵션에 포함되면 안됨)
      if (popoverOptions.event) {
        delete popoverOptions.event;
      }
      if (popoverOptions.props) {
        delete popoverOptions.props;
      }

      // Popover 생성 (단순 포커스 제거만)
      const popover = await withPopoverFocus(
        popoverController.create(popoverOptions),
        { debug: false }
      );

      // Stack 등록
      addToStack(popover, component);

      // Popover 표시
      await popover.present();

      // 사용자 응답 대기
      const { role, data } = await popover.onDidDismiss().then((msg) => {
        removeFromStack(popover);
        return msg;
      });

      // 결과 처리
      return {
        result: role !== 'cancel' && role !== 'backdrop',
        data
      };

    } catch (error) {
      console.error('[usePopover] Popover 열기 실패:', error);
      return { result: false };
    }
  }

  /**
   * 현재 활성 Popover 닫기
   * @param result 결과값 (기본값: false)
   * @param data 전달할 데이터
   */
  function closePopover(result: boolean = false, data?: any): void {
    const topPopover = getTopPopover();

    if (!topPopover) {
      console.warn('[usePopover] 닫을 Popover가 없습니다.');
      return;
    }

    try {
      const role = result ? 'confirm' : 'cancel';
      topPopover.element.dismiss(data, role);
    } catch (error) {
      console.error('[usePopover] Popover 닫기 실패:', error);
    }
  }

  return {
    // Popover 관리 기능
    openPopover,
    closePopover,

    // BackButton용 정보 제공 함수
    getTopPopover
  };
}
