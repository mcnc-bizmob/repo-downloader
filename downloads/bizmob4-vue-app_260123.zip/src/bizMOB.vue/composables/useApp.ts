/**
 * @namespace useApp
 * @description
 * 모든 bizMOB.vue 컴포저블을 통합한 단일 API
 *
 * **주요 기능:**
 * - 모든 개별 컴포저블을 조합하여 단일 인터페이스 제공
 * - 개발자는 useApp()으로 모든 기능에 접근 가능
 *
 * **현재 제공되는 API:**
 * - Alert: alert, confirm, setAlertDefaults, getAlertDefaults
 * - Toast: toast, closeToast, setToastDefaults, getToastDefaults, getActiveToastCount, getActiveToastIds
 * - Menu: openMenu, closeMenu, toggleMenu, isMenuOpen, setMenuDefaults, getMenuDefaults, getActiveMenuCount, getActiveMenuIds, closeAllMenus
 * - ActionSheet: openActionSheet, closeActionSheet, isActionSheetOpen
 * - Router: push, replace, back, go, getQuery, getParams, getHash, navigationType
 * - Modal: openModal, closeModal
 * - Popover: openPopover, closePopover
 * - BackButton: onPageBack, onModalBack, onPopoverBack, offBack, clearAllBack
 * - Loading: withLoading, isLoading, loadingCount, startLoading, stopLoading, stopAllLoading
 * - i18n: t, locale, changeLocale, initLocale, getLocale, setLocaleMessage, mergeLocaleMessage
 *
 * @returns {Object} 모든 컴포저블 기능을 포함한 통합 API 객체
 *
 * @example
 * <caption><b>통합 API 사용법 (유일한 공개 방식)</b></caption>
 * ```typescript
 * // 기본 사용법
 * import { useApp } from '@bizMOB/vue';
 *
 * const { alert, confirm, toast, openMenu, openActionSheet, push, back, navigationType, openModal, closeModal, openPopover, closePopover, onPageBack, onModalBack, onPopoverBack, t, locale, changeLocale, initLocale } = useApp();
 *
 * // Alert 사용
 * await alert('저장되었습니다');
 * const confirmed = await confirm('정말 삭제하시겠습니까?');
 *
 * // Toast 사용
 * await toast('파일이 업로드되었습니다');
 * await toast({
 *   message: '에러가 발생했습니다',
 *   color: 'danger',
 *   duration: 3000
 * });
 *
 * // Menu 사용
 * await openMenu();
 * await toggleMenu('sidebar');
 *
 * // ActionSheet 사용
 * const result = await openActionSheet([
 *   { text: '편집', value: 'edit' },
 *   { text: '삭제', value: 'delete' },
 *   { text: '취소', role: 'cancel' }
 * ]);
 *
 * // Router 사용
 * push('/new-page');
 * push('/user-detail', {
 *   params: { id: '123' },
 *   query: { tab: 'profile' }
 * });
 * back();
 * console.log('Navigation type:', navigationType.value);
 *
 * // Modal 사용
 * const result = await openModal(UserDetailComponent, {
 *   props: { userId: 123 },
 *   cssClass: ['custom-modal']
 * });
 *
 * // Sheet Modal 사용
 * const sheetResult = await openModal(SettingsComponent, {
 *   props: { settings: currentSettings },
 *   initialBreakpoint: 0.8,
 *   breakpoints: [0, 0.5, 0.8, 1],
 *   showHandle: true
 * }, 'sheet');
 *
 * // Modal 닫기
 * closeModal(true, { saved: true });
 *
 * // Popover 사용 (Select 최적화)
 * const popoverResult = await openPopover(SelectOptionsList, {
 *   event: clickEvent, // 클릭 이벤트
 *   props: {
 *     options: selectOptions,
 *     selected: currentValue
 *   }
 * });
 *
 * if (popoverResult.result) {
 *   currentValue = popoverResult.data;
 * }
 *
 * // Popover 닫기
 * closePopover(true, { selectedValue: 'option-1' });
 *
 * // i18n 사용
 * const greeting = t('main.greeting');
 * const welcomeMsg = t('main.name_greeting', { name: '홍길동' });
 * console.log('현재 언어:', locale.value);
 * await changeLocale('en');
 * await initLocale();
 *
 * // Vue 컴포넌트에서 사용
 * <script setup lang="ts">
 * import { useApp } from '@bizMOB/vue';
 *
 * const { alert, confirm, toast, openMenu, openActionSheet, push, back, navigationType, openModal, closeModal, openPopover, closePopover, onPageBack, onModalBack, onPopoverBack, t, locale, changeLocale, initLocale } = useApp();
 *
 * const handleSave = async () => {
 *   await toast('저장되었습니다');
 * };
 *
 * const handleDelete = async () => {
 *   const confirmed = await confirm('정말 삭제하시겠습니까?');
 *   if (confirmed) {
 *     await toast('삭제되었습니다');
 *   }
 * };
 *
 * const handleNavigate = () => {
 *   push('/detail-page', {
 *     query: { from: 'list' }
 *   });
 * };
 *
 * const handleGoBack = () => {
 *   back();
 * };
 *
 * const handleOpenModal = async () => {
 *   const result = await openModal(UserSettingsModal, {
 *     props: { currentUser: user.value },
 *     cssClass: ['settings-modal']
 *   });
 *
 *   if (result.result) {
 *     await toast('설정이 저장되었습니다');
 *   }
 * };
 *
 * const handleOpenPopover = async (event) => {
 *   const result = await openPopover(SelectComponent, {
 *     event,
 *     props: { options: selectOptions }
 *   });
 *
 *   if (result.result) {
 *     selectedValue.value = result.data;
 *   }
 * };
 * </script>
 * ```
 */

// ========================================
// 개별 컴포저블 Import
// ========================================

import { useAlert } from './useApp.alert';
import { useToast } from './useApp.toast';
import { useMenu } from './useApp.menu';
import { useActionSheet } from './useApp.actionSheet';
import { useRouter } from './useApp.router';
import { useModal } from './useApp.modal';
import { usePopover } from './useApp.popover';
import { useBackButton } from './useApp.backButton';
import { useAppLoading } from './useApp.loading';
import { useI18n } from './useApp.i18n';

// ========================================
// 통합 컴포저블 함수
// ========================================

export function useApp() {
  // 개별 컴포저블 인스턴스 생성
  const alertApi = useAlert();
  const toastApi = useToast();
  const menuApi = useMenu();
  const actionSheetApi = useActionSheet();
  const routerApi = useRouter();
  const modalApi = useModal();
  const popoverApi = usePopover();
  const backButtonApi = useBackButton();
  const loadingApi = useAppLoading();
  const i18nApi = useI18n();

  // 통합 API 객체 반환
  return {
    // Alert API
    alert: alertApi.alert,
    confirm: alertApi.confirm,
    setAlertDefaults: alertApi.setAlertDefaults,
    getAlertDefaults: alertApi.getAlertDefaults,

    // Toast API
    toast: toastApi.toast,
    closeToast: toastApi.closeToast,
    setToastDefaults: toastApi.setToastDefaults,
    getToastDefaults: toastApi.getToastDefaults,
    getActiveToastCount: toastApi.getActiveToastCount,
    getActiveToastIds: toastApi.getActiveToastIds,

    // Menu API
    openMenu: menuApi.openMenu,
    closeMenu: menuApi.closeMenu,
    toggleMenu: menuApi.toggleMenu,
    isMenuOpen: menuApi.isMenuOpen,
    setMenuDefaults: menuApi.setMenuDefaults,
    getMenuDefaults: menuApi.getMenuDefaults,
    getActiveMenuCount: menuApi.getActiveMenuCount,
    getActiveMenuIds: menuApi.getActiveMenuIds,
    closeAllMenus: menuApi.closeAllMenus,

    // ActionSheet API
    openActionSheet: actionSheetApi.openActionSheet,
    closeActionSheet: actionSheetApi.closeActionSheet,
    isActionSheetOpen: actionSheetApi.isActionSheetOpen,

    // Router API
    push: routerApi.push,
    replace: routerApi.replace,
    back: routerApi.back,
    go: routerApi.go,
    getQuery: routerApi.getQuery,
    getParams: routerApi.getParams,
    getHash: routerApi.getHash,
    navigationType: routerApi.navigationType,

    // Modal API
    openModal: modalApi.openModal,
    closeModal: modalApi.closeModal,

    // Popover API
    openPopover: popoverApi.openPopover,
    closePopover: popoverApi.closePopover,

    // BackButton API
    onPageBack: backButtonApi.onPageBack,
    onModalBack: backButtonApi.onModalBack,
    onPopoverBack: backButtonApi.onPopoverBack,
    offBack: backButtonApi.offBack,
    clearAllBack: backButtonApi.clearAllBack,

    // Loading API
    withLoading: loadingApi.withLoading,
    isLoading: loadingApi.isLoading,
    loadingCount: loadingApi.loadingCount,
    startLoading: loadingApi.start,
    stopLoading: loadingApi.stop,
    stopAllLoading: loadingApi.stopAll,

    // i18n API
    t: i18nApi.t,
    locale: i18nApi.locale,
    changeLocale: i18nApi.changeLocale,
    initLocale: i18nApi.initLocale,
    getLocale: i18nApi.getLocale,
    setLocaleMessage: i18nApi.setLocaleMessage,
    mergeLocaleMessage: i18nApi.mergeLocaleMessage
  };
}
