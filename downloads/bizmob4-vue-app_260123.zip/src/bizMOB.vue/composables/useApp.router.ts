/**
 * @namespace useRouter
 * @description
 * Ionic Router 컴포저블 (Navigation API 기반)
 *
 * **주요 기능:**
 * - Ionic ionRouter를 활용한 페이지 전환
 * - Navigation API를 활용한 브라우저 뒤로가기와 프로그래밍 뒤로가기 동작 통일
 * - 네비게이션 함수 및 조회 함수 제공
 *
 * @returns {Object} Router를 제어하는 API 객체
 * @property {function(to, options?): void} push 새 페이지로 이동
 * @property {function(to, options?): void} replace 현재 페이지 교체
 * @property {function(): void} back 뒤로가기
 * @property {function(target): void} go 특정 페이지로 돌아가기 (route name/path 지원)
 * @property {function(): Record<string, any>; function(key: string): any} getQuery URL 쿼리 파라미터 조회 (오버로드 지원)
 * @property {function(): Record<string, any>; function(key: string): any} getParams Vue Router params 조회 (오버로드 지원)
 * @property {function(): string; function(key: string): any} getHash Vue Router hash 조회 (오버로드 지원)
 * @property {Readonly<Ref<NavigationType>>} navigationType 화면 진입 타입 조회 (읽기 전용)
 *
 * @remarks
 * 백버튼 처리(./useApp.backButton.ts 에서 통합 관리):
 * - Navigation API 인터셉터 설정
 * - 백버튼 처리 시스템의 기반 제공 (9-10단계)
 * - navigationType 변경 함수 제공 (setNavigationType)
 *
 * @remarks
 * 네비게이션 처리:
 * - ionRouter.navigate 사용해서 이동
 *
 * @remarks
 * navigationType 관리:
 * - 읽기 전용으로 제공 (직접 변경 불가)
 * - 프로그래밍적 네비게이션(push/replace/back)에서 자동 변경
 * - 브라우저 백버튼은 useApp.backButton.ts에서 감지하여 변경
 *
 * @example
 * <caption><b>push/replace/back/go 사용법</b></caption>
 * ```typescript
 * import { useRouter } from '@bizMOB/vue';
 *
 * const router = useRouter();
 *
 * router.push('/new-page');
 * router.replace('/another-page');
 *
 * // to : router.name 또는 router.path
 * // options.direction
 * // 'forward': 기본값, 오른쪽에서 나타나는 진입 애니메이션 (일반적인 교체)
 * // 'back': 오른쪽으로 사라지는 뒤로가기 애니메이션 (이전 화면 느낌)
 * // 'root': 네비게이션 스택 초기화 후 새 루트 페이지 설정 (로그아웃 시)
 * // 'none': 애니메이션 없이 즉시 교체 (URL 파라미터 변경, 조용한 리다이렉트)
 * router.push('/new-page', {
 *   query: { foo: 'bar' },
 *   params: { id: 123 },
 *   hash: '#section1',
 *   direction: 'forward' // default: 'forward'
 * });
 *
 * router.replace('/another-page', {
 *   query: { baz: 'qux' },
 *   params: { id: 456 },
 *   hash: '#section2',
 *   direction: 'root'
 * });
 *
 * router.back();
 *
 * // route name 또는 route path
 * router.go('MAIN');
 * ```
 *
 * @example
 * <caption><b>getQuery/getParams/getHash 사용법</b></caption>
 * ```typescript
 * import { useRouter } from '@bizMOB/vue';
 *
 * const { getQuery, getParams, getHash } = useRouter();
 *
 * // 쿼리 파라미터 조회
 * const query = getQuery();           // 전체 쿼리 객체
 * const queryVal = getQuery('val');   // 특정 쿼리 값
 *
 * // URL 파라미터 조회
 * const params = getParams();         // 전체 params 객체
 * const paramVal = getParams('id');   // 특정 param 값
 *
 * // Hash 조회
 * const hash = getHash();             // 전체 hash 문자열 (예: "#section1")
 * const hashParam = getHash('key');   // Hash에서 파라미터 추출 (예: "#key=value" 형태)
 * ```
 *
 * @example
 * <caption><b>navigationType 사용법</b></caption>
 * ```typescript
 * import { onIonViewWillEnter } from '@ionic/vue';
 * import { useRouter } from '@bizMOB/vue';
 *
 * const { navigationType } = useRouter();
 *
 * onIonViewWillEnter(() => {
 *   // 네비게이션 유형에 따라 로직 분기
 *   switch (navigationType.value) {
 *     // 🚀 새로운 페이지로 진입했거나, replace로 들어온 경우
 *     case 'push':
 *     case 'replace':
 *     case 'initial': // 앱 초기 진입
 *       fetchData();
 *       break;
 *
 *     // ⏪ 뒤로가기로 돌아온 경우
 *     case 'back':
 *       // 캐시된 데이터를 그대로 사용하므로 아무것도 하지 않음
 *       // 또는, 특정 조건에서만 최소한의 데이터 갱신을 수행할 수 있음
 *       console.log('캐시된 데이터를 사용합니다.');
 *       break;
 *   }
 * });
 * ```
 */

import { ref, readonly, type Ref } from 'vue';
import { useIonRouter } from '@ionic/vue';
import { useRoute, useRouter as useVueRouter } from 'vue-router';
import { clearCurrentFocus } from '../utils/ionicFocusManager';

// ========================================
// 타입 정의
// ========================================

/**
 * 네비게이션 타입
 */
type NavigationType = 'push' | 'replace' | 'back' | 'initial';

/**
 * 네비게이션 방향
 */
type NavigationDirection = 'forward' | 'back' | 'root' | 'none';

/**
 * 네비게이션 옵션
 */
interface NavigationOptions {
  query?: Record<string, any>;
  params?: Record<string, any>;
  hash?: string;
  direction?: NavigationDirection;
}

/**
 * 라우터 이동 대상 (경로 또는 라우트명)
 */
type NavigationTarget = string;

// ========================================
// 공유 상태 관리
// ========================================

/**
 * 전역 네비게이션 타입 상태 (useApp.backButton.ts와 공유)
 */
export const globalNavigationType = ref<NavigationType>('initial');

/**
 * 네비게이션 타입 변경 함수 (useApp.backButton.ts에서 사용)
 * @param type 설정할 네비게이션 타입
 */
export const setNavigationType = (type: NavigationType): void => {
  globalNavigationType.value = type;
};

/**
 * 읽기 전용 네비게이션 타입 (외부 노출용)
 */
const readonlyNavigationType: Readonly<Ref<NavigationType>> = readonly(globalNavigationType);

// ========================================
// 유틸리티 함수들
// ========================================

/**
 * 라우트명인지 경로인지 판별
 * @param target 대상 문자열
 * @returns true if route name, false if path
 */
function isRouteName(target: string): boolean {
  return !target.startsWith('/') && !target.includes('/');
}

/**
 * 쿼리 파라미터, params, hash를 포함한 완전한 경로 생성
 * @param to 이동할 경로 또는 라우트명
 * @param options 네비게이션 옵션
 * @returns 완전한 경로 문자열
 */
function buildFullPath(to: string, options?: NavigationOptions): string {
  let path = to;

  // Route name인 경우 경로로 변환 (실제로는 Vue Router를 통해 resolve 필요)
  if (isRouteName(to)) {
    const vueRouter = useVueRouter();
    try {
      const resolved = vueRouter.resolve({ name: to, params: options?.params });
      path = resolved.path;
    } catch (error) {
      console.warn(`[useRouter] Route name '${to}' not found, treating as path`);
      path = `/${to}`;
    }
  }

  // 쿼리 파라미터 추가
  if (options?.query && Object.keys(options.query).length > 0) {
    const queryParams: string[] = [];
    for (const key in options.query) {
      if (options.query.hasOwnProperty(key)) {
        queryParams.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(options.query[key]))}`);
      }
    }
    path += `?${queryParams.join('&')}`;
  }

  // Hash 추가
  if (options?.hash) {
    path += options.hash.startsWith('#') ? options.hash : `#${options.hash}`;
  }

  return path;
}

// ========================================
// 메인 컴포저블 함수
// ========================================

export function useRouter() {
  const ionRouter = useIonRouter();
  const route = useRoute();
  const vueRouter = useVueRouter();

  /**
   * 새 페이지로 이동
   * @param to 이동할 경로 또는 라우트명
   * @param options 네비게이션 옵션
   */
  const push = (to: NavigationTarget, options?: NavigationOptions): void => {
    try {
      // 네비게이션 전 현재 포커스 제거 (aria-hidden 경고 방지)
      clearCurrentFocus();

      // 네비게이션 타입 설정
      setNavigationType('push');

      // 완전한 경로 생성
      const fullPath = buildFullPath(to, options);

      // Ionic Router로 이동
      const direction = options?.direction || 'forward';
      ionRouter.navigate(fullPath, direction, 'push');

    } catch (error) {
      console.error('[useRouter] Push navigation failed:', error);
    }
  };

  /**
   * 현재 페이지 교체
   * @param to 이동할 경로 또는 라우트명
   * @param options 네비게이션 옵션
   */
  const replace = (to: NavigationTarget, options?: NavigationOptions): void => {
    try {
      // 네비게이션 전 현재 포커스 제거 (aria-hidden 경고 방지)
      clearCurrentFocus();

      // 네비게이션 타입 설정
      setNavigationType('replace');

      // 완전한 경로 생성
      const fullPath = buildFullPath(to, options);

      // Ionic Router로 교체
      const direction = options?.direction || 'forward';
      ionRouter.navigate(fullPath, direction, 'replace');

    } catch (error) {
      console.error('[useRouter] Replace navigation failed:', error);
    }
  };

  /**
   * 뒤로가기
   */
  const back = (): void => {
    try {
      // 네비게이션 전 현재 포커스 제거 (aria-hidden 경고 방지)
      clearCurrentFocus();

      // 네비게이션 타입 설정
      setNavigationType('back');

      // Ionic Router로 뒤로가기
      // useBackButton에서 자동으로 인터셉트되어 10단계 체인 실행됨
      ionRouter.back();

    } catch (error) {
      console.error('[useRouter] Back navigation failed:', error);
    }
  };

  /**
   * 특정 페이지로 돌아가기 (route name/path 지원)
   * @param target 이동할 라우트명 또는 경로
   */
  const go = (target: NavigationTarget): void => {
    try {
      // 네비게이션 전 현재 포커스 제거 (aria-hidden 경고 방지)
      clearCurrentFocus();

      if (isRouteName(target)) {
        // Route name인 경우
        const resolved = vueRouter.resolve({ name: target });
        if (resolved.matched.length > 0) {
          push(resolved.path);
        } else {
          console.warn(`[useRouter] Route name '${target}' not found`);
        }
      } else {
        // Path인 경우
        push(target);
      }
    } catch (error) {
      console.error('[useRouter] Go navigation failed:', error);
    }
  };

  /**
   * URL 쿼리 파라미터 조회 (오버로드)
   */
  function getQuery(): Record<string, any>;
  function getQuery(key: string): any;
  function getQuery(key?: string): any {
    if (key) {
      return route.query[key];
    }
    return { ...route.query };
  }

  /**
   * Vue Router params 조회 (오버로드)
   */
  function getParams(): Record<string, any>;
  function getParams(key: string): any;
  function getParams(key?: string): any {
    if (key) {
      return route.params[key];
    }
    return { ...route.params };
  }

  /**
   * Vue Router hash 조회 (오버로드)
   */
  function getHash(): string;
  function getHash(key: string): any;
  function getHash(key?: string): any {
    if (key) {
      // Hash를 파싱하여 특정 키 조회 (#key1=value1&key2=value2 형태)
      const hash = route.hash.substring(1); // # 제거
      if (hash.includes('=')) {
        const params = new URLSearchParams(hash);
        return params.get(key);
      }
      return null;
    }
    return route.hash;
  }

  return {
    push,
    replace,
    back,
    go,
    getQuery,
    getParams,
    getHash,
    navigationType: readonlyNavigationType
  };
}
