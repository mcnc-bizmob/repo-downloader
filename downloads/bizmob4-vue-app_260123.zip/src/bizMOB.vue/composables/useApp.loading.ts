/**
 * @namespace useAppLoading
 * @description
 * Ionic Loading 컴포저블
 *
 * **주요 기능:**
 * - Ionic loadingController 활용한 Loading 오버레이 표시/닫기
 * - useLoadingStore와 연동한 동시 요청 안전 처리
 * - 싱글톤 패턴으로 중복 Loading 인스턴스 방지
 * - Debounce 패턴으로 연속 호출 최적화 (100ms 지연)
 * - withLoading 래퍼를 통한 자동 Loading 상태 관리
 *
 * @returns {Object} Loading을 제어하는 API 객체
 * @property {function<T>(asyncFunction: () => Promise<T>, description?: string): Promise<T>} withLoading 비동기 함수 실행 중 자동 로딩 관리 (권장)
 * @property {Ref<boolean>} isLoading 현재 로딩 상태 (읽기 전용)
 * @property {Ref<number>} loadingCount 활성 로딩 작업 수 (읽기 전용)
 * @property {function(component?, type?, description?): string} start 로딩 시작 (수동 제어용)
 * @property {function(taskId: string): boolean} stop 로딩 중지 (수동 제어용)
 * @property {function(): void} stopAll 모든 로딩 중지 (수동 제어용)
 *
 * @remarks
 * **싱글톤 로딩 매니저:**
 * - 전역에서 하나의 Loading 인스턴스만 관리
 * - 첫 번째 useAppLoading() 호출 시 매니저 초기화
 * - watch를 통한 isLoading 상태 감시 및 UI 자동 제어
 *
 * @remarks
 * **Debounce 최적화:**
 * - 로딩 해제 시 100ms 지연 후 실제 dismiss 실행
 * - 연속 API 호출 시 깜빡임 현상 방지
 * - 타이머 중 새로운 로딩 요청 시 타이머 취소 및 인스턴스 재사용
 *
 * @remarks
 * **Store 연동:**
 * - useLoadingStore를 통한 로딩 작업 카운팅
 * - 동시 다발적 API 호출 시 안전한 상태 관리
 * - taskId 기반 개별 작업 추적 및 정리
 *
 * @example
 * <caption><b>withLoading 사용법 (권장)</b></caption>
 * ```typescript
 * import { useAppLoading } from '@bizMOB/vue';
 *
 * const { withLoading } = useAppLoading();
 *
 * // 1. 기본 사용법
 * const result = await withLoading(async () => {
 *   return await apiCall();
 * });
 *
 * // 2. 설명과 함께 사용
 * const userData = await withLoading(async () => {
 *   const response = await fetch('/api/user');
 *   return await response.json();
 * }, '사용자 정보 로딩 중...');
 *
 * // 3. 에러 처리
 * try {
 *   const result = await withLoading(async () => {
 *     return await riskyApiCall();
 *   }, '위험한 API 호출');
 * } catch (error) {
 *   console.error('API 호출 실패:', error);
 *   // 로딩은 자동으로 해제됨
 * }
 * ```
 *
 * @example
 * <caption><b>수동 제어 사용법</b></caption>
 * ```typescript
 * import { useAppLoading } from '@bizMOB/vue';
 *
 * const { start, stop, stopAll, isLoading, loadingCount } = useAppLoading();
 *
 * // 1. 수동 로딩 시작/중지
 * const taskId = start(null, 'api', '데이터 로딩 중...');
 * try {
 *   await someAsyncWork();
 * } finally {
 *   stop(taskId);
 * }
 *
 * // 2. 로딩 상태 감시
 * watch(isLoading, (loading) => {
 *   console.log('Loading state:', loading);
 * });
 *
 * // 3. 활성 작업 수 확인
 * console.log('Active loading tasks:', loadingCount.value);
 *
 * // 4. 모든 로딩 강제 중지 (비상시)
 * stopAll();
 * ```
 *
 * @example
 * <caption><b>동시 다발적 API 호출</b></caption>
 * ```typescript
 * import { useAppLoading } from '@bizMOB/vue';
 *
 * const { withLoading } = useAppLoading();
 *
 * // 여러 API를 동시에 호출해도 하나의 로딩만 표시됨
 * const [userData, profileData, settingsData] = await Promise.all([
 *   withLoading(() => fetchUser(), '사용자 정보'),
 *   withLoading(() => fetchProfile(), '프로필 정보'),
 *   withLoading(() => fetchSettings(), '설정 정보')
 * ]);
 *
 * // 모든 API가 완료될 때까지 로딩이 유지됨
 * console.log('모든 데이터 로딩 완료');
 * ```
 */

// src/bizMOB.vue/composables/useApp.loading.ts

import { ref, watch } from 'vue';
import { loadingController } from '@ionic/vue';
import { useLoadingStore } from '../stores/useLoadingStore';
import { storeToRefs } from 'pinia';

// ========================================
// 싱글톤 로딩 매니저
// ========================================

let isInitialized = false;
const loadingInstance = ref<HTMLIonLoadingElement | null>(null);
let dismissTimer: number | null = null;
const DISMISS_DELAY = 100; // 100ms 지연 후 로딩 해제

/**
 * 로딩 매니저를 초기화합니다 (한 번만 실행됨)
 */
function initializeLoadingManager() {
  if (isInitialized) return;

  const loadingStore = useLoadingStore();
  const { isLoading, loadingCount } = storeToRefs(loadingStore);

  // 로딩 상태가 변경될 때 UI를 제어하는 감시자(watcher) - 한 번만 등록
  watch(isLoading, async (newIsLoading) => {
    console.log('🔄 Loading state changed:', newIsLoading, 'Tasks:', loadingCount.value);

    if (newIsLoading) {
      // 로딩이 필요한 경우

      // 기존 dismiss 타이머가 있으면 취소 (연속 호출 대응)
      if (dismissTimer) {
        clearTimeout(dismissTimer);
        dismissTimer = null;
        console.log('⏰ Dismiss timer cancelled - continuous loading detected');
      }

      // 로딩 인스턴스가 없는 경우에만 새로 생성
      if (!loadingInstance.value) {
        try {
          console.log('🚀 Creating loading instance...');
          loadingInstance.value = await loadingController.create({
            spinner: 'dots',
            backdropDismiss: false,
            duration: 0,
          });
          await loadingInstance.value.present();
          console.log('✅ Loading instance created and presented');
        } catch (error) {
          console.error('❌ 로딩 표시에 실패했습니다.', error);
          loadingInstance.value = null;
        }
      } else {
        console.log('♻️ Loading instance already exists - reusing');
      }
    } else {
      // 로딩이 필요 없는 경우 - 지연 후 해제 (연속 호출 대응)
      if (loadingInstance.value && !dismissTimer) {
        console.log(`⏰ Scheduling loading dismiss in ${DISMISS_DELAY}ms...`);

        dismissTimer = setTimeout(async () => {
          // 타이머 실행 시점에 다시 로딩 상태 확인
          if (!isLoading.value && loadingInstance.value) {
            try {
              console.log('🔄 Dismissing loading instance (after delay)...');
              await loadingInstance.value.dismiss();
              console.log('✅ Loading instance dismissed');
            } catch (error) {
              console.log('⚠️ Loading instance already dismissed or error:', error);
            } finally {
              loadingInstance.value = null;
            }
          } else {
            console.log('🔄 Loading state changed during delay - keeping instance');
          }
          dismissTimer = null;
        }, DISMISS_DELAY);
      }
    }
  }, { immediate: true }); // 즉시 실행으로 초기 상태 처리

  isInitialized = true;
  console.log('🔧 Loading manager initialized with debounce pattern');
}

// ========================================
// 메인 컴포저블 함수
// ========================================

/**
 * 프로그래매틱 방식으로 로딩 오버레이를 관리하는 컴포저블입니다.
 * useLoadingStore와 연동하여 동시 요청을 안전하게 처리합니다.
 */
export function useAppLoading() {
  // 로딩 매니저 초기화 (첫 번째 호출 시에만 실행됨)
  initializeLoadingManager();

  const loadingStore = useLoadingStore();
  const { isLoading, loadingCount } = storeToRefs(loadingStore);  /**
   * 비동기 함수를 실행하는 동안 자동으로 로딩 상태를 관리합니다. (가장 권장)
   * @param asyncFunction 실행할 비동기 함수
   * @param description 로딩 작업에 대한 설명 (디버깅용)
   */
  const withLoading = async <T>(
    asyncFunction: () => Promise<T>,
    description?: string
  ): Promise<T> => {
    const taskId = loadingStore.startLoading(null, 'api', description);
    console.log('🎯 withLoading started:', { taskId, description, activeCount: loadingCount.value });

    try {
      const result = await asyncFunction();
      console.log('✅ withLoading completed:', { taskId, description });
      return result;
    } catch (error) {
      console.error('❌ withLoading error:', { taskId, description, error });
      throw error;
    } finally {
      const stopped = loadingStore.stopLoading(taskId);
      console.log('🔄 withLoading cleanup:', { taskId, stopped, remainingCount: loadingCount.value });
    }
  };

  return {
    withLoading,
    isLoading,
    loadingCount,
    start: loadingStore.startLoading,
    stop: loadingStore.stopLoading,
    stopAll: loadingStore.stopAllLoading,
  };
}
