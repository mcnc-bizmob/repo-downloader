// stores/common/loading.store.ts
import { defineStore } from 'pinia';
import { ref, computed, readonly } from 'vue';

/**
 * 로딩 태스크 정보
 */
export interface LoadingTask {
  /** 태스크 고유 ID */
  id: string
  /** 태스크 시작 시간 */
  startTime: Date
  /** 태스크 타입 */
  type: LoadingTaskType
  /** 태스크 설명 (선택사항) */
  description?: string
}

/**
 * 로딩 태스크 타입
 */
export type LoadingTaskType = 'api' | 'upload' | 'download' | 'custom' | 'app' | 'manual'

/**
 * API 호출 시 로딩 옵션
 */
export interface LoadingApiOptions {
  /** 사용자 지정 태스크 ID (선택사항) */
  taskId?: string
  /** 로딩 태스크 설명 (선택사항) */
  description?: string
  /** 로딩 태스크 타입 (선택사항, 기본값: 'api') */
  type?: LoadingTaskType
  /** 전역 로딩 표시 여부 (선택사항, 기본값: true) */
  showGlobalLoading?: boolean
}


export const useLoadingStore = defineStore('loading', () => {
  // State
  const loadingTasks = ref(new Map<string, LoadingTask>());
  const loadingVisible = ref(true);

  // Getters
  const isLoading = computed((): boolean => loadingTasks.value.size > 0);
  const loadingCount = computed((): number => loadingTasks.value.size);
  const activeTasks = computed((): string[] => Array.from(loadingTasks.value.keys()));

  const shouldShowLoading = computed((): boolean =>
    isLoading.value && loadingVisible.value
  );

  // Actions
  const startLoading = (
    taskId: string | null = null,
    type: LoadingTaskType = 'api',
    description?: string
  ): string => {
    const id = taskId || `task_${Date.now()}_${Math.random()}`;

    const task: LoadingTask = {
      id,
      startTime: new Date(),
      type,
      description
    };

    loadingTasks.value.set(id, task);
    console.log('📊 Loading task started:', { id, type, description, totalTasks: loadingTasks.value.size });
    return id;
  };

  const stopLoading = (taskId: string): boolean => {
    if (taskId && loadingTasks.value.has(taskId)) {
      loadingTasks.value.delete(taskId);
      console.log('📊 Loading task stopped:', { taskId, remainingTasks: loadingTasks.value.size });
      return true;
    }
    console.log('⚠️ Loading task not found:', { taskId, availableTasks: Array.from(loadingTasks.value.keys()) });
    return false;
  };

  const stopAllLoading = (): void => {
    const taskCount = loadingTasks.value.size;
    loadingTasks.value.clear();
    console.log('🧹 All loading tasks cleared:', { clearedCount: taskCount });
  };

  const setLoadingVisible = (visible: boolean): void => {
    loadingVisible.value = visible;
  };

  return {
    // State
    loadingTasks: readonly(loadingTasks),
    loadingVisible: readonly(loadingVisible),

    // Getters
    isLoading,
    loadingCount,
    activeTasks,
    shouldShowLoading,

    // Actions
    startLoading,
    stopLoading,
    stopAllLoading,
    setLoadingVisible
  };
});
