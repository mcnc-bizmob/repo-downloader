---
title: "bizMOB-Xross-4.0-vue-Composables"
document_title: "Composables"
department: "technical"
document_category: "라이브러리"
platform: "bizMOB"
product: "Xross"
version: "4.0"
language: "vue"
target_role: ["developer", "frontend_developer"]
frameworks: ["Vue3", "Composition API", "TypeScript", "Ionic"]
keywords: ["Vue", "컴포저블", "Composition API", "useApp", "useModal", "useLoading", "useApi", "모바일", "재사용"]
purpose: "bizMOB Xross 환경에서 Vue 컴포저블을 효율적으로 활용한 모바일 앱 개발 방법 제공"
---

# bizMOB Xross Vue 컴포저블 라이브러리

bizMOB Xross는 Vue.js + Ionic 환경에서 사용할 수 있는 통합 컴포저블 라이브러리입니다. 모바일 앱 개발에 필요한 모든 기능을 하나의 간단한 API로 제공합니다.

## 1. 시작하기

### 1.1 설치 및 설정

```javascript
// main.js
import { ionicPlugin, bizMOBPlugin } from '@bizMOB/vue'

app.use(ionicPlugin)
app.use(bizMOBPlugin)
```

### 1.2 기본 사용법

```javascript
// 컴포넌트에서 사용
import { useApp } from '@bizMOB/vue'

const { alert, toast, push, openModal } = useApp()

// Alert 표시
await alert('저장되었습니다')

// Toast 표시
await toast('파일 업로드 완료')

// 페이지 이동
push('/detail-page')

// Modal 열기
const result = await openModal(DetailComponent)
```

---

## 2. 핵심 API

### 2.1 useApp() - 통합 API

모든 기능에 접근할 수 있는 **유일한 공개 API**입니다.

```javascript
const {
  // Alert 관련
  alert, confirm, setAlertDefaults,

  // Toast 관련
  toast, closeToast, setToastDefaults,

  // Loading 관련
  withLoading, isLoading, startLoading, stopLoading,

  // Router 관련
  push, replace, back, go, getQuery, getParams,

  // Modal 관련
  openModal, closeModal,

  // Menu 관련
  openMenu, closeMenu, toggleMenu,

  // ActionSheet 관련
  openActionSheet, closeActionSheet,

  // 백버튼 처리
  onPageBack, onModalBack, clearAllBack
} = useApp()
```

---

## 3. 컴포저블 기능

### 3.1 Alert & Confirm

사용자에게 알림이나 확인을 요청하는 다이얼로그를 표시합니다.

#### 기본 사용법

```javascript
// 간단한 알림
await alert('저장되었습니다')

// 줄바꿈 지원
await alert('첫 번째 줄\n두 번째 줄')

// 확인 대화상자
const confirmed = await confirm('정말 삭제하시겠습니까?')
if (confirmed) {
  // 삭제 로직
}
```

#### 고급 옵션

```javascript
// 상세 옵션을 사용한 Alert
await alert({
  title: '알림',
  message: '저장이 완료되었습니다\n계속 진행하시겠습니까?',
  buttons: [
    {
      text: '확인',
      handler: () => {
        console.log('확인 클릭됨')
        return true
      }
    }
  ],
  style: {
    titleAlign: 'left',
    textAlign: 'left',
    cssClass: 'custom-alert'
  },
  preventBackButton: true // 백버튼 차단
})
```

#### 주요 옵션

| 옵션 | 타입 | 설명 |
|------|------|------|
| `title` | string | 제목 |
| `message` | string | 메시지 (줄바꿈 지원) |
| `preventBackButton` | boolean | 백버튼 차단 여부 |
| `style.titleAlign` | 'left'\|'center'\|'right' | 제목 정렬 |
| `style.textAlign` | 'left'\|'center'\|'right' | 텍스트 정렬 |

---

### 3.2 Toast

사용자에게 간단한 알림 메시지를 표시합니다.

#### 기본 사용법

```javascript
// 간단한 토스트
await toast('저장되었습니다')

// 줄바꿈 지원
await toast('파일 업로드 중\n잠시 기다려주세요')
```

#### 고급 옵션

```javascript
// 상세 옵션을 사용한 Toast
await toast({
  message: '에러가 발생했습니다',
  duration: 3000,
  position: 'top',
  color: 'danger',
  showCloseButton: true,
  closeButtonText: '닫기'
})
```

#### 주요 옵션

| 옵션 | 타입 | 설명 |
|------|------|------|
| `message` | string | 표시할 메시지 |
| `duration` | number | 표시 시간 (ms, 기본값: 1500) |
| `position` | 'top'\|'middle'\|'bottom' | 표시 위치 |
| `color` | string | 색상 테마 |
| `showCloseButton` | boolean | 닫기 버튼 표시 여부 |

---

### 3.3 Loading

비동기 작업 중 로딩 상태를 표시합니다.

#### withLoading (권장)

```javascript
// 자동 로딩 관리
const result = await withLoading(async () => {
  const response = await fetch('/api/data')
  return await response.json()
}, '데이터 로딩 중...')

// 에러가 발생해도 자동으로 로딩 해제
try {
  const result = await withLoading(() => riskyApiCall())
} catch (error) {
  console.error('API 호출 실패:', error)
  // 로딩은 자동으로 해제됨
}
```

#### 수동 제어

```javascript
// 수동 로딩 시작/중지
const taskId = startLoading('데이터 로딩 중...')
try {
  await someAsyncWork()
} finally {
  stopLoading(taskId)
}

// 모든 로딩 강제 중지
stopAllLoading()
```

#### 동시 다발적 API 호출

```javascript
// 여러 API를 동시에 호출해도 하나의 로딩만 표시
const [userData, profileData, settingsData] = await Promise.all([
  withLoading(() => fetchUser(), '사용자 정보'),
  withLoading(() => fetchProfile(), '프로필 정보'),
  withLoading(() => fetchSettings(), '설정 정보')
])
```

---

### 3.4 Router

페이지 네비게이션을 관리합니다.

#### 기본 네비게이션

```javascript
// 새 페이지로 이동
push('/detail-page')

// 현재 페이지 교체
replace('/another-page')

// 뒤로가기
back()

// 특정 페이지로 이동 (라우트명 또는 경로)
go('HOME')
go('/home')
```

#### 옵션을 사용한 네비게이션

```javascript
// 쿼리 파라미터와 함께 이동
push('/user-detail', {
  params: { id: '123' },
  query: { tab: 'profile' },
  hash: '#section1',
  direction: 'forward'
})

// 애니메이션 방향 옵션
// 'forward': 일반적인 진입 애니메이션 (기본값)
// 'back': 뒤로가기 애니메이션
// 'root': 네비게이션 스택 초기화
// 'none': 애니메이션 없음
```

#### URL 정보 조회

```javascript
// 쿼리 파라미터 조회
const query = getQuery()           // 전체 쿼리 객체
const tabValue = getQuery('tab')   // 특정 쿼리 값

// URL 파라미터 조회
const params = getParams()         // 전체 params 객체
const userId = getParams('id')     // 특정 param 값

// Hash 조회
const hash = getHash()             // 전체 hash 문자열
```

#### 네비게이션 타입 활용

```javascript
import { onIonViewWillEnter } from '@ionic/vue'

const { navigationType } = useApp()

onIonViewWillEnter(() => {
  switch (navigationType.value) {
    case 'push':
    case 'replace':
    case 'initial':
      // 새로운 페이지 진입 시 데이터 로드
      fetchData()
      break

    case 'back':
      // 뒤로가기로 돌아온 경우 캐시된 데이터 사용
      console.log('캐시된 데이터를 사용합니다')
      break
  }
})
```

---

### 3.5 Modal

모달 다이얼로그를 관리합니다.

#### 기본 사용법

```javascript
// 기본 모달 열기
const result = await openModal(UserDetailComponent, {
  props: { userId: 123 },
  cssClass: ['custom-modal']
})

if (result.result) {
  console.log('모달이 성공적으로 닫혔습니다:', result.data)
}
```

#### Sheet Modal

```javascript
// Bottom Sheet 스타일 모달
const result = await openModal(SettingsComponent, {
  props: { settings: currentSettings },
  initialBreakpoint: 0.8,
  breakpoints: [0, 0.5, 0.8, 1],
  showHandle: true
}, 'sheet') // 세 번째 파라미터로 모달 타입 지정
```

#### 모달 닫기

```javascript
// 모달 내부에서 닫기
closeModal(true, { saved: true })

// 또는 컴포넌트에서 직접 닫기
const { closeModal } = useApp()
closeModal()
```

#### 백버튼 처리

```javascript
// 모달 내부 컴포넌트에서 백버튼 핸들러 등록
const { onModalBack } = useApp()

onMounted(() => {
  onModalBack(async () => {
    if (hasUnsavedChanges()) {
      const confirmed = await confirm('저장하지 않고 나가시겠습니까?')
      return confirmed
    }
    return true // 바로 닫기
  })
})
```

---

### 3.6 Menu

사이드 메뉴를 제어합니다.

#### 템플릿 준비

```vue
<template>
  <!-- 메뉴 정의 -->
  <ion-menu menu-id="main-menu" content-id="main-content">
    <ion-header>
      <ion-toolbar>
        <ion-title>Menu</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content>
      <!-- 메뉴 내용 -->
    </ion-content>
  </ion-menu>

  <!-- 메인 컨텐츠 -->
  <ion-router-outlet id="main-content"></ion-router-outlet>
</template>
```

#### 메뉴 제어

```javascript
// 기본 메뉴 제어
await openMenu()
await closeMenu()
await toggleMenu()

// 특정 메뉴 제어 (여러 메뉴 사용 시)
await openMenu('sidebar')
await toggleMenu('sidebar')

// 메뉴 상태 확인
const isOpen = await isMenuOpen('main-menu')
console.log('메뉴 열림 상태:', isOpen)
```

---

### 3.7 ActionSheet

사용자에게 선택 옵션을 제시하는 액션시트를 표시합니다.

#### 기본 사용법

```javascript
const result = await openActionSheet([
  { text: '편집', value: 'edit' },
  { text: '삭제', value: 'delete', role: 'destructive' },
  { text: '취소', role: 'cancel' }
])

if (result.value === 'edit') {
  // 편집 로직
} else if (result.value === 'delete') {
  // 삭제 로직
}
```

#### 줄바꿈 지원

```javascript
await openActionSheet([
  { text: '상세 보기\n전체 정보', value: 'detail' },
  { text: '간단 보기\n요약만', value: 'summary' }
])
```

---

### 3.8 백버튼 처리

하드웨어 백버튼과 브라우저 뒤로가기를 통합 관리합니다.

#### 페이지별 백버튼 핸들러

```javascript
const { onPageBack } = useApp()

onMounted(() => {
  onPageBack(async () => {
    if (hasUnsavedData()) {
      const confirmed = await confirm('저장하지 않고 나가시겠습니까?')
      return confirmed
    }
    return true // 기본 뒤로가기 실행
  })
})
```

#### 모달 내 백버튼 핸들러

```javascript
const { onModalBack } = useApp()

onMounted(() => {
  onModalBack(async () => {
    // 모달별 백버튼 로직
    return await validateAndClose()
  })
})
```

#### 핸들러 제거

```javascript
// 특정 핸들러 제거
const removeHandler = onPageBack(() => { /* 핸들러 */ })
removeHandler()

// 모든 핸들러 제거
clearAllBack()
```

---

## 4. 스토어

간단한 key-value 저장소를 제공합니다.

### 4.1 useAppStore

```javascript
import { useAppStore } from '@bizMOB/vue'

const appStore = useAppStore()

// 메모리 저장 (기본)
appStore.set('key', 'value')
const value = appStore.get('key')

// localStorage (암호화)
appStore.local.set('userToken', token)
const token = appStore.local.get('userToken')

// sessionStorage (암호화)
appStore.session.set('tempData', data)

// Properties (앱 내부)
appStore.properties.set('appConfig', config)

// 유틸리티 메서드
appStore.has('key')          // 키 존재 여부
appStore.keys()              // 모든 키 목록
appStore.getAll()            // 모든 데이터
appStore.remove('key')       // 키 삭제
appStore.clear()             // 전체 삭제
```

### 4.2 useLoadingStore

로딩 상태를 관리하는 전용 스토어입니다. (내부적으로 사용됨)

---

## 5. 플러그인

### 5.1 ionicPlugin

Ionic Vue 플러그인을 설정합니다.

### 5.2 bizMOBPlugin

bizMOB 환경 설정을 초기화합니다.

### 5.3 createCryptoStorage

암호화된 저장소를 생성합니다.

```javascript
import { createCryptoStorage } from '@bizMOB/vue'

const secureStorage = createCryptoStorage(localStorage, {
  secretKey: 'your-secret-key'
})

secureStorage.setItem('data', JSON.stringify(sensitiveData))
```

---

## 6. 실전 사용 예시

### 6.1 데이터 저장 화면

```javascript
<script setup>
import { ref } from 'vue'
import { useApp } from '@bizMOB/vue'

const { alert, confirm, toast, withLoading, onPageBack } = useApp()

const formData = ref({
  name: '',
  email: ''
})
const hasChanges = ref(false)

// 저장 함수
const saveData = async () => {
  const result = await withLoading(async () => {
    // API 호출
    await fetch('/api/save', {
      method: 'POST',
      body: JSON.stringify(formData.value)
    })
  }, '저장 중...')

  await toast('저장되었습니다')
  hasChanges.value = false
}

// 삭제 함수
const deleteData = async () => {
  const confirmed = await confirm({
    title: '삭제 확인',
    message: '정말 삭제하시겠습니까?\n삭제된 데이터는 복구할 수 없습니다'
  })

  if (confirmed) {
    await withLoading(() => fetch('/api/delete', { method: 'DELETE' }))
    await alert('삭제되었습니다')
  }
}

// 백버튼 처리
onMounted(() => {
  onPageBack(async () => {
    if (hasChanges.value) {
      return await confirm('저장하지 않고 나가시겠습니까?')
    }
    return true
  })
})

// 폼 변경 감지
watch(formData, () => {
  hasChanges.value = true
}, { deep: true })
</script>
```

### 6.2 설정 모달

```javascript
<script setup>
// SettingsModal.vue
import { ref } from 'vue'
import { useApp } from '@bizMOB/vue'

const { closeModal, onModalBack, confirm } = useApp()

const settings = ref({
  theme: 'light',
  notifications: true
})
const originalSettings = ref({ ...settings.value })

const hasChanges = computed(() => {
  return JSON.stringify(settings.value) !== JSON.stringify(originalSettings.value)
})

// 저장 및 닫기
const saveAndClose = async () => {
  await saveSettings()
  closeModal(true, settings.value)
}

// 백버튼 처리
onMounted(() => {
  onModalBack(async () => {
    if (hasChanges.value) {
      const result = await confirm('저장하지 않고 나가시겠습니까?')
      return result
    }
    return true
  })
})
</script>
```

### 6.3 메뉴가 있는 메인 화면

```javascript
<script setup>
import { useApp } from '@bizMOB/vue'

const { openMenu, push, openActionSheet } = useApp()

const navigateToPage = (route) => {
  push(route, { direction: 'forward' })
}

const showOptions = async () => {
  const result = await openActionSheet([
    { text: '설정', value: 'settings', icon: 'settings-outline' },
    { text: '도움말', value: 'help', icon: 'help-circle-outline' },
    { text: '로그아웃', value: 'logout', role: 'destructive' }
  ])

  switch (result.value) {
    case 'settings':
      navigateToPage('/settings')
      break
    case 'help':
      navigateToPage('/help')
      break
    case 'logout':
      handleLogout()
      break
  }
}
</script>

<template>
  <ion-menu menu-id="main-menu" content-id="main-content">
    <ion-header>
      <ion-toolbar>
        <ion-title>메뉴</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content>
      <ion-list>
        <ion-item @click="navigateToPage('/profile')">
          <ion-label>프로필</ion-label>
        </ion-item>
        <ion-item @click="navigateToPage('/settings')">
          <ion-label>설정</ion-label>
        </ion-item>
      </ion-list>
    </ion-content>
  </ion-menu>

  <div id="main-content">
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-button @click="openMenu()">
            <ion-icon name="menu-outline"></ion-icon>
          </ion-button>
        </ion-buttons>
        <ion-title>홈</ion-title>
        <ion-buttons slot="end">
          <ion-button @click="showOptions()">
            <ion-icon name="ellipsis-vertical"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content>
      <!-- 메인 컨텐츠 -->
    </ion-content>
  </div>
</template>
```

---

## 7. 추가 정보

### 7.1 주요 특징

- **통합 API**: `useApp()` 하나로 모든 기능 접근
- **TypeScript 지원**: 완전한 타입 안정성
- **줄바꿈 지원**: Alert, Toast, ActionSheet에서 `\n` 자동 변환
- **백버튼 통합**: 하드웨어 백버튼과 브라우저 뒤로가기 통합 처리
- **자동 리소스 관리**: 메모리 누수 방지를 위한 자동 정리
- **동시 요청 최적화**: 중복 로딩, 중첩 모달 등 안전 처리

### 7.2 성능 최적화

- **싱글톤 패턴**: 로딩 매니저 등 전역 인스턴스 관리
- **Debounce 패턴**: 연속 호출 시 깜빡임 방지
- **WeakMap 활용**: 메모리 누수 방지
- **지연 해제**: 100ms 지연으로 연속 API 호출 최적화

### 7.3 호환성

- Vue 3.x + Composition API
- Ionic Vue 7.x+
- TypeScript 5.x+
- Vite 기반 빌드 시스템
