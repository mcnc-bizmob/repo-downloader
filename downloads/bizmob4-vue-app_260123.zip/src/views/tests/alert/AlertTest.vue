<!--
=== AlertTest.vue ===
useApp.alert 컴포저블의 주요 기능 테스트 화면

** 테스트 범위 **
- 실제 구현: 기본 Alert, 기본 Confirm, 커스텀 옵션 Alert/Confirm (4개 핵심 기능)
- 주석 설명: 나머지 고급 기능들의 테스트 케이스
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>Alert & Confirm 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">

        <h1>Alert & Confirm 기능 테스트</h1>
        <p class="test-description">
          브라우저 개발자 도구의 Console에서 테스트 결과를 확인하세요.
        </p>

        <!-- 핵심 기능 테스트 버튼들 -->
        <div class="test-section">
          <h2>핵심 기능 테스트</h2>

          <div class="button-group">
            <button @click="testBasicAlert" class="test-button">
              기본 Alert 테스트
            </button>

            <button @click="testBasicConfirm" class="test-button">
              기본 Confirm 테스트
            </button>

            <button @click="testCustomAlert" class="test-button">
              커스텀 Alert 테스트
            </button>

            <button @click="testCustomConfirm" class="test-button">
              커스텀 Confirm 테스트
            </button>
          </div>
        </div>

        <!-- 테스트 안내 -->
        <div class="test-guide">
          <h3>테스트 방법</h3>
          <ul>
            <li>각 버튼을 클릭하여 해당 기능을 테스트하세요</li>
            <li>Alert/Confirm 창이 나타나면 상호작용해보세요</li>
            <li>Console에서 결과 로그를 확인하세요</li>
            <li>다양한 옵션들의 동작을 확인해보세요</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';

// bizMOB.vue 통합 API에서 Alert 기능들 가져오기
const { alert, confirm, back } = useApp();

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

/*
=== 핵심 기능 테스트 구현 ===
*/

// 1. 기본 Alert 테스트
const testBasicAlert = async () => {
  console.log('%c📋 기본 Alert 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await alert('저장되었습니다.');
    console.log('%c✅ 기본 Alert 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', { result });
  } catch (error) {
    console.log('%c❌ 기본 Alert 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 2. 기본 Confirm 테스트
const testBasicConfirm = async () => {
  console.log('%c📋 기본 Confirm 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await confirm('정말 삭제하시겠습니까?');
    console.log('%c✅ 기본 Confirm 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      result: result,
      message: result ? '사용자가 확인을 선택했습니다' : '사용자가 취소를 선택했습니다'
    });
  } catch (error) {
    console.log('%c❌ 기본 Confirm 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 3. 커스텀 Alert 테스트
const testCustomAlert = async () => {
  console.log('%c📋 커스텀 Alert 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await alert({
      title: '알림',
      message: '파일 업로드가 완료되었습니다.\n총 3개의 파일이 업로드되었습니다.',
      buttons: [
        {
          text: '확인했습니다',
          handler: () => {
            console.log('%c📋 커스텀 버튼 핸들러 실행됨', 'color: blue; font-weight: bold;');
            return true;
          }
        }
      ],
      style: {
        titleAlign: 'center',
        textAlign: 'left',
        cssClass: 'custom-alert'
      },
      preventBackButton: false
    });

    console.log('%c✅ 커스텀 Alert 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', { result });
  } catch (error) {
    console.log('%c❌ 커스텀 Alert 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 4. 커스텀 Confirm 테스트
const testCustomConfirm = async () => {
  console.log('%c📋 커스텀 Confirm 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await confirm({
      title: '로그아웃',
      message: '정말 로그아웃 하시겠습니까?\n현재 작업 중인 내용이 저장되지 않을 수 있습니다.',
      buttons: [
        {
          text: '취소',
          handler: () => {
            console.log('%c📋 취소 버튼 핸들러 실행됨', 'color: blue; font-weight: bold;');
            return false;
          }
        },
        {
          text: '로그아웃',
          handler: () => {
            console.log('%c📋 로그아웃 버튼 핸들러 실행됨', 'color: blue; font-weight: bold;');
            return true;
          }
        }
      ],
      style: {
        titleAlign: 'center',
        textAlign: 'center',
        cssClass: 'logout-confirm'
      },
      preventBackButton: true
    });

    console.log('%c✅ 커스텀 Confirm 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      result: result,
      action: result ? '로그아웃 진행' : '로그아웃 취소'
    });
  } catch (error) {
    console.log('%c❌ 커스텀 Confirm 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== 추가 테스트 필요한 기능들 ===

1. 줄바꿈 포함 메시지 테스트:
   - 테스트 케이스: 메시지에 \n이 포함된 Alert/Confirm 표시
   - 확인 포인트: \n이 <br> 태그로 정확히 변환되어 줄바꿈 표시되는지
   - 예상 결과: 메시지가 여러 줄로 표시됨

2. 핸들러 함수 입력 테스트:
   - 테스트 케이스: alert('메시지', handlerFunction) 형태로 호출
   - 확인 포인트: 핸들러 함수가 정상적으로 실행되는지
   - 예상 결과: 확인 버튼 클릭 시 핸들러 함수 호출됨

3. preventBackButton 동작 테스트:
   - 테스트 케이스: preventBackButton: true 설정 후 하드웨어 백버튼 테스트
   - 확인 포인트: 백버튼이 실제로 차단되는지 확인
   - 예상 결과: 백버튼 눌러도 Alert가 닫히지 않음

4. Default 설정 변경 테스트:
   - 테스트 케이스: setAlertDefaults()로 기본값 변경 후 Alert 호출
   - 확인 포인트: 변경된 기본값이 적용되는지
   - 예상 결과: 설정한 기본값으로 Alert 표시됨

5. 스타일 옵션 테스트:
   - 테스트 케이스: titleAlign, textAlign, cssClass 등 다양한 조합
   - 확인 포인트: 각 스타일 옵션이 올바르게 적용되는지
   - 예상 결과: 지정한 정렬과 CSS 클래스가 적용됨

6. 에러 상황 테스트:
   - 테스트 케이스: 잘못된 옵션이나 핸들러에서 에러 발생
   - 확인 포인트: 에러가 적절히 처리되는지
   - 예상 결과: Console에 에러 로그 출력, 기본값으로 동작

7. WeakMap 백버튼 설정 관리 테스트:
   - 테스트 케이스: 여러 Alert를 연속으로 표시하며 각각 다른 백버튼 설정
   - 확인 포인트: 각 Alert의 백버튼 설정이 독립적으로 관리되는지
   - 예상 결과: 각 Alert마다 설정된 백버튼 동작이 다르게 적용됨

8. 중첩 Alert 처리 테스트:
   - 테스트 케이스: Alert 표시 중에 또 다른 Alert 호출
   - 확인 포인트: 중첩 상황에서의 동작 확인
   - 예상 결과: 적절한 처리 또는 에러 핸들링
*/
</script>

<style scoped lang="scss">
// ============================================================================
// 🚨 Alert 컴포넌트 스타일 변경 샘플
//   * 주의사항: alert 스타일은 scoped가 없어야 됨
// ============================================================================
// .sc-ion-alert-md {
//   &.alert-wrapper {
//     border-radius: 20px;
//     width: calc(100% - 32px);
//   }

//   &.alert-head {
//     padding: 36px 44px 24px;
//   }

//   &.alert-message {
//     padding: 60px 44px 24px;
//     font-size: 14px;
//     line-height: 20px;
//     font-weight: bold;
//     color: #4d4d4d;

//     &~.alert-button-group.sc-ion-alert-md {
//       padding-top: 0;
//     }

//     .text-warning {
//       color: #eb4e40;
//     }
//   }

//   &.alert-button-group {
//     column-gap: 8px;
//     padding: 24px 44px 42px;
//   }

//   &.alert-button {
//     flex: 1;
//     border-radius: 5px;
//     padding: 12px;
//     margin: 0;
//     font-size: 16px;
//     line-height: 20px;
//     font-weight: medium;
//     color: #fff;

//     &,
//     &.ion-focused {
//       background-color: #2f4592;
//     }
//   }

//   &.alert-button-line {
//     background-color: transparent;
//     color: #2f4592;
//     border: 1px solid #2f4592;
//   }

//   &.alert-button-inner {
//     text-transform: math-auto;
//     justify-content: center;
//   }
// }

// ============================================================================
// 화면 스타일
// ============================================================================
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.back-link {
  margin-bottom: 20px;
}

.back-button {
  --color: #007bff;
  --padding-start: 0;
  --padding-end: 0;
  margin: 0;
  font-weight: 500;
  text-decoration: none;
}

.back-button:hover {
  --color: #0056b3;
  text-decoration: underline;
}

.test-container h1 {
  color: #333;
  margin-bottom: 10px;
}

.test-description {
  color: #666;
  margin-bottom: 30px;
  font-style: italic;
}

.test-section {
  margin-bottom: 30px;
}

.test-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #007bff;
  padding-bottom: 5px;
}

.button-group {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
}

.test-button {
  padding: 12px 20px;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.test-button:hover {
  background: #0056b3;
}

.test-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
}

.test-guide h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.test-guide ul {
  margin: 0;
  padding-left: 20px;
}

.test-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>