<!--
=== MenuTest.vue ===
useApp.menu 컴포저블의 메인 테스트 화면

** 구성 **
- MenuComponent 컴포넌트 import (실제 ion-menu 포함)
- Menu 열기 기능만 제공
- 컴포저블 기능 테스트
-->

<template>
  <!-- 실제 구현은 App.vue 에 있음 -->
  <!-- !! 구현시 ion-router 태그와 같은 레벨에 있어야 함 -->
  <!--
  <ion-menu menu-id="main-menu" content-id="main-content" type="overlay">
    <MenuComponent />
  </ion-menu>
  -->

  <!-- 메인 테스트 화면 -->
  <ion-page id="main-content">
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>Menu 테스트</ion-title>
        <ion-buttons slot="end">
          <ion-button @click="testOpenMenu">
            <ion-icon :icon="menu"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">

        <h1>Menu 기능 테스트</h1>
        <p class="test-description">
          Menu 열기 기능을 테스트할 수 있는 메인 화면입니다.<br>
          브라우저 개발자 도구의 Console에서 테스트 결과를 확인하세요.
        </p>

        <!-- 컴포저블 기능 테스트 버튼들 -->
        <div class="test-section">
          <h2>🧪 컴포저블 기능 테스트</h2>

          <div class="button-group">
            <button @click="testOpenMenu" class="test-button">
              Menu 열기 테스트
            </button>

            <button @click="testMenuStatus" class="test-button">
              Menu 상태 확인 테스트
            </button>
          </div>
        </div>

        <!-- 실제 프로젝트 적용 안내 -->
        <div class="implementation-guide">
          <h3>실제 프로젝트에서 Menu 사용하기</h3>
          <div class="code-example">
            <pre><code>&lt;template&gt;
  &lt;ion-menu menu-id="main-menu" content-id="main-content"&gt;
    &lt;ion-header&gt;
      &lt;ion-toolbar&gt;
        &lt;ion-title&gt;Menu&lt;/ion-title&gt;
      &lt;/ion-toolbar&gt;
    &lt;/ion-header&gt;
    &lt;ion-content&gt;
      &lt;!-- 메뉴 내용 --&gt;
    &lt;/ion-content&gt;
  &lt;/ion-menu&gt;

  &lt;ion-router-outlet id="main-content"&gt;&lt;/ion-router-outlet&gt;
&lt;/template&gt;</code></pre>
          </div>
        </div>

        <!-- 테스트 안내 -->
        <div class="test-guide">
          <h3>테스트 방법</h3>
          <ul>
            <li>헤더 버튼이나 "메뉴 열기" 버튼을 클릭하여 Menu를 열어보세요</li>
            <li>Menu가 열리면 MenuComponent에서 닫기 및 페이지 이동을 테스트할 수 있습니다</li>
            <li>Console에서 결과 로그를 확인하세요</li>
            <li>각 테스트 버튼으로 컴포저블 기능을 확인하세요</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton,
  IonButton,
  IonIcon
} from '@ionic/vue';
import { useIonRouter } from '@ionic/vue';
import { menu } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';
// import MenuComponent from './MenuComponent.vue';

// bizMOB.vue 통합 API에서 Menu 기능들 가져오기
const {
  openMenu,
  isMenuOpen,
  back
} = useApp();

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

/*
=== 컴포저블 기능 테스트 구현 ===
*/

// 1. Menu 열기 테스트
const testOpenMenu = async () => {
  console.log('%c📋 Menu 열기 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openMenu('main-menu');
    console.log('%c✅ Menu 열기 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      success: result,
      menuId: 'main-menu'
    });
  } catch (error) {
    console.log('%c❌ Menu 열기 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 2. Menu 상태 확인 테스트
const testMenuStatus = async () => {
  console.log('%c📋 Menu 상태 확인 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    // 기본 Menu 상태 확인
    const isOpen = await isMenuOpen('main-menu');

    console.log('%c✅ Menu 상태 확인 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      isOpen,
      menuId: 'main-menu'
    });

  } catch (error) {
    console.log('%c❌ Menu 상태 확인 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};
</script>

<style scoped>
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.back-link {
  margin-bottom: 20px;
}

.back-button {
  --color: #007bff;
  --padding-start: 0;
  --padding-end: 0;
  margin: 0;
  font-weight: 500;
  text-decoration: none;
}

.back-button:hover {
  --color: #0056b3;
  text-decoration: underline;
}

.test-container h1 {
  color: #333;
  margin-bottom: 10px;
}

.test-description {
  color: #666;
  margin-bottom: 30px;
  font-style: italic;
}

.test-section {
  margin-bottom: 30px;
}

.test-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #007bff;
  padding-bottom: 5px;
}

.button-group {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
}

.test-button {
  padding: 12px 20px;
  background: #6f42c1;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.test-button:hover {
  background: #5a379a;
}

.implementation-guide {
  background: #e7f3ff;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #007bff;
  margin-bottom: 30px;
}

.implementation-guide h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.code-example {
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  padding: 15px;
  overflow-x: auto;
}

.code-example pre {
  margin: 0;
  white-space: pre-wrap;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
  line-height: 1.4;
}

.test-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
}

.test-guide h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.test-guide ul {
  margin: 0;
  padding-left: 20px;
}

.test-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}

/* Menu 제어 섹션 스타일 */
.menu-control-section {
  background: #f0fff0;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
  margin-bottom: 30px;
}

.menu-control-section h2 {
  color: #333;
  margin: 0 0 10px 0;
  border: none;
  padding: 0;
}

.menu-control-section p {
  color: #555;
  margin: 0 0 15px 0;
  line-height: 1.5;
}

.control-button-group {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 12px;
}

.control-button {
  padding: 12px 20px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
  font-size: 0.95em;
}

.control-button.open-button {
  background: #28a745;
  color: white;
}

.control-button.open-button:hover {
  background: #218838;
}

.control-button.status-button {
  background: #17a2b8;
  color: white;
}

.control-button.status-button:hover {
  background: #138496;
}
</style>