<!--
=== MenuTarget.vue ===
Menu Target 페이지 - 메뉴에서 이동하는 타겟 페이지

** 구성 **
- 화면 뒤로가기 기능만 제공
- Menu 이동 테스트 확인용 페이지
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-button @click="goBack">
            <ion-icon :icon="arrowBack"></ion-icon>
          </ion-button>
        </ion-buttons>
        <ion-title>Menu Target</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="target-container">
        <div class="back-link">
          <button @click="goBack" class="back-button">
            ← MenuTest로 돌아가기
          </button>
        </div>

        <div class="success-section">
          <div class="success-icon">✅</div>
          <h1>Menu 이동 성공!</h1>
          <p class="success-description">
            MenuComponent에서 이 페이지로 성공적으로 이동했습니다.<br>
            메뉴가 자동으로 닫히고 페이지 이동이 완료되었습니다.
          </p>
        </div>

        <div class="info-section">
          <h2>📋 페이지 정보</h2>
          <div class="info-card">
            <div class="info-item">
              <span class="info-label">현재 경로:</span>
              <span class="info-value">/tests/menu/target</span>
            </div>
            <div class="info-item">
              <span class="info-label">이전 페이지:</span>
              <span class="info-value">/tests/menu (MenuTest)</span>
            </div>
            <div class="info-item">
              <span class="info-label">이동 방식:</span>
              <span class="info-value">Menu 항목 클릭 → 메뉴 닫기 → 페이지 이동</span>
            </div>
          </div>
        </div>

        <div class="test-results-section">
          <h2>🧪 테스트 결과</h2>
          <div class="test-results">
            <div class="test-result-item success">
              <div class="result-icon">✅</div>
              <div class="result-text">
                <div class="result-title">Menu 닫기</div>
                <div class="result-description">메뉴가 성공적으로 닫혔습니다</div>
              </div>
            </div>

            <div class="test-result-item success">
              <div class="result-icon">✅</div>
              <div class="result-text">
                <div class="result-title">페이지 이동</div>
                <div class="result-description">Target 페이지로 성공적으로 이동했습니다</div>
              </div>
            </div>

            <div class="test-result-item success">
              <div class="result-icon">✅</div>
              <div class="result-text">
                <div class="result-title">라우터 연동</div>
                <div class="result-description">Vue Router가 정상적으로 동작했습니다</div>
              </div>
            </div>
          </div>
        </div>

        <div class="navigation-section">
          <h2>🧭 탐색</h2>
          <div class="navigation-buttons">
            <button @click="goBack" class="nav-button primary">
              ← MenuTest로 돌아가기
            </button>
          </div>
        </div>

        <!-- Console 확인 안내 -->
        <div class="console-guide">
          <h3>💡 Console 확인</h3>
          <p>
            브라우저 개발자 도구의 Console에서 Menu 이동 과정의 상세 로그를 확인할 수 있습니다.<br>
            메뉴 닫기와 페이지 이동의 각 단계가 기록되어 있습니다.
          </p>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton,
  IonButton,
  IonIcon
} from '@ionic/vue';
import { arrowBack } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';

const { back } = useApp();

/*
=== 내비게이션 함수들 ===
*/

// MenuTest로 뒤로가기
const goBack = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  console.log('%c🔙 MenuTest로 뒤로가기', 'color: blue; font-weight: bold;');
  back();
};

// 페이지 로드 시 성공 메시지 출력
console.log('%c🎯 MenuTarget 페이지 로드 완료', 'color: green; font-weight: bold;');
console.log('%c📍 현재 위치: /tests/menu/target', 'color: purple; font-weight: bold;');
</script>

<style scoped>
.target-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.back-link {
  margin-bottom: 30px;
}

.back-button {
  background: #007bff;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.back-button:hover {
  background: #0056b3;
}

.success-section {
  text-align: center;
  background: linear-gradient(135deg, #28a745, #20c997);
  color: white;
  padding: 40px 20px;
  border-radius: 12px;
  margin-bottom: 30px;
}

.success-icon {
  font-size: 4em;
  margin-bottom: 16px;
}

.success-section h1 {
  margin: 0 0 16px 0;
  font-size: 2.2em;
  font-weight: 600;
}

.success-description {
  margin: 0;
  font-size: 1.1em;
  opacity: 0.95;
  line-height: 1.6;
}

.info-section {
  margin-bottom: 30px;
}

.info-section h2 {
  color: #333;
  margin-bottom: 16px;
  border-bottom: 2px solid #007bff;
  padding-bottom: 8px;
}

.info-card {
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 20px;
}

.info-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px solid #e9ecef;
}

.info-item:last-child {
  border-bottom: none;
}

.info-label {
  font-weight: 600;
  color: #495057;
}

.info-value {
  color: #007bff;
  font-family: monospace;
  background: #e7f3ff;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 0.9em;
}

.test-results-section {
  margin-bottom: 30px;
}

.test-results-section h2 {
  color: #333;
  margin-bottom: 16px;
  border-bottom: 2px solid #28a745;
  padding-bottom: 8px;
}

.test-results {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.test-result-item {
  display: flex;
  align-items: center;
  background: #f8f9fa;
  padding: 16px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
}

.result-icon {
  font-size: 1.5em;
  margin-right: 16px;
}

.result-text {
  flex: 1;
}

.result-title {
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
}

.result-description {
  color: #666;
  font-size: 0.9em;
}

.navigation-section {
  margin-bottom: 30px;
}

.navigation-section h2 {
  color: #333;
  margin-bottom: 16px;
  border-bottom: 2px solid #6c757d;
  padding-bottom: 8px;
}

.navigation-buttons {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 16px;
}

.nav-button {
  padding: 14px 24px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  font-size: 1em;
  transition: all 0.2s ease;
}

.nav-button.primary {
  background: #007bff;
  color: white;
}

.nav-button.primary:hover {
  background: #0056b3;
  transform: translateY(-1px);
}

.nav-button.secondary {
  background: #6c757d;
  color: white;
}

.nav-button.secondary:hover {
  background: #545b62;
  transform: translateY(-1px);
}

.console-guide {
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 20px;
  border-left: 4px solid #ffc107;
}

.console-guide h3 {
  margin: 0 0 12px 0;
  color: #856404;
}

.console-guide p {
  margin: 0;
  color: #856404;
  line-height: 1.6;
}

@media (max-width: 768px) {
  .target-container {
    padding: 16px;
  }

  .success-section {
    padding: 30px 16px;
  }

  .success-section h1 {
    font-size: 1.8em;
  }

  .navigation-buttons {
    grid-template-columns: 1fr;
  }

  .info-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
  }
}
</style>