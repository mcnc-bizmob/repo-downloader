<!--
=== MenuComponent.vue ===
Menu 컴포넌트 - 메뉴 닫기와 페이지 이동 기능

** 구성 **
- ion-menu 태그를 포함한 실제 메뉴 컴포넌트
- 메뉴 닫기 기능
- MenuTarget 페이지로 이동하면서 메뉴 닫기
-->

<template>
  <ion-header>
    <ion-toolbar color="primary">
      <ion-title>테스트 메뉴</ion-title>
      <ion-buttons slot="end">
        <ion-button @click="testMenuClose">
          <ion-icon :icon="close"></ion-icon>
        </ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>

  <ion-content>
    <div class="menu-content">
      <div class="menu-header">
        <h2>🧪 Menu 테스트</h2>
        <p>메뉴 기능을 테스트해보세요</p>
      </div>

      <div class="menu-actions">
        <div class="menu-item" @click="testMenuClose">
          <ion-icon :icon="checkmark" class="menu-icon"></ion-icon>
          <div class="menu-text">
            <div class="menu-title">메뉴 닫기 테스트</div>
            <div class="menu-subtitle">Console에서 결과 확인</div>
          </div>
        </div>

        <div class="menu-item" @click="testMenuStatus">
          <ion-icon :icon="informationCircle" class="menu-icon"></ion-icon>
          <div class="menu-text">
            <div class="menu-title">메뉴 상태 확인</div>
            <div class="menu-subtitle">현재 메뉴 상태를 확인합니다</div>
          </div>
        </div>

        <!-- MenuTarget으로 이동 -->
        <div class="menu-item" @click="navigateToTarget">
          <ion-icon :icon="navigate" class="menu-icon"></ion-icon>
          <div class="menu-text">
            <div class="menu-title">Target 페이지로 이동</div>
            <div class="menu-subtitle">메뉴를 닫고 Target 페이지로 이동합니다</div>
          </div>
        </div>
      </div>

      <!-- 메뉴 정보 -->
      <div class="menu-info">
        <h3>📋 메뉴 정보</h3>
        <ul>
          <li><strong>Menu ID:</strong> main-menu</li>
          <li><strong>Content ID:</strong> main-content</li>
          <li><strong>Type:</strong> overlay</li>
        </ul>
      </div>
    </div>
  </ion-content>
</template>

<script setup lang="ts">
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonButton,
  IonIcon
} from '@ionic/vue';
import { useIonRouter } from '@ionic/vue';
import {
  close,
  navigate,
  checkmark,
  informationCircle
} from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';

const ionRouter = useIonRouter();

// bizMOB.vue 통합 API에서 Menu 기능들 가져오기
const {
  closeMenu,
  isMenuOpen
} = useApp();

/*
=== Menu 제어 함수들 ===
*/

// MenuTarget으로 이동하면서 메뉴 닫기
const navigateToTarget = async () => {
  console.log('%c🎮 MenuTarget으로 이동 (메뉴 닫기 포함)', 'color: green; font-weight: bold;');

  try {
    // 먼저 메뉴를 닫고
    const closeResult = await closeMenu('main-menu');
    console.log('%c📊 메뉴 닫기 결과:', 'color: purple; font-weight: bold;', { success: closeResult });

    // MenuTarget 페이지로 이동
    // FIXME push 시 useApp에서 제공하는 push 또는 프로젝트에서 직접 구현한 push를 호출해야 함
    await ionRouter.push('/tests/menu/target');
    console.log('%c📊 페이지 이동 완료:', 'color: blue; font-weight: bold;', { route: '/tests/menu/target' });

  } catch (error) {
    console.log('%c❌ 이동 중 에러 발생', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== 테스트 함수들 ===
*/

// 메뉴 닫기 테스트
const testMenuClose = async () => {
  console.log('%c📋 Menu 닫기 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await closeMenu('main-menu');
    console.log('%c✅ Menu 닫기 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      success: result,
      menuId: 'main-menu'
    });
  } catch (error) {
    console.log('%c❌ Menu 닫기 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 메뉴 상태 확인 테스트
const testMenuStatus = async () => {
  console.log('%c📋 Menu 상태 확인 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const isOpen = await isMenuOpen('main-menu');
    console.log('%c✅ Menu 상태 확인 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      isOpen,
      menuId: 'main-menu'
    });
  } catch (error) {
    console.log('%c❌ Menu 상태 확인 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};
</script>

<style scoped>
.menu-content {
  padding: 0;
}

.menu-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 20px;
  text-align: center;
}

.menu-header h2 {
  margin: 0 0 8px 0;
  font-size: 1.4em;
  font-weight: 600;
}

.menu-header p {
  margin: 0;
  opacity: 0.9;
  font-size: 0.9em;
}

.menu-actions {
  padding: 16px 0;
}

.menu-item {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  cursor: pointer;
  transition: background-color 0.2s ease;
  border-bottom: 1px solid #f0f0f0;
}

.menu-item:hover {
  background-color: #f8f9fa;
}

.menu-item:last-child {
  border-bottom: none;
}

.menu-icon {
  font-size: 1.5em;
  color: #666;
  margin-right: 16px;
  min-width: 24px;
}

.menu-text {
  flex: 1;
}

.menu-title {
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
  font-size: 1em;
}

.menu-subtitle {
  color: #666;
  font-size: 0.85em;
  line-height: 1.3;
}

.menu-divider {
  height: 1px;
  background: #e0e0e0;
  margin: 8px 20px;
}

.menu-info {
  background: #f8f9fa;
  padding: 20px;
  margin: 16px 20px;
  border-radius: 8px;
  border-left: 4px solid #007bff;
}

.menu-info h3 {
  margin: 0 0 12px 0;
  color: #333;
  font-size: 1.1em;
}

.menu-info ul {
  margin: 0;
  padding-left: 20px;
  color: #555;
}

.menu-info li {
  margin-bottom: 6px;
  font-size: 0.9em;
}

.menu-info strong {
  color: #333;
}
</style>