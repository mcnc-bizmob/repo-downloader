<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>App Store 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <!-- 스토리지 상태 표시 -->
      <div class="section">
        <h2>📊 스토리지 상태</h2>
        <div class="storage-status">
          <div class="storage-item">
            <span>메모리:</span>
            <ion-badge color="primary">{{ Object.keys(storageData.memory).length }}개</ion-badge>
          </div>
          <div class="storage-item">
            <span>로컬:</span>
            <ion-badge color="success">{{ Object.keys(storageData.local).length }}개</ion-badge>
          </div>
          <div class="storage-item">
            <span>세션:</span>
            <ion-badge color="warning">{{ Object.keys(storageData.session).length }}개</ion-badge>
          </div>
          <div class="storage-item">
            <span>Properties:</span>
            <ion-badge color="tertiary">{{ Object.keys(storageData.properties).length }}개</ion-badge>
          </div>
        </div>
      </div>

      <!-- 데이터 입력 -->
      <div class="section">
        <h2>💾 데이터 저장</h2>
        <div class="input-group">
          <ion-item>
            <ion-label position="stacked">키 (Key)</ion-label>
            <ion-input v-model="inputKey" placeholder="예: user_name" clear-input></ion-input>
          </ion-item>
          <ion-item>
            <ion-label position="stacked">값 (Value)</ion-label>
            <ion-input v-model="inputValue" placeholder="예: 홍길동" clear-input></ion-input>
          </ion-item>
          <ion-item>
            <ion-label>스토리지 타입</ion-label>
            <ion-select v-model="selectedStorage" placeholder="선택하세요">
              <ion-select-option value="memory">메모리</ion-select-option>
              <ion-select-option value="local">로컬</ion-select-option>
              <ion-select-option value="session">세션</ion-select-option>
              <ion-select-option value="properties">Properties</ion-select-option>
            </ion-select>
          </ion-item>
        </div>

        <div class="button-group">
          <ion-button @click="saveData" :disabled="!inputKey || !selectedStorage" expand="block">
            저장
          </ion-button>
          <ion-button @click="loadData" :disabled="!inputKey || !selectedStorage" fill="outline" expand="block">
            불러오기
          </ion-button>
          <ion-button @click="deleteData" :disabled="!inputKey || !selectedStorage" color="danger" fill="outline"
            expand="block">
            삭제
          </ion-button>
        </div>
      </div>

      <!-- 빠른 테스트 -->
      <div class="section">
        <h2>⚡ 빠른 테스트</h2>
        <div class="button-group">
          <ion-button @click="testAllStorages" color="tertiary" expand="block">
            모든 스토리지 테스트
          </ion-button>
          <ion-button @click="clearAllStorages" color="danger" fill="outline" expand="block">
            모든 데이터 삭제
          </ion-button>
        </div>
      </div>

      <!-- 저장된 데이터 표시 -->
      <div class="section">
        <h2>📋 저장된 데이터</h2>

        <!-- 메모리 -->
        <div class="storage-section" v-if="Object.keys(storageData.memory).length > 0">
          <h3>💻 메모리 ({{ Object.keys(storageData.memory).length }}개)</h3>
          <div class="data-list">
            <div v-for="key in Object.keys(storageData.memory)" :key="key" class="data-item">
              <span class="data-key">{{ key }}:</span>
              <span class="data-value">{{ formatValue(storageData.memory[key]) }}</span>
              <ion-button size="small" fill="clear" color="danger" @click="deleteSpecificData('memory', key)">
              </ion-button>
            </div>
          </div>
        </div>

        <!-- 로컬 -->
        <div class="storage-section" v-if="Object.keys(storageData.local).length > 0">
          <h3>🏠 로컬 ({{ Object.keys(storageData.local).length }}개)</h3>
          <div class="data-list">
            <div v-for="key in Object.keys(storageData.local)" :key="key" class="data-item">
              <span class="data-key">{{ key }}:</span>
              <span class="data-value">{{ formatValue(storageData.local[key]) }}</span>
              <ion-button size="small" fill="clear" color="danger" @click="deleteSpecificData('local', key)">
              </ion-button>
            </div>
          </div>
        </div>

        <!-- 세션 -->
        <div class="storage-section" v-if="Object.keys(storageData.session).length > 0">
          <h3>🕐 세션 ({{ Object.keys(storageData.session).length }}개)</h3>
          <div class="data-list">
            <div v-for="key in Object.keys(storageData.session)" :key="key" class="data-item">
              <span class="data-key">{{ key }}:</span>
              <span class="data-value">{{ formatValue(storageData.session[key]) }}</span>
              <ion-button size="small" fill="clear" color="danger" @click="deleteSpecificData('session', key)">
              </ion-button>
            </div>
          </div>
        </div>

        <!-- Properties -->
        <div class="storage-section" v-if="Object.keys(storageData.properties).length > 0">
          <h3>⚙️ Properties ({{ Object.keys(storageData.properties).length }}개)</h3>
          <div class="data-list">
            <div v-for="key in Object.keys(storageData.properties)" :key="key" class="data-item">
              <span class="data-key">{{ key }}:</span>
              <span class="data-value">{{ formatValue(storageData.properties[key]) }}</span>
              <ion-button size="small" fill="clear" color="danger" @click="deleteSpecificData('properties', key)">
              </ion-button>
            </div>
          </div>
        </div>

        <div v-if="isAllEmpty" class="empty-state">
          저장된 데이터가 없습니다
        </div>
      </div>

      <!-- 테스트 로그 -->
      <div class="section">
        <h2>📝 테스트 로그</h2>
        <div class="log-controls">
          <ion-button @click="clearLogs" color="medium" fill="clear" size="small">
            로그 지우기
          </ion-button>
        </div>
        <div class="log-container">
          <div v-for="(log, index) in logs" :key="index" class="log-item">
            {{ log }}
          </div>
          <div v-if="logs.length === 0" class="log-empty">
            로그가 없습니다
          </div>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonBadge,
  IonItem,
  IonLabel,
  IonInput,
  IonSelect,
  IonSelectOption,
  IonButtons,
  IonBackButton,
  toastController
} from '@ionic/vue';
import { useAppStore, useApp } from '@bizMOB/vue';

// App Store 사용
const appStore = useAppStore();
const { back } = useApp();

// 입력 데이터
const inputKey = ref('');
const inputValue = ref('');
const selectedStorage = ref<'memory' | 'local' | 'session' | 'properties'>('memory');

// 로그 데이터
const logs = ref<string[]>([]);

// 저장된 데이터 (반응형)
const storageData = ref({
  memory: {} as Record<string, any>,
  local: {} as Record<string, any>,
  session: {} as Record<string, any>,
  properties: {} as Record<string, any>
});

// 모든 스토리지가 비어있는지 확인
const isAllEmpty = computed(() => {
  const storages = [
    storageData.value.memory,
    storageData.value.local,
    storageData.value.session,
    storageData.value.properties
  ];
  return storages.every((storage: Record<string, any>) =>
    Object.keys(storage).length === 0
  );
});

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

// 로그 추가
const addLog = (message: string) => {
  const timestamp = new Date().toLocaleTimeString();
  logs.value.unshift(`[${timestamp}] ${message}`);
  console.log(`[AppStore Test] ${message}`);
};

// 토스트 표시
const showToast = async (message: string, color: string = 'success') => {
  const toast = await toastController.create({
    message,
    duration: 2000,
    color,
    position: 'bottom'
  });
  await toast.present();
};

// 값 포맷팅
const formatValue = (value: any): string => {
  if (typeof value === 'object') {
    return JSON.stringify(value);
  }
  return String(value);
};

// 스토리지 데이터 새로고침
const refreshStorageData = () => {
  storageData.value = {
    memory: appStore.getAll(),
    local: appStore.local.getAll(),
    session: appStore.session.getAll(),
    properties: appStore.properties.getAll()
  };
};

// 데이터 저장
const saveData = async () => {
  if (!inputKey.value || !selectedStorage.value) return;

  try {
    const key = inputKey.value.trim();
    const value = inputValue.value;

    // 숫자인지 확인하여 자동 변환
    const processedValue = !isNaN(Number(value)) && value !== '' ? Number(value) : value;

    switch (selectedStorage.value) {
      case 'memory':
        appStore.set(key, processedValue);
        break;
      case 'local':
        appStore.local.set(key, processedValue);
        break;
      case 'session':
        appStore.session.set(key, processedValue);
        break;
      case 'properties':
        appStore.properties.set(key, processedValue);
        break;
    }

    addLog(`✅ 저장 성공: ${selectedStorage.value}.${key} = ${formatValue(processedValue)}`);
    await showToast(`${selectedStorage.value}에 저장되었습니다`);

    refreshStorageData();

    // 입력 필드 초기화
    inputKey.value = '';
    inputValue.value = '';
  } catch (error) {
    addLog(`❌ 저장 실패: ${error}`);
    await showToast('저장에 실패했습니다', 'danger');
  }
};

// 데이터 불러오기
const loadData = async () => {
  if (!inputKey.value || !selectedStorage.value) return;

  try {
    const key = inputKey.value.trim();
    let value: any;

    switch (selectedStorage.value) {
      case 'memory':
        value = appStore.get(key);
        break;
      case 'local':
        value = appStore.local.get(key);
        break;
      case 'session':
        value = appStore.session.get(key);
        break;
      case 'properties':
        value = appStore.properties.get(key);
        break;
    }

    if (value !== undefined) {
      inputValue.value = formatValue(value);
      addLog(`✅ 불러오기 성공: ${selectedStorage.value}.${key} = ${formatValue(value)}`);
      await showToast('데이터를 불러왔습니다');
    } else {
      addLog(`❌ 불러오기 실패: ${selectedStorage.value}.${key} 키를 찾을 수 없음`);
      await showToast('해당 키를 찾을 수 없습니다', 'warning');
    }
  } catch (error) {
    addLog(`❌ 불러오기 실패: ${error}`);
    await showToast('불러오기에 실패했습니다', 'danger');
  }
};

// 데이터 삭제
const deleteData = async () => {
  if (!inputKey.value || !selectedStorage.value) return;

  try {
    const key = inputKey.value.trim();

    switch (selectedStorage.value) {
      case 'memory':
        appStore.remove(key);
        break;
      case 'local':
        appStore.local.remove(key);
        break;
      case 'session':
        appStore.session.remove(key);
        break;
      case 'properties':
        appStore.properties.remove(key);
        break;
    }

    addLog(`✅ 삭제 성공: ${selectedStorage.value}.${key}`);
    await showToast('데이터가 삭제되었습니다');

    refreshStorageData();

    // 입력 필드 초기화
    inputKey.value = '';
    inputValue.value = '';
  } catch (error) {
    addLog(`❌ 삭제 실패: ${error}`);
    await showToast('삭제에 실패했습니다', 'danger');
  }
};

// 특정 데이터 삭제
const deleteSpecificData = async (storageType: string, key: string) => {
  try {
    switch (storageType) {
      case 'memory':
        appStore.remove(key);
        break;
      case 'local':
        appStore.local.remove(key);
        break;
      case 'session':
        appStore.session.remove(key);
        break;
      case 'properties':
        appStore.properties.remove(key);
        break;
    }

    addLog(`✅ 삭제 성공: ${storageType}.${key}`);
    await showToast(`${key} 삭제됨`);
    refreshStorageData();
  } catch (error) {
    addLog(`❌ 삭제 실패: ${error}`);
    await showToast('삭제에 실패했습니다', 'danger');
  }
};

// 모든 스토리지 테스트
const testAllStorages = async () => {
  addLog('🧪 모든 스토리지 테스트 시작');

  const testData = {
    string: 'Hello World',
    number: 42,
    boolean: true,
    object: { name: '홍길동', age: 30 },
    array: [1, 2, 3, 'test']
  };

  try {
    // 각 스토리지에 테스트 데이터 저장
    const keys = Object.keys(testData);
    keys.forEach((key: string) => {
      const value = (testData as any)[key];
      appStore.set(`test_${key}`, value);
      appStore.local.set(`test_${key}`, value);
      appStore.session.set(`test_${key}`, value);
      appStore.properties.set(`test_${key}`, value);
    });

    addLog('✅ 테스트 데이터 저장 완료');

    // 데이터 검증
    let allPassed = true;
    keys.forEach((key: string) => {
      const originalValue = (testData as any)[key];
      const testKey = `test_${key}`;

      const memoryValue = appStore.get(testKey);
      const localValue = appStore.local.get(testKey);
      const sessionValue = appStore.session.get(testKey);
      const propertiesValue = appStore.properties.get(testKey);

      const values = [memoryValue, localValue, sessionValue, propertiesValue];
      const storageNames = ['memory', 'local', 'session', 'properties'];

      values.forEach((value, index) => {
        const matches = JSON.stringify(value) === JSON.stringify(originalValue);
        if (matches) {
          addLog(`✅ ${storageNames[index]}.${testKey} 검증 통과`);
        } else {
          addLog(`❌ ${storageNames[index]}.${testKey} 검증 실패`);
          allPassed = false;
        }
      });
    });

    if (allPassed) {
      addLog('🎉 모든 스토리지 테스트 통과!');
      await showToast('모든 테스트 통과!', 'success');
    } else {
      addLog('❌ 일부 테스트 실패');
      await showToast('일부 테스트 실패', 'warning');
    }

    refreshStorageData();
  } catch (error) {
    addLog(`❌ 테스트 실패: ${error}`);
    await showToast('테스트 실행 실패', 'danger');
  }
};

// 모든 데이터 삭제
const clearAllStorages = async () => {
  try {
    appStore.clear();
    appStore.local.clear();
    appStore.session.clear();
    appStore.properties.clear();

    addLog('🧹 모든 스토리지 데이터 삭제 완료');
    await showToast('모든 데이터가 삭제되었습니다');
    refreshStorageData();
  } catch (error) {
    addLog(`❌ 삭제 실패: ${error}`);
    await showToast('삭제에 실패했습니다', 'danger');
  }
};

// 로그 지우기
const clearLogs = () => {
  logs.value = [];
  addLog('🧹 로그 초기화');
};

// 컴포넌트 마운트시 데이터 로드
onMounted(() => {
  addLog('📱 App Store 테스트 페이지 로드됨');
  refreshStorageData();
});
</script>

<style scoped>
.section {
  margin-bottom: 2rem;
}

.section h2 {
  font-size: 1.2rem;
  margin-bottom: 1rem;
  color: #333;
  border-bottom: 2px solid #eee;
  padding-bottom: 0.5rem;
}

.storage-status {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  background: #f8f9fa;
  padding: 1rem;
  border-radius: 8px;
}

.storage-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
}

.input-group {
  margin-bottom: 1rem;
}

.button-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.storage-section {
  margin-bottom: 1.5rem;
}

.storage-section h3 {
  font-size: 1rem;
  margin-bottom: 0.5rem;
  color: #555;
}

.data-list {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 0.5rem;
}

.data-item {
  display: flex;
  align-items: center;
  padding: 0.5rem;
  border-bottom: 1px solid #eee;
  gap: 0.5rem;
}

.data-item:last-child {
  border-bottom: none;
}

.data-key {
  font-weight: 600;
  color: #007bff;
  min-width: 80px;
}

.data-value {
  flex: 1;
  font-family: monospace;
  font-size: 0.9rem;
  color: #333;
  word-break: break-all;
}

.empty-state {
  text-align: center;
  padding: 2rem;
  color: #666;
  font-style: italic;
  background: #f8f9fa;
  border-radius: 8px;
}

.log-controls {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 0.5rem;
}

.log-container {
  background: #f8f9fa;
  border: 1px solid #ddd;
  border-radius: 8px;
  max-height: 200px;
  overflow-y: auto;
  padding: 0.5rem;
}

.log-item {
  padding: 0.25rem 0;
  border-bottom: 1px solid #eee;
  font-size: 0.8rem;
  font-family: monospace;
  line-height: 1.4;
}

.log-item:last-child {
  border-bottom: none;
}

.log-empty {
  padding: 1rem;
  text-align: center;
  color: #666;
  font-style: italic;
}

@media (min-width: 768px) {
  .button-group {
    flex-direction: row;
    flex-wrap: wrap;
  }

  .storage-status {
    justify-content: space-around;
  }
}
</style>