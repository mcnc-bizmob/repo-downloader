<!--
=== SimpleModal.vue ===
Modal 테스트를 위한 간단한 컴포넌트

** 기능 **
- 간단한 제목과 메시지 표시
- 기본적인 확인/취소 버튼
- Modal 닫기 테스트용
-->

<template>
  <ion-header>
    <ion-toolbar>
      <ion-title>{{ title }}</ion-title>
      <ion-buttons slot="end">
        <ion-button @click="closeModal" fill="clear">
          <ion-icon :icon="close"></ion-icon>
        </ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>

  <ion-content class="ion-padding">
    <div class="modal-content">
      <p class="message">{{ message }}</p>

      <!-- 전달받은 데이터가 있으면 표시 -->
      <div v-if="data" class="data-section">
        <h3>전달받은 데이터:</h3>
        <pre>{{ JSON.stringify(data, null, 2) }}</pre>
      </div>

      <!-- 중첩 Modal 테스트 버튼 -->
      <div class="nested-test" v-if="title.includes('첫 번째')">
        <h3>중첩 Modal 테스트</h3>
        <ion-button @click="openNestedModal" color="secondary">
          두 번째 Modal 열기
        </ion-button>
      </div>

      <!-- 액션 버튼들 -->
      <div class="action-buttons">
        <ion-button @click="confirmAction" color="primary">
          확인
        </ion-button>
        <ion-button @click="cancelAction" fill="outline" color="medium">
          취소
        </ion-button>
      </div>
    </div>
  </ion-content>
</template>

<script setup lang="ts">
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonButton,
  IonIcon,
  IonContent,
  modalController
} from '@ionic/vue';
import { close } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';

interface Props {
  title: string;
  message: string;
  data?: any;
}

const props = withDefaults(defineProps<Props>(), {
  title: 'Simple Modal',
  message: '기본 메시지입니다.',
  data: undefined
});

const { openModal } = useApp();

// Modal 닫기
const closeModal = () => {
  modalController.dismiss(null, 'close');
};

// 확인 액션
const confirmAction = () => {
  const result = {
    action: 'confirm',
    timestamp: Date.now(),
    data: props.data
  };

  console.log('%c✅ SimpleModal 확인 액션', 'color: green; font-weight: bold;', result);
  modalController.dismiss(result, 'confirm');
};

// 취소 액션
const cancelAction = () => {
  const result = {
    action: 'cancel',
    timestamp: Date.now()
  };

  console.log('%c❌ SimpleModal 취소 액션', 'color: red; font-weight: bold;', result);
  modalController.dismiss(result, 'cancel');
};

// 중첩 Modal 열기
const openNestedModal = async () => {
  console.log('%c🔗 중첩 Modal 열기 시작', 'color: blue; font-weight: bold;');

  try {
    // 현재 컴포넌트를 다시 사용하여 중첩 Modal 생성
    const SimpleModal = (await import('./SimpleModal.vue')).default;

    const nestedResult = await openModal(SimpleModal, {
      props: {
        title: '두 번째 Modal (중첩)',
        message: '이것은 중첩된 Modal입니다. 백 버튼으로 이전 Modal로 돌아갈 수 있습니다.'
      }
    });

    console.log('%c✅ 중첩 Modal 결과', 'color: green; font-weight: bold;', nestedResult);
  } catch (error) {
    console.log('%c❌ 중첩 Modal 실패', 'color: red; font-weight: bold;', error);
  }
};
</script>

<style scoped lang="scss">
// ============================================================================
// Modal 내부 스타일
// ============================================================================
.modal-content {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 200px;
}

.message {
  font-size: 16px;
  line-height: 1.5;
  color: #333;
  margin: 0;
}

.data-section {
  background: #f8f9fa;
  padding: 15px;
  border-radius: 8px;
  border: 1px solid #dee2e6;

  h3 {
    margin: 0 0 10px 0;
    color: #495057;
    font-size: 14px;
    font-weight: 600;
  }

  pre {
    background: #ffffff;
    padding: 10px;
    border-radius: 4px;
    border: 1px solid #e9ecef;
    font-size: 12px;
    line-height: 1.4;
    overflow-x: auto;
    margin: 0;
    color: #212529;
  }
}

.nested-test {
  background: #e3f2fd;
  padding: 15px;
  border-radius: 8px;
  border: 1px solid #bbdefb;

  h3 {
    margin: 0 0 15px 0;
    color: #1976d2;
    font-size: 16px;
    font-weight: 600;
  }
}

.action-buttons {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  margin-top: auto;

  ion-button {
    --padding-start: 20px;
    --padding-end: 20px;
  }
}

// 반응형 디자인
@media (max-width: 600px) {
  .action-buttons {
    flex-direction: column;
    gap: 8px;

    ion-button {
      width: 100%;
    }
  }
}
</style>