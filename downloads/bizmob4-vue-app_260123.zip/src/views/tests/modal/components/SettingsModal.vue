<!--
=== SettingsModal.vue ===
설정을 관리하는 Modal 컴포넌트

** 기능 **
- 다양한 설정 옵션 제공
- 설정 변경 및 저장
- 폼 검증 및 결과 반환
-->

<template>
  <ion-header>
    <ion-toolbar>
      <ion-title>설정</ion-title>
      <ion-buttons slot="end">
        <ion-button @click="closeModal" fill="clear">
          <ion-icon :icon="close"></ion-icon>
        </ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>

  <ion-content class="ion-padding">
    <div class="settings-content">
      <!-- 일반 설정 -->
      <div class="settings-section">
        <h3>
          <ion-icon :icon="settings" color="primary"></ion-icon>
          일반 설정
        </h3>

        <div class="setting-item">
          <div class="setting-info">
            <label class="setting-label">테마</label>
            <p class="setting-description">애플리케이션의 테마를 선택하세요</p>
          </div>
          <ion-select v-model="localSettings.theme" placeholder="테마 선택" interface="popover">
            <ion-select-option value="light">라이트</ion-select-option>
            <ion-select-option value="dark">다크</ion-select-option>
            <ion-select-option value="auto">자동</ion-select-option>
          </ion-select>
        </div>

        <div class="setting-item">
          <div class="setting-info">
            <label class="setting-label">자동 저장</label>
            <p class="setting-description">변경사항을 자동으로 저장합니다</p>
          </div>
          <ion-toggle v-model="localSettings.autoSave" color="primary"></ion-toggle>
        </div>
      </div>

      <!-- 알림 설정 -->
      <div class="settings-section">
        <h3>
          <ion-icon :icon="notifications" color="primary"></ion-icon>
          알림 설정
        </h3>

        <div class="setting-item">
          <div class="setting-info">
            <label class="setting-label">알림 받기</label>
            <p class="setting-description">푸시 알림을 받습니다</p>
          </div>
          <ion-toggle v-model="localSettings.notifications" color="primary"></ion-toggle>
        </div>

        <div class="setting-item" v-if="localSettings.notifications">
          <div class="setting-info">
            <label class="setting-label">알림 소리</label>
            <p class="setting-description">알림 소리를 선택하세요</p>
          </div>
          <ion-select v-model="localSettings.notificationSound" placeholder="소리 선택" interface="popover">
            <ion-select-option value="default">기본</ion-select-option>
            <ion-select-option value="soft">부드러운</ion-select-option>
            <ion-select-option value="loud">큰 소리</ion-select-option>
            <ion-select-option value="silent">무음</ion-select-option>
          </ion-select>
        </div>
      </div>

      <!-- 개발자 설정 -->
      <div class="settings-section">
        <h3>
          <ion-icon :icon="code" color="primary"></ion-icon>
          개발자 설정
        </h3>

        <div class="setting-item">
          <div class="setting-info">
            <label class="setting-label">디버그 모드</label>
            <p class="setting-description">개발자 도구를 활성화합니다</p>
          </div>
          <ion-toggle v-model="localSettings.debugMode" color="warning"></ion-toggle>
        </div>

        <div class="setting-item" v-if="localSettings.debugMode">
          <div class="setting-info">
            <label class="setting-label">로그 레벨</label>
            <p class="setting-description">로그 출력 레벨을 설정합니다</p>
          </div>
          <ion-select v-model="localSettings.logLevel" placeholder="로그 레벨" interface="popover">
            <ion-select-option value="error">ERROR</ion-select-option>
            <ion-select-option value="warn">WARN</ion-select-option>
            <ion-select-option value="info">INFO</ion-select-option>
            <ion-select-option value="debug">DEBUG</ion-select-option>
          </ion-select>
        </div>
      </div>

      <!-- 사용자 정보 -->
      <div class="settings-section">
        <h3>
          <ion-icon :icon="person" color="primary"></ion-icon>
          사용자 정보
        </h3>

        <div class="setting-item">
          <div class="setting-info">
            <label class="setting-label">사용자명</label>
            <p class="setting-description">표시될 사용자명을 입력하세요</p>
          </div>
          <ion-input v-model="localSettings.username" placeholder="사용자명 입력" clear-input></ion-input>
        </div>

        <div class="setting-item">
          <div class="setting-info">
            <label class="setting-label">언어</label>
            <p class="setting-description">인터페이스 언어를 선택하세요</p>
          </div>
          <ion-select v-model="localSettings.language" placeholder="언어 선택" interface="popover">
            <ion-select-option value="ko">한국어</ion-select-option>
            <ion-select-option value="en">English</ion-select-option>
            <ion-select-option value="ja">日本語</ion-select-option>
          </ion-select>
        </div>
      </div>

      <!-- 설정 미리보기 -->
      <div class="settings-preview">
        <h4>현재 설정</h4>
        <pre>{{ JSON.stringify(localSettings, null, 2) }}</pre>
      </div>

      <!-- 액션 버튼들 -->
      <div class="action-buttons">
        <ion-button @click="resetToDefaults" fill="outline" color="medium">
          <ion-icon :icon="refresh" slot="start"></ion-icon>
          기본값으로 재설정
        </ion-button>

        <ion-button @click="saveSettings" color="primary">
          <ion-icon :icon="save" slot="start"></ion-icon>
          설정 저장
        </ion-button>

        <ion-button @click="cancelSettings" fill="outline" color="danger">
          <ion-icon :icon="close" slot="start"></ion-icon>
          취소
        </ion-button>
      </div>
    </div>
  </ion-content>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonButton,
  IonIcon,
  IonContent,
  IonSelect,
  IonSelectOption,
  IonToggle,
  IonInput,
  modalController,
  alertController,
  toastController
} from '@ionic/vue';
import {
  close,
  settings,
  notifications,
  code,
  person,
  refresh,
  save
} from 'ionicons/icons';

interface Settings {
  theme: 'light' | 'dark' | 'auto';
  notifications: boolean;
  notificationSound: 'default' | 'soft' | 'loud' | 'silent';
  autoSave: boolean;
  debugMode: boolean;
  logLevel: 'error' | 'warn' | 'info' | 'debug';
  username: string;
  language: 'ko' | 'en' | 'ja';
}

interface Props {
  currentSettings: Partial<Settings>;
}

const props = withDefaults(defineProps<Props>(), {
  currentSettings: () => ({
    theme: 'light',
    notifications: true,
    notificationSound: 'default',
    autoSave: false,
    debugMode: false,
    logLevel: 'info',
    username: '',
    language: 'ko'
  })
});

// 기본 설정값
const defaultSettings: Settings = {
  theme: 'light',
  notifications: true,
  notificationSound: 'default',
  autoSave: false,
  debugMode: false,
  logLevel: 'info',
  username: '',
  language: 'ko'
};

// 로컬 설정 (편집 가능)
const localSettings = reactive<Settings>({
  ...defaultSettings,
  ...props.currentSettings
});

// Modal 닫기
const closeModal = () => {
  modalController.dismiss(null, 'close');
};

// 기본값으로 재설정
const resetToDefaults = async () => {
  const alert = await alertController.create({
    header: '설정 초기화',
    message: '모든 설정을 기본값으로 재설정하시겠습니까?',
    buttons: [
      {
        text: '취소',
        role: 'cancel'
      },
      {
        text: '초기화',
        handler: () => {
          Object.assign(localSettings, defaultSettings);
          console.log('%c🔄 설정이 기본값으로 재설정되었습니다', 'color: orange; font-weight: bold;');
        }
      }
    ]
  });

  await alert.present();
};

// 설정 저장
const saveSettings = async () => {
  console.log('%c💾 설정 저장:', 'color: green; font-weight: bold;', localSettings);

  // 설정 검증
  if (!localSettings.username.trim()) {
    const toast = await toastController.create({
      message: '사용자명을 입력해주세요.',
      duration: 2000,
      position: 'bottom',
      color: 'warning'
    });
    await toast.present();
    return;
  }

  const result = {
    action: 'save',
    settings: { ...localSettings },
    timestamp: Date.now(),
    changes: getChangedSettings()
  };

  const toast = await toastController.create({
    message: '설정이 저장되었습니다.',
    duration: 2000,
    position: 'bottom',
    color: 'success'
  });
  await toast.present();

  modalController.dismiss(result, 'save');
};

// 설정 취소
const cancelSettings = async () => {
  const hasChanges = JSON.stringify(localSettings) !== JSON.stringify({
    ...defaultSettings,
    ...props.currentSettings
  });

  if (hasChanges) {
    const alert = await alertController.create({
      header: '변경사항 확인',
      message: '저장하지 않은 변경사항이 있습니다. 정말 취소하시겠습니까?',
      buttons: [
        {
          text: '계속 편집',
          role: 'cancel'
        },
        {
          text: '취소',
          handler: () => {
            const result = {
              action: 'cancel',
              timestamp: Date.now()
            };

            console.log('%c❌ 설정 변경 취소:', 'color: red; font-weight: bold;', result);
            modalController.dismiss(result, 'cancel');
          }
        }
      ]
    });

    await alert.present();
  } else {
    const result = {
      action: 'cancel',
      timestamp: Date.now()
    };

    console.log('%c❌ 설정 변경 취소:', 'color: red; font-weight: bold;', result);
    modalController.dismiss(result, 'cancel');
  }
};

// 변경된 설정 항목 확인
const getChangedSettings = () => {
  const originalSettings = {
    ...defaultSettings,
    ...props.currentSettings
  };

  const changes: Record<string, { from: any; to: any }> = {};

  Object.keys(localSettings).forEach(key => {
    const originalValue = originalSettings[key as keyof Settings];
    const currentValue = localSettings[key as keyof Settings];

    if (originalValue !== currentValue) {
      changes[key] = {
        from: originalValue,
        to: currentValue
      };
    }
  });

  return changes;
};
</script>

<style scoped lang="scss">
// ============================================================================
// 설정 Modal 스타일
// ============================================================================
.settings-content {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

// 설정 섹션
.settings-section {
  background: #f8f9fa;
  border-radius: 12px;
  padding: 20px;
  border: 1px solid #e9ecef;

  h3 {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0 0 20px 0;
    color: #333;
    font-size: 18px;
    font-weight: 600;
  }
}

// 개별 설정 항목
.setting-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 16px 0;
  border-bottom: 1px solid #e9ecef;

  &:last-child {
    border-bottom: none;
    padding-bottom: 0;
  }

  .setting-info {
    flex: 1;

    .setting-label {
      display: block;
      font-weight: 600;
      color: #333;
      margin-bottom: 4px;
      font-size: 14px;
    }

    .setting-description {
      margin: 0;
      font-size: 12px;
      color: #666;
      line-height: 1.4;
    }
  }

  ion-select,
  ion-input {
    min-width: 140px;
    max-width: 200px;
  }

  ion-toggle {
    --handle-width: 20px;
    --handle-height: 20px;
  }
}

// 설정 미리보기
.settings-preview {
  background: #ffffff;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 16px;

  h4 {
    margin: 0 0 12px 0;
    color: #495057;
    font-size: 14px;
    font-weight: 600;
  }

  pre {
    background: #f8f9fa;
    padding: 12px;
    border-radius: 6px;
    border: 1px solid #e9ecef;
    font-size: 11px;
    line-height: 1.4;
    overflow-x: auto;
    margin: 0;
    color: #495057;
  }
}

// 액션 버튼들
.action-buttons {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  padding-top: 20px;
  border-top: 2px solid #e9ecef;

  ion-button {
    --padding-start: 16px;
    --padding-end: 16px;
    --border-radius: 8px;
    text-transform: none;
    font-weight: 500;
  }
}

// 반응형 디자인
@media (max-width: 768px) {
  .setting-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;

    ion-select,
    ion-input {
      width: 100%;
      max-width: none;
    }
  }

  .action-buttons {
    flex-direction: column;

    ion-button {
      width: 100%;
    }
  }
}

@media (max-width: 480px) {
  .settings-section {
    padding: 16px;
  }

  .settings-content {
    gap: 16px;
  }
}
</style>
