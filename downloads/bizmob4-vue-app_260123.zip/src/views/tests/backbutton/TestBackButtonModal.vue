<!--
=== TestBackButtonModal.vue ===
백버튼 테스트용 Modal 컴포넌트

** 기능 **
- Modal 내에서 백버튼 핸들러 등록/해제
- 폼 변경사항 시뮬레이션
- 백버튼 시 확인 다이얼로그 표시
-->

<template>
  <ion-header>
    <ion-toolbar>
      <ion-title>{{ title }}</ion-title>
      <ion-buttons slot="end">
        <ion-button @click="closeModal(false)">
          <ion-icon :icon="closeOutline"></ion-icon>
        </ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>

  <ion-content class="ion-padding">
    <div class="modal-content">
      <p>{{ message }}</p>

      <div class="form-section">
        <h3>폼 시뮬레이션</h3>
        <ion-item>
          <ion-label position="stacked">테스트 입력</ion-label>
          <ion-input v-model="formData" @ionInput="onFormChange" placeholder="내용을 입력하세요"></ion-input>
        </ion-item>

        <div class="status-info">
          <p><strong>변경사항:</strong> {{ hasChanges ? '있음' : '없음' }}</p>
          <p><strong>Modal 핸들러:</strong> {{ handlerActive ? '활성' : '비활성' }}</p>
        </div>
      </div>

      <div class="button-section">
        <ion-button @click="enableModalHandler" expand="block" fill="outline">
          Modal 백버튼 핸들러 활성화
        </ion-button>

        <ion-button @click="disableModalHandler" expand="block" fill="outline">
          Modal 백버튼 핸들러 비활성화
        </ion-button>

        <ion-button @click="saveData" expand="block" fill="solid" color="primary">
          데이터 저장 (+ 닫기)
        </ion-button>

        <ion-button @click="closeModal(false)" expand="block" fill="outline" color="medium">
          취소
        </ion-button>
      </div>

      <div class="test-guide">
        <h4>🔍 테스트 방법</h4>
        <ol>
          <li>위 입력 필드에 내용을 입력하여 변경사항을 만드세요</li>
          <li>"Modal 백버튼 핸들러 활성화" 버튼을 클릭하세요</li>
          <li>브라우저의 뒤로가기 버튼을 누르거나 하드웨어 백버튼을 누르세요</li>
          <li>변경사항이 있으면 확인 다이얼로그가 표시됩니다</li>
        </ol>
      </div>
    </div>
  </ion-content>
</template>

<script setup lang="ts">
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonButton,
  IonIcon,
  IonContent,
  IonItem,
  IonLabel,
  IonInput,
  modalController
} from '@ionic/vue';
import { closeOutline } from 'ionicons/icons';
import { ref, onMounted } from 'vue';
import { useApp } from '@bizMOB/vue';

// Props 정의
interface Props {
  title?: string;
  message?: string;
}

const props = withDefaults(defineProps<Props>(), {
  title: '테스트 Modal',
  message: '이것은 테스트용 Modal입니다.'
});

// useApp에서 필요한 기능들 가져오기
const { onModalBack, closeModal, offBack, alert, confirm } = useApp();

// 상태 관리
const formData = ref('');
const hasChanges = ref(false);
const handlerActive = ref(false);

// 폼 변경 처리
const onFormChange = () => {
  hasChanges.value = formData.value.trim().length > 0;
  console.log(`%c📝 Modal 폼 변경사항: ${hasChanges.value ? '있음' : '없음'}`, 'color: purple;');
};

// Modal 백버튼 핸들러 활성화
const enableModalHandler = () => {
  console.log('%c🎯 Modal 백버튼 핸들러 등록', 'color: blue; font-weight: bold;');

  onModalBack(async () => {
    console.log('%c📱 Modal 백버튼 핸들러 실행됨', 'color: green; font-weight: bold;');

    if (hasChanges.value) {
      const confirmed = await confirm('저장하지 않은 변경사항이 있습니다. 정말 나가시겠습니까?');
      return confirmed;
    }
    else {
      await alert('변경사항이 없습니다.');
      return true;
    }
  });

  handlerActive.value = true;
  console.log('%c✅ Modal 핸들러 등록 완료', 'color: green;');
};

// Modal 백버튼 핸들러 비활성화
const disableModalHandler = () => {
  console.log('%c🎯 Modal 백버튼 핸들러 해제', 'color: blue; font-weight: bold;');

  offBack('modal');
  handlerActive.value = false;

  console.log('%c✅ Modal 핸들러 해제 완료', 'color: green;');
};

// 데이터 저장
const saveData = async () => {
  console.log('%c💾 데이터 저장됨:', 'color: green;', formData.value);
  hasChanges.value = false;
  await alert('데이터가 저장되었습니다.');

  closeModal(true, formData.value);
};

// 컴포넌트 마운트 시 초기화
onMounted(() => {
  console.log('%c🚀 TestBackButtonModal 마운트됨', 'color: blue; font-weight: bold;');
  console.log('%c💡 이 Modal에서 백버튼 핸들러 테스트를 진행해보세요', 'color: orange;');

  enableModalHandler();
});
</script>

<style scoped>
.modal-content {
  max-width: 600px;
  margin: 0 auto;
}

.form-section {
  margin: 20px 0;
  padding: 20px;
  background: #f8f9fa;
  border-radius: 8px;
}

.form-section h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.status-info {
  margin-top: 15px;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 10px;
}

.status-info p {
  margin: 5px 0;
  font-size: 0.9em;
  color: #666;
}

.button-section {
  margin: 20px 0;
}

.button-section ion-button {
  margin: 5px 0;
}

.test-guide {
  background: #d1ecf1;
  padding: 15px;
  border-radius: 8px;
  border-left: 4px solid #17a2b8;
  margin-top: 20px;
}

.test-guide h4 {
  margin: 0 0 10px 0;
  color: #333;
}

.test-guide ol {
  margin: 0;
  padding-left: 20px;
}

.test-guide li {
  margin-bottom: 5px;
  line-height: 1.4;
  font-size: 0.9em;
  color: #555;
}
</style>