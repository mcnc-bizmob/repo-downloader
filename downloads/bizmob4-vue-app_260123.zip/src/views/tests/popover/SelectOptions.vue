<template>
  <ion-content>
    <ion-header class="select-header" v-if="title">
      <ion-toolbar>
        <ion-title size="small">{{ title }}</ion-title>
        <ion-buttons slot="end" v-if="multiple">
          <ion-button @click="confirmSelection" color="primary">
            확인
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <!-- 다중 선택일 때 상단 액션 버튼 -->
    <div v-if="multiple" class="multi-actions">
      <ion-button size="small" fill="clear" @click="selectAll" :disabled="allSelected">
        전체 선택
      </ion-button>
      <ion-button size="small" fill="clear" @click="clearAll" :disabled="noneSelected">
        전체 해제
      </ion-button>
    </div>

    <ion-list>
      <ion-item v-for="option in options" :key="option.value" button @click="handleItemClick(option)"
        :class="{ 'selected': isSelected(option.value) }">
        <ion-checkbox v-if="multiple" slot="start" :checked="isSelected(option.value)" />
        <ion-label>{{ option.label }}</ion-label>
        <ion-icon v-if="!multiple && isSelected(option.value)" :icon="checkmark" slot="end" color="primary" />
      </ion-item>
    </ion-list>

    <!-- 다중 선택일 때 하단 버튼 -->
    <ion-footer v-if="multiple">
      <ion-toolbar>
        <ion-button expand="block" @click="confirmSelection" color="primary" :disabled="noneSelected">
          선택 완료 ({{ selectedCount }}개)
        </ion-button>
      </ion-toolbar>
    </ion-footer>
  </ion-content>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import {
  IonContent, IonList, IonItem, IonLabel, IonCheckbox, IonIcon,
  IonHeader, IonToolbar, IonTitle, IonButtons, IonButton, IonFooter
} from '@ionic/vue';
import { checkmark } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';

interface SelectOption {
  value: string;
  label: string;
}

interface Props {
  options: SelectOption[];
  selected?: string | string[];
  title?: string;
  multiple?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  selected: () => [],
  title: '',
  multiple: false
});

const { closePopover } = useApp();

// 내부 상태 관리
const selectedValues = ref<string[]>([]);

// Computed 속성들
const allSelected = computed(() => {
  return props.options.length > 0 && selectedValues.value.length === props.options.length;
});

const noneSelected = computed(() => {
  return selectedValues.value.length === 0;
});

const selectedCount = computed(() => {
  return selectedValues.value.length;
});

// 초기 선택값 설정
onMounted(() => {
  if (props.multiple) {
    selectedValues.value = Array.isArray(props.selected) ? [...props.selected] : [];
  } else {
    selectedValues.value = props.selected ? [props.selected as string] : [];
  }
});

// 선택 상태 확인
const isSelected = (value: string): boolean => {
  return selectedValues.value.indexOf(value) !== -1;
};

// 아이템 클릭 처리 (모바일 친화적)
const handleItemClick = (option: SelectOption) => {
  if (props.multiple) {
    // 다중 선택: 체크박스 토글
    toggleOption(option);
  } else {
    // 단일 선택: 바로 선택하고 닫기
    closePopover(true, option.value);
  }
};

// 단일 선택 (사용하지 않음 - handleItemClick으로 통합)
const selectOption = (option: SelectOption) => {
  if (!props.multiple) {
    closePopover(true, option.value);
  }
};

// 다중 선택 토글
const toggleOption = (option: SelectOption) => {
  if (!props.multiple) return;

  const index = selectedValues.value.indexOf(option.value);
  if (index > -1) {
    selectedValues.value.splice(index, 1);
  } else {
    selectedValues.value.push(option.value);
  }
};

// 전체 선택
const selectAll = () => {
  if (!props.multiple) return;
  selectedValues.value = props.options.map(option => option.value);
};

// 전체 해제
const clearAll = () => {
  if (!props.multiple) return;
  selectedValues.value = [];
};

// 다중 선택 확인
const confirmSelection = () => {
  if (props.multiple) {
    closePopover(true, selectedValues.value);
  }
};
</script>

<style scoped>
.select-header {
  box-shadow: none;
  border-bottom: 1px solid var(--ion-color-light);
}

.multi-actions {
  display: flex;
  justify-content: space-around;
  padding: 8px 16px;
  border-bottom: 1px solid var(--ion-color-light);
  background-color: var(--ion-color-light-tint);
}

.multi-actions ion-button {
  margin: 0;
  min-width: 80px;
}

.selected {
  --background: var(--ion-color-primary-tint);
  --color: var(--ion-color-primary-contrast);
}

/* 다중 선택일 때 아이템 스타일 */
ion-item.selected ion-checkbox {
  --checkmark-color: var(--ion-color-primary);
  --border-color-checked: var(--ion-color-primary);
  --background-checked: var(--ion-color-primary);
}

/* 모바일 터치 친화적 스타일 */
ion-item {
  --min-height: 48px;
  --padding-start: 16px;
  --padding-end: 16px;
}

ion-checkbox {
  --size: 20px;
  margin-right: 12px;
}

ion-footer {
  border-top: 1px solid var(--ion-color-light);
}

ion-footer ion-toolbar {
  padding: 12px;
}

ion-footer ion-button {
  --border-radius: 8px;
  height: 44px;
  font-weight: 600;
}

/* 비활성화된 버튼 스타일 */
ion-button[disabled] {
  opacity: 0.5;
}

/* 리스트 스크롤 영역 */
ion-list {
  max-height: 300px;
  overflow-y: auto;
}

/* 스크롤바 숨김 (모바일에서는 보통 숨김) */
ion-list::-webkit-scrollbar {
  display: none;
}
</style>