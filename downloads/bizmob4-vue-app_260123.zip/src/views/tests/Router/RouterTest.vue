<!--
=== RouterTest.vue ===
useApp.router 컴포저블의 주요 기능 테스트 화면

** 테스트 범위 **
- 실제 구현: push, replace, back, go, getQuery, getParams, getHash, navigationType (8개 핵심 기능)
- 주석 설명: 나머지 고급 기능들의 테스트 케이스
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>Router 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">

        <h1>Router 기능 테스트</h1>
        <p class="test-description">
          브라우저 개발자 도구의 Console에서 테스트 결과를 확인하세요.
        </p>

        <!-- 현재 상태 표시 -->
        <div class="status-section">
          <h2>현재 상태</h2>
          <div class="status-info">
            <p><strong>Navigation Type:</strong> {{ navigationType }}</p>
            <p><strong>Current Query:</strong> {{ JSON.stringify(currentQuery) }}</p>
            <p><strong>Current Params:</strong> {{ JSON.stringify(currentParams) }}</p>
            <p><strong>Current Hash:</strong> {{ currentHash || '없음' }}</p>
          </div>
        </div>

        <!-- 핵심 기능 테스트 버튼들 -->
        <div class="test-section">
          <h2>네비게이션 함수 테스트</h2>

          <div class="button-group">
            <button @click="testPush" class="test-button">
              Push 테스트
            </button>

            <button @click="testPushWithOptions" class="test-button">
              Push + 옵션 테스트
            </button>

            <button @click="testReplace" class="test-button">
              Replace 테스트
            </button>

            <button @click="testBack" class="test-button">
              Back 테스트
            </button>

            <button @click="testGo" class="test-button">
              Go 테스트
            </button>
          </div>
        </div>

        <!-- 조회 함수 테스트 -->
        <div class="test-section">
          <h2>조회 함수 테스트</h2>

          <div class="button-group">
            <button @click="testGetQuery" class="test-button">
              getQuery 테스트
            </button>

            <button @click="testGetParams" class="test-button">
              getParams 테스트
            </button>

            <button @click="testGetHash" class="test-button">
              getHash 테스트
            </button>

            <button @click="testNavigationType" class="test-button">
              navigationType 테스트
            </button>
          </div>
        </div>

        <!-- Direction 'root' 테스트 섹션 -->
        <div class="test-section">
          <h2>Direction 'root' 테스트</h2>
          <p class="section-description">
            root Direction 테스트용
          </p>

          <div class="button-group">
            <button @click="testGoToRootTest" class="test-button root-test">
              <span class="button-icon">🏠</span>
              로그인 화면으로
            </button>
            <button @click="testGoToMainTest" class="test-button root-test">
              <span class="button-icon">🏠</span>
              메인 화면으로
            </button>
          </div>
        </div>

        <!-- 테스트 안내 -->
        <div class="test-guide">
          <h3>테스트 방법</h3>
          <ul>
            <li>각 버튼을 클릭하여 해당 기능을 테스트하세요</li>
            <li>네비게이션 변경사항을 브라우저 URL에서 확인하세요</li>
            <li>Console에서 결과 로그를 확인하세요</li>
            <li>현재 상태 섹션에서 실시간 정보를 확인하세요</li>
          </ul>

          <h3>🎯 Direction 'root' 테스트 포인트</h3>
          <ul>
            <li><strong>메인화면 테스트:</strong> 앱의 메인 루트 화면으로 이동 (로그인 후 시나리오)</li>
            <li><strong>로그아웃 테스트:</strong> 인증 세션 종료 후 로그인 화면으로 강제 이동</li>
            <li><strong>연속 테스트:</strong> 메인 → 로그인 순서로 root direction 동작 확인</li>
            <li><strong>스택 초기화:</strong> 이전 네비게이션 히스토리가 모두 제거되는지 확인</li>
            <li><strong>포커스 관리:</strong> 입력 필드에서 네비게이션 시 포커스 제거 확인</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { computed } from 'vue';
import { useApp } from '@bizMOB/vue';

// bizMOB.vue 통합 API에서 Router 기능들 가져오기
const {
  push,
  replace,
  back,
  go,
  getQuery,
  getParams,
  getHash,
  navigationType
} = useApp();

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

// 현재 상태를 실시간으로 표시하기 위한 computed
const currentQuery = computed(() => getQuery());
const currentParams = computed(() => getParams());
const currentHash = computed(() => getHash());

/*
=== 핵심 기능 테스트 구현 ===
*/

// 1. Push 테스트 (기본)
const testPush = () => {
  console.log('%c📋 Push 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    push('/tests/router');
    console.log('%c✅ Push 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과: 같은 페이지로 이동 (URL 확인)', 'color: purple; font-weight: bold;');
  } catch (error) {
    console.log('%c❌ Push 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 2. Push + 옵션 테스트 (쿼리, params, hash, direction)
const testPushWithOptions = () => {
  console.log('%c📋 Push + 옵션 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    push('/tests/router', {
      query: {
        test: 'push-options',
        timestamp: Date.now(),
        mode: 'advanced'
      },
      hash: '#test-section',
      direction: 'forward'
    });

    console.log('%c✅ Push + 옵션 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과: URL에 쿼리와 해시 추가됨', 'color: purple; font-weight: bold;');
  } catch (error) {
    console.log('%c❌ Push + 옵션 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 3. Replace 테스트
const testReplace = () => {
  console.log('%c📋 Replace 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    replace('/tests/router', {
      query: {
        test: 'replace',
        replaced: 'true'
      },
      direction: 'none'
    });

    console.log('%c✅ Replace 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과: 현재 페이지 교체 (히스토리 스택에 추가 안됨)', 'color: purple; font-weight: bold;');
  } catch (error) {
    console.log('%c❌ Replace 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 4. Back 테스트
const testBack = () => {
  console.log('%c📋 Back 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    back();
    console.log('%c✅ Back 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과: 이전 페이지로 이동', 'color: purple; font-weight: bold;');
  } catch (error) {
    console.log('%c❌ Back 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 5. Go 테스트 (경로 방식)
const testGo = () => {
  console.log('%c📋 Go 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    go('/tests');
    console.log('%c✅ Go 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과: 지정한 경로로 이동', 'color: purple; font-weight: bold;');
  } catch (error) {
    console.log('%c❌ Go 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 6. getQuery 테스트
const testGetQuery = () => {
  console.log('%c📋 getQuery 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const allQuery = getQuery();
    const testQuery = getQuery('test');
    const timestampQuery = getQuery('timestamp');

    console.log('%c✅ getQuery 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      전체쿼리: allQuery,
      test파라미터: testQuery,
      timestamp파라미터: timestampQuery
    });
  } catch (error) {
    console.log('%c❌ getQuery 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 7. getParams 테스트
const testGetParams = () => {
  console.log('%c📋 getParams 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const allParams = getParams();
    const idParam = getParams('id');

    console.log('%c✅ getParams 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      전체파라미터: allParams,
      id파라미터: idParam,
      설명: '현재 라우트에 params가 없어서 빈 객체입니다'
    });
  } catch (error) {
    console.log('%c❌ getParams 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 8. getHash 테스트
const testGetHash = () => {
  console.log('%c📋 getHash 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const fullHash = getHash();
    const hashValue = getHash('section');

    console.log('%c✅ getHash 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      전체해시: fullHash,
      section값: hashValue,
      설명: 'URL에 #이 있을 때만 값이 나타납니다'
    });
  } catch (error) {
    console.log('%c❌ getHash 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 9. navigationType 테스트
const testNavigationType = () => {
  console.log('%c📋 navigationType 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    console.log('%c✅ navigationType 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      현재타입: navigationType.value,
      설명: 'push/replace/back/initial 중 하나의 값',
      읽기전용: '직접 변경할 수 없습니다'
    });
  } catch (error) {
    console.log('%c❌ navigationType 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== Direction 'root' 테스트를 위한 함수 ===
*/

// 10. 로그인 화면을 이동 테스트
const testGoToRootTest = () => {
  push('/tests/router/login');
};

// 10. 메인 화면을 이동 테스트
const testGoToMainTest = () => {
  push('/tests/router/main', {
    query: {
      from: 'main',
      action: `main_${Date.now()}`,
    }
  });
};

/*
=== 추가 테스트 필요한 기능들 ===

1. Route Name 테스트:
   - 테스트 케이스: go('ROUTE_NAME') 방식으로 라우트명으로 이동
   - 확인 포인트: 라우트명이 올바르게 경로로 변환되어 이동하는지
   - 예상 결과: 라우트명에 해당하는 경로로 이동

2. 다양한 Direction 테스트:
   - 테스트 케이스: direction을 'forward', 'back', 'root', 'none'으로 각각 테스트
   - 확인 포인트: 각 방향에 따른 애니메이션이 올바르게 적용되는지
   - 예상 결과: 지정한 방향으로 페이지 전환 애니메이션 실행

3. 복잡한 쿼리 파라미터 테스트:
   - 테스트 케이스: 배열, 객체, 특수문자가 포함된 쿼리 파라미터
   - 확인 포인트: URL 인코딩이 올바르게 처리되는지
   - 예상 결과: 복잡한 데이터도 URL에 안전하게 인코딩됨

4. Hash 파싱 테스트:
   - 테스트 케이스: #key1=value1&key2=value2 형태의 해시 파라미터
   - 확인 포인트: getHash('key1') 방식으로 특정 값 추출 가능한지
   - 예상 결과: 해시에서 원하는 키의 값만 정확히 추출

5. 에러 상황 테스트:
   - 테스트 케이스: 존재하지 않는 라우트명으로 이동 시도
   - 확인 포인트: 에러가 적절히 처리되고 fallback 동작하는지
   - 예상 결과: Console에 경고 메시지, 경로로 treating하여 이동 시도

6. 네비게이션 타입 변화 추적:
   - 테스트 케이스: 연속된 네비게이션에서 타입 변화 관찰
   - 확인 포인트: push → back → replace 순서로 실행시 타입 변화
   - 예상 결과: 각 단계마다 navigationType이 올바르게 업데이트

7. 브라우저 뒤로가기 버튼 테스트:
   - 테스트 케이스: 브라우저의 뒤로가기 버튼 클릭
   - 확인 포인트: navigationType이 'back'으로 변경되는지
   - 예상 결과: useApp.backButton.ts에서 감지하여 타입 업데이트

8. 히스토리 스택 관리 테스트:
   - 테스트 케이스: push → push → replace → back 시퀀스
   - 확인 포인트: 히스토리 스택이 올바르게 관리되는지
   - 예상 결과: replace는 스택에 추가 안되고, back은 올바른 페이지로 이동

9. 동시 네비게이션 요청 테스트:
   - 테스트 케이스: 짧은 시간 내에 여러 네비게이션 함수 호출
   - 확인 포인트: Race condition이나 충돌 없이 처리되는지
   - 예상 결과: 마지막 요청이 적용되거나 적절한 큐잉 처리

10. 메모리 누수 테스트:
    - 테스트 케이스: 반복적인 네비게이션 후 메모리 사용량 확인
    - 확인 포인트: 이벤트 리스너나 참조가 제대로 정리되는지
    - 예상 결과: 메모리 사용량이 지속적으로 증가하지 않음
*/
</script>

<style scoped lang="scss">
// ============================================================================
// 화면 스타일
// ============================================================================
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.back-link {
  margin-bottom: 20px;
}

.back-button {
  --color: #007bff;
  --padding-start: 0;
  --padding-end: 0;
  margin: 0;
  font-weight: 500;
  text-decoration: none;
}

.back-button:hover {
  --color: #0056b3;
  text-decoration: underline;
}

.test-container h1 {
  color: #333;
  margin-bottom: 10px;
}

.test-description {
  color: #666;
  margin-bottom: 30px;
  font-style: italic;
}

.status-section {
  background: #f0f8ff;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 30px;
  border-left: 4px solid #007bff;
}

.status-section h2 {
  color: #333;
  margin: 0 0 15px 0;
}

.status-info p {
  margin: 8px 0;
  color: #555;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

.status-info strong {
  color: #007bff;
}

.test-section {
  margin-bottom: 30px;
}

.test-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #007bff;
  padding-bottom: 5px;
}

.section-description {
  color: #666;
  font-style: italic;
  margin-bottom: 20px;
  font-size: 0.95em;
  line-height: 1.4;
}

.button-group {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
}

.test-button {
  padding: 12px 20px;
  background: #28a745;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.test-button:hover {
  background: #218838;
}

.test-button.root-test {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
}

.test-button.root-test:hover {
  background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.button-icon {
  font-size: 1.2em;
}

.test-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
}

.test-guide h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.test-guide ul {
  margin: 0;
  padding-left: 20px;
}

.test-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>