<!--
=== LoginTest.vue ===
로그인화면 테스트용 컴포넌트 (direction: 'root' 테스트용)
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>로그인 (테스트)</ion-title>
        <ion-buttons slot="start">
          <ion-back-button default-href="/tests/router"></ion-back-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="login-container">
        <div class="login-section">
          <h1>로그인화면</h1>
          <p class="login-text">
            이것은 로그인화면 테스트용 컴포넌트<br>
          </p>
        </div>

        <div class="form-section">
          <h2>테스트용 로그인 폼</h2>
          <div class="form-container">
            <ion-item>
              <ion-input v-model="userId" type="text" placeholder="테스트용 ID 입력"></ion-input>
            </ion-item>

            <ion-item>
              <ion-input v-model="password" type="password" placeholder="테스트용 비밀번호"></ion-input>
            </ion-item>

            <ion-button @click="handleLogin" expand="block" class="login-button" :disabled="!userId || !password">
              로그인 (메인으로 이동)
            </ion-button>
          </div>
        </div>

        <div class="info-section">
          <h2>네비게이션 정보</h2>
          <div class="info-card">
            <p><strong>현재 경로:</strong> <code>{{ currentPath }}</code></p>
            <p><strong>Navigation Type:</strong> <code>{{ navigationType }}</code></p>
            <p><strong>Direction 설정:</strong> <code>'root'</code></p>
            <p><strong>From 파라미터:</strong> <code>{{ fromParam }}</code></p>
            <p><strong>Action 파라미터:</strong> <code>{{ actionParam }}</code></p>
          </div>
        </div>

        <div class="action-section">
          <h3>테스트 액션</h3>
          <div class="button-group">
            <ion-button @click="goToMain" expand="block" color="success">
              메인화면으로 (root)
            </ion-button>

            <ion-button @click="goToRouterTest" expand="block" color="primary">
              Router 테스트로 돌아가기
            </ion-button>
          </div>
        </div>

        <div class="guide-section">
          <h3>🔐 로그인 테스트 포인트</h3>
          <ul>
            <li><strong>Root Direction:</strong> 로그아웃 시나리오로 <code>direction: 'root'</code> 진입</li>
            <li><strong>스택 초기화:</strong> 이전 인증된 세션의 네비게이션 히스토리 제거</li>
            <li><strong>보안:</strong> 인증이 필요한 화면들로의 직접 접근 차단</li>
            <li><strong>로그인 후:</strong> 메인화면으로 <code>direction: 'root'</code>로 이동</li>
            <li><strong>포커스 관리:</strong> 입력 필드에서 네비게이션 시 포커스 제거 테스트</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonButtons,
  IonBackButton,
  IonItem,
  IonLabel,
  IonInput
} from '@ionic/vue';
import { ref, computed } from 'vue';
import { useRoute } from 'vue-router';
import { useApp } from '@bizMOB/vue';

const route = useRoute();
const { push, replace, navigationType, getQuery } = useApp();

// 폼 데이터
const userId = ref('test');
const password = ref('1234');

// 현재 경로 및 쿼리 정보
const currentPath = computed(() => route.path);
const fromParam = computed(() => getQuery('from') || '없음');
const actionParam = computed(() => getQuery('action') || '없음');

// 로그인 처리 (메인화면으로 이동)
const handleLogin = () => {
  console.log('%c🔐 로그인 처리 중...', 'color: green; font-weight: bold;');
  console.log('입력 데이터:', { userId: userId.value, password: password.value });

  // 실제 로그인 로직은 여기에 구현
  // 테스트용으로 바로 메인화면으로 이동
  setTimeout(() => {
    console.log('%c✅ 로그인 성공! 메인화면으로 이동', 'color: green; font-weight: bold;');
    goToMain();
  }, 1000);
};

// 메인화면으로 이동 (root direction)
const goToMain = () => {
  console.log('%c🏠 메인화면으로 이동 (direction: root)', 'color: blue; font-weight: bold;');

  replace('/tests/router/main', {
    direction: 'root',
    query: {
      from: 'login',
      loginTime: Date.now(),
      action: 'main'
    }
  });
};

// Router 테스트로 돌아가기
const goToRouterTest = () => {
  console.log('%c🔙 Router 테스트로 돌아가기', 'color: blue; font-weight: bold;');
  push('/tests/router');
};
</script>

<style scoped lang="scss">
.login-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

.login-section {
  text-align: center;
  margin-bottom: 40px;
  padding: 30px 20px;
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  border-radius: 16px;
  color: white;
}

.login-icon {
  font-size: 4rem;
  margin-bottom: 20px;
  opacity: 0.9;
}

.login-section h1 {
  margin: 0 0 15px 0;
  font-size: 2.5rem;
  font-weight: 300;
}

.login-text {
  font-size: 1.1rem;
  line-height: 1.6;
  opacity: 0.9;
  margin: 0;
}

.form-section {
  margin-bottom: 30px;
}

.form-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #f5576c;
  padding-bottom: 5px;
}

.form-container {
  background: #fff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.login-button {
  margin-top: 20px;
  --background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.info-section {
  margin-bottom: 30px;
}

.info-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #f5576c;
  padding-bottom: 5px;
}

.info-card {
  background: #fff5f5;
  padding: 20px;
  border-radius: 12px;
  border-left: 4px solid #f5576c;
}

.info-card p {
  margin: 10px 0;
  line-height: 1.5;
}

.info-card strong {
  color: #f5576c;
}

.info-card code {
  background: #ffe8e8;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

.action-section {
  margin-bottom: 30px;
}

.action-section h3 {
  color: #333;
  margin-bottom: 15px;
}

.button-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.guide-section {
  background: #f0f8ff;
  padding: 20px;
  border-radius: 12px;
  border-left: 4px solid #dc3545;
}

.guide-section h3 {
  margin: 0 0 15px 0;
  color: #dc3545;
}

.guide-section ul {
  margin: 0;
  padding-left: 20px;
}

.guide-section li {
  margin-bottom: 10px;
  line-height: 1.5;
}

.guide-section strong {
  color: #dc3545;
}

.guide-section code {
  background: #ffeaa7;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}
</style>