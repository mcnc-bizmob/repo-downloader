<!--
=== MainTest.vue ===
메인화면 테스트용 컴포넌트 (direction: 'root' 테스트용)
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>메인화면 (테스트)</ion-title>
        <ion-buttons slot="start">
          <ion-back-button default-href="/tests/router"></ion-back-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="main-container">
        <div class="welcome-section">
          <h1>메인화면</h1>
          <p class="welcome-text">
            이것은 메인화면 테스트용 컴포넌트<br>
          </p>
        </div>

        <div class="form-section">
          <h2>테스트용 폼</h2>
          <div class="form-container">
            <ion-item>
              <ion-input v-model="text" type="text" placeholder="테스트용"></ion-input>
            </ion-item>
          </div>
        </div>

        <div class="info-section">
          <h2>네비게이션 정보</h2>
          <div class="info-card">
            <p><strong>현재 경로:</strong> <code>{{ currentPath }}</code></p>
            <p><strong>Navigation Type:</strong> <code>{{ navigationType }}</code></p>
            <p><strong>Direction 설정:</strong> <code>'root'</code></p>
            <p><strong>Action 파라미터:</strong> <code>{{ actionParam }}</code></p>
          </div>
        </div>

        <div class="action-section">
          <h3>테스트 액션</h3>
          <div class="button-group">
            <ion-button @click="goToLogin" expand="block" color="warning">
              로그아웃 (root)
            </ion-button>

            <ion-button @click="goToHistoryStack" expand="block" color="secondary">
              Stack 쌓기 (push)
            </ion-button>

            <ion-button @click="goToBack" expand="block" color="primary">
              뒤로가기 (back)
            </ion-button>
          </div>
        </div>

        <div class="guide-section">
          <h3>🎯 테스트 포인트</h3>
          <ul>
            <li><strong>Root Direction:</strong> 이 화면은 <code>direction: 'root'</code>로 진입</li>
            <li><strong>스택 초기화:</strong> 이전 네비게이션 히스토리가 모두 지워짐</li>
            <li><strong>애니메이션:</strong> 특별한 루트 전환 애니메이션 적용</li>
            <li><strong>뒤로가기:</strong> 브라우저 뒤로가기가 제한적으로 작동</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonButtons,
  IonBackButton,
  IonInput
} from '@ionic/vue';
import { ref, computed } from 'vue';
import { useRoute } from 'vue-router';
import { useApp } from '@bizMOB/vue';

const route = useRoute();
const { push, replace, back, navigationType, getQuery } = useApp();

// 폼 데이터
const text = ref('');

// 현재 경로 정보
const currentPath = computed(() => route.path);
const actionParam = computed(() => getQuery('action') || '없음');

// 로그인 화면으로 이동 (root direction)
const goToLogin = () => {
  console.log('%c🔐 로그인 화면으로 이동 (direction: root)', 'color: orange; font-weight: bold;');

  replace('/tests/router/login', {
    direction: 'root',
    query: {
      from: 'main',
      action: 'logout'
    }
  });
};

// 스택 쌓기
const goToHistoryStack = () => {
  console.log('%c📋 화면 재오픈', 'color: green; font-weight: bold;');
  push('/tests/router/main', {
    query: {
      from: 'main',
      action: 'logout',
      loginTime: Date.now()
    }
  });
};

// Back 테스트
const goToBack = () => {
  console.log('%c🔙 뒤로 돌아가기', 'color: blue; font-weight: bold;');
  back();
};
</script>

<style scoped lang="scss">
.main-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

.welcome-section {
  text-align: center;
  margin-bottom: 40px;
  padding: 30px 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 16px;
  color: white;
}

.main-icon {
  font-size: 4rem;
  margin-bottom: 20px;
  opacity: 0.9;
}

.welcome-section h1 {
  margin: 0 0 15px 0;
  font-size: 2.5rem;
  font-weight: 300;
}

.welcome-text {
  font-size: 1.1rem;
  line-height: 1.6;
  opacity: 0.9;
  margin: 0;
}

.info-section {
  margin-bottom: 30px;
}

.info-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #667eea;
  padding-bottom: 5px;
}

.info-card {
  background: #f8f9ff;
  padding: 20px;
  border-radius: 12px;
  border-left: 4px solid #667eea;
}

.info-card p {
  margin: 10px 0;
  line-height: 1.5;
}

.info-card strong {
  color: #667eea;
}

.info-card code {
  background: #e1e5ff;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

.action-section {
  margin-bottom: 30px;
}

.action-section h3 {
  color: #333;
  margin-bottom: 15px;
}

.button-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.guide-section {
  background: #f0f8ff;
  padding: 20px;
  border-radius: 12px;
  border-left: 4px solid #28a745;
}

.guide-section h3 {
  margin: 0 0 15px 0;
  color: #28a745;
}

.guide-section ul {
  margin: 0;
  padding-left: 20px;
}

.guide-section li {
  margin-bottom: 10px;
  line-height: 1.5;
}

.guide-section strong {
  color: #28a745;
}

.guide-section code {
  background: #e8f5e8;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}
</style>