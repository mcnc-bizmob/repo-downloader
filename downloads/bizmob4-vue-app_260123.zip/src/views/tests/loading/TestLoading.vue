<!--
=== TestLoading.vue ===
Loading 컴포저블 테스트 화면

** 테스트 시나리오 **
1. ✅ withLoading 패턴 테스트 (권장 방식)
2. ✅ 수동 loading 제어 테스트 (start/stop)
3. ✅ 중첩 loading 테스트 (동시 요청 처리)
4. ✅ 로딩 상태 모니터링 테스트

** 주요 기능 **
- withLoading: 비동기 함수 실행 중 자동 로딩 관리
- startLoading/stopLoading: 수동 로딩 제어
- isLoading: 현재 로딩 상태 확인
- loadingCount: 활성 로딩 작업 수 확인
- stopAllLoading: 모든 로딩 강제 종료

** 사용 패턴 **
- API 호출 시 withLoading 사용 (가장 권장)
- 복잡한 로직에서 수동 제어 필요시 start/stop 사용
- 백버튼 처리 시 isLoading으로 상태 확인
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>Loading 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">
        <h1>Loading 컴포저블 테스트</h1>
        <p class="description">
          프로그래매틱 로딩 오버레이 관리 및 withLoading 패턴을 테스트합니다.<br>
          로딩 상태는 실시간으로 모니터링되며 중첩 요청도 안전하게 처리됩니다.
        </p>

        <!-- 현재 로딩 상태 -->
        <div class="status-section">
          <h2>현재 로딩 상태</h2>
          <div class="status-info">
            <p><strong>로딩 상태:</strong> {{ isLoading ? '로딩 중' : '대기 중' }}</p>
            <p><strong>활성 작업 수:</strong> {{ loadingCount }}</p>
            <p><strong>마지막 테스트:</strong> {{ lastTest }}</p>
          </div>
        </div>

        <!-- 1. withLoading 패턴 테스트 (권장) -->
        <div class="test-section">
          <h2>1. withLoading 패턴 테스트 (권장)</h2>
          <p class="test-description">
            비동기 함수를 withLoading으로 감싸서 자동으로 로딩 상태를 관리합니다.
          </p>

          <ion-button @click="testWithLoadingShort" expand="block" fill="outline" class="test-button">
            짧은 작업 (1초) - withLoading
          </ion-button>

          <ion-button @click="testWithLoadingLong" expand="block" fill="outline" class="test-button">
            긴 작업 (3초) - withLoading
          </ion-button>

          <ion-button @click="testWithLoadingError" expand="block" fill="outline" class="test-button">
            에러 발생 작업 - withLoading
          </ion-button>

          <ion-button @click="testConsecutiveLoading" expand="block" fill="outline" class="test-button">
            연속 API 호출 테스트 (딜레이 없이)
          </ion-button>

          <ion-button @click="testRapidConsecutiveLoading" expand="block" fill="outline" class="test-button">
            고속 연속 호출 테스트 (5회)
          </ion-button>
        </div>

        <!-- 2. 수동 로딩 제어 테스트 -->
        <div class="test-section">
          <h2>2. 수동 로딩 제어 테스트</h2>
          <p class="test-description">
            startLoading/stopLoading을 사용하여 수동으로 로딩 상태를 제어합니다.
          </p>

          <ion-button @click="startManualLoading" expand="block" fill="outline" class="test-button">
            수동 로딩 시작
          </ion-button>

          <ion-button @click="stopManualLoading" expand="block" fill="outline" class="test-button">
            수동 로딩 중지
          </ion-button>

          <ion-button @click="testManualLoadingWithDelay" expand="block" fill="outline" class="test-button">
            수동 로딩 (2초 후 자동 중지)
          </ion-button>
        </div>

        <!-- 3. 중첩 로딩 테스트 -->
        <div class="test-section">
          <h2>3. 중첩 로딩 테스트</h2>
          <p class="test-description">
            여러 작업을 동시에 실행하거나 연속으로 실행하여 로딩 처리를 테스트합니다.
          </p>

          <ion-button @click="testMultipleLoading" expand="block" fill="outline" class="test-button">
            동시 작업 3개 실행 (withLoading)
          </ion-button>

          <ion-button @click="testMixedLoading" expand="block" fill="outline" class="test-button">
            혼합 로딩 (withLoading + 수동)
          </ion-button>

          <ion-button @click="testSequentialWithConcurrent" expand="block" fill="outline" class="test-button">
            순차 + 동시 실행 혼합 테스트
          </ion-button>
        </div>

        <!-- 4. 로딩 상태 관리 테스트 -->
        <div class="test-section">
          <h2>4. 로딩 상태 관리 테스트</h2>
          <p class="test-description">
            로딩 상태 모니터링 및 강제 종료 기능을 테스트합니다.
          </p>

          <ion-button @click="startLongRunningTask" expand="block" fill="outline" class="test-button">
            장시간 작업 시작 (10초)
          </ion-button>

          <ion-button @click="stopAllLoadings" expand="block" fill="solid" color="danger" class="test-button">
            모든 로딩 강제 종료
          </ion-button>
        </div>

        <!-- 5. 실전 시나리오 테스트 -->
        <div class="test-section">
          <h2>5. 실전 시나리오 테스트</h2>
          <p class="test-description">
            실제 앱에서 사용되는 패턴들을 시뮬레이션합니다.
          </p>

          <ion-button @click="simulateApiCall" expand="block" fill="outline" class="test-button">
            API 호출 시뮬레이션
          </ion-button>

          <ion-button @click="simulateDataSave" expand="block" fill="outline" class="test-button">
            데이터 저장 시뮬레이션
          </ion-button>

          <ion-button @click="simulateFileUpload" expand="block" fill="outline" class="test-button">
            파일 업로드 시뮬레이션
          </ion-button>
        </div>

        <!-- 추가 테스트 케이스 (주석으로 설명) -->
        <div class="additional-tests">
          <h2>📝 추가 테스트 케이스 (구현 예정)</h2>
          <ul>
            <li><strong>백버튼 연동 테스트:</strong> 로딩 중 백버튼 차단 동작 확인</li>
            <li><strong>네트워크 오류 처리:</strong> 네트워크 실패 시 로딩 상태 관리</li>
            <li><strong>타임아웃 처리:</strong> 장시간 로딩 시 자동 타임아웃 설정</li>
            <li><strong>사용자 취소:</strong> 사용자가 로딩을 중간에 취소하는 경우</li>
            <li><strong>메모리 누수 방지:</strong> 컴포넌트 언마운트시 로딩 상태 정리</li>
            <li><strong>커스텀 로딩 UI:</strong> 기본 스피너 외 커스텀 로딩 인디케이터</li>
            <li><strong>진행률 표시:</strong> 파일 업로드 등에서 진행률과 함께 사용</li>
            <li><strong>배치 작업:</strong> 여러 작업을 순차적으로 실행하며 로딩 관리</li>
          </ul>
        </div>

        <!-- 사용 가이드 -->
        <div class="usage-guide">
          <h2>🔍 테스트 방법</h2>
          <ol>
            <li>각 테스트 버튼을 클릭하여 로딩 동작을 확인하세요</li>
            <li>상단의 "현재 로딩 상태"에서 실시간 상태를 모니터링하세요</li>
            <li>Console 로그에서 상세한 로딩 처리 과정을 확인하세요</li>
            <li>중첩 로딩 테스트로 동시 요청 처리를 확인하세요</li>
            <li>로딩 중 백버튼을 눌러 차단 동작을 테스트해보세요</li>
          </ol>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { ref } from 'vue';
import { onIonViewWillEnter } from '@ionic/vue';
import { useApp } from '@bizMOB/vue';

// useApp 컴포저블에서 필요한 기능들 가져오기
const {
  withLoading,
  isLoading,
  loadingCount,
  startLoading,
  stopLoading,
  stopAllLoading,
  toast,
  alert,
  back
} = useApp();

// 테스트 상태 관리
const lastTest = ref('없음');
const manualLoadingId = ref<string | null>(null);

// 지연 함수 (테스트용)
const delay = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

// 1. withLoading 패턴 테스트 - 짧은 작업
const testWithLoadingShort = async () => {
  console.log('%c🎯 withLoading 패턴 테스트 - 짧은 작업 시작', 'color: blue; font-weight: bold;');
  console.log('Initial loading state:', { isLoading: isLoading.value, count: loadingCount.value });
  lastTest.value = 'withLoading 짧은 작업 시작';

  try {
    const result = await withLoading(async () => {
      console.log('%c⏳ 1초 작업 실행 중...', 'color: orange;');
      console.log('During task loading state:', { isLoading: isLoading.value, count: loadingCount.value });
      await delay(1000);
      return '짧은 작업 완료!';
    }, '짧은 작업 처리');

    console.log('%c✅ 작업 결과:', 'color: green;', result);
    console.log('After task loading state:', { isLoading: isLoading.value, count: loadingCount.value });
    lastTest.value = 'withLoading 짧은 작업 완료';

    // Toast 전에 잠시 대기하여 로딩이 완전히 해제되도록 함
    await new Promise(resolve => setTimeout(resolve, 100));
    await toast('1초 작업이 완료되었습니다.');
  } catch (error) {
    console.error('%c❌ 작업 오류:', 'color: red;', error);
    console.log('Error loading state:', { isLoading: isLoading.value, count: loadingCount.value });
    lastTest.value = 'withLoading 짧은 작업 오류';
  }
};

// withLoading 패턴 테스트 - 긴 작업
const testWithLoadingLong = async () => {
  console.log('%c🎯 withLoading 패턴 테스트 - 긴 작업 시작', 'color: blue; font-weight: bold;');
  lastTest.value = 'withLoading 긴 작업 시작';

  try {
    const result = await withLoading(async () => {
      console.log('%c⏳ 3초 작업 실행 중...', 'color: orange;');
      await delay(3000);
      return '긴 작업 완료!';
    }, '긴 작업 처리');

    console.log('%c✅ 작업 결과:', 'color: green;', result);
    lastTest.value = 'withLoading 긴 작업 완료';
    await toast('3초 작업이 완료되었습니다.');
  } catch (error) {
    console.error('%c❌ 작업 오류:', 'color: red;', error);
    lastTest.value = 'withLoading 긴 작업 오류';
  }
};

// withLoading 패턴 테스트 - 에러 발생
const testWithLoadingError = async () => {
  console.log('%c🎯 withLoading 패턴 테스트 - 에러 발생', 'color: blue; font-weight: bold;');
  lastTest.value = 'withLoading 에러 테스트 시작';

  try {
    await withLoading(async () => {
      console.log('%c⏳ 2초 후 에러 발생 예정...', 'color: orange;');
      await delay(2000);
      throw new Error('의도적인 테스트 에러');
    }, '에러 발생 작업');

  } catch (error) {
    console.error('%c❌ 예상된 에러 발생:', 'color: red;', error);
    lastTest.value = 'withLoading 에러 처리 완료';
    await alert('에러가 발생했지만 로딩은 정상적으로 종료되었습니다.');
  }
};

// withLoading 패턴 테스트 - 연속 API 호출 (딜레이 없이)
const testConsecutiveLoading = async () => {
  console.log('%c🎯 연속 API 호출 테스트 시작', 'color: blue; font-weight: bold;');
  lastTest.value = '연속 API 호출 시작';

  try {
    // 첫 번째 API 호출
    console.log('%c📡 1차 API 호출 시작...', 'color: purple; font-weight: bold;');
    const result1 = await withLoading(async () => {
      console.log('%c⏳ 1차 API: 사용자 정보 조회 중...', 'color: orange;');
      await delay(1500);
      return { userId: 123, name: '홍길동' };
    }, '1차 API: 사용자 정보 조회');

    console.log('%c✅ 1차 API 완료:', 'color: green;', result1);
    console.log('1차 완료 후 로딩 상태:', { isLoading: isLoading.value, count: loadingCount.value });

    // 딜레이 없이 즉시 두 번째 API 호출
    console.log('%c📡 2차 API 호출 시작 (딜레이 없이)...', 'color: purple; font-weight: bold;');
    const result2 = await withLoading(async () => {
      console.log('%c⏳ 2차 API: 사용자 권한 조회 중...', 'color: orange;');
      await delay(1200);
      return { permissions: ['read', 'write'], role: 'admin' };
    }, '2차 API: 사용자 권한 조회');

    console.log('%c✅ 2차 API 완료:', 'color: green;', result2);
    console.log('2차 완료 후 로딩 상태:', { isLoading: isLoading.value, count: loadingCount.value });

    // 딜레이 없이 즉시 세 번째 API 호출
    console.log('%c📡 3차 API 호출 시작 (딜레이 없이)...', 'color: purple; font-weight: bold;');
    const result3 = await withLoading(async () => {
      console.log('%c⏳ 3차 API: 대시보드 데이터 조회 중...', 'color: orange;');
      await delay(1000);
      return { dashboard: { totalUsers: 150, activeUsers: 120 } };
    }, '3차 API: 대시보드 데이터 조회');

    console.log('%c✅ 3차 API 완료:', 'color: green;', result3);
    console.log('최종 로딩 상태:', { isLoading: isLoading.value, count: loadingCount.value });

    lastTest.value = '연속 API 호출 완료';
    await toast('3개의 연속 API 호출이 완료되었습니다.');

  } catch (error) {
    console.error('%c❌ 연속 API 호출 오류:', 'color: red;', error);
    lastTest.value = '연속 API 호출 오류';
  }
};

// withLoading 패턴 테스트 - 고속 연속 호출 (5회)
const testRapidConsecutiveLoading = async () => {
  console.log('%c🎯 고속 연속 호출 테스트 시작 (5회)', 'color: blue; font-weight: bold;');
  lastTest.value = '고속 연속 호출 시작';

  try {
    const apiCalls = [
      { name: '로그인', delay: 800 },
      { name: '프로필 조회', delay: 600 },
      { name: '설정 로드', delay: 500 },
      { name: '알림 확인', delay: 400 },
      { name: '통계 조회', delay: 700 }
    ];

    const results = [];

    for (let i = 0; i < apiCalls.length; i++) {
      const api = apiCalls[i];
      const apiNumber = i + 1;

      console.log(`%c📡 ${apiNumber}차 API 호출: ${api.name}`, 'color: purple; font-weight: bold;');

      const result = await withLoading(async () => {
        console.log(`%c⏳ ${apiNumber}차 API: ${api.name} 처리 중... (${api.delay}ms)`, 'color: orange;');
        await delay(api.delay);
        return { api: api.name, timestamp: new Date().toISOString(), order: apiNumber };
      }, `${apiNumber}차 API: ${api.name}`);

      console.log(`%c✅ ${apiNumber}차 API 완료:`, 'color: green;', result);
      console.log(`${apiNumber}차 완료 후 로딩 상태:`, { isLoading: isLoading.value, count: loadingCount.value });

      results.push(result);
    }

    console.log('%c🎉 모든 고속 연속 호출 완료:', 'color: green; font-weight: bold;', results);
    console.log('최종 로딩 상태:', { isLoading: isLoading.value, count: loadingCount.value });

    lastTest.value = '고속 연속 호출 완료';
    await toast(`${apiCalls.length}개의 고속 연속 API 호출이 완료되었습니다.`);

  } catch (error) {
    console.error('%c❌ 고속 연속 호출 오류:', 'color: red;', error);
    lastTest.value = '고속 연속 호출 오류';
  }
};

// 2. 수동 로딩 시작
const startManualLoading = () => {
  console.log('%c🎯 수동 로딩 시작', 'color: blue; font-weight: bold;');

  if (manualLoadingId.value) {
    console.log('%c⚠️ 이미 수동 로딩이 실행 중입니다', 'color: orange;');
    return;
  }

  manualLoadingId.value = startLoading(null, 'manual', '수동 로딩 테스트');
  lastTest.value = '수동 로딩 시작';

  console.log('%c✅ 수동 로딩 시작됨. ID:', 'color: green;', manualLoadingId.value);
};

// 수동 로딩 중지
const stopManualLoading = () => {
  console.log('%c🎯 수동 로딩 중지', 'color: blue; font-weight: bold;');

  if (!manualLoadingId.value) {
    console.log('%c⚠️ 중지할 수동 로딩이 없습니다', 'color: orange;');
    return;
  }

  stopLoading(manualLoadingId.value);
  console.log('%c✅ 수동 로딩 중지됨. ID:', 'color: green;', manualLoadingId.value);

  manualLoadingId.value = null;
  lastTest.value = '수동 로딩 중지';
};

// 수동 로딩 (자동 중지)
const testManualLoadingWithDelay = async () => {
  console.log('%c🎯 수동 로딩 - 2초 후 자동 중지', 'color: blue; font-weight: bold;');
  lastTest.value = '수동 로딩 자동 중지 시작';

  const taskId = startLoading(null, 'manual', '2초 자동 중지 테스트');
  console.log('%c⏳ 2초 후 자동 중지됩니다...', 'color: orange;');

  setTimeout(() => {
    stopLoading(taskId);
    console.log('%c✅ 자동 중지 완료', 'color: green;');
    lastTest.value = '수동 로딩 자동 중지 완료';
    toast('2초 후 자동으로 로딩이 중지되었습니다.');
  }, 2000);
};

// 3. 동시 작업 테스트
const testMultipleLoading = async () => {
  console.log('%c🎯 동시 작업 3개 실행', 'color: blue; font-weight: bold;');
  lastTest.value = '동시 작업 시작';

  try {
    const promises = [
      withLoading(() => delay(1500), '작업 1'),
      withLoading(() => delay(2000), '작업 2'),
      withLoading(() => delay(1000), '작업 3')
    ];

    console.log('%c⏳ 3개 작업 동시 실행 중...', 'color: orange;');
    await Promise.all(promises);

    console.log('%c✅ 모든 동시 작업 완료', 'color: green;');
    lastTest.value = '동시 작업 완료';
    await toast('3개 작업이 모두 완료되었습니다.');
  } catch (error) {
    console.error('%c❌ 동시 작업 오류:', 'color: red;', error);
    lastTest.value = '동시 작업 오류';
  }
};

// 혼합 로딩 테스트
const testMixedLoading = async () => {
  console.log('%c🎯 혼합 로딩 테스트 (withLoading + 수동)', 'color: blue; font-weight: bold;');
  lastTest.value = '혼합 로딩 시작';

  // 수동 로딩 시작
  const manualId = startLoading(null, 'manual', '혼합 테스트 수동');

  try {
    // withLoading과 수동 로딩이 동시에 실행
    await withLoading(async () => {
      console.log('%c⏳ withLoading 작업 실행 중...', 'color: orange;');
      await delay(2000);
    }, '혼합 테스트 withLoading');

    // 수동 로딩은 조금 더 늦게 중지
    setTimeout(() => {
      stopLoading(manualId);
      console.log('%c✅ 수동 로딩 중지됨', 'color: green;');
    }, 3000);

    console.log('%c✅ 혼합 로딩 테스트 완료', 'color: green;');
    lastTest.value = '혼합 로딩 완료';
    await toast('withLoading과 수동 로딩이 혼합 실행되었습니다.');
  } catch (error) {
    stopLoading(manualId);
    console.error('%c❌ 혼합 로딩 오류:', 'color: red;', error);
    lastTest.value = '혼합 로딩 오류';
  }
};

// 순차 + 동시 실행 혼합 테스트
const testSequentialWithConcurrent = async () => {
  console.log('%c🎯 순차 + 동시 실행 혼합 테스트', 'color: blue; font-weight: bold;');
  lastTest.value = '순차+동시 실행 시작';

  try {
    // 1단계: 초기화 API (순차)
    console.log('%c📡 1단계: 초기화 API', 'color: purple; font-weight: bold;');
    const initResult = await withLoading(async () => {
      console.log('%c⏳ 앱 초기화 중...', 'color: orange;');
      await delay(1000);
      return { initialized: true, version: '1.0.0' };
    }, '앱 초기화');
    console.log('%c✅ 초기화 완료:', 'color: green;', initResult);

    // 2단계: 사용자 데이터 로드 (순차)
    console.log('%c📡 2단계: 사용자 데이터 로드', 'color: purple; font-weight: bold;');
    const userResult = await withLoading(async () => {
      console.log('%c⏳ 사용자 데이터 로드 중...', 'color: orange;');
      await delay(800);
      return { user: { id: 1, name: '사용자' } };
    }, '사용자 데이터 로드');
    console.log('%c✅ 사용자 데이터 완료:', 'color: green;', userResult);

    // 3단계: 여러 리소스 동시 로드 (동시)
    console.log('%c📡 3단계: 여러 리소스 동시 로드', 'color: purple; font-weight: bold;');
    const concurrentPromises = [
      withLoading(async () => {
        console.log('%c⏳ 메뉴 데이터 로드 중...', 'color: orange;');
        await delay(600);
        return { menus: ['홈', '설정', '프로필'] };
      }, '메뉴 데이터'),

      withLoading(async () => {
        console.log('%c⏳ 알림 데이터 로드 중...', 'color: orange;');
        await delay(800);
        return { notifications: ['새 메시지', '시스템 업데이트'] };
      }, '알림 데이터'),

      withLoading(async () => {
        console.log('%c⏳ 설정 데이터 로드 중...', 'color: orange;');
        await delay(700);
        return { settings: { theme: 'dark', language: 'ko' } };
      }, '설정 데이터')
    ];

    const concurrentResults = await Promise.all(concurrentPromises);
    console.log('%c✅ 동시 로드 완료:', 'color: green;', concurrentResults);

    // 4단계: 마무리 API (순차)
    console.log('%c📡 4단계: 마무리 설정', 'color: purple; font-weight: bold;');
    const finalResult = await withLoading(async () => {
      console.log('%c⏳ 최종 설정 적용 중...', 'color: orange;');
      await delay(500);
      return { ready: true, loadTime: new Date().toISOString() };
    }, '최종 설정');
    console.log('%c✅ 최종 설정 완료:', 'color: green;', finalResult);

    console.log('%c🎉 순차+동시 실행 혼합 테스트 완료', 'color: green; font-weight: bold;');
    lastTest.value = '순차+동시 실행 완료';
    await toast('순차 및 동시 실행 혼합 테스트가 완료되었습니다.');

  } catch (error) {
    console.error('%c❌ 순차+동시 실행 오류:', 'color: red;', error);
    lastTest.value = '순차+동시 실행 오류';
  }
};

// 4. 장시간 작업 시작
const startLongRunningTask = async () => {
  console.log('%c🎯 장시간 작업 시작 (10초)', 'color: blue; font-weight: bold;');
  lastTest.value = '장시간 작업 시작';

  try {
    await withLoading(async () => {
      console.log('%c⏳ 10초 장시간 작업 실행 중...', 'color: orange;');
      await delay(10000);
      return '장시간 작업 완료!';
    }, '장시간 작업');

    console.log('%c✅ 장시간 작업 완료', 'color: green;');
    lastTest.value = '장시간 작업 완료';
    await toast('10초 장시간 작업이 완료되었습니다.');
  } catch (error) {
    console.error('%c❌ 장시간 작업 오류:', 'color: red;', error);
    lastTest.value = '장시간 작업 중단됨';
  }
};

// 모든 로딩 강제 종료
const stopAllLoadings = () => {
  console.log('%c🎯 모든 로딩 강제 종료', 'color: blue; font-weight: bold;');

  stopAllLoading();
  manualLoadingId.value = null;
  lastTest.value = '모든 로딩 강제 종료';

  console.log('%c✅ 모든 로딩이 강제 종료되었습니다', 'color: green;');
  toast('모든 로딩이 강제 종료되었습니다.');
};

// 5. 실전 시나리오 - API 호출 시뮬레이션
const simulateApiCall = async () => {
  console.log('%c🎯 API 호출 시뮬레이션', 'color: blue; font-weight: bold;');
  lastTest.value = 'API 호출 시뮬레이션';

  try {
    const result = await withLoading(async () => {
      console.log('%c📡 서버 연결 중...', 'color: orange;');
      await delay(1000);

      console.log('%c📡 데이터 요청 중...', 'color: orange;');
      await delay(1500);

      console.log('%c📡 응답 처리 중...', 'color: orange;');
      await delay(500);

      return { data: '사용자 정보', status: 'success' };
    }, 'API 호출');

    console.log('%c✅ API 응답:', 'color: green;', result);
    lastTest.value = 'API 호출 완료';
    await toast('API 호출이 성공적으로 완료되었습니다.');
  } catch (error) {
    console.error('%c❌ API 호출 실패:', 'color: red;', error);
    lastTest.value = 'API 호출 실패';
  }
};

// 데이터 저장 시뮬레이션
const simulateDataSave = async () => {
  console.log('%c🎯 데이터 저장 시뮬레이션', 'color: blue; font-weight: bold;');
  lastTest.value = '데이터 저장 시뮬레이션';

  try {
    await withLoading(async () => {
      console.log('%c💾 데이터 검증 중...', 'color: orange;');
      await delay(800);

      console.log('%c💾 서버 전송 중...', 'color: orange;');
      await delay(1200);

      console.log('%c💾 저장 완료 확인 중...', 'color: orange;');
      await delay(500);
    }, '데이터 저장');

    console.log('%c✅ 데이터 저장 완료', 'color: green;');
    lastTest.value = '데이터 저장 완료';
    await toast('데이터가 성공적으로 저장되었습니다.');
  } catch (error) {
    console.error('%c❌ 데이터 저장 실패:', 'color: red;', error);
    lastTest.value = '데이터 저장 실패';
  }
};

// 파일 업로드 시뮬레이션
const simulateFileUpload = async () => {
  console.log('%c🎯 파일 업로드 시뮬레이션', 'color: blue; font-weight: bold;');
  lastTest.value = '파일 업로드 시뮬레이션';

  try {
    await withLoading(async () => {
      console.log('%c📁 파일 준비 중...', 'color: orange;');
      await delay(500);

      console.log('%c📁 업로드 중... (0%)');
      await delay(800);

      console.log('%c📁 업로드 중... (50%)');
      await delay(1000);

      console.log('%c📁 업로드 중... (100%)');
      await delay(700);

      console.log('%c📁 서버 처리 중...', 'color: orange;');
      await delay(600);
    }, '파일 업로드');

    console.log('%c✅ 파일 업로드 완료', 'color: green;');
    lastTest.value = '파일 업로드 완료';
    await toast('파일 업로드가 성공적으로 완료되었습니다.');
  } catch (error) {
    console.error('%c❌ 파일 업로드 실패:', 'color: red;', error);
    lastTest.value = '파일 업로드 실패';
  }
};

// 페이지 진입시 초기 상태 설정
onIonViewWillEnter(() => {
  console.log('%c🚀 Loading 테스트 페이지 진입', 'color: blue; font-weight: bold;');
  console.log('%c💡 브라우저 개발자 도구 Console을 열어 로그를 확인하세요', 'color: orange;');
  console.log('%c💡 로딩 중 백버튼을 눌러 차단 동작을 테스트해보세요', 'color: orange;');
});
</script>

<style scoped>
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.test-container h1 {
  text-align: center;
  color: #333;
  margin-bottom: 10px;
}

.description {
  text-align: center;
  color: #666;
  margin-bottom: 30px;
  line-height: 1.6;
}

.status-section {
  background: #f0f8ff;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 30px;
  border-left: 4px solid #007bff;
}

.status-section h2 {
  margin: 0 0 15px 0;
  color: #333;
  font-size: 1.1em;
}

.status-info {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 10px;
}

.status-info p {
  margin: 5px 0;
  font-size: 0.9em;
}

.test-section {
  margin-bottom: 30px;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #fff;
}

.test-section h2 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 1.1em;
}

.test-description {
  color: #666;
  font-size: 0.9em;
  margin-bottom: 15px;
  line-height: 1.5;
}

.test-button {
  --color: #007bff;
  --border-color: #007bff;
  --border-width: 2px;
  --border-radius: 8px;
  --padding-top: 12px;
  --padding-bottom: 12px;
  margin: 5px 0;
  font-weight: 500;
}

.test-button:hover {
  --background: #007bff;
  --color: white;
}

.additional-tests {
  background: #fff3cd;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 30px;
  border-left: 4px solid #ffc107;
}

.additional-tests h2 {
  margin: 0 0 15px 0;
  color: #333;
}

.additional-tests ul {
  margin: 0;
  padding-left: 20px;
}

.additional-tests li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}

.usage-guide {
  background: #d1ecf1;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #17a2b8;
}

.usage-guide h2 {
  margin: 0 0 15px 0;
  color: #333;
}

.usage-guide ol {
  margin: 0;
  padding-left: 20px;
}

.usage-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>