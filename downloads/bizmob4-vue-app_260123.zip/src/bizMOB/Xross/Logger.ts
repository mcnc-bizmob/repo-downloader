export default class Logger {
  /** 정보성 로그 메시지 기록 */
  static info(_sMessage: string): void {
    window.bizMOB.Logger.info(_sMessage);
  }

  /** 일반 로그 메시지 기록 */
  static log(_sMessage: string): void {
    window.bizMOB.Logger.log(_sMessage);
  }

  /** 경고 로그 메시지 기록 */
  static warn(_sMessage: string): void {
    window.bizMOB.Logger.warn(_sMessage);
  }

  /** 디버그 로그 메시지 기록 */
  static debug(_sMessage: string): void {
    window.bizMOB.Logger.debug(_sMessage);
  }

  /** 오류 로그 메시지 기록 */
  static error(_sMessage: string): void {
    window.bizMOB.Logger.error(_sMessage);
  }
}
