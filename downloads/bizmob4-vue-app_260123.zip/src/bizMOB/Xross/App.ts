export default class App {
  /** Native 플러그인 호출 API */
  static callPlugIn(api: string, arg?: {
    [key: string]: any;
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.App.callPlugIn(api, {
        ...arg,
        callback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** 애플리케이션을 종료하거나 재시작합니다. */
  static exit(arg: {
    _sType: 'exit' | 'kill' | 'logout', // 어플리케이션 종료 유형
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): void {
    window.bizMOB.App.exit({
      ...arg,
    });
  }

  /** App 자동 종료 시간 조회 */
  static getTimeout(arg?: {
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.App.getTimeout({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** App 자동 종료 시간 설정 */
  static setTimeout(arg?: {
    _nSeconds: number, // 어플리케이션의 자동 종료 시간 값
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.App.setTimeout({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** App 스플래시 화면 수동 종료 */
  static hideSplash(): void {
    window.bizMOB.App.hideSplash();
  }
}
