export default class Config {
  /** bizMOB Core 모듈의 설정 값을 설정하는 함수 */
  static setConfig(target: string, className: string, arg: any) {
    window.bizMOB.setConfig(target, className, arg);
  }

  /** bizMOB Core 모듈의 설정 값을 조회하는 함수 */
  static getConfig(target: string, className: string) {
    return window.bizMOB.getConfig(target, className);
  }
}
