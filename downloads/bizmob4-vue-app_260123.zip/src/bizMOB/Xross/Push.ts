export default class Push {

  /** 푸시키 정보 조회 */
  static getPushKey(arg?: {
    _bProgressEnable?: boolean, // 푸시 서버와 통신 중일때 화면에 progress 를 표시할지에 대한 여부
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Push.getPushKey({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** 푸시키를 서버에 등록합니다. */
  static registerToServer(arg: {
    _sServerType: 'bizpush' | 'push', // 푸시키를 등록할 서버 타입입니다. bizpush(대용량 푸시 서버)와 push(일반 푸시 서버)
    _sUserId: string, // 푸시키를 등록할 사용자의 아이디
    _sAppName: string, // 푸시키를 등록할 앱 이름
    _bProgressEnable?: boolean, // 푸시 서버와 통신 중일때 화면에 progress 를 표시할지에 대한 여부
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Push.registerToServer({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** 디바이스에 저장된 푸시 등록 관련 정보를 리셋합니다.  */
  static reset(): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Push.reset({
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }
}
