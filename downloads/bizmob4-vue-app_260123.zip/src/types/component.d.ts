// types/component.d.ts
// Vue 전역 컴포넌트 타입 선언

import type {
  IonPage,
  IonHeader,
  IonContent,
  IonFooter,
  IonModal,
} from '@ionic/vue';

/**
 * Vue 3의 전역 컴포넌트 타입 확장
 * 이 선언으로 템플릿에서 import 없이 Ionic 컴포넌트 사용 가능
 */
declare module '@vue/runtime-core' {
  export interface GlobalComponents {
    // PascalCase 컴포넌트 명
    IonPage: typeof IonPage;
    IonHeader: typeof IonHeader;
    IonContent: typeof IonContent;
    IonFooter: typeof IonFooter;
    IonModal: typeof IonModal;

    // kebab-case 별칭들 (템플릿에서 <ion-*> 형태로 사용)
    'ion-page': typeof IonPage;
    'ion-header': typeof IonHeader;
    'ion-content': typeof IonContent;
    'ion-footer': typeof IonFooter;
    'ion-modal': typeof IonModal;
  }
}

// 이 파일을 모듈로 만들어 타입 확장이 전역에 적용되도록 함
export { };
