export default {
  message: {
    welcome: 'bizMOB 샘플 프로젝트에 오신 것을 환영합니다',
    greeting: '안녕하세요',
    user: {
      welcome: '{name}님 환영합니다',
      profile_greeting: '{0}님의 프로필입니다'
    },
    loading: {
      full: '데이터를 불러오는 중입니다. 잠시만 기다려주세요.',
      short: '로딩 중...'
    }
  },
  button: {
    save: '저장',
    cancel: '취소',
    confirm: '확인'
  },
  error: {
    network: '네트워크 오류가 발생했습니다',
    validation: '입력값을 확인해주세요'
  }
};
