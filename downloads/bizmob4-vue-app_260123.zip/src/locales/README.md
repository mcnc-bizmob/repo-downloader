# bizMOB Vue 다국어 가이드

bizMOB Vue 프로젝트에서 다국어(i18n) 처리를 위한 컴포저블 사용법과 설정 방법을 설명합니다.

---

## 1. 사용법

### 1.1 기본 사용
이 폴더에 `locale.{언어코드}.ts` 형태의 TypeScript 파일을 추가하면 자동으로 다국어 시스템에 포함됩니다.

```
src/locales/
├── locale.ko.ts      # 한국어 (기본)
├── locale.en.ts      # 영어
├── locale.ja.ts      # 일본어 (추가하면 자동 인식)
└── locale.zh.ts      # 중국어 (추가하면 자동 인식)
```

### 1.2 파일 형식

```typescript
// src/locales/locale.ko.ts
export default {
  message: {
    welcome: 'bizMOB 샘플 프로젝트에 오신 것을 환영합니다',
    greeting: '안녕하세요',
    user: {
      welcome: '{name}님 환영합니다'
    }
  },
  button: {
    save: '저장',
    cancel: '취소'
  },
  error: {
    network: '네트워크 오류가 발생했습니다'
  }
}
```

### 1.3 Vue에서의 다국어 클래스 사용법

Vue 프로젝트에서는 다국어 처리를 위해 두 가지 방식 중 선택하여 사용할 수 있습니다:

**권장: bizMOB Vue 컴포저블 사용**
- `useApp()` 컴포저블의 `t()`, `changeLocale()` 함수 사용
- Xross Localization 클래스 기반으로 개발된 Vue 전용 래퍼

**직접 구현 시: Xross Localization 클래스 사용**
- 프로젝트에서 직접 다국어 기능을 구현할 경우
- `bizMOB.Localization.getLocale()`, `setLocale()` 메서드 직접 호출

### 1.4 컴포넌트에서 사용

```vue
<template>
  <div>
    <h1>{{ $t('message.welcome') }}</h1>
    <p>{{ $t('message.user.welcome', { name: '홍길동' }) }}</p>
    <button>{{ $t('button.save') }}</button>
  </div>
</template>

<script setup>
import { useApp } from '@bizMOB/vue'

const { t, changeLocale } = useApp()

// 프로그래밍 방식으로 사용
const greeting = t('message.greeting')
const userWelcome = t('message.user.welcome', { name: 'John' })

// 언어 변경
await changeLocale('en')
</script>
```

---

## 2. 지원 언어 코드

bizMOB에서 지원하는 언어 코드 목록입니다. 파일명은 **2자리 언어 코드**를 사용하세요.

| 파일명 | 언어 | 전체 코드 |
|--------|------|-----------|
| `locale.ko.ts` | 한국어 | ko-KR |
| `locale.en.ts` | 영어 | en-US |
| `locale.ja.ts` | 일본어 | ja-JP |
| `locale.zh.ts` | 중국어 | zh-CN |
| `locale.de.ts` | 독일어 | de-DE |
| `locale.fr.ts` | 프랑스어 | fr-FR |
| `locale.es.ts` | 스페인어 | es-ES |
| `locale.it.ts` | 이탈리아어 | it-IT |
| `locale.pt.ts` | 포르투갈어 | pt-BR |
| `locale.ru.ts` | 러시아어 | ru-RU |
| `locale.ar.ts` | 아랍어 | ar-SA |
| `locale.hi.ts` | 힌디어 | hi-IN |
| `locale.th.ts` | 태국어 | th-TH |
| `locale.vi.ts` | 베트남어 | vi-VN |
| `locale.id.ts` | 인도네시아어 | id-ID |
| `locale.ms.ts` | 말레이어 | ms-MY |
| `locale.tl.ts` | 타갈로그어 | tl-PH |

전체 지원 언어 목록은 `/public/bizMOB/bizMOB-locale.js` 파일을 참조하세요.

---

## 3. 자동 기능

1. **자동 로드**: TS 파일 추가시 자동으로 시스템에 포함
2. **자동 인식**: 파일명을 언어 코드로 자동 매핑
3. **핫 리로드**: 개발 중 파일 수정시 즉시 반영
4. **타입 안전성**: TypeScript 지원으로 오타 방지 및 자동완성

---

## 4. 작성 가이드

### 4.1 TypeScript 파일 구조 권장사항

**기본 구조 (비즈니스 프로젝트)**

```typescript
// src/locales/locale.ko.ts
export default {
  message: {
    welcome: '프로젝트에 오신 것을 환영합니다',
    greeting: '안녕하세요',
    loading: {
      full: '데이터를 불러오는 중입니다. 잠시만 기다려주세요.',
      short: '로딩 중...'
    }
  },
  button: {
    save: '저장',
    cancel: '취소',
    confirm: '확인'
  },
  error: {
    network: '네트워크 오류가 발생했습니다',
    validation: '입력값을 확인해주세요'
  }
}
```

**서버 기반 구조 (서버 연동시)**

```typescript
// 서버에서 받은 데이터 변환 후
export default {
  LABEL: {
    '40554': 'Esqueci a senha',
    '40555': 'Login',
    '40556': {
      full: '파일을 업로드하는 중입니다',
      short: '업로드 중'
    }
  },
  MSG: {
    '50001': '네트워크 오류가 발생했습니다'
  }
}
```

### 4.2 네이밍 컨벤션
- **스네이크 케이스**: `user_name`, `error_message`
- **계층 구조**: 기능별/페이지별로 그룹화
- **일관성**: 같은 의미의 단어는 동일하게 사용

---

## 5. 고급 기능 (서버 기반 다국어)

서버에서 다국어 데이터를 가져와야 하는 경우, `src/locales/index.ts` 파일을 수정하여 구현할 수 있습니다.

### 5.1 수정해야 할 부분

1. **API 호출 함수 교체** (`callServerApi` 함수)
2. **데이터 변환 로직 구현** (`transformServerData` 함수)

```typescript
// src/locales/index.ts에서

// 1. API 호출 로직 교체
async function callServerApi(lang: string): Promise<any> {
  // TODO: 각 비즈니스 프로젝트의 API 모듈로 교체
  // 예시:
  // return await ApiService.getI18nData(lang);
  // return await httpClient.get(`/dictionary/${lang}`);
  // return await fetch(`/api/i18n/${lang}`).then(res => res.json());
}

// 2. 데이터 변환 로직 구현
function transformServerData(data: any): Record<string, any> {
  // TODO: 서버 원본 데이터를 아래 형식으로 변환

  /*
   * 변환 결과물 형태 (Vue-i18n 형식):
   * {
   *   "LABEL": {
   *     "40554": "Esqueci a senha",
   *     "40555": "Login",
   *     "40556": {
   *       "full": "파일을 업로드하는 중입니다",
   *       "short": "업로드 중"
   *     }
   *   },
   *   "MSG": {
   *     "50001": "네트워크 오류가 발생했습니다"
   *   }
   * }
   *
   * 사용 예시:
   * - t('LABEL.40554')           → "Esqueci a senha"
   * - t('LABEL.40556.full')      → "파일을 업로드하는 중입니다"
   * - t('LABEL.40556.short')     → "업로드 중"
   */
}
```

### 5.2 간단한 폴더 구조

```
src/locales/
├── locale.ko.ts      # 기본 한국어 (로그인 화면용 기본 데이터)
├── locale.en.ts      # 기본 영어 (로그인 화면용 기본 데이터)
├── index.ts          # 서버 연동 로직 (필요시에만)
└── README.md         # 이 파일
```

### 5.3 사용 방법

**(공통) main.ts에서 i18n 설정**

```typescript
// main.ts
import { createApp } from 'vue'
import { i18n } from '@bizMOB/vue'
import App from './App.vue'

const app = createApp(App)
app.use(i18n)
app.mount('#app')
```

**로컬모드 사용방법**

```vue
<!-- App.vue -->
<script setup lang="ts">
import { onMounted } from 'vue';
import { useApp } from '@bizMOB/vue';

const { initLocale } = useApp();

onMounted(async() => {
  await initLocale();  // locales 폴더에서 언어 설정 가져와서 Vue-i18n 업데이트
})
</script>
```

```vue
<!-- *.vue -->
<script setup lang="ts">
import { useApp } from '@bizMOB/vue';
const { changeLocale } = useApp();

// 언어 변경
await changeLocale('en'); // TS 파일에서 즉시 전환
</script>
```

**서버데이터 활용방법**

```vue
<!-- App.vue -->
<script setup lang="ts">
import { onMounted } from 'vue';
import { initLocale } from '@/locales'

onMounted(() => {
  // 백그라운드에서 서버 데이터 병합 (await 없이)
  initLocale().catch(console.warn)
})
</script>
```

```typescript
// 서버 모드
import { changeLocale } from '@/locales'
await changeLocale('en')  // 로컬 + 서버 데이터 병합 → 언어 전환
```