/**
 * @fileoverview 서버 기반 다국어 지원
 * 
 * 로컬 TS 파일의 기본 다국어 데이터와 서버의 최신 데이터를 병합하여
 * 완전한 다국어 환경을 제공합니다.
 * 
 * 주요 기능:
 * - 서버에서 최신 다국어 데이터 로드
 * - 로컬 TS 파일과 서버 데이터 자동 병합
 * - 서버 오류시 로컬 데이터로 안전한 fallback
 * 
 * 사용법:
 * - initLocale(): 앱 시작시 백그라운드에서 서버 데이터 병합
 * - changeLocale(lang): 언어 변경시 서버 데이터와 함께 전환
 * 
 * ⚠️ 주의사항:
 * 서버 기반 다국어를 사용하지 않는 경우, 이 파일을 삭제해도 됩니다.
 * 로컬 TS 파일만 사용하는 경우 @bizMOB/vue의 useApp()으로 충분합니다.
 */

import { useApp } from '@bizMOB/vue';

// ========================================
// 🚨 비즈니스에서 구현해야 할 함수들 🚨
// ========================================

/**
 * 서버 API 호출 (비즈니스별 구현 필요)
 * ⚠️ 이 함수는 직접 호출하지 마세요. changeLocale() 등에서 자동으로 호출됩니다.
 * @param lang 언어 코드 (예: 'ko', 'en')
 * @returns 서버에서 받은 원본 데이터
 */
async function callServerApi(lang: string): Promise<any> {
  // TODO: 각 비즈니스 프로젝트의 API 모듈로 교체
  // 예시:
  // return await ApiService.getI18nData(lang);
  // return await httpClient.get(`/dictionary/${lang}`);
  // return await fetch(`/api/i18n/${lang}`).then(res => res.json());

  throw new Error('🚨 callServerApi function must be implemented in your business project');
}

/**
 * 서버 데이터 변환 (비즈니스별 구현 필요)
 * ⚠️ 이 함수는 직접 호출하지 마세요. changeLocale() 등에서 자동으로 호출됩니다.
 * @param data 서버에서 받은 원본 데이터
 * @returns Vue-i18n 형식으로 변환된 데이터
 */
function transformServerData(data: any): Record<string, any> {
  // TODO: 서버 원본 데이터를 아래 형식으로 변환하는 로직 구현

  /*
   * 🎯 변환 결과물 형태 (Vue-i18n 형식):
   * {
   *   "LABEL": {
   *     "40554": "Esqueci a senha",
   *     "40555": "Login",
   *     "40556": {
   *       "full": "파일을 업로드하는 중입니다",
   *       "short": "업로드 중"
   *     }
   *   },
   *   "MSG": {
   *     "50001": "네트워크 오류가 발생했습니다"
   *   }
   * }
   *
   * 사용 예시:
   * - t('LABEL.40554')           → "Esqueci a senha"
   * - t('LABEL.40556.full')      → "파일을 업로드하는 중입니다"
   * - t('LABEL.40556.short')     → "업로드 중"
   */

  throw new Error('🚨 transformServerData function must be implemented in your business project');
}

// ========================================
// ✅ 기본 제공 함수들 (필요시 수정)
// ========================================

const { setLocaleMessage, mergeLocaleMessage, changeLocale: changeVueLocale } = useApp();


// 서버 데이터와 로컬 데이터 병합
export async function mergeServerLanguage(lang: string) {
  try {
    const serverData = await callServerApi(lang);
    const messages = transformServerData(serverData);

    // 기존 로컬 데이터에 서버 데이터 병합
    mergeLocaleMessage(lang, messages);

    return messages;
  } catch (error) {
    console.error(`Failed to merge language ${lang}:`, error);
    // 서버 오류시 로컬 데이터 그대로 사용
  }
}

// 언어 변경 + 서버 데이터 병합 (서버 모드에서의 changeLocale)
export async function changeLocale(lang: string) {
  // 1. 서버 데이터를 로컬 TS 파일과 병합
  await mergeServerLanguage(lang);

  // 2. Vue-i18n 언어 변경
  await changeVueLocale(lang);
}

// 앱 시작시 초기 언어 설정
export async function initLocale() {
  const defaultLang = import.meta.env.VITE_I18N_LOCALE;

  try {
    // 서버 데이터를 로컬 TS 파일과 병합
    await changeLocale(defaultLang);
  } catch (error) {
    // 서버 오류시 로컬 TS 데이터만 사용
    console.warn('Server language merge failed, using local TS data only');
    await changeVueLocale(defaultLang);
  }
}
