// ✅ 구형 브라우저(ES5 환경)까지 정상 동작 보장. 반드시 최상단에 위치해야 함!
// Chrome 개발자도구 → Network 탭 → index-legacy.*.js 파일 로드되는지 확인
import 'core-js/stable';
import 'regenerator-runtime/runtime';

import { createApp } from 'vue';
import { createPinia } from 'pinia';
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';

import App from './App.vue';
import router from './router';

import { i18n, ionicPlugin, bizMOBPlugin } from '@bizMOB/vue';

// 📌 CSS 로딩 순서 중요: Ionic CSS 먼저, 커스텀 CSS 나중에
// 1. Ionic CSS는 위의 ionicPlugin import 시점에 로드됨
// 2. 글로벌 CSS는 마지막에 로드하여 Ionic CSS를 오버라이드할 수 있도록 함
import '@/assets/css/global.scss';

// Vue 앱 생성 및 기본 설정
const app = createApp(App);
// Pinia 생성 및 Persisted State 설정
const pinia = createPinia().use(piniaPluginPersistedstate);

// 플러그인 등록
app.use(pinia);
app.use(router);
app.use(i18n); // i18n 등록
app.use(bizMOBPlugin); // bizMOB 플러그인 등록
app.use(ionicPlugin);  // Ionic 플러그인 등록

app.mount('#app');
