// ============================================================================
// 📋 Constants - 상수 정의
// ============================================================================

/**
 * API 엔드포인트 상수
 */
export const API_ENDPOINTS = {
  // 파일 관련
  // FILE: {
  //   UPLOAD: '/api/file/upload',
  //   DOWNLOAD: '/api/file/download',
  //   DELETE: '/api/file/delete'
  // }
} as const;

/**
 * 앱 설정 상수
 */
export const APP_CONFIG = {
  // 앱 기본 정보
  // APP_NAME: 'BizMOB App',
  // VERSION: '1.0.0',
  // BUILD_NUMBER: '1',

  // 페이지네이션
  // DEFAULT_PAGE_SIZE: 20,
  // MAX_PAGE_SIZE: 100,

  // 타임아웃
  // REQUEST_TIMEOUT: 30000, // 30초
  // FILE_UPLOAD_TIMEOUT: 300000, // 5분
} as const;

/**
 * 기본값 상수
 */
export const DEFAULT_VALUES = {
  // 언어 설정
  // LOCALE: 'ko',
  // FALLBACK_LOCALE: 'en',

  // 날짜 형식
  // DATE_FORMAT: 'YYYY-MM-DD',
  // DATETIME_FORMAT: 'YYYY-MM-DD HH:mm:ss',
  // TIME_FORMAT: 'HH:mm',

  // 파일 크기 제한 (바이트)
  // MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  // MAX_IMAGE_SIZE: 5 * 1024 * 1024,  // 5MB
} as const;

/**
 * 파일 관련 상수
 */
export const FILE_CONSTANTS = {
  // 허용된 이미지 확장자
  // ALLOWED_IMAGE_EXTENSIONS: ['jpg', 'jpeg', 'png', 'gif', 'webp'],

  // 허용된 문서 확장자
  // ALLOWED_DOCUMENT_EXTENSIONS: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'],

  // MIME 타입
  // MIME_TYPES: {
  //   'jpg': 'image/jpeg',
  //   'jpeg': 'image/jpeg',
  //   'png': 'image/png',
  //   'gif': 'image/gif',
  //   'pdf': 'application/pdf'
  // }
} as const;

/**
 * 로컬 스토리지 키 상수
 */
export const STORAGE_KEYS = {
  // 사용자 정보
  // USER_TOKEN: 'user_token',
  // USER_INFO: 'user_info',
  // USER_PREFERENCES: 'user_preferences',

  // 앱 설정
  // APP_LANGUAGE: 'app_language',
  // APP_THEME: 'app_theme',
  // APP_NOTIFICATIONS: 'app_notifications',
} as const;

/**
 * HTTP 상태 코드 상수
 */
export const HTTP_STATUS = {
  // 성공
  // OK: 200,
  // CREATED: 201,
  // NO_CONTENT: 204,

  // 클라이언트 에러
  // BAD_REQUEST: 400,
  // UNAUTHORIZED: 401,
  // FORBIDDEN: 403,
  // NOT_FOUND: 404,

  // 서버 에러
  // INTERNAL_SERVER_ERROR: 500,
  // BAD_GATEWAY: 502,
  // SERVICE_UNAVAILABLE: 503,
} as const;
