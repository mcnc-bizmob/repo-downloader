// ============================================================================
// 📱 Native Utils - bizMOB 네이티브 관련 유틸리티 함수들
// ============================================================================

/**
 * 플랫폼 감지
 */
// export const getPlatform = (): 'android' | 'ios' | 'web' => {
//   if (typeof window === 'undefined') return 'web';
//
//   if (window.bizMOB?.Device?.isAndroid?.()) {
//     return 'android';
//   } else if (window.bizMOB?.Device?.isIOS?.()) {
//     return 'ios';
//   }
//   return 'web';
// };

/**
 * 디바이스 타입 감지
 * @returns 디바이스 타입
 * @example
 * getDeviceType() // 'mobile' | 'tablet' | 'desktop'
 */
// export const getDeviceType = (): 'mobile' | 'tablet' | 'desktop' => {
//   if (typeof window === 'undefined') return 'desktop';
//
//   if (window.bizMOB?.Device?.isPhone?.()) {
//     return 'mobile';
//   } else if (window.bizMOB?.Device?.isTablet?.()) {
//     return 'tablet';
//   } else if (window.bizMOB?.Device?.isPC?.()) {
//     return 'desktop';
//   }
//
//   // fallback to user agent detection
//   const userAgent = navigator.userAgent;
//   if (/tablet|ipad/i.test(userAgent)) {
//     return 'tablet';
//   } else if (/mobile|android|iphone/i.test(userAgent)) {
//     return 'mobile';
//   }
//   return 'desktop';
// };

/**
 * 앱 환경인지 확인
 * @returns 앱 환경이면 true, 웹 환경이면 false
 * @example
 * isNativeApp() // true or false
 */
// export const isNativeApp = (): boolean => {
//   return typeof window !== 'undefined' && !!window.bizMOB?.Device?.isApp?.();
// };

/**
 * 웹 환경인지 확인
 * @returns 웹 환경이면 true, 앱 환경이면 false
 * @example
 * isWebEnvironment() // true or false
 */
// export const isWebEnvironment = (): boolean => {
//   return !isNativeApp();
// };

/**
 * 디바이스 정보 조회
 * @param key - 조회할 정보 키
 * @returns 디바이스 정보 값
 * @example
 * getDeviceInfo('app_version') // '1.0.0'
 * getDeviceInfo('os_version') // 'iOS 16.0'
 */
// export const getDeviceInfo = (key?: string): any => {
//   if (!isNativeApp()) {
//     return null;
//   }
//
//   try {
//     if (key) {
//       return window.bizMOB?.Device?.getInfo?.({ _sKey: key });
//     } else {
//       return window.bizMOB?.Device?.getInfo?.();
//     }
//   } catch (error) {
//     console.error('Failed to get device info:', error);
//     return null;
//   }
// };

/**
 * 파일 선택/촬영 헬퍼
 * @param options - 파일 선택 옵션
 * @returns Promise<파일 정보>
 * @example
 * const file = await selectFile({ source: 'camera', type: 'image' });
 * const files = await selectFile({ source: 'gallery', type: 'image', multiple: true });
 */
// export const selectFile = async (options: {
//   source: 'camera' | 'gallery';
//   type?: 'image' | 'video' | 'all';
//   multiple?: boolean;
//   maxCount?: number;
// }): Promise<any> => {
//   if (!isNativeApp()) {
//     throw new Error('File selection is only available in native app');
//   }
//
//   try {
//     if (options.source === 'camera') {
//       return await window.bizMOB?.System?.callCamera?.({
//         _bAutoVerticalHorizontal: true
//       });
//     } else {
//       return await window.bizMOB?.System?.callGallery?.({
//         _sType: options.type || 'all',
//         _nMaxCount: options.maxCount || (options.multiple ? 10 : 1)
//       });
//     }
//   } catch (error) {
//     console.error('Failed to select file:', error);
//     throw error;
//   }
// };

/**
 * 이미지 촬영 헬퍼
 * @param options - 촬영 옵션
 * @returns Promise<이미지 정보>
 * @example
 * const image = await captureImage({ fileName: 'profile.jpg' });
 */
// export const captureImage = async (options?: {
//   fileName?: string;
//   directory?: string;
//   autoVerticalHorizontal?: boolean;
// }): Promise<any> => {
//   if (!isNativeApp()) {
//     throw new Error('Camera is only available in native app');
//   }
//
//   try {
//     return await window.bizMOB?.System?.callCamera?.({
//       _sFileName: options?.fileName,
//       _sDirectory: options?.directory,
//       _bAutoVerticalHorizontal: options?.autoVerticalHorizontal ?? true
//     });
//   } catch (error) {
//     console.error('Failed to capture image:', error);
//     throw error;
//   }
// };

/**
 * 갤러리에서 이미지/비디오 선택 헬퍼
 * @param options - 선택 옵션
 * @returns Promise<선택된 파일들>
 * @example
 * const images = await selectFromGallery({ type: 'image', maxCount: 5 });
 */
// export const selectFromGallery = async (options?: {
//   type?: 'image' | 'video' | 'all';
//   maxCount?: number;
// }): Promise<any> => {
//   if (!isNativeApp()) {
//     throw new Error('Gallery is only available in native app');
//   }
//
//   try {
//     return await window.bizMOB?.System?.callGallery?.({
//       _sType: options?.type || 'all',
//       _nMaxCount: options?.maxCount || 1
//     });
//   } catch (error) {
//     console.error('Failed to select from gallery:', error);
//     throw error;
//   }
// };

/**
 * GPS 위치 정보 조회
 * @returns Promise<위치 정보>
 * @example
 * const location = await getCurrentLocation();
 * console.log(location.latitude, location.longitude);
 */
// export const getCurrentLocation = async (): Promise<{
//   latitude: number;
//   longitude: number;
//   address?: string;
// }> => {
//   if (!isNativeApp()) {
//     // 웹 환경에서는 브라우저 Geolocation API 사용
//     return new Promise((resolve, reject) => {
//       if (!navigator.geolocation) {
//         reject(new Error('Geolocation is not supported'));
//         return;
//       }
//
//       navigator.geolocation.getCurrentPosition(
//         (position) => {
//           resolve({
//             latitude: position.coords.latitude,
//             longitude: position.coords.longitude
//           });
//         },
//         (error) => {
//           reject(error);
//         }
//       );
//     });
//   }
//
//   try {
//     const result = await window.bizMOB?.System?.getGPS?.();
//     return {
//       latitude: result.latitude,
//       longitude: result.longitude,
//       address: result.address
//     };
//   } catch (error) {
//     console.error('Failed to get GPS location:', error);
//     throw error;
//   }
// };

/**
 * 전화 걸기
 * @param phoneNumber - 전화번호
 * @returns Promise<호출 결과>
 * @example
 * await makePhoneCall('010-1234-5678');
 */
// export const makePhoneCall = async (phoneNumber: string): Promise<any> => {
//   if (!isNativeApp()) {
//     // 웹 환경에서는 tel: 링크 사용
//     window.open(`tel:${phoneNumber}`, '_self');
//     return;
//   }
//
//   try {
//     return await window.bizMOB?.System?.callTEL?.({
//       _sNumber: phoneNumber
//     });
//   } catch (error) {
//     console.error('Failed to make phone call:', error);
//     throw error;
//   }
// };

/**
 * SMS 발송
 * @param phoneNumbers - 전화번호 배열
 * @param message - 메시지 내용
 * @returns Promise<발송 결과>
 * @example
 * await sendSMS(['010-1234-5678'], 'Hello World');
 */
// export const sendSMS = async (
//   phoneNumbers: string[],
//   message?: string
// ): Promise<any> => {
//   if (!isNativeApp()) {
//     // 웹 환경에서는 sms: 링크 사용
//     const smsUrl = `sms:${phoneNumbers.join(',')}${message ? `?body=${encodeURIComponent(message)}` : ''}`;
//     window.open(smsUrl, '_self');
//     return;
//   }
//
//   try {
//     return await window.bizMOB?.System?.callSMS?.({
//       _aNumber: phoneNumbers,
//       _sMessage: message
//     });
//   } catch (error) {
//     console.error('Failed to send SMS:', error);
//     throw error;
//   }
// };

/**
 * 브라우저 열기
 * @param url - 열 URL
 * @returns Promise<결과>
 * @example
 * await openBrowser('https://www.example.com');
 */
// export const openBrowser = async (url: string): Promise<any> => {
//   if (!isNativeApp()) {
//     // 웹 환경에서는 새 창으로 열기
//     window.open(url, '_blank');
//     return;
//   }
//
//   try {
//     return await window.bizMOB?.System?.callBrowser?.({
//       _sURL: url
//     });
//   } catch (error) {
//     console.error('Failed to open browser:', error);
//     throw error;
//   }
// };

/**
 * 지도 앱 열기
 * @param location - 위치 정보 (주소 또는 좌표)
 * @returns Promise<결과>
 * @example
 * await openMap('서울특별시 강남구 테헤란로 152');
 * await openMap('37.5665,126.9780'); // 위도,경도
 */
// export const openMap = async (location: string): Promise<any> => {
//   if (!isNativeApp()) {
//     // 웹 환경에서는 Google Maps 열기
//     const mapsUrl = `https://maps.google.com/maps?q=${encodeURIComponent(location)}`;
//     window.open(mapsUrl, '_blank');
//     return;
//   }
//
//   try {
//     return await window.bizMOB?.System?.callMap?.({
//       _sLocation: location
//     });
//   } catch (error) {
//     console.error('Failed to open map:', error);
//     throw error;
//   }
// };

/**
 * 파일 존재 여부 확인
 * @param filePath - 파일 경로
 * @returns Promise<존재 여부>
 * @example
 * const exists = await fileExists('/path/to/file.jpg');
 */
// export const fileExists = async (filePath: string): Promise<boolean> => {
//   if (!isNativeApp()) {
//     return false; // 웹 환경에서는 파일 시스템 접근 불가
//   }
//
//   try {
//     const result = await window.bizMOB?.File?.exist?.({
//       _sFilePath: filePath
//     });
//     return result?.result === true;
//   } catch (error) {
//     console.error('Failed to check file existence:', error);
//     return false;
//   }
// };

/**
 * 파일 정보 조회
 * @param filePath - 파일 경로
 * @returns Promise<파일 정보>
 * @example
 * const fileInfo = await getFileInfo('/path/to/file.jpg');
 */
// export const getFileInfo = async (filePath: string): Promise<any> => {
//   if (!isNativeApp()) {
//     throw new Error('File info is only available in native app');
//   }
//
//   try {
//     return await window.bizMOB?.File?.getInfo?.({
//       _sFilePath: filePath
//     });
//   } catch (error) {
//     console.error('Failed to get file info:', error);
//     throw error;
//   }
// };

/**
 * 푸시 알림 권한 확인
 * @returns Promise<권한 상태>
 * @example
 * const hasPermission = await checkPushPermission();
 */
// export const checkPushPermission = async (): Promise<boolean> => {
//   if (!isNativeApp()) {
//     // 웹 환경에서는 Notification API 사용
//     if (!('Notification' in window)) {
//       return false;
//     }
//     return Notification.permission === 'granted';
//   }
//
//   try {
//     const pushKey = await window.bizMOB?.Push?.getPushKey?.();
//     return !!pushKey?.push_key;
//   } catch (error) {
//     console.error('Failed to check push permission:', error);
//     return false;
//   }
// };

/**
 * 주소록 접근 권한 확인 및 연락처 조회
 * @returns Promise<연락처 목록>
 * @example
 * const contacts = await getContacts();
 */
// export const getContacts = async (): Promise<any[]> => {
//   if (!isNativeApp()) {
//     throw new Error('Contacts access is only available in native app');
//   }
//
//   try {
//     const result = await window.bizMOB?.Contacts?.get?.();
//     return result?.contacts || [];
//   } catch (error) {
//     console.error('Failed to get contacts:', error);
//     throw error;
//   }
// };

/**
 * 네트워크 상태 확인
 * @returns 네트워크 연결 상태
 * @example
 * const isOnline = checkNetworkStatus();
 */
// export const checkNetworkStatus = (): boolean => {
//   if (typeof window === 'undefined') {
//     return true; // 서버 환경에서는 항상 true
//   }
//
//   if (isNativeApp()) {
//     // 네이티브 앱에서는 bizMOB API 사용 가능
//     try {
//       return window.bizMOB?.Network?.isConnected?.() ?? navigator.onLine;
//     } catch (error) {
//       return navigator.onLine;
//     }
//   }
//
//   return navigator.onLine;
// };

/**
 * 앱 종료
 * @example
 * exitApp();
 */
// export const exitApp = (): void => {
//   if (!isNativeApp()) {
//     // 웹 환경에서는 브라우저 창 닫기 시도
//     window.close();
//     return;
//   }
//
//   try {
//     window.bizMOB?.App?.exit?.();
//   } catch (error) {
//     console.error('Failed to exit app:', error);
//   }
// };
