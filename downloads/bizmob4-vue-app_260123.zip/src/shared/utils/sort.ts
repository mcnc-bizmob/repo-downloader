// ============================================================================
// 🔤 Sort Utils - 배열 및 객체 정렬 유틸리티 함수들
// ============================================================================

/**
 * 🎯 지원하는 정렬 함수 목록
 *
 * 📌 기본 정렬 함수들:
 * • sortArray           - 기본 타입 배열 정렬 (숫자, 문자열, 불린, 날짜)
 * • sortByKey           - 객체 배열의 특정 키 기준 정렬
 * • sortByMultipleKeys  - 여러 조건 순차 적용 정렬
 * • sortByDate          - 날짜 기준 정렬 (문자열 자동 변환)
 * • sortByNumber        - 숫자 기준 정렬 (자연어 순서, NaN 처리)
 * • sortByString        - 문자열 정렬 (로케일 지원, 한국어 포함)
 *
 * 📌 고급 정렬 함수들:
 * • sortByCustom        - 사용자 정의 비교 함수로 정렬
 * • shuffleArray        - Fisher-Yates 알고리즘으로 배열 섞기
 * • binarySearch        - 정렬된 배열에서 이진 탐색 (O(log n))
 * • isSorted            - 배열 정렬 상태 확인
 * • stableSort          - 안정 정렬 (동일 값의 원본 순서 유지)
 * • getTopK             - 부분 정렬 (상위/하위 K개 요소만 추출)
 *
 * 🔧 주요 특징:
 * • TypeScript 완전 지원 (제네릭, 타입 안전성)
 * • 한국어/국제화 정렬 지원 (Intl.Collator)
 * • null/undefined 안전 처리
 * • 중첩 객체 키 접근 지원 (KeyExtractor)
 * • 불변성 보장 (원본 배열 변경 안함)
 * • 다양한 데이터 타입 지원 (Date, number, string, boolean)
 *
 * 🤖 AI 에이전트 친화적 구조:
 * • 명확한 함수 목적과 사용법 JSDoc 작성
 * • 실용적인 코드 예제와 시나리오 제공
 * • 타입 정보와 매개변수 상세 설명
 * • 예외 상황 및 경계 조건 처리 가이드
 * • 성능 특성과 복잡도 정보 명시
 * • 한국어 지원 및 로케일 처리 안내
 * • 단계별 사용 예제 (기본 → 고급 활용)
 * • 에러 처리 및 fallback 동작 설명
 */

/**
 * 정렬 방향 타입
 */
export type SortDirection = 'asc' | 'desc';

/**
 * 정렬 가능한 기본 타입
 */
export type SortableValue = string | number | boolean | Date | null | undefined;

/**
 * 객체에서 값을 추출하는 함수 타입
 */
export type KeyExtractor<T> = (item: T) => SortableValue;

/**
 * 정렬 조건 타입 (다중 정렬용)
 */
export interface SortCriteria<T> {
  key: keyof T | KeyExtractor<T>;
  direction?: SortDirection;
}

/**
 * 기본 배열 정렬 (primitives)
 * @description 숫자, 문자열, 불린 등의 기본 타입 배열을 정렬합니다.
 * @param array - 정렬할 배열
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'asc')
 * @returns 정렬된 새로운 배열
 * @throws {Error} 배열이 null 또는 undefined인 경우
 * @since 1.0.0
 * @example
 * ```typescript
 * // 숫자 배열 정렬
 * sortArray([3, 1, 4, 1, 5]) // [1, 1, 3, 4, 5]
 * sortArray([3, 1, 4, 1, 5], 'desc') // [5, 4, 3, 1, 1]
 *
 * // 문자열 배열 정렬 (한국어 지원)
 * sortArray(['banana', 'apple', 'cherry'], 'desc') // ['cherry', 'banana', 'apple']
 * sortArray(['바나나', '사과', '체리']) // ['바나나', '사과', '체리']
 *
 * // 불린 배열 정렬
 * sortArray([true, false, true]) // [false, true, true]
 *
 * // Date 배열 정렬
 * sortArray([new Date('2023-01-01'), new Date('2022-12-31')]) // [2022-12-31, 2023-01-01]
 *
 * // null/undefined 처리
 * sortArray([3, null, 1, undefined, 2]) // [1, 2, 3, null, undefined]
 * ```
 */
export const sortArray = <T extends SortableValue>(
  array: T[],
  direction: SortDirection = 'asc'
): T[] => {
  const sortedArray = [...array].sort((a, b) => {
    // null, undefined를 배열 끝으로 이동
    if (a == null && b == null) return 0;
    if (a == null) return 1;
    if (b == null) return -1;

    // 타입별 비교 로직
    if (typeof a === 'string' && typeof b === 'string') {
      const result = a.localeCompare(b, 'ko', { sensitivity: 'base' });
      return direction === 'asc' ? result : -result;
    }

    if (typeof a === 'number' && typeof b === 'number') {
      const result = a - b;
      return direction === 'asc' ? result : -result;
    }

    if (typeof a === 'boolean' && typeof b === 'boolean') {
      const result = Number(a) - Number(b);
      return direction === 'asc' ? result : -result;
    }

    if (a instanceof Date && b instanceof Date) {
      const result = a.getTime() - b.getTime();
      return direction === 'asc' ? result : -result;
    }

    // 기본 비교 (문자열 변환 후 비교)
    const strA = String(a);
    const strB = String(b);
    const result = strA.localeCompare(strB, 'ko');
    return direction === 'asc' ? result : -result;
  });

  return sortedArray;
};

/**
 * 객체 배열을 특정 키로 정렬
 * @description JSON 객체 배열을 지정된 키(속성)를 기준으로 정렬합니다.
 * @param array - 정렬할 객체 배열
 * @param key - 정렬 기준 키 (string 또는 KeyExtractor 함수)
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'asc')
 * @returns 정렬된 새로운 배열
 * @throws {Error} key가 객체에 존재하지 않는 경우 undefined로 처리
 * @since 1.0.0
 * @example
 * ```typescript
 * // 기본 키로 정렬
 * const users = [{name: 'John', age: 30}, {name: 'Jane', age: 25}];
 * sortByKey(users, 'age') // [{name: 'Jane', age: 25}, {name: 'John', age: 30}]
 * sortByKey(users, 'name', 'desc') // [{name: 'John', age: 30}, {name: 'Jane', age: 25}]
 *
 * // 중첩 객체 접근을 위한 함수 사용
 * const products = [
 *   {name: 'A', stats: {sales: 100}},
 *   {name: 'B', stats: {sales: 200}}
 * ];
 * sortByKey(products, item => item.stats.sales, 'desc')
 * // [{name: 'B', stats: {sales: 200}}, {name: 'A', stats: {sales: 100}}]
 *
 * // 다양한 타입 처리
 * const mixed = [
 *   {id: 1, date: '2023-01-01', active: true},
 *   {id: 2, date: '2022-12-31', active: false}
 * ];
 * sortByKey(mixed, 'date') // 날짜 문자열 자동 변환
 * sortByKey(mixed, 'active') // 불린 값 정렬
 * ```
 */
export const sortByKey = <T extends Record<string, any>>(
  array: T[],
  key: keyof T | KeyExtractor<T>,
  direction: SortDirection = 'asc'
): T[] => {
  const getValue = (item: T): SortableValue => {
    if (typeof key === 'function') {
      return key(item);
    }
    return item[key];
  };

  return [...array].sort((a, b) => {
    const valueA = getValue(a);
    const valueB = getValue(b);

    // null, undefined를 배열 끝으로 이동
    if (valueA == null && valueB == null) return 0;
    if (valueA == null) return 1;
    if (valueB == null) return -1;

    // 타입별 비교 로직
    if (typeof valueA === 'string' && typeof valueB === 'string') {
      const result = valueA.localeCompare(valueB, 'ko', { sensitivity: 'base' });
      return direction === 'asc' ? result : -result;
    }

    if (typeof valueA === 'number' && typeof valueB === 'number') {
      const result = valueA - valueB;
      return direction === 'asc' ? result : -result;
    }

    if (typeof valueA === 'boolean' && typeof valueB === 'boolean') {
      const result = Number(valueA) - Number(valueB);
      return direction === 'asc' ? result : -result;
    }

    if (valueA instanceof Date && valueB instanceof Date) {
      const result = valueA.getTime() - valueB.getTime();
      return direction === 'asc' ? result : -result;
    }

    // 기본 비교 (문자열 변환 후 비교)
    const strA = String(valueA);
    const strB = String(valueB);
    const result = strA.localeCompare(strB, 'ko');
    return direction === 'asc' ? result : -result;
  });
};

/**
 * 다중 조건으로 객체 배열 정렬
 * @description 여러 개의 정렬 조건을 순차적으로 적용하여 객체 배열을 정렬합니다.
 * @param array - 정렬할 객체 배열
 * @param criteria - 정렬 조건 배열 (우선순위 순서대로 배치)
 * @returns 정렬된 새로운 배열
 * @throws {Error} criteria가 빈 배열인 경우 원본 배열 복사본 반환
 * @since 1.0.0
 * @example
 * ```typescript
 * const employees = [
 *   { name: 'John', department: 'IT', salary: 50000, joinDate: '2023-01-01' },
 *   { name: 'Jane', department: 'IT', salary: 60000, joinDate: '2022-06-01' },
 *   { name: 'Bob', department: 'HR', salary: 45000, joinDate: '2023-03-01' }
 * ];
 *
 * // 부서별 오름차순 → 급여별 내림차순 → 이름별 오름차순
 * sortByMultipleKeys(employees, [
 *   { key: 'department', direction: 'asc' },
 *   { key: 'salary', direction: 'desc' },
 *   { key: 'name', direction: 'asc' }
 * ]);
 *
 * // 함수형 키 추출기 사용
 * sortByMultipleKeys(employees, [
 *   { key: emp => emp.department.toLowerCase() },
 *   { key: 'salary', direction: 'desc' }
 * ]);
 *
 * // 단일 조건 정렬 (direction 기본값: 'asc')
 * sortByMultipleKeys(employees, [{ key: 'name' }]);
 * ```
 */
export const sortByMultipleKeys = <T extends Record<string, any>>(
  array: T[],
  criteria: SortCriteria<T>[]
): T[] => {
  if (criteria.length === 0) return [...array];

  const getValue = (item: T, key: keyof T | KeyExtractor<T>): SortableValue => {
    if (typeof key === 'function') {
      return key(item);
    }
    return item[key];
  };

  const compareValues = (a: SortableValue, b: SortableValue, direction: SortDirection = 'asc'): number => {
    // null, undefined 처리
    if (a == null && b == null) return 0;
    if (a == null) return 1;
    if (b == null) return -1;

    // 타입별 비교
    if (typeof a === 'string' && typeof b === 'string') {
      const result = a.localeCompare(b, 'ko', { sensitivity: 'base' });
      return direction === 'asc' ? result : -result;
    }

    if (typeof a === 'number' && typeof b === 'number') {
      const result = a - b;
      return direction === 'asc' ? result : -result;
    }

    if (typeof a === 'boolean' && typeof b === 'boolean') {
      const result = Number(a) - Number(b);
      return direction === 'asc' ? result : -result;
    }

    if (a instanceof Date && b instanceof Date) {
      const result = a.getTime() - b.getTime();
      return direction === 'asc' ? result : -result;
    }

    // 기본 비교
    const strA = String(a);
    const strB = String(b);
    const result = strA.localeCompare(strB, 'ko');
    return direction === 'asc' ? result : -result;
  };

  return [...array].sort((a, b) => {
    for (const criterion of criteria) {
      const valueA = getValue(a, criterion.key);
      const valueB = getValue(b, criterion.key);
      const result = compareValues(valueA, valueB, criterion.direction);

      if (result !== 0) return result; // 다르면 결과 반환
    }
    return 0; // 모든 조건이 같으면 0 반환
  });
};

/**
 * 날짜 배열/객체 정렬
 * @description 날짜 값들을 정렬합니다. 문자열 날짜도 자동 변환하여 처리합니다.
 * @param array - 정렬할 배열 (Date[] 또는 객체 배열)
 * @param key - 객체 배열인 경우 날짜 값이 있는 키 (선택사항)
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'asc')
 * @returns 정렬된 새로운 배열
 * @throws {Error} 잘못된 날짜 형식은 null로 처리되어 배열 끝으로 이동
 * @since 1.0.0
 * @example
 * ```typescript
 * // Date 객체 배열 정렬
 * const dates = [new Date('2023-01-01'), new Date('2022-12-31'), new Date('2023-06-01')];
 * sortByDate(dates) // [2022-12-31, 2023-01-01, 2023-06-01]
 * sortByDate(dates, undefined, 'desc') // [2023-06-01, 2023-01-01, 2022-12-31]
 *
 * // 문자열 날짜 자동 변환
 * const stringDates = ['2023-01-01', '2022-12-31', '2023-06-01'];
 * sortByDate(stringDates) // 자동으로 Date로 변환하여 정렬
 *
 * // 객체 배열의 날짜 키로 정렬
 * const events = [
 *   { name: 'Event A', createdAt: '2023-01-01' },
 *   { name: 'Event B', createdAt: '2022-12-31' },
 *   { name: 'Event C', createdAt: new Date('2023-06-01') }
 * ];
 * sortByDate(events, 'createdAt', 'desc') // 생성일 기준 최신순 정렬
 *
 * // 함수형 키 추출기로 중첩 객체 접근
 * sortByDate(events, event => event.metadata?.timestamp)
 *
 * // 잘못된 날짜 처리
 * const invalidDates = ['2023-01-01', 'invalid-date', '2022-12-31'];
 * sortByDate(invalidDates) // ['2022-12-31', '2023-01-01', 'invalid-date']
 * ```
 */
export const sortByDate = <T>(
  array: T[],
  key?: keyof T | KeyExtractor<T>,
  direction: SortDirection = 'asc'
): T[] => {
  const getDateValue = (item: T): Date | null => {
    let value: any;

    if (key) {
      if (typeof key === 'function') {
        value = key(item);
      } else {
        value = (item as any)[key];
      }
    } else {
      value = item;
    }

    // null, undefined 처리
    if (value == null) return null;

    // 이미 Date 객체인 경우
    if (value instanceof Date) {
      return isNaN(value.getTime()) ? null : value;
    }

    // 문자열이나 숫자를 Date로 변환
    const date = new Date(value);
    return isNaN(date.getTime()) ? null : date;
  };

  return [...array].sort((a, b) => {
    const dateA = getDateValue(a);
    const dateB = getDateValue(b);

    // null 날짜를 배열 끝으로 이동
    if (dateA == null && dateB == null) return 0;
    if (dateA == null) return 1;
    if (dateB == null) return -1;

    const result = dateA.getTime() - dateB.getTime();
    return direction === 'asc' ? result : -result;
  });
};

/**
 * 숫자 배열/객체 정렬 (자연어 순서 지원)
 * @description 숫자 값들을 정렬합니다. 문자열 숫자도 자동 변환하여 처리합니다.
 * @param array - 정렬할 배열
 * @param key - 객체 배열인 경우 숫자 값이 있는 키 (선택사항)
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'asc')
 * @returns 정렬된 새로운 배열
 * @throws {Error} NaN 값은 null로 처리되어 배열 끝으로 이동
 * @since 1.0.0
 * @example
 * ```typescript
 * // 숫자 배열 정렬
 * sortByNumber([10, 2, 1, 20]) // [1, 2, 10, 20]
 * sortByNumber([10, 2, 1, 20], undefined, 'desc') // [20, 10, 2, 1]
 *
 * // 문자열 숫자 자동 변환 (자연어 순서)
 * sortByNumber(['10', '2', '1']) // ['1', '2', '10'] (문자열 '10'이 '2'보다 뒤에 정렬)
 *
 * // 객체 배열의 숫자 키로 정렬
 * const products = [
 *   { name: 'Product A', price: 100 },
 *   { name: 'Product B', price: 50 },
 *   { name: 'Product C', price: 200 }
 * ];
 * sortByNumber(products, 'price', 'desc') // 가격 높은 순
 *
 * // 문자열 숫자가 포함된 객체
 * const items = [
 *   { name: 'Item 1', quantity: '10' },
 *   { name: 'Item 2', quantity: '2' },
 *   { name: 'Item 3', quantity: '100' }
 * ];
 * sortByNumber(items, 'quantity') // quantity를 숫자로 변환하여 정렬
 *
 * // NaN 처리
 * const mixed = [5, 'invalid', 1, 'abc', 3];
 * sortByNumber(mixed) // [1, 3, 5, 'invalid', 'abc'] (NaN은 끝으로)
 *
 * // 함수형 키 추출기
 * sortByNumber(products, item => item.stats?.sales || 0)
 * ```
 */
export const sortByNumber = <T>(
  array: T[],
  key?: keyof T | KeyExtractor<T>,
  direction: SortDirection = 'asc'
): T[] => {
  const getNumberValue = (item: T): number | null => {
    let value: any;

    if (key) {
      if (typeof key === 'function') {
        value = key(item);
      } else {
        value = (item as any)[key];
      }
    } else {
      value = item;
    }

    // null, undefined 처리
    if (value == null) return null;

    // 숫자로 변환
    const num = typeof value === 'number' ? value : Number(value);
    return isNaN(num) ? null : num;
  };

  return [...array].sort((a, b) => {
    const numA = getNumberValue(a);
    const numB = getNumberValue(b);

    // null 값을 배열 끝으로 이동
    if (numA == null && numB == null) return 0;
    if (numA == null) return 1;
    if (numB == null) return -1;

    const result = numA - numB;
    return direction === 'asc' ? result : -result;
  });
};

/**
 * 문자열 배열/객체 정렬 (로케일 지원)
 * @description 문자열 값들을 정렬합니다. 한국어, 영어 등 로케일을 고려한 정렬을 지원합니다.
 * @param array - 정렬할 배열
 * @param key - 객체 배열인 경우 문자열 값이 있는 키 (선택사항)
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'asc')
 * @param locale - 로케일 설정 (기본값: 'ko', 한국어)
 * @param caseSensitive - 대소문자 구분 여부 (기본값: false)
 * @returns 정렬된 새로운 배열
 * @since 1.0.0
 * @example
 * ```typescript
 * // 한국어 문자열 정렬
 * sortByString(['바나나', '사과', '체리']) // ['바나나', '사과', '체리'] (한글 자음순)
 *
 * // 영어 문자열 정렬
 * sortByString(['banana', 'apple', 'cherry'], undefined, 'asc', 'en')
 * // ['apple', 'banana', 'cherry']
 *
 * // 대소문자 구분 없는 정렬
 * sortByString(['Apple', 'apple', 'APPLE'], undefined, 'asc', 'en', false)
 * // ['Apple', 'apple', 'APPLE'] (대소문자 구분 없이 같은 순서 유지)
 *
 * // 대소문자 구분 정렬
 * sortByString(['Apple', 'apple', 'APPLE'], undefined, 'asc', 'en', true)
 * // ['APPLE', 'Apple', 'apple'] (대문자 → 소문자 순)
 *
 * // 객체 배열의 문자열 키로 정렬
 * const users = [
 *   { name: '김철수', city: '서울' },
 *   { name: '이영희', city: '부산' },
 *   { name: '박민수', city: '대구' }
 * ];
 * sortByString(users, 'name') // 이름 순 정렬 (한글)
 * sortByString(users, 'city', 'desc') // 도시명 역순 정렬
 *
 * // 자연어 순서 정렬 (숫자 포함)
 * const files = ['file1.txt', 'file10.txt', 'file2.txt'];
 * sortByString(files) // ['file1.txt', 'file2.txt', 'file10.txt'] (자연어 순서)
 *
 * // 함수형 키 추출기
 * sortByString(users, user => user.profile?.displayName || user.name)
 *
 * // null/undefined 처리
 * const mixed = ['apple', null, 'banana', undefined, 'cherry'];
 * sortByString(mixed) // ['apple', 'banana', 'cherry', null, undefined]
 * ```
 */
export const sortByString = <T>(
  array: T[],
  key?: keyof T | KeyExtractor<T>,
  direction: SortDirection = 'asc',
  locale: string = 'ko',
  caseSensitive: boolean = false
): T[] => {
  const getStringValue = (item: T): string | null => {
    let value: any;

    if (key) {
      if (typeof key === 'function') {
        value = key(item);
      } else {
        value = (item as any)[key];
      }
    } else {
      value = item;
    }

    // null, undefined 처리
    if (value == null) return null;

    return String(value);
  };

  const collator = new Intl.Collator(locale, {
    sensitivity: caseSensitive ? 'case' : 'base',
    numeric: true, // 자연어 순서 정렬 (1, 2, 10)
    ignorePunctuation: false
  });

  return [...array].sort((a, b) => {
    const strA = getStringValue(a);
    const strB = getStringValue(b);

    // null 값을 배열 끝으로 이동
    if (strA == null && strB == null) return 0;
    if (strA == null) return 1;
    if (strB == null) return -1;

    const result = collator.compare(strA, strB);
    return direction === 'asc' ? result : -result;
  });
};

/**
 * 사용자 정의 비교 함수로 정렬
 * @description 사용자가 정의한 비교 함수를 사용하여 배열을 정렬합니다.
 * @param array - 정렬할 배열
 * @param compareFn - 비교 함수 (a, b) => number (음수: a < b, 0: a === b, 양수: a > b)
 * @returns 정렬된 새로운 배열
 * @since 1.0.0
 * @example
 * ```typescript
 * const items = [
 *   { name: 'A', priority: 1, category: 'urgent' },
 *   { name: 'B', priority: 2, category: 'normal' },
 *   { name: 'C', priority: 1, category: 'normal' }
 * ];
 *
 * // 복잡한 사용자 정의 정렬 로직
 * sortByCustom(items, (a, b) => {
 *   // 1순위: priority 높은 순 (내림차순)
 *   if (a.priority !== b.priority) return b.priority - a.priority;
 *   // 2순위: category urgent가 우선
 *   if (a.category !== b.category) {
 *     if (a.category === 'urgent') return -1;
 *     if (b.category === 'urgent') return 1;
 *   }
 *   // 3순위: name 오름차순
 *   return a.name.localeCompare(b.name);
 * });
 *
 * // 숫자 배열 역순 정렬
 * sortByCustom([1, 2, 3, 4, 5], (a, b) => b - a) // [5, 4, 3, 2, 1]
 *
 * // 문자열 길이순 정렬
 * sortByCustom(['apple', 'hi', 'banana'], (a, b) => a.length - b.length)
 * // ['hi', 'apple', 'banana']
 *
 * // Date 객체 최신순 정렬
 * sortByCustom(dates, (a, b) => b.getTime() - a.getTime())
 * ```
 */
export const sortByCustom = <T>(
  array: T[],
  compareFn: (a: T, b: T) => number
): T[] => {
  return [...array].sort(compareFn);
};

/**
 * 배열을 섞기 (랜덤 정렬)
 * @description Fisher-Yates 알고리즘을 사용하여 배열을 무작위로 섞습니다.
 * @param array - 섞을 배열
 * @returns 섞인 새로운 배열 (원본 배열은 변경되지 않음)
 * @algorithm Fisher-Yates shuffle - O(n) 시간 복잡도, 균등한 무작위 분포 보장
 * @since 1.0.0
 * @example
 * ```typescript
 * // 숫자 배열 섞기
 * shuffleArray([1, 2, 3, 4, 5]) // [3, 1, 5, 2, 4] (매번 다른 결과)
 *
 * // 문자열 배열 섞기
 * shuffleArray(['apple', 'banana', 'cherry']) // ['cherry', 'apple', 'banana']
 *
 * // 객체 배열 섞기
 * const cards = [
 *   { suit: 'hearts', value: 'A' },
 *   { suit: 'spades', value: 'K' },
 *   { suit: 'clubs', value: 'Q' }
 * ];
 * shuffleArray(cards) // 카드 덱 섞기
 *
 * // 빈 배열 처리
 * shuffleArray([]) // []
 *
 * // 단일 요소 처리
 * shuffleArray([42]) // [42]
 * ```
 */
export const shuffleArray = <T>(array: T[]): T[] => {
  const shuffled = [...array];

  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  return shuffled;
};

/**
 * 정렬된 배열에서 이진 탐색
 * @description 정렬된 배열에서 특정 값의 인덱스를 이진 탐색으로 찾습니다.
 * @param sortedArray - 정렬된 배열 (반드시 정렬되어 있어야 함)
 * @param target - 찾을 값
 * @param compareFn - 비교 함수 (선택사항, 기본: 기본 비교)
 * @returns 찾은 인덱스 (없으면 -1)
 * @complexity O(log n) 시간 복잡도
 * @throws {Error} 배열이 정렬되어 있지 않으면 예상치 못한 결과 발생 가능
 * @since 1.0.0
 * @example
 * ```typescript
 * // 숫자 배열에서 탐색
 * const numbers = [1, 3, 5, 7, 9, 11, 13];
 * binarySearch(numbers, 5) // 2 (인덱스)
 * binarySearch(numbers, 6) // -1 (없음)
 * binarySearch(numbers, 1) // 0 (첫 번째)
 * binarySearch(numbers, 13) // 6 (마지막)
 *
 * // 문자열 배열에서 탐색
 * const names = ['Alice', 'Bob', 'Charlie', 'David'];
 * binarySearch(names, 'Charlie') // 2
 * binarySearch(names, 'Eve') // -1
 *
 * // 객체 배열에서 사용자 정의 비교 함수 사용
 * const users = [
 *   { id: 1, name: 'Alice' },
 *   { id: 3, name: 'Bob' },
 *   { id: 5, name: 'Charlie' }
 * ];
 * const targetUser = { id: 3, name: 'Bob' };
 * binarySearch(users, targetUser, (a, b) => a.id - b.id) // 1
 *
 * // 단순히 ID로 검색
 * binarySearch(users, { id: 5 }, (a, b) => a.id - b.id) // 2
 * binarySearch(users, { id: 4 }, (a, b) => a.id - b.id) // -1
 *
 * // 빈 배열 처리
 * binarySearch([], 1) // -1
 * ```
 */
export const binarySearch = <T>(
  sortedArray: T[],
  target: T,
  compareFn?: (a: T, b: T) => number
): number => {
  let left = 0;
  let right = sortedArray.length - 1;

  // 기본 비교 함수 정의
  const compare = compareFn || ((a: T, b: T) => {
    if (a < b) return -1;
    if (a > b) return 1;
    return 0;
  });

  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    const comparison = compare(sortedArray[mid], target);

    if (comparison === 0) {
      return mid; // 찾았음
    } else if (comparison < 0) {
      left = mid + 1; // 오른쪽 절반 탐색
    } else {
      right = mid - 1; // 왼쪽 절반 탐색
    }
  }

  return -1; // 찾지 못함
};

/**
 * 배열이 정렬되어 있는지 확인
 * @description 배열이 주어진 방향으로 정렬되어 있는지 검증합니다.
 * @param array - 확인할 배열
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'asc')
 * @param key - 객체 배열인 경우 비교할 키 (선택사항)
 * @returns 정렬되어 있으면 true, 아니면 false
 * @complexity O(n) 시간 복잡도
 * @since 1.0.0
 * @example
 * ```typescript
 * // 기본 타입 배열 확인
 * isSorted([1, 2, 3, 4, 5]) // true (오름차순)
 * isSorted([5, 4, 3, 2, 1], 'desc') // true (내림차순)
 * isSorted([1, 3, 2, 4, 5]) // false (정렬되지 않음)
 *
 * // 빈 배열과 단일 요소 배열
 * isSorted([]) // true (빈 배열은 정렬된 것으로 간주)
 * isSorted([42]) // true (단일 요소는 정렬된 것으로 간주)
 *
 * // 객체 배열의 특정 키 확인
 * const users = [
 *   { name: 'Alice', age: 25 },
 *   { name: 'Bob', age: 30 },
 *   { name: 'Charlie', age: 35 }
 * ];
 * isSorted(users, 'asc', 'age') // true (나이 오름차순)
 * isSorted(users, 'desc', 'name') // false (이름 내림차순 아님)
 *
 * // 함수형 키 추출기 사용
 * isSorted(users, 'asc', user => user.name.toLowerCase())
 *
 * // 날짜 정렬 확인
 * const events = [
 *   { date: new Date('2023-01-01') },
 *   { date: new Date('2023-02-01') },
 *   { date: new Date('2023-03-01') }
 * ];
 * isSorted(events, 'asc', 'date') // true
 *
 * // null/undefined 처리
 * isSorted([1, 2, null, undefined], 'asc') // true (null은 끝으로 간주)
 * isSorted([null, undefined, 1, 2], 'desc') // true
 * ```
 */
export const isSorted = <T>(
  array: T[],
  direction: SortDirection = 'asc',
  key?: keyof T | KeyExtractor<T>
): boolean => {
  if (array.length <= 1) return true;

  for (let i = 1; i < array.length; i++) {
    const currentValue = key
      ? (typeof key === 'function' ? key(array[i]) : array[i][key])
      : array[i];
    const previousValue = key
      ? (typeof key === 'function' ? key(array[i - 1]) : array[i - 1][key])
      : array[i - 1];

    // null/undefined 처리
    if (currentValue == null && previousValue == null) continue;
    if (currentValue == null) return direction === 'desc';
    if (previousValue == null) return direction === 'asc';

    // 날짜 타입 처리
    if (currentValue instanceof Date && previousValue instanceof Date) {
      const comparison = currentValue.getTime() - previousValue.getTime();
      if (direction === 'asc' && comparison < 0) return false;
      if (direction === 'desc' && comparison > 0) return false;
      continue;
    }

    // 숫자 타입 처리
    if (typeof currentValue === 'number' && typeof previousValue === 'number') {
      if (direction === 'asc' && currentValue < previousValue) return false;
      if (direction === 'desc' && currentValue > previousValue) return false;
      continue;
    }

    // 문자열 타입 처리
    if (typeof currentValue === 'string' && typeof previousValue === 'string') {
      const comparison = currentValue.localeCompare(previousValue);
      if (direction === 'asc' && comparison < 0) return false;
      if (direction === 'desc' && comparison > 0) return false;
      continue;
    }

    // 일반적인 비교
    if (direction === 'asc' && currentValue < previousValue) return false;
    if (direction === 'desc' && currentValue > previousValue) return false;
  }

  return true;
};

/**
 * 안정 정렬 (Stable Sort)
 * @description 동일한 값에 대해 원래 순서를 유지하는 안정 정렬을 수행합니다.
 * @param array - 정렬할 배열
 * @param key - 정렬 기준 키
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'asc')
 * @returns 안정 정렬된 새로운 배열
 * @algorithm 원본 인덱스를 활용한 안정 정렬 보장
 * @since 1.0.0
 * @example
 * ```typescript
 * // 학생 성적 정렬 (같은 성적일 때 원본 순서 유지)
 * const students = [
 *   { name: 'Alice', grade: 'A', order: 1 },
 *   { name: 'Bob', grade: 'B', order: 2 },
 *   { name: 'Charlie', grade: 'A', order: 3 },
 *   { name: 'David', grade: 'B', order: 4 }
 * ];
 *
 * stableSort(students, 'grade')
 * // 결과: Alice(A), Charlie(A), Bob(B), David(B)
 * // 같은 성적 A인 Alice와 Charlie는 원본 순서 유지
 *
 * // 일반 정렬과의 차이점 확인
 * const data = [
 *   { value: 1, id: 'first' },
 *   { value: 2, id: 'second' },
 *   { value: 1, id: 'third' },
 *   { value: 2, id: 'fourth' }
 * ];
 *
 * stableSort(data, 'value')
 * // { value: 1, id: 'first' }, { value: 1, id: 'third' },
 * // { value: 2, id: 'second' }, { value: 2, id: 'fourth' }
 * // 같은 value를 가진 요소들의 원본 순서 유지
 *
 * // 함수형 키 추출기 사용
 * stableSort(students, student => student.grade.charCodeAt(0))
 *
 * // 내림차순 안정 정렬
 * stableSort(students, 'grade', 'desc')
 * ```
 */
export const stableSort = <T extends Record<string, any>>(
  array: T[],
  key: keyof T | KeyExtractor<T>,
  direction: SortDirection = 'asc'
): T[] => {
  // 원본 인덱스와 함께 저장하여 안정 정렬 보장
  const indexed = array.map((item, index) => ({ item, index }));

  return indexed
    .sort((a, b) => {
      const aValue = typeof key === 'function' ? key(a.item) : a.item[key];
      const bValue = typeof key === 'function' ? key(b.item) : b.item[key];

      // null/undefined 처리
      if (aValue == null && bValue == null) return a.index - b.index;
      if (aValue == null) return direction === 'asc' ? -1 : 1;
      if (bValue == null) return direction === 'asc' ? 1 : -1;

      // 날짜 비교
      if (aValue instanceof Date && bValue instanceof Date) {
        const comparison = aValue.getTime() - bValue.getTime();
        if (comparison !== 0) {
          return direction === 'asc' ? comparison : -comparison;
        }
        return a.index - b.index; // 안정 정렬을 위한 원본 순서 유지
      }

      // 숫자 비교
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        if (isNaN(aValue) && isNaN(bValue)) return a.index - b.index;
        if (isNaN(aValue)) return direction === 'asc' ? 1 : -1;
        if (isNaN(bValue)) return direction === 'asc' ? -1 : 1;

        const comparison = aValue - bValue;
        if (comparison !== 0) {
          return direction === 'asc' ? comparison : -comparison;
        }
        return a.index - b.index;
      }

      // 문자열 비교
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        const comparison = (aValue as string).localeCompare(bValue as string);
        if (comparison !== 0) {
          return direction === 'asc' ? comparison : -comparison;
        }
        return a.index - b.index;
      }

      // 일반적인 비교
      if (aValue < bValue) return direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return direction === 'asc' ? 1 : -1;
      return a.index - b.index;
    })
    .map(({ item }) => item);
};

/**
 * 부분 정렬 (Top-K)
 * @description 배열에서 상위/하위 K개의 요소만 정렬하여 반환합니다.
 * @param array - 정렬할 배열
 * @param k - 반환할 요소 개수 (0 이하면 빈 배열 반환)
 * @param key - 정렬 기준 키 (선택사항)
 * @param direction - 정렬 방향 ('asc' | 'desc', 기본값: 'desc')
 * @returns 상위/하위 K개 요소 배열
 * @performance k << n일 때 전체 정렬보다 효율적
 * @since 1.0.0
 * @example
 * ```typescript
 * // 숫자 배열에서 상위 3개
 * const numbers = [10, 5, 8, 20, 3, 15, 7];
 * getTopK(numbers, 3, undefined, 'desc') // [20, 15, 10]
 * getTopK(numbers, 3, undefined, 'asc') // [3, 5, 7]
 *
 * // 상품 매출 상위 5개
 * const products = [
 *   { name: 'Product A', sales: 1000 },
 *   { name: 'Product B', sales: 1500 },
 *   { name: 'Product C', sales: 800 },
 *   { name: 'Product D', sales: 2000 },
 *   { name: 'Product E', sales: 1200 }
 * ];
 * getTopK(products, 3, 'sales', 'desc')
 * // [Product D (2000), Product B (1500), Product E (1200)]
 *
 * // 점수 하위 2개
 * const scores = [85, 92, 78, 95, 88];
 * getTopK(scores, 2, undefined, 'asc') // [78, 85]
 *
 * // 함수형 키 추출기 사용
 * const users = [
 *   { name: 'Alice', profile: { score: 100 } },
 *   { name: 'Bob', profile: { score: 85 } },
 *   { name: 'Charlie', profile: { score: 95 } }
 * ];
 * getTopK(users, 2, user => user.profile.score, 'desc')
 * // [Alice (100), Charlie (95)]
 *
 * // 경계 조건 처리
 * getTopK([1, 2, 3], 0) // [] (k=0)
 * getTopK([1, 2, 3], 5) // [3, 2, 1] (k > 배열 길이면 전체 정렬)
 * getTopK([], 3) // [] (빈 배열)
 *
 * // 날짜 기준 최신 3개
 * const events = [
 *   { name: 'A', date: '2023-01-01' },
 *   { name: 'B', date: '2023-03-01' },
 *   { name: 'C', date: '2023-02-01' }
 * ];
 * getTopK(events, 2, 'date', 'desc') // [B (2023-03-01), C (2023-02-01)]
 * ```
 */
export const getTopK = <T>(
  array: T[],
  k: number,
  key?: keyof T | KeyExtractor<T>,
  direction: SortDirection = 'desc'
): T[] => {
  if (k <= 0) return [];
  if (k >= array.length) {
    // k가 배열 길이보다 크면 전체 정렬
    if (key) {
      return sortByKey(array as any, key as any, direction) as T[];
    }
    return sortArray(array as any, direction) as T[];
  }

  // Top-K를 위한 효율적인 부분 정렬
  const copied = [...array];

  // 힙을 사용한 부분 정렬 대신 간단한 정렬 후 슬라이스 사용
  // 실제 프로덕션에서는 QuickSelect나 Heap을 사용하여 최적화 가능
  if (key) {
    copied.sort((a, b) => {
      const aValue = typeof key === 'function' ? key(a) : a[key];
      const bValue = typeof key === 'function' ? key(b) : b[key];

      // null/undefined 처리
      if (aValue == null && bValue == null) return 0;
      if (aValue == null) return direction === 'asc' ? -1 : 1;
      if (bValue == null) return direction === 'asc' ? 1 : -1;

      // 날짜 비교
      if (aValue instanceof Date && bValue instanceof Date) {
        const comparison = aValue.getTime() - bValue.getTime();
        return direction === 'asc' ? comparison : -comparison;
      }

      // 숫자 비교
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        if (isNaN(aValue) && isNaN(bValue)) return 0;
        if (isNaN(aValue)) return direction === 'asc' ? 1 : -1;
        if (isNaN(bValue)) return direction === 'asc' ? -1 : 1;

        const comparison = aValue - bValue;
        return direction === 'asc' ? comparison : -comparison;
      }

      // 문자열 비교
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        const comparison = (aValue as string).localeCompare(bValue as string);
        return direction === 'asc' ? comparison : -comparison;
      }

      // 일반적인 비교
      if (aValue < bValue) return direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return direction === 'asc' ? 1 : -1;
      return 0;
    });
  } else {
    copied.sort((a, b) => {
      // null/undefined 처리
      if (a == null && b == null) return 0;
      if (a == null) return direction === 'asc' ? -1 : 1;
      if (b == null) return direction === 'asc' ? 1 : -1;

      // 날짜 비교
      if (a instanceof Date && b instanceof Date) {
        const comparison = a.getTime() - b.getTime();
        return direction === 'asc' ? comparison : -comparison;
      }

      // 숫자 비교
      if (typeof a === 'number' && typeof b === 'number') {
        if (isNaN(a) && isNaN(b)) return 0;
        if (isNaN(a)) return direction === 'asc' ? 1 : -1;
        if (isNaN(b)) return direction === 'asc' ? -1 : 1;

        const comparison = a - b;
        return direction === 'asc' ? comparison : -comparison;
      }

      // 문자열 비교
      if (typeof a === 'string' && typeof b === 'string') {
        const comparison = a.localeCompare(b);
        return direction === 'asc' ? comparison : -comparison;
      }

      // 일반적인 비교
      if (a < b) return direction === 'asc' ? -1 : 1;
      if (a > b) return direction === 'asc' ? 1 : -1;
      return 0;
    });
  }

  return copied.slice(0, k);
};
