// ============================================================================
// ✅ Validators - 유효성 검사 함수들
// ============================================================================

/**
 * 이메일 유효성 검사
 * @param email - 검사할 이메일 주소
 * @returns 유효하면 true, 그렇지 않으면 false
 * @example
 * isValidEmail('user@example.com') // true
 * isValidEmail('invalid-email') // false
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email.trim());
};

/**
 * 전화번호 유효성 검사 (한국)
 * @param phone - 검사할 전화번호
 * @returns 유효하면 true, 그렇지 않으면 false
 * @example
 * isValidPhoneKR('010-1234-5678') // true
 * isValidPhoneKR('01012345678') // true
 * isValidPhoneKR('02-123-4567') // false (지역번호는 별도 함수 사용)
 */
// export const isValidPhoneKR = (phone: string): boolean => {
//   const phoneRegex = /^(01[016789])-?([0-9]{3,4})-?([0-9]{4})$/;
//   return phoneRegex.test(phone.replace(/\s/g, ''));
// };

/**
 * 국제 전화번호 유효성 검사
 * @param phone - 검사할 국제 전화번호
 * @returns 유효하면 true, 그렇지 않으면 false
 * @example
 * isValidInternationalPhone('+82-10-1234-5678') // true
 * isValidInternationalPhone('+1-555-123-4567') // true
 */
// export const isValidInternationalPhone = (phone: string): boolean => {
//   const intlPhoneRegex = /^\+[1-9]\d{1,14}$/;
//   return intlPhoneRegex.test(phone.replace(/[\s-]/g, ''));
// };

/**
 * 비밀번호 강도 검사
 * @param password - 검사할 비밀번호
 * @param options - 검사 옵션
 * @returns 검사 결과 객체
 * @example
 * validatePassword('MyPass123!') // { isValid: true, score: 4, errors: [] }
 * validatePassword('weak') // { isValid: false, score: 1, errors: ['길이 부족', ...] }
 */
// export const validatePassword = (
//   password: string,
//   options: {
//     minLength?: number;
//     requireUppercase?: boolean;
//     requireLowercase?: boolean;
//     requireNumbers?: boolean;
//     requireSpecialChars?: boolean;
//   } = {}
// ): {
//   isValid: boolean;
//   score: number; // 0-4 점수
//   errors: string[];
// } => {
//   const {
//     minLength = 8,
//     requireUppercase = true,
//     requireLowercase = true,
//     requireNumbers = true,
//     requireSpecialChars = true
//   } = options;
//
//   const errors: string[] = [];
//   let score = 0;
//
//   // 길이 검사
//   if (password.length < minLength) {
//     errors.push(`최소 ${minLength}자 이상이어야 합니다`);
//   } else {
//     score++;
//   }
//
//   // 대문자 검사
//   if (requireUppercase && !/[A-Z]/.test(password)) {
//     errors.push('대문자가 포함되어야 합니다');
//   } else if (/[A-Z]/.test(password)) {
//     score++;
//   }
//
//   // 소문자 검사
//   if (requireLowercase && !/[a-z]/.test(password)) {
//     errors.push('소문자가 포함되어야 합니다');
//   } else if (/[a-z]/.test(password)) {
//     score++;
//   }
//
//   // 숫자 검사
//   if (requireNumbers && !/\d/.test(password)) {
//     errors.push('숫자가 포함되어야 합니다');
//   } else if (/\d/.test(password)) {
//     score++;
//   }
//
//   // 특수문자 검사
//   if (requireSpecialChars && !/[@$!%*?&]/.test(password)) {
//     errors.push('특수문자가 포함되어야 합니다');
//   } else if (/[@$!%*?&]/.test(password)) {
//     score++;
//   }
//
//   return {
//     isValid: errors.length === 0,
//     score,
//     errors
//   };
// };

/**
 * 사업자등록번호 유효성 검사
 * @param businessNumber - 사업자등록번호 (하이픈 포함/미포함 모두 가능)
 * @returns 유효하면 true, 그렇지 않으면 false
 * @example
 * isValidBusinessNumber('123-45-67890') // true (체크섬 계산 후)
 * isValidBusinessNumber('1234567890') // true (체크섬 계산 후)
 */
// export const isValidBusinessNumber = (businessNumber: string): boolean => {
//   const cleaned = businessNumber.replace(/-/g, '');
//
//   if (!/^\d{10}$/.test(cleaned)) {
//     return false;
//   }
//
//   // 체크섬 계산
//   const checkArray = [1, 3, 7, 1, 3, 7, 1, 3, 5];
//   let sum = 0;
//
//   for (let i = 0; i < 9; i++) {
//     sum += parseInt(cleaned[i]) * checkArray[i];
//   }
//
//   const remainder = sum % 10;
//   const checkDigit = remainder === 0 ? 0 : 10 - remainder;
//
//   return checkDigit === parseInt(cleaned[9]);
// };

/**
 * 주민등록번호 유효성 검사
 * @param residentNumber - 주민등록번호 (하이픈 포함/미포함 모두 가능)
 * @returns 유효하면 true, 그렇지 않으면 false
 * @example
 * isValidResidentNumber('123456-1234567') // true (체크섬 계산 후)
 * isValidResidentNumber('1234561234567') // true (체크섬 계산 후)
 */
// export const isValidResidentNumber = (residentNumber: string): boolean => {
//   const cleaned = residentNumber.replace(/-/g, '');
//
//   if (!/^\d{13}$/.test(cleaned)) {
//     return false;
//   }
//
//   // 성별 숫자 검증 (7번째 자리)
//   const genderDigit = parseInt(cleaned[6]);
//   if (![1, 2, 3, 4, 5, 6, 7, 8, 9, 0].includes(genderDigit)) {
//     return false;
//   }
//
//   // 체크섬 계산
//   const checkArray = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5];
//   let sum = 0;
//
//   for (let i = 0; i < 12; i++) {
//     sum += parseInt(cleaned[i]) * checkArray[i];
//   }
//
//   const remainder = sum % 11;
//   const checkDigit = (11 - remainder) % 10;
//
//   return checkDigit === parseInt(cleaned[12]);
// };

/**
 * URL 유효성 검사
 * @param url - 검사할 URL
 * @returns 유효하면 true, 그렇지 않으면 false
 * @example
 * isValidURL('https://www.example.com') // true
 * isValidURL('invalid-url') // false
 */
// export const isValidURL = (url: string): boolean => {
//   try {
//     new URL(url);
//     return true;
//   } catch {
//     return false;
//   }
// };

/**
 * 파일 확장자 검사
 * @param filename - 파일명
 * @param allowedExtensions - 허용된 확장자 배열
 * @returns 허용된 확장자면 true, 그렇지 않으면 false
 * @example
 * isValidFileExtension('image.jpg', ['jpg', 'png']) // true
 * isValidFileExtension('document.pdf', ['jpg', 'png']) // false
 */
// export const isValidFileExtension = (
//   filename: string,
//   allowedExtensions: string[]
// ): boolean => {
//   const extension = filename.split('.').pop()?.toLowerCase();
//   return extension ? allowedExtensions.includes(extension) : false;
// };

/**
 * 문자열 길이 검사
 * @param text - 검사할 텍스트
 * @param minLength - 최소 길이
 * @param maxLength - 최대 길이
 * @returns 길이가 범위 내면 true, 그렇지 않으면 false
 * @example
 * isValidLength('Hello', 3, 10) // true
 * isValidLength('Hi', 3, 10) // false
 */
// export const isValidLength = (
//   text: string,
//   minLength: number,
//   maxLength: number
// ): boolean => {
//   const length = text.trim().length;
//   return length >= minLength && length <= maxLength;
// };

/**
 * 빈 값 검사 (null, undefined, 빈 문자열, 공백만 있는 문자열)
 * @param value - 검사할 값
 * @returns 값이 있으면 true, 빈 값이면 false
 * @example
 * isNotEmpty('Hello') // true
 * isNotEmpty('   ') // false
 * isNotEmpty(null) // false
 */
// export const isNotEmpty = (value: any): boolean => {
//   if (value === null || value === undefined) {
//     return false;
//   }
//
//   if (typeof value === 'string') {
//     return value.trim().length > 0;
//   }
//
//   return true;
// };

/**
 * 숫자 범위 검사
 * @param value - 검사할 값
 * @param min - 최솟값
 * @param max - 최댓값
 * @returns 범위 내면 true, 그렇지 않으면 false
 * @example
 * isValidNumberRange(5, 1, 10) // true
 * isValidNumberRange(15, 1, 10) // false
 */
// export const isValidNumberRange = (
//   value: number,
//   min: number,
//   max: number
// ): boolean => {
//   return value >= min && value <= max;
// };

/**
 * 날짜 형식 검사 (YYYY-MM-DD)
 * @param dateString - 날짜 문자열
 * @returns 유효한 날짜 형식이면 true, 그렇지 않으면 false
 * @example
 * isValidDateFormat('2023-12-25') // true
 * isValidDateFormat('2023/12/25') // false
 */
// export const isValidDateFormat = (dateString: string): boolean => {
//   const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
//   if (!dateRegex.test(dateString)) {
//     return false;
//   }
//
//   const date = new Date(dateString);
//   return date.toISOString().slice(0, 10) === dateString;
// };
