// ============================================================================
// 📅 Date Utils - 날짜 관련 유틸리티 함수들 (Luxon 기반)
// ============================================================================

/**
 * 🎯 지원하는 날짜 함수 목록
 *
 * 📌 기본 변환 및 포맷팅:
 * • parseToDateTime       - 입력값을 DateTime 객체로 변환
 * • formatDate           - 날짜를 지정된 형식으로 포맷팅 (Luxon format 직접 사용)
 * • convertToISO         - YYYYMMDD/YYYYMMDDHHMMSS를 ISO 8601로 변환
 * • parseDate            - 문자열을 Date 객체로 변환 (실패시 null)
 * • toISODate            - ISO 날짜 문자열로 변환 (날짜 부분만)
 *
 * 📌 날짜 계산 및 연산:
 * • addToDate            - 날짜에 일/월/년 더하기/빼기
 * • getDateDiff          - 두 날짜 사이의 차이 계산
 * • calculateAge         - 생년월일 기준 만 나이 계산
 *
 * 📌 날짜 비교 및 확인:
 * • isSameDay           - 같은 날인지 비교 (시간 무시)
 * • isToday             - 오늘인지 확인
 * • isYesterday         - 어제인지 확인
 * • isTomorrow          - 내일인지 확인
 * • isWeekend           - 주말 여부 확인
 * • isValidDate         - 날짜 유효성 검증
 *
 * 📌 기간 및 범위 유틸리티:
 * • getFirstDay         - 해당 월의 첫 번째 날
 * • getLastDay          - 해당 월의 마지막 날
 * • getWeekStart        - 해당 주의 시작일 (월요일)
 * • getWeekEnd          - 해당 주의 마지막일 (일요일)
 *
 * 📌 시간 표시 및 문자열:
 * • getRelativeTime     - 상대적 시간 표시 ('1분 전', '2시간 후' 등)
 * • getPeriodString     - 두 날짜 사이의 기간을 문자열로 표시
 * • now                 - 현재 날짜/시간 반환
 *
 * 🔧 주요 특징:
 * • Luxon 라이브러리 기반으로 안정적이고 정확한 날짜 처리
 * • ISO 8601 표준 지원 및 다양한 날짜 형식 지원 (ISO 8601 형식: 2024-07-19T14:30:00Z)
 * • YYYYMMDD, YYYYMMDDHHMMSS 형식 자동 감지 및 변환
 * • 타임존 안전 처리 및 로케일 지원 (한국어/영어)
 * • TypeScript 완전 지원 (제네릭, 타입 안전성)
 * • null/undefined 안전 처리 및 에러 핸들링
 * • 불변성 보장 (원본 날짜 객체 변경 안함)
 *
 * 🤖 AI 에이전트 친화적 구조:
 * • 명확한 함수 목적과 사용법 JSDoc 작성
 * • 실용적인 코드 예제와 시나리오 제공 (YYYYMMDD, ISO 8601 등)
 * • 타입 정보와 매개변수 상세 설명
 * • 예외 상황 및 경계 조건 처리 가이드
 * • 한국어 지원 및 로케일 처리 안내
 * • 단계별 사용 예제 (기본 → 고급 활용)
 * • 날짜 형식 변환 및 포맷팅 가이드
 * • 비즈니스 로직에 바로 적용 가능한 실무 예제
 */

import { DateTime } from 'luxon';

/**
 * 입력 날짜 타입 (string 또는 Date)
 */
export type DateInput = string | Date;

/**
 * 날짜 단위 타입 (전체형 및 축약형)
 */
export type DateUnit = 'days' | 'months' | 'years' | 'd' | 'M' | 'y';

/**
 * YYYYMMDD 또는 YYYYMMDDHHMMSS 형식을 ISO 8601 형식으로 변환
 * @param dateString - YYYYMMDD(8자리) 또는 YYYYMMDDHHMMSS(14자리) 형식 문자열
 * @returns ISO 8601 형식 문자열
 * @example
 * convertToISO('20231225') // '2023-12-25T00:00:00'
 * convertToISO('20231225143000') // '2023-12-25T14:30:00'
 */
export const convertToISO = (dateString: string): string => {
  if (dateString.length === 8) {
    // YYYYMMDD 형식 - 시간은 00:00:00으로 설정
    const year = dateString.substring(0, 4);
    const month = dateString.substring(4, 6);
    const day = dateString.substring(6, 8);
    return `${year}-${month}-${day}T00:00:00`;
  }

  if (dateString.length === 14) {
    // YYYYMMDDHHMMSS 형식
    const year = dateString.substring(0, 4);
    const month = dateString.substring(4, 6);
    const day = dateString.substring(6, 8);
    const hour = dateString.substring(8, 10);
    const minute = dateString.substring(10, 12);
    const second = dateString.substring(12, 14);
    return `${year}-${month}-${day}T${hour}:${minute}:${second}`;
  }

  throw new Error('Date format must be YYYYMMDD (8 chars) or YYYYMMDDHHMMSS (14 chars)');
};

/**
 * 입력값을 DateTime 객체로 변환
 * @param date - 변환할 날짜 (string 또는 Date)
 * @returns DateTime 객체
 * @example
 * parseToDateTime('2023-12-25') // DateTime 객체
 * parseToDateTime('20231225') // DateTime 객체 (YYYYMMDD)
 * parseToDateTime('20231225143000') // DateTime 객체 (YYYYMMDDHHMMSS)
 * parseToDateTime(new Date()) // DateTime 객체
 */
export const parseToDateTime = (date: DateInput): DateTime => {
  if (date instanceof Date) {
    return DateTime.fromJSDate(date);
  }

  // YYYYMMDD (8자리) 또는 YYYYMMDDHHMMSS (14자리) 형식 감지
  if (typeof date === 'string' && /^\d{8}$|^\d{14}$/.test(date)) {
    const isoString = convertToISO(date);
    return DateTime.fromISO(isoString);
  }

  // ISO 8601 또는 기타 형식
  if (typeof date === 'string') {
    return DateTime.fromISO(date);
  }

  throw new Error('Invalid date input');
};

/**
 * 날짜를 지정된 형식으로 포맷팅 (Luxon format 직접 사용)
 * @param date - 포맷할 날짜
 * @param format - Luxon 포맷 문자열 (기본값: ISO format)
 * @returns 포맷된 날짜 문자열
 * @example
 * formatDate('2023-12-25', 'yyyyMMdd') // '20231225'
 * formatDate('20231225', 'yyyy-MM-dd') // '2023-12-25'
 * formatDate('20231225143000', 'yyyy-MM-dd HH:mm:ss') // '2023-12-25 14:30:00'
 */
export const formatDate = (date: DateInput, format?: string): string => {
  const dt = parseToDateTime(date);

  if (!dt.isValid) {
    throw new Error(`Invalid date: ${date}`);
  }

  // format이 없으면 ISO string 반환
  if (!format) {
    return dt.toISO() || '';
  }

  // Luxon format 직접 사용
  return dt.toFormat(format);
};

/**
 * 날짜에 일/월/년 더하기
 * @param date - 기준 날짜
 * @param value - 더할 값 (음수면 빼기)
 * @param unit - 단위 ('days'|'d', 'months'|'M', 'years'|'y')
 * @param returnFormat - Luxon 포맷 문자열
 * @returns 계산된 날짜 문자열
 * @example
 * addToDate('2023-12-25', 7, 'days', 'yyyy-MM-dd') // '2024-01-01'
 * addToDate('2023-12-25', 7, 'd', 'yyyy-MM-dd') // '2024-01-01'
 * addToDate('20231225', 2, 'M', 'yyyyMMdd') // '20240225'
 */
export const addToDate = (
  date: DateInput,
  value: number,
  unit: DateUnit,
  returnFormat?: string
): string => {
  // 축약형을 전체형으로 변환
  const normalizedUnit = unit === 'd' ? 'days' : unit === 'M' ? 'months' : unit === 'y' ? 'years' : unit;
  const dt = parseToDateTime(date).plus({ [normalizedUnit]: value });
  return formatDate(dt.toJSDate(), returnFormat);
};

/**
 * 두 날짜 사이의 차이 계산
 * @param date1 - 첫 번째 날짜
 * @param date2 - 두 번째 날짜
 * @param unit - 단위 ('days'|'d', 'months'|'M', 'years'|'y')
 * @returns 차이값 (date2가 더 크면 양수)
 * @example
 * getDateDiff('2023-12-20', '2023-12-25', 'days') // 5
 * getDateDiff('2023-12-20', '2023-12-25', 'd') // 5
 * getDateDiff('20231015', '20231215', 'M') // 2
 */
export const getDateDiff = (
  date1: DateInput,
  date2: DateInput,
  unit: DateUnit
): number => {
  // 축약형을 전체형으로 변환
  const normalizedUnit = unit === 'd' ? 'days' : unit === 'M' ? 'months' : unit === 'y' ? 'years' : unit;
  const dt1 = parseToDateTime(date1);
  const dt2 = parseToDateTime(date2);
  return Math.floor(dt2.diff(dt1, normalizedUnit)[normalizedUnit]);
};

/**
 * 날짜 비교 및 확인 유틸리티
 */

/**
 * 같은 날인지 비교
 * @description 두 날짜가 같은 날(년/월/일)인지 비교합니다. 시간은 무시됩니다.
 * @param date1 - 첫 번째 날짜 (DateInput: string | Date)
 * @param date2 - 두 번째 날짜 (DateInput: string | Date)
 * @returns 같은 날이면 true, 다른 날이면 false
 * @example
 * isSameDay('2023-12-25', '2023-12-25') // true
 * isSameDay('2023-12-25T10:00:00', '2023-12-25T20:00:00') // true (시간 무시)
 * isSameDay('20231225', '2023-12-25') // true (다른 형식이어도 같은 날)
 * isSameDay('2023-12-25', '2023-12-26') // false
 */
export const isSameDay = (date1: DateInput, date2: DateInput): boolean =>
  parseToDateTime(date1).hasSame(parseToDateTime(date2), 'day');

/**
 * 오늘인지 확인
 * @description 주어진 날짜가 오늘인지 확인합니다.
 * @param date - 확인할 날짜 (DateInput: string | Date)
 * @returns 오늘이면 true, 오늘이 아니면 false
 * @example
 * isToday('2023-12-25') // true (오늘이 12월 25일인 경우)
 * isToday('20231225143000') // true (시간 무시, 날짜만 비교)
 * isToday('2023-12-24') // false (어제)
 */
export const isToday = (date: DateInput): boolean =>
  parseToDateTime(date).hasSame(DateTime.now(), 'day');

/**
 * 어제인지 확인
 * @description 주어진 날짜가 어제인지 확인합니다.
 * @param date - 확인할 날짜 (DateInput: string | Date)
 * @returns 어제면 true, 어제가 아니면 false
 * @example
 * isYesterday('2023-12-24') // true (오늘이 12월 25일인 경우)
 * isYesterday('20231224') // true (YYYYMMDD 형식)
 * isYesterday('2023-12-25') // false (오늘)
 */
export const isYesterday = (date: DateInput): boolean =>
  parseToDateTime(date).hasSame(DateTime.now().minus({ days: 1 }), 'day');

/**
 * 내일인지 확인
 * @description 주어진 날짜가 내일인지 확인합니다.
 * @param date - 확인할 날짜 (DateInput: string | Date)
 * @returns 내일이면 true, 내일이 아니면 false
 * @example
 * isTomorrow('2023-12-26') // true (오늘이 12월 25일인 경우)
 * isTomorrow('20231226') // true (YYYYMMDD 형식)
 * isTomorrow('2023-12-25') // false (오늘)
 */
export const isTomorrow = (date: DateInput): boolean =>
  parseToDateTime(date).hasSame(DateTime.now().plus({ days: 1 }), 'day');

/**
 * 변환 유틸리티
 */

/**
 * 문자열을 Date 객체로 변환
 * @description 날짜 문자열을 JavaScript Date 객체로 변환합니다. 변환 실패시 null을 반환합니다.
 * @param dateString - 날짜 문자열 (ISO 8601, YYYYMMDD, YYYYMMDDHHMMSS 등)
 * @returns Date 객체 또는 null (변환 실패시)
 * @example
 * parseDate('2023-12-25') // Date 객체
 * parseDate('20231225') // Date 객체 (YYYYMMDD)
 * parseDate('20231225143000') // Date 객체 (YYYYMMDDHHMMSS)
 * parseDate('invalid-date') // null
 */
export const parseDate = (dateString: string): Date | null => {
  try {
    const dt = parseToDateTime(dateString);
    return dt.isValid ? dt.toJSDate() : null;
  } catch {
    return null;
  }
};

/**
 * ISO 날짜 문자열로 변환 (날짜 부분만)
 * @description 날짜를 'YYYY-MM-DD' 형식의 ISO 날짜 문자열로 변환합니다. 시간 부분은 제외됩니다.
 * @param date - 변환할 날짜 (DateInput: string | Date)
 * @returns 'YYYY-MM-DD' 형식 문자열
 * @example
 * toISODate(new Date('2023-12-25T14:30:00')) // '2023-12-25'
 * toISODate('20231225143000') // '2023-12-25'
 * toISODate('2023-12-25') // '2023-12-25'
 */
export const toISODate = (date: DateInput): string =>
  parseToDateTime(date).toFormat('yyyy-MM-dd');

/**
 * 시간 관련 유틸리티
 */

/**
 * 상대적 시간 표시
 * @description 주어진 날짜와 현재 시간 사이의 상대적 시간을 자연어로 반환합니다.
 * @param date - 기준 날짜 (DateInput: string | Date)
 * @param locale - 언어 코드 (기본값: 'ko' - 한국어)
 * @param now - 비교 기준 시간 (DateInput: string | Date, 선택사항, 기본값: 현재 시간)
 * @returns 상대적 시간 문자열 ('1분 전', '2시간 후', '3일 전' 등)
 * @example
 * getRelativeTime('2023-12-25T10:00:00') // '1분 전' (현재가 10:01인 경우)
 * getRelativeTime('20231225100000', 'en') // '1 minute ago'
 * getRelativeTime('2023-12-24', '2023-12-25') // '1일 전'
 */
export const getRelativeTime = (
  date: DateInput,
  locale: string = 'ko',
  now?: DateInput
): string => {
  const dt = parseToDateTime(date).setLocale(locale);
  const nowDt = now ? parseToDateTime(now) : DateTime.now();
  return dt.toRelative({ base: nowDt }) || '';
};

/**
 * 두 날짜 사이의 기간을 문자열로 표시
 * @description 시작일과 종료일 사이의 기간을 자연어로 표현합니다. 년/월/일 단위로 분해하여 표시합니다.
 * @param startDate - 시작 날짜 (DateInput: string | Date)
 * @param endDate - 종료 날짜 (DateInput: string | Date)
 * @param locale - 언어 코드 (기본값: 'ko' - 한국어)
 * @returns 기간 문자열 ('1년 2개월 3일', '2 years 3 months' 등)
 * @example
 * getPeriodString('2023-01-01', '2023-12-31') // '11개월 30일'
 * getPeriodString('20230101', '20231231', 'en') // '11 months 30 days'
 * getPeriodString('2020-01-01', '2023-06-15') // '3년 5개월 14일'
 * getPeriodString('2023-12-25', '2023-12-25') // '0일'
 */
export const getPeriodString = (
  startDate: DateInput,
  endDate: DateInput,
  locale: string = 'ko'
): string => {
  const diff = parseToDateTime(endDate).diff(parseToDateTime(startDate), ['years', 'months', 'days']).toObject();

  const parts: string[] = [];
  const isKorean = locale === 'ko';

  if (diff.years && diff.years > 0) {
    const years = Math.floor(diff.years);
    parts.push(isKorean ? `${years}년` : `${years} year${years > 1 ? 's' : ''}`);
  }
  if (diff.months && diff.months > 0) {
    const months = Math.floor(diff.months);
    parts.push(isKorean ? `${months}개월` : `${months} month${months > 1 ? 's' : ''}`);
  }
  if (diff.days && diff.days > 0) {
    const days = Math.floor(diff.days);
    parts.push(isKorean ? `${days}일` : `${days} day${days > 1 ? 's' : ''}`);
  }

  return parts.length > 0 ? parts.join(' ') : (isKorean ? '0일' : '0 days');
};

/**
 * 기간 및 범위 유틸리티
 */

/**
 * 해당 월의 첫 번째 날 구하기
 * @description 주어진 날짜가 속한 월의 첫 번째 날(1일)을 반환합니다.
 * @param date - 기준 날짜 (DateInput: string | Date)
 * @param format - 반환할 날짜 형식 (Luxon format string, 선택사항)
 * @returns 해당 월의 첫 번째 날 문자열
 * @example
 * getFirstDay('2023-12-25') // '2023-12-01T00:00:00.000Z'
 * getFirstDay('20231225', 'yyyy-MM-dd') // '2023-12-01'
 * getFirstDay('2023-12-25', 'yyyyMMdd') // '20231201'
 */
export const getFirstDay = (date: DateInput, format?: string): string => {
  const dt = parseToDateTime(date).startOf('month');
  return formatDate(dt.toJSDate(), format);
};

/**
 * 해당 월의 마지막 날 구하기
 * @description 주어진 날짜가 속한 월의 마지막 날을 반환합니다.
 * @param date - 기준 날짜 (DateInput: string | Date)
 * @param format - 반환할 날짜 형식 (Luxon format string, 선택사항)
 * @returns 해당 월의 마지막 날 문자열
 * @example
 * getLastDay('2023-12-25') // '2023-12-31T23:59:59.999Z'
 * getLastDay('20231225', 'yyyy-MM-dd') // '2023-12-31'
 * getLastDay('2023-02-15', 'yyyyMMdd') // '20230228'
 */
export const getLastDay = (date: DateInput, format?: string): string => {
  const dt = parseToDateTime(date).endOf('month');
  return formatDate(dt.toJSDate(), format);
};

/**
 * 해당 주의 시작일 구하기 (월요일 기준)
 * @description 주어진 날짜가 속한 주의 시작일(월요일)을 반환합니다.
 * @param date - 기준 날짜 (DateInput: string | Date)
 * @param format - 반환할 날짜 형식 (Luxon format string, 선택사항)
 * @returns 해당 주의 월요일 문자열
 * @example
 * getWeekStart('2023-12-25') // '2023-12-25T00:00:00.000Z' (월요일)
 * getWeekStart('20231227', 'yyyy-MM-dd') // '2023-12-25' (수요일 → 월요일)
 */
export const getWeekStart = (date: DateInput, format?: string): string => {
  const dt = parseToDateTime(date).startOf('week');
  return formatDate(dt.toJSDate(), format);
};

/**
 * 해당 주의 마지막일 구하기 (일요일 기준)
 * @description 주어진 날짜가 속한 주의 마지막일(일요일)을 반환합니다.
 * @param date - 기준 날짜 (DateInput: string | Date)
 * @param format - 반환할 날짜 형식 (Luxon format string, 선택사항)
 * @returns 해당 주의 일요일 문자열
 * @example
 * getWeekEnd('2023-12-25') // '2023-12-31T23:59:59.999Z' (일요일)
 * getWeekEnd('20231227', 'yyyy-MM-dd') // '2023-12-31' (수요일 → 일요일)
 */
export const getWeekEnd = (date: DateInput, format?: string): string => {
  const dt = parseToDateTime(date).endOf('week');
  return formatDate(dt.toJSDate(), format);
};

/**
 * 계산 및 검증 유틸리티
 */

/**
 * 만 나이 계산하기
 * @description 생년월일을 기준으로 만 나이를 계산합니다. 기준일이 없으면 현재 날짜를 기준으로 합니다.
 * @param birthDate - 생년월일 (DateInput: string | Date)
 * @param baseDate - 나이 계산 기준일 (DateInput: string | Date, 선택사항)
 * @returns 만 나이 (number)
 * @example
 * calculateAge('1990-01-01') // 현재 기준 만 나이
 * calculateAge('19900101') // 33 (YYYYMMDD 형식도 지원)
 * calculateAge('1990-01-01', '2023-01-01') // 33 (특정 기준일)
 */
export const calculateAge = (birthDate: DateInput, baseDate?: DateInput): number => {
  const birth = parseToDateTime(birthDate);
  const base = baseDate ? parseToDateTime(baseDate) : DateTime.now();
  return Math.floor(base.diff(birth, 'years').years);
};

/**
 * 날짜 유효성 검증
 * @description 입력된 날짜가 유효한지 검증합니다. 모든 DateInput 형식을 지원합니다.
 * @param date - 검증할 날짜 (DateInput: string | Date)
 * @returns 유효하면 true, 유효하지 않으면 false
 * @example
 * isValidDate('2023-12-25') // true
 * isValidDate('20231225') // true (YYYYMMDD)
 * isValidDate('20231225143000') // true (YYYYMMDDHHMMSS)
 * isValidDate('invalid-date') // false
 * isValidDate('2023-13-45') // false (잘못된 월/일)
 */
export const isValidDate = (date: DateInput): boolean => {
  try {
    return parseToDateTime(date).isValid;
  } catch {
    return false;
  }
};

/**
 * 주말 여부 확인
 * @description 주어진 날짜가 주말(토요일, 일요일)인지 확인합니다.
 * @param date - 확인할 날짜 (DateInput: string | Date)
 * @returns 주말이면 true, 평일이면 false
 * @example
 * isWeekend('2023-12-23') // true (토요일)
 * isWeekend('2023-12-24') // true (일요일)
 * isWeekend('2023-12-25') // false (월요일)
 * isWeekend('20231223') // true (YYYYMMDD 형식)
 */
export const isWeekend = (date: DateInput): boolean => {
  const weekday = parseToDateTime(date).weekday;
  return weekday === 6 || weekday === 7; // 토요일(6) 또는 일요일(7)
};

/**
 * 현재 날짜/시간 반환
 * @description 현재 날짜와 시간을 지정된 형식으로 반환합니다.
 * @param format - 반환할 날짜 형식 (Luxon format string, 선택사항)
 * @returns 현재 날짜/시간 문자열 (format 없으면 ISO 8601 형식)
 * @example
 * now() // '2023-12-25T14:30:00.000Z' (ISO 8601)
 * now('yyyy-MM-dd') // '2023-12-25'
 * now('yyyyMMddHHmmss') // '20231225143000'
 * now('yyyy년 MM월 dd일') // '2023년 12월 25일'
 */
export const now = (format?: string): string =>
  formatDate(new Date(), format);
