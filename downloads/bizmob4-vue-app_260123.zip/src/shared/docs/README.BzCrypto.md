# BzCrypto 사용 가이드

bizMOB 하이브리드 앱에서 웹 환경에서의 암호화 통신을 관리하는 클래스입니다.

---

## 1. 개요

### 1.1 목적
RSA 키 교환, 암호화 토큰 관리를 통한 안전한 데이터 통신을 지원합니다.

### 1.2 주요 기능
- RSA 키 쌍 생성 및 암호화 키 교환
- 암호화 인증 토큰 관리
- 토큰 자동 갱신
- 토큰 만료 확인

### 1.3 사전 요구사항
- bizMOB Xross 4.0 환경
- 웹 환경 (앱은 네이티브에서 자동 처리)
- forge.js 라이브러리 포함
- TypeScript 지원 프로젝트

---

## 2. 암호화 설정

### 2.1 웹 환경 (.env 파일)
```bash
# 웹 암호화 사용 여부
VITE_WEB_ENCRYPTION_USE='true'
```

### 2.2 앱 환경 (app.config)
```json
"NETWORK": {
  "ENCRYPTION_USE": true
}
```

---

## 3. 기본 사용법

### 3.1 암호화 키 공유 (최초 인증)

```typescript
import { BzCrypto } from '@bizMOB';

// 최초 암호화 키 공유
try {
  const authResult = await BzCrypto.shareAuthKey({ _bProgressEnable: false });

  console.log('암호화 키 공유 성공');
  console.log('암호화 키:', authResult.crySymKey);
  console.log('인증 토큰:', authResult.cryAuthToken);
} catch (errorCode) {
  console.error('암호화 키 공유 실패:', errorCode);
  // BM4001IMPL0001: 서버 오류 - 서버 로그 확인 필요
}
```

### 3.2 암호화 정보 조회

```typescript
// 초기화 여부 확인
const isInit = BzCrypto.isInit();

// 암호화 키 조회
const symKey = BzCrypto.getSymKey();

// 인증 토큰 조회
const authToken = BzCrypto.getCryAuthToken();

// 토큰 만료 시간 조회
const expTime = BzCrypto.getCryAuthTokenExpTime();
```

### 3.3 토큰 만료 확인

```typescript
// 토큰 발급 필요 여부 확인
if (BzCrypto.isTokenRequired()) {
  console.log('암호화 토큰이 없습니다. 키 공유가 필요합니다.');
}

// 토큰 만료 여부 확인
if (BzCrypto.isTokenExpired()) {
  console.log('암호화 토큰이 만료되었습니다.');
}
```

### 3.4 암호화 토큰 갱신

```typescript
try {
  // 토큰 갱신 (프로그레스 표시 안함)
  const renewResult = await BzCrypto.renewAuthToken({ _bProgressEnable: false });

  console.log('토큰 갱신 성공:', renewResult.cryAuthToken);
} catch (errorCode) {
  console.log('토큰 갱신 실패:', errorCode);
  // BM4002TKER1002: Refresh token 만료 - 키 공유 재호출 필요
}
```

---

## 4. 실제 사용 예시

### 4.1 암호화 통신 초기화

```typescript
async function initEncryption() {
  // 토큰 발급이 필요한 경우
  if (BzCrypto.isTokenRequired()) {
    try {
      await BzCrypto.shareAuthKey({ _bProgressEnable: false });
      console.log('암호화 키 공유 완료');
    } catch (error) {
      throw new Error('암호화 초기화 실패');
    }
  }

  // 토큰이 만료된 경우 갱신
  if (BzCrypto.isTokenExpired()) {
    try {
      await BzCrypto.renewAuthToken({ _bProgressEnable: false });
      console.log('암호화 토큰 갱신 완료');
    } catch (error) {
      // 갱신 실패 시 키 공유 재시도
      await BzCrypto.shareAuthKey({ _bProgressEnable: false });
      console.log('암호화 키 재공유 완료');
    }
  }
}
```

### 4.2 API 호출 전 암호화 토큰 확인

```typescript
import { BzCrypto, Network } from '@bizMOB';

async function callEncryptedApi(trcode: string, body: any) {
  // 암호화 초기화
  await initEncryption();

  const result = await Network.requestTr({
    _sTrcode: trcode,
    _oBody: body
  });

  // 암호화 토큰 만료 에러 처리
  if (!result.header.result && result.header.error_code === 'EAH001') {
    console.log('암호화 토큰 만료, 갱신 후 재시도');

    try {
      await BzCrypto.renewAuthToken({ _bProgressEnable: false });
      // 토큰 갱신 성공 시 API 재호출
      return await Network.requestTr({
        _sTrcode: trcode,
        _oBody: body
      });
    } catch (error) {
      // 갱신 실패 시 키 공유 후 재시도
      await BzCrypto.shareAuthKey({ _bProgressEnable: false });
      return await Network.requestTr({
        _sTrcode: trcode,
        _oBody: body
      });
    }
  }

  return result;
}
```

---

## 5. 에러 처리

### 5.1 키 공유/토큰 갱신 에러 처리

```typescript
async function handleCryptoError(errorCode: string) {
  switch (errorCode) {
    case 'BM4001IMPL0001':
      // 서버에서 암호화 키 생성 오류
      console.error('서버 암호화 키 생성 오류 - 서버 로그 확인 필요');
      break;

    case 'BM4002TKER1001':
      // 유효하지 않은 토큰 - 키 공유 재호출
      console.error('유효하지 않은 토큰');
      await BzCrypto.shareAuthKey({ _bProgressEnable: false });
      break;

    case 'BM4002TKER1002':
      // Refresh Token 만료 - 키 공유 재호출
      console.error('Refresh Token 만료');
      await BzCrypto.shareAuthKey({ _bProgressEnable: false });
      break;

    case 'EAH000':
      // 서버 세션 만료 - 키 공유 재호출
      console.error('서버 세션 만료');
      await BzCrypto.shareAuthKey({ _bProgressEnable: false });
      break;

    case 'EAH001':
      // 암호화 인증 토큰 만료 - 토큰 갱신
      console.error('암호화 토큰 만료');
      await BzCrypto.renewAuthToken({ _bProgressEnable: false });
      break;

    default:
      if (errorCode.endsWith('CRPTEDC001')) {
        // 복호화 오류 - 키 불일치
        console.error('암호화 키 불일치 - 키 공유 재호출');
        await BzCrypto.shareAuthKey({ _bProgressEnable: false });
      }
      break;
  }
}
```

---

## 6. 주의사항

### 6.1 사용 환경 제한사항
- **웹 환경 전용**: BzCrypto는 웹 환경에서만 사용 (앱은 네이티브에서 자동 처리)
- **forge.js 필수**: RSA 암호화를 위해 forge.js 라이브러리 필요
- **환경변수 설정**: `VITE_WEB_ENCRYPTION_USE='true'` 설정 후 사용
- **앱 설정**: app.config에서 `ENCRYPTION_USE: true` 설정

### 6.2 토큰 관리 규칙
- **토큰 순서**: 키 공유(BM4001) → 토큰 갱신(BM4002) 순서 준수
- **초기화**: 앱 시작 시 키 공유 과정 필요
- **만료 처리**: 토큰 만료 시 자동 갱신 또는 키 재공유

### 6.3 에러 코드 참고

| 코드 | 설명 | 후처리 |
|------|------|--------|
| `BM4001IMPL0001` | 서버 암호화 키 생성 오류 | 서버 로그 확인 |
| `BM4002TKER1001` | 유효하지 않은 토큰 | 키 공유 재호출 |
| `BM4002TKER1002` | Refresh Token 만료 | 키 공유 재호출 |
| `EAH000` | 서버 세션 만료 | 키 공유 재호출 |
| `EAH001` | 암호화 토큰 만료 | 토큰 갱신 |
| `{TRCODE}CRPTEDC001` | 복호화 오류 | 키 공유 재호출 |