# bizMOB app.config 설정 가이드

bizMOB 네이티브 앱의 동작을 제어하는 클라이언트 설정 파일입니다.

---

## 1. 개요

### 1.1 목적
bizMOB 네이티브 앱의 버전, 보안, UI, 네트워크 등 전반적인 동작을 설정합니다.

### 1.2 파일 위치
- **경로**: `public/bizMOB/app.config`
- **형식**: JSON 형태의 설정 파일
- **환경별**: PROD, SIT, UAT 환경별로 설정 관리

### 1.3 주요 설정 영역
- **VERSION**: 앱 및 프론트 버전 정보
- **SETTINGS**: 앱 기본 설정
- **SECURITY**: 보안 관련 설정
- **STATUSBAR**: 상태바 UI 설정
- **WEBVIEW**: 웹뷰 화면 설정
- **NETWORK**: 네트워크 통신 설정

---

## 2. VERSION 설정

앱과 프론트엔드의 버전 정보를 관리합니다.

### 2.1 NATIVE
```json
"NATIVE": "4.0"
```
- **타입**: String
- **기본값**: "4.0"
- **설명**: bizMOB 네이티브 앱 버전

### 2.2 FRONT
```json
"FRONT": "4.0"
```
- **타입**: String
- **기본값**: "4.0"
- **설명**: 웹 프론트엔드 버전

---

## 3. SETTINGS 설정

앱의 기본 동작을 제어하는 설정입니다.

### 3.1 TYPE
```json
"TYPE": "B2B"
```
- **타입**: String
- **기본값**: "B2B"
- **옵션**: B2C, B2B
- **설명**: 비즈니스 모델 타입 설정

### 3.2 APPLICATION_TYPE
```json
"APPLICATION_TYPE": "MOBILE"
```
- **타입**: String
- **기본값**: "MOBILE"
- **옵션**: MOBILE, WEB
- **설명**: 애플리케이션 타입 설정

### 3.3 NOTICE_USE
```json
"NOTICE_USE": false
```
- **타입**: Boolean
- **기본값**: false
- **설명**: 공지 팝업 기능 사용 여부

---

## 4. SECURITY 설정

보안 관련 기능을 제어합니다.

### 4.1 CONTENTS_INTEGRITY
```json
"CONTENTS_INTEGRITY": false
```
- **타입**: Boolean
- **기본값**: false
- **네이티브 키**: CHECK_CONTENTS_INTEGRITY
- **설명**: 컨텐츠 무결성 검증 기능
- **참고**: 업무적 설정 후 설정상 전달 불가하여 설정값이 무의미 (검토 후 옵션 재정의 필요)

### 4.2 INACTIVITY_SECONDS
```json
"INACTIVITY_SECONDS": 300
```
- **타입**: Number
- **기본값**: 300
- **네이티브 키**: SET_SESSION_TIMEOUT
- **설명**: 앱 미사용 시 세션 종료 시간 (초 단위)
- **옵션**: 0 (Unlimited), 1~ (Seconds)

---

## 5. STATUSBAR 설정

상태바의 외관을 제어합니다.

### 5.1 MODE
```json
"MODE": "DEFAULT"
```
- **타입**: String
- **기본값**: "DEFAULT"
- **네이티브 키**: MODE
- **옵션**: DEFAULT / EXTEND / FULL
- **중요**: 2025.09.03 작성 - 네이티브에서 설정값 반영하는 방식으로 변경. AOS SDK 35 이후부터 OSM에서 전면적으로 사용하도록 의무강제된 bizMOB status bar 베경색 및 아이콘 색상은 OS정책에 완주도록 변경

### 5.2 BGCOLOR
```json
"BGCOLOR": "FFFFFF"
```
- **타입**: String
- **기본값**: "FFFFFF"
- **네이티브 키**: BG_COLOR
- **설명**: RGB 색상값 (상태바 배경색)

### 5.3 TEXT_BLIGHT
```json
"TEXT_BLIGHT": "BLACK"
```
- **타입**: String
- **기본값**: "BLACK"
- **네이티브 키**: LIGHT_MODE
- **옵션**: BLACK / WHITE
- **설명**: 상태바 텍스트 밝기 설정

---

## 6. WEBVIEW 설정

웹뷰 화면의 배경색을 설정합니다.

### 6.1 BACKGROUNDCOLOR
웹뷰의 상황별 배경색을 설정합니다.

#### NORMAL
```json
"NORMAL": "FFFFFFFF"
```
- **타입**: String
- **기본값**: "FFFFFFFF"
- **설명**: 일반 웹뷰의 aRGB 색상값

#### DIALOG
```json
"DIALOG": "FFFFFFFF"
```
- **타입**: String
- **기본값**: "FFFFFFFF"
- **설명**: 다이얼로그 웹뷰의 aRGB 색상값

---

## 7. NETWORK 설정

네트워크 통신 관련 설정을 제어합니다.

### 7.1 FILE 설정
파일 관련 네트워크 타임아웃을 설정합니다.

#### CONNECT
```json
"CONNECT": 3
```
- **타입**: Number
- **기본값**: 3
- **설명**: 파일 Connection Timeout 시간 (초 단위)

#### READ
```json
"READ": 30
```
- **타입**: Number
- **기본값**: 30
- **설명**: 파일 Read Timeout 시간 (초 단위)

### 7.2 API 설정
API 통신 타임아웃을 설정합니다.

#### CONNECT
```json
"CONNECT": 3
```
- **타입**: Number
- **기본값**: 3
- **설명**: API Connection Timeout 시간 (초 단위)

#### READ
```json
"READ": 15
```
- **타입**: Number
- **기본값**: 15
- **설명**: API Read Timeout 시간 (초 단위)

### 7.3 ENCRYPTION_USE
```json
"ENCRYPTION_USE": false
```
- **타입**: Boolean
- **기본값**: false
- **네이티브 키**: USE_ENCRYPTED_COMM
- **설명**: 통신 데이터 구간 암호화 사용 여부

### 7.4 DETECT_STAUTS
```json
"DETECT_STAUTS": false
```
- **타입**: Boolean
- **기본값**: false
- **네이티브 키**: USE_NETWORK_STATUS_CHECKER
- **설명**: 통신 상태 이벤트 사용 여부

---

## 8. 설정 예시

### 8.1 개발 환경 (SIT)
```json
{
  "SIT": {
    "VERSION": {
      "NATIVE": "4.0",
      "FRONT": "4.0"
    },
    "SETTINGS": {
      "TYPE": "B2C",
      "APPLICATION_TYPE": "MOBILE",
      "NOTICE_USE": false
    },
    "SECURITY": {
      "CONTENTS_INTEGRITY": false,
      "INACTIVITY_SECONDS": 300
    },
    "NETWORK": {
      "ENCRYPTION_USE": false,
      "DETECT_STAUTS": false
    }
  }
}
```

### 8.2 운영 환경 (PROD)
```json
{
  "PROD": {
    "VERSION": {
      "NATIVE": "4.0",
      "FRONT": "4.0"
    },
    "SETTINGS": {
      "TYPE": "B2C",
      "APPLICATION_TYPE": "MOBILE",
      "NOTICE_USE": false
    },
    "SECURITY": {
      "CONTENTS_INTEGRITY": false,
      "INACTIVITY_SECONDS": 300
    },
    "NETWORK": {
      "ENCRYPTION_USE": true,
      "DETECT_STAUTS": true
    }
  }
}
```

---

## 9. 주의사항

### 9.1 환경별 설정
- 환경별로 다른 설정값 사용 가능 (PROD, SIT, UAT)
- 운영 환경에서는 보안 설정을 활성화 권장

### 9.2 타임아웃 설정
- CONNECT: 서버 연결 대기 시간
- READ: 데이터 읽기 대기 시간
- 네트워크 환경에 따라 적절히 조정 필요

### 9.3 보안 설정
- **ENCRYPTION_USE**: 운영 환경에서는 true 권장
- **INACTIVITY_SECONDS**: 보안 요구사항에 따라 설정
- **CONTENTS_INTEGRITY**: 현재 설정 무효 (개선 예정)

### 9.4 상태바 설정 변경사항
- **2025.09.03 기준**: AOS SDK 35 이후 OS 정책 준수로 변경
- 네이티브에서 설정값 직접 반영하는 방식으로 개선