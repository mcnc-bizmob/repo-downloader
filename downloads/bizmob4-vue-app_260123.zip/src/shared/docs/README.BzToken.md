# BzToken 사용 가이드

bizMOB 하이브리드 앱에서 JWT 토큰을 관리하는 클래스입니다.

---

## 1. 개요

### 1.1 목적
JWT 토큰의 저장, 갱신, 만료 확인 기능을 제공하여 안전한 인증 처리를 지원합니다.

### 1.2 주요 기능
- JWT 토큰 저장 및 관리
- 토큰 자동 갱신
- 토큰 만료 확인

### 1.3 사전 요구사항
- bizMOB Xross 4.0 환경
- TypeScript 지원 프로젝트
- 로그인 API 연동 완료

### 1.4 적용 조건

BzToken은 **bizMOB 서버 환경에서만 사용 가능한 JWT 토큰 관리 기능**입니다.

**사용 가능한 경우**
- bizMOB 서버와 연동하는 프로젝트
- JWT 토큰 기반 인증이 필요한 경우

**직접 구현 필요한 경우**
- 일반 웹 서버 환경 (bizMOB 서버가 아닌 경우)
- 프로젝트별 커스텀 토큰 관리가 필요한 경우

**중요**: JWT 토큰 관리는 필수 기능이 아니므로 프로젝트 요구사항에 따라 선택적으로 사용하세요.

---

## 2. 기본 사용법

### 2.1 로그인 후 토큰 초기화

```typescript
import { BzToken, Network } from '@bizMOB';

// 로그인 성공 후 토큰 저장
const loginResult = await Network.requestLogin({
  _sTrcode: 'DM0001',
  _sUserId: 'user@example.com',
  _sPassword: 'password123',
  _oBody: { userId: 'test', password: 'password123' }
});

if (loginResult.header.result) {
  // 토큰 초기화
  BzToken.init({
    accessToken: loginResult.body.accessToken,
    accessTokenExpTime: loginResult.body.accessTokenExpTime,
    refreshToken: loginResult.body.refreshToken,
    refreshTokenExpTime: loginResult.body.refreshTokenExpTime
  });
}
```

### 2.2 토큰 조회

```typescript
// 현재 액세스 토큰 조회
const accessToken = BzToken.getAccessToken();

// 토큰 만료 시간 조회
const expTime = BzToken.getAccessTokenExpTime();

// 초기화 여부 확인
const isInit = BzToken.isInit();
```

### 2.3 토큰 만료 확인

```typescript
// 토큰 만료 여부 확인
if (BzToken.isTokenExpired()) {
  console.log('토큰이 만료되었습니다.');
  // 토큰 갱신 필요
}
```

### 2.4 토큰 자동 갱신

```typescript
try {
  // 토큰 갱신 (프로그레스 표시 안함)
  const renewResult = await BzToken.renewToken({ _bProgressEnable: false });

  console.log('토큰 갱신 성공:', renewResult.accessToken);
} catch (errorCode) {
  console.log('토큰 갱신 실패:', errorCode);
  // 재로그인 필요 (BM4002TKER1002: Refresh token 만료)
}
```

---

## 3. 실제 사용 예시

### 3.1 API 호출 전 토큰 확인

```typescript
async function callApi() {
  // 토큰 초기화 확인
  if (!BzToken.isInit()) {
    throw new Error('토큰이 초기화되지 않았습니다. 먼저 로그인하세요.');
  }

  // 토큰 만료 확인 및 갱신
  if (BzToken.isTokenExpired()) {
    try {
      await BzToken.renewToken();
      console.log('토큰 갱신 완료');
    } catch (error) {
      // 갱신 실패시 재로그인 필요
      throw new Error('토큰 갱신 실패. 재로그인이 필요합니다.');
    }
  }

  // API 호출
  const result = await Network.requestTr({
    _sTrcode: 'USER001',
    _oBody: { pageNo: 1, pageSize: 20 }
  });

  return result;
}
```

---

## 4. 에러 처리

### 4.1 토큰 갱신 시 에러 처리

```typescript
async function handleTokenRenewal() {
  try {
    const renewResult = await BzToken.renewToken({ _bProgressEnable: false });
    console.log('토큰 갱신 성공');
    return true;
  } catch (errorCode) {
    switch (errorCode) {
      case 'BM4002TKER1001':
        // 유효하지 않은 토큰 - 재로그인 필요
        console.error('유효하지 않은 토큰입니다.');
        redirectToLogin();
        break;

      case 'BM4002TKER1002':
        // Refresh Token 만료 - 재로그인 필요
        console.error('Refresh Token이 만료되었습니다.');
        redirectToLogin();
        break;

      default:
        // 기타 에러 - 네트워크 등
        console.error('토큰 갱신 중 오류 발생:', errorCode);
        showErrorMessage('네트워크 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
        break;
    }
    return false;
  }
}

function redirectToLogin() {
  // 토큰 초기화
  BzToken.init({
    accessToken: '',
    accessTokenExpTime: '',
    refreshToken: '',
    refreshTokenExpTime: ''
  });

  // 로그인 페이지로 이동
  window.location.href = '/login';
}
```

### 4.2 API 호출 시 ERR000 에러 처리

```typescript
async function callApiWithRetry(trcode: string, body: any) {
  const result = await Network.requestTr({
    _sTrcode: trcode,
    _oBody: body
  });

  // ERR000 에러 시 토큰 갱신 후 재시도
  if (!result.header.result && result.header.error_code === 'ERR000') {
    console.log('Access Token 만료, 갱신 후 재시도');

    const renewSuccess = await handleTokenRenewal();
    if (renewSuccess) {
      // 토큰 갱신 성공 시 API 재호출
      return await Network.requestTr({
        _sTrcode: trcode,
        _oBody: body
      });
    }
  }

  return result;
}
```

---

## 5. 주의사항

### 5.1 사용 시 주의점
- `BzToken.init()`은 로그인 성공 후 반드시 한 번만 호출
- 토큰 갱신 실패 시 (`BM4002TKER1002`) 재로그인 필요
- bizMOB 네이티브 설정도 자동으로 업데이트됨
- 토큰 만료 시간은 UTC 기준이므로 `Z`가 자동 추가됨

### 5.2 에러 코드 참고

| 코드 | 설명 | 후처리 |
|------|------|--------|
| `BM4002TKER1001` | 유효하지 않은 토큰 | 재로그인 필요 |
| `BM4002TKER1002` | Refresh Token 만료 | 재로그인 필요 |
| `ERR000` | Access Token 만료 | 토큰 갱신 후 API 재호출 |