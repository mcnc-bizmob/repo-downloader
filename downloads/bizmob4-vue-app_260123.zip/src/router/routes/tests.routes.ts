// 테스트 화면 라우터 설정
export default [
  // 메인 테스트 대시보드
  {
    path: '/tests',
    name: 'TestDashboard',
    component: () => import('@/views/tests/TestDashboard.vue')
  },

  // App Store 테스트
  {
    path: '/tests/appstore',
    name: 'AppStoreTest',
    component: () => import('@/views/tests/appStore/AppStoreTest.vue')
  },

  // Alert & Confirm 테스트
  {
    path: '/tests/alert',
    name: 'AlertTest',
    component: () => import('@/views/tests/alert/AlertTest.vue')
  },

  // Toast 테스트
  {
    path: '/tests/toast',
    name: 'ToastTest',
    component: () => import('@/views/tests/toast/ToastTest.vue')
  },

  // Menu 테스트
  {
    path: '/tests/menu',
    name: 'MenuTest',
    component: () => import('@/views/tests/menu/MenuTest.vue')
  },

  // Menu Target (Menu에서 이동하는 타겟 페이지)
  {
    path: '/tests/menu/target',
    name: 'MenuTarget',
    component: () => import('@/views/tests/menu/MenuTarget.vue')
  },

  // ActionSheet 테스트
  {
    path: '/tests/actionsheet',
    name: 'ActionSheetTest',
    component: () => import('@/views/tests/actionsheet/ActionSheetTest.vue')
  },

  // Router 테스트
  {
    path: '/tests/router',
    name: 'RouterTest',
    component: () => import('@/views/tests/router/RouterTest.vue')
  },

  // Router 테스트 - 메인화면 (direction: 'root' 테스트용)
  {
    path: '/tests/router/main',
    name: 'RouterMainTest',
    component: () => import('@/views/tests/router/MainTest.vue')
  },

  // Router 테스트 - 로그인화면 (direction: 'root' 테스트용)
  {
    path: '/tests/router/login',
    name: 'RouterLoginTest',
    component: () => import('@/views/tests/router/LoginTest.vue')
  },

  // Modal 테스트
  {
    path: '/tests/modal',
    name: 'ModalTest',
    component: () => import('@/views/tests/modal/ModalTest.vue')
  },

  // Popover 테스트
  {
    path: '/tests/popover',
    name: 'PopoverTest',
    component: () => import('@/views/tests/popover/PopoverTest.vue')
  },

  // BackButton 테스트
  {
    path: '/tests/backbutton',
    name: 'BackButtonTest',
    component: () => import('@/views/tests/backbutton/TestBackButton.vue')
  },

  // Loading 테스트
  {
    path: '/tests/loading',
    name: 'LoadingTest',
    component: () => import('@/views/tests/loading/TestLoading.vue')
  }
];
