import { createRouter, createWebHistory } from '@ionic/vue-router';

import testsRoutes from '@/router/routes/tests.routes';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/tests',
    },

    ...testsRoutes,
  ],
});

// ===================================================================
// 🚨 Error Handling
// ===================================================================

/**
 * ChunkLoadError 처리 (Vite 청크 로딩 실패)
 * 주로 배포 후 이전 버전 캐시로 인해 발생
 */
router.onError((error) => {
  console.error('[Router Error]', error);

  // ChunkLoadError 감지
  if (error.name === 'ChunkLoadError' || error.message?.includes('Loading chunk')) {
    console.warn('ChunkLoadError 감지: 페이지를 새로고침합니다.');

    // 개발 환경에서는 알림 표시
    if (import.meta.env?.DEV) {
      alert('청크 로딩 실패로 페이지를 새로고침합니다.');
    }

    // 새로고침하여 최신 청크 다운로드
    window.location.reload();
    return;
  }

  // 기타 라우팅 에러 처리
  if (error.message?.includes('Failed to resolve component')) {
    console.error('컴포넌트 로딩 실패:', error);

    // 홈으로 리다이렉트
    router.push('/').catch(() => {
      // 리다이렉트도 실패하면 새로고침
      window.location.href = '/';
    });
  }
});

export default router;
