# Business Modules Stores

각 프로젝트의 **비즈니스 도메인별 스토어**들을 관리하는 폴더입니다.

## 📁 **폴더 구조**

```text
stores/modules/
├── auth.store.ts           # 인증 관련 스토어
├── user.store.ts           # 사용자 관리 스토어
├── product.store.ts        # 상품 관리 스토어 (예시)
├── order.store.ts          # 주문 관리 스토어 (예시)
└── README.md              # 이 파일
```

## 🎯 **Base 프로젝트 정책**

### **❌ Base에서 제공하지 않는 이유**
비즈니스 도메인별 스토어는 **각 프로젝트마다 완전히 다르기 때문**에 Base에서 미리 만들지 않습니다.

- **인증 (Auth)**: OAuth, JWT, 세션, 생체인증 등 방식이 다름
- **사용자 (User)**: 역할, 권한, 프로필 구조가 프로젝트마다 상이
- **비즈니스 로직**: 각 도메인의 특성과 요구사항이 완전히 다름

### **✅ 각 프로젝트에서 직접 구현**
프로젝트 요구사항에 맞춰 이 폴더에 도메인별 스토어를 추가하세요.

## 🤖 **AI 에이전트 활용 가이드**

### **1. 도메인 스토어 생성 요청 템플릿**

```text
"Vue 3 + Ionic + bizMOB 프로젝트용 {도메인명} 스토어를 만들어줘.

📁 생성할 파일:
stores/modules/{domain}.store.ts

🎯 비즈니스 요구사항:
- 주요 엔티티: {예: User, Profile, Settings}
- 관리할 상태: {예: currentUser, isLoggedIn, permissions}
- 필요한 액션: {예: login, logout, updateProfile}
- API 연동: {예: REST API, GraphQL}

⚙️ 기술 요구사항:
- Vue 3 Composition API
- Pinia defineStore
- TypeScript 완전 지원
- 암호화 저장소: cryptoLocalStorage 사용
- bizMOB 네이티브 연동 (필요시)
- JSDoc 주석 포함

📝 예시 API:
- POST /api/auth/login
- GET /api/user/profile
- PUT /api/user/profile"
```

### **2. 표준 스토어 구조**

```typescript
// stores/modules/auth.store.ts
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import { cryptoLocalStorage } from '@/stores/plugins/crypto-storage';

/**
 * 사용자 정보 인터페이스
 */
interface UserInfo {
  id: ID; // 전역 타입 사용
  name: string;
  email: string;
  role: 'admin' | 'user' | 'guest';
}

/**
 * 로그인 요청 데이터
 */
interface LoginRequest {
  username: string;
  password: string;
}

/**
 * 인증 스토어
 */
export const useAuthStore = defineStore('auth', () => {
  // ===== State =====
  const currentUser = ref<UserInfo | null>(null);
  const isLoading = ref(false);
  const loginError = ref<string | null>(null);

  // ===== Getters =====
  /**
   * 로그인 상태 확인
   */
  const isLoggedIn = computed(() => currentUser.value !== null);

  /**
   * 관리자 권한 확인
   */
  const isAdmin = computed(() => currentUser.value?.role === 'admin');

  // ===== Actions =====
  /**
   * 사용자 로그인
   */
  const login = async (credentials: LoginRequest): Promise<boolean> => {
    isLoading.value = true;
    loginError.value = null;

    try {
      // bizMOB API 호출 (실제 프로젝트에서 구현)
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });

      if (!response.ok) {
        throw new Error('로그인에 실패했습니다.');
      }

      const data = await response.json();
      currentUser.value = data.user;

      return true;
    } catch (error) {
      loginError.value = error instanceof Error ? error.message : '알 수 없는 오류';
      return false;
    } finally {
      isLoading.value = false;
    }
  };

  /**
   * 사용자 로그아웃
   */
  const logout = async (): Promise<void> => {
    try {
      // API 호출 (필요시)
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (error) {
      console.error('로그아웃 API 호출 실패:', error);
    } finally {
      // 로컬 상태 정리
      currentUser.value = null;
      loginError.value = null;
    }
  };

  /**
   * 사용자 정보 새로고침
   */
  const refreshUser = async (): Promise<void> => {
    if (!isLoggedIn.value) return;

    try {
      const response = await fetch('/api/user/profile');
      const userData = await response.json();
      currentUser.value = userData;
    } catch (error) {
      console.error('사용자 정보 새로고침 실패:', error);
    }
  };

  return {
    // State
    currentUser,
    isLoading,
    loginError,

    // Getters
    isLoggedIn,
    isAdmin,

    // Actions
    login,
    logout,
    refreshUser
  };
}, {
  // 암호화된 localStorage에 사용자 정보 저장
  persist: {
    paths: ['currentUser'],
    storage: cryptoLocalStorage,
    key: 'auth-store'
  }
});
```

### **3. 생성 후 체크리스트**

#### **필수 확인사항**
- [ ] `stores/index.ts`에 export 추가
- [ ] 모든 타입이 올바르게 정의됨
- [ ] JSDoc 주석이 완성됨
- [ ] 에러 처리가 포함됨
- [ ] Loading 상태 관리 포함
- [ ] TypeScript 컴파일 오류 없음

#### **보안 확인사항**
- [ ] 민감한 데이터는 `cryptoLocalStorage` 사용
- [ ] API 토큰 등은 암호화 저장
- [ ] 사용자 정보 persist 설정 확인

#### **기능 테스트**
- [ ] 스토어 초기화 정상 동작
- [ ] 상태 변경 시 반응성 확인
- [ ] API 호출 성공/실패 케이스 테스트
- [ ] 암호화 저장소 동작 확인
- [ ] 페이지 새로고침 후 상태 복원 확인

## 💡 **개발 팁**

1. **단일 책임 원칙**: 하나의 스토어는 하나의 도메인만 관리
2. **명확한 이름**: 함수와 변수명에서 용도가 바로 이해되도록
3. **에러 처리**: 모든 비동기 작업에 적절한 에러 처리 포함
4. **상태 정규화**: 복잡한 중첩 데이터는 정규화해서 관리
5. **성능 최적화**: computed 활용으로 불필요한 재계산 방지
6. **보안 고려**: 민감한 데이터는 반드시 암호화 저장소 사용