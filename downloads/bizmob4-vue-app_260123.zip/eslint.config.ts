import pluginVue from 'eslint-plugin-vue';
import tseslint from 'typescript-eslint';
import vueParser from 'vue-eslint-parser';

export default [
  // Global ignores
  {
    ignores: [
      '**/dist/**',
      '**/dist-ssr/**',
      '**/coverage/**',
      'vite.config.ts',
      'public/bizMOB/**',
      'public/extlib/**'
    ]
  },

  // Vue essential rules
  ...pluginVue.configs['flat/essential'],

  // TypeScript recommended rules
  ...tseslint.configs.recommended,

  // Vue specific rules
  {
    name: 'app/vue-rules',
    files: ['**/*.vue'],
    languageOptions: {
      parser: vueParser,
      parserOptions: {
        parser: '@typescript-eslint/parser',
        ecmaVersion: 'latest',
        sourceType: 'module',
        extraFileExtensions: ['.vue'],
      },
    },
    rules: {
      // Vue 컴포넌트 이름을 여러 단어로 구성하는 것에 대해 규칙을 적용하지 않음.
      'vue/multi-word-component-names': 'off',

      // Vue.js에서 deprecated slot 속성 사용을 금지하지 않음.
      'vue/no-deprecated-slot-attribute': 'off',

      // Vue.js의 특정 주석 지시어 사용을 금지하지 않음.
      'vue/comment-directive': 'off',
    }
  },

  // TypeScript and general rules
  {
    name: 'app/typescript-rules',
    files: ['**/*.{ts,mts,tsx,vue}'],
    rules: {
      // TypeScript의 any 타입 사용을 금지하지 않음.
      '@typescript-eslint/no-explicit-any': 'off',

      // TypeScript의 사용하지 않는 변수 오류 off
      '@typescript-eslint/no-unused-vars': 'off',

      // TypeScript의 사용하지 않는 표현식 오류 off (단축 평가, 조건부 실행 등 허용)
      '@typescript-eslint/no-unused-expressions': 'off',

      // no-undef 규칙 비활성화 (TypeScript가 처리)
      'no-undef': 'off',

      // 프로덕션 환경에서는 console 사용에 대해 경고를 표시하고, 그 외 환경에서는 금지하지 않음.
      'no-console': process.env.NODE_ENV === 'production' ? 'warn' : 'off',

      // 프로덕션 환경에서 debugger 사용에 대해 경고를 표시하고, 그 외 환경에서는 금지하지 않음.
      'no-debugger': process.env.NODE_ENV === 'production' ? 'warn' : 'off',

      // 문단 마지막 항상 세미콜론
      'semi': ['error', 'always'],

      // single quote 사용
      'quotes': ['error', 'single'],

      // Tab은 Space 2칸으로 정의
      'indent': ['error', 2, { 'SwitchCase': 1 }],

      // var 선언 금지 off
      'no-var': 'off',

      // arguments 객체 사용 금지 off
      'prefer-rest-params': 'off',
    }
  }
];
