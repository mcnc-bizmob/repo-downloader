# BizMOB4 Base App

Vue 3 + Vite + TypeScript 기반의 BizMOB4 하이브리드 앱 개발을 위한 베이스 템플릿입니다.

## 📋 프로젝트 개요

이 템플릿은 다음과 같은 특징을 제공합니다:

- 🚀 **Vue 3 + Vite**: 빠른 개발 서버와 최적화된 빌드
- 📱 **BizMOB4 네이티브 연동**: 하이브리드 앱 개발을 위한 네이티브 API
- 🔧 **멀티 환경 지원**: SIT/UAT/PROD 환경별 독립적 설정
- 🎯 **TypeScript**: 타입 안전성과 개발 생산성 향상
- 🌐 **대화형 스크립트**: 편리한 개발/빌드 환경 선택

## 🔧 빌드 및 환경 설정

### 환경별 개발 서버 실행

이 프로젝트는 **대화형 스크립트**를 통해 편리하게 개발 환경을 선택할 수 있습니다.

```sh
# 대화형 개발 도구 실행 (권장)
npm run dev

# 환경별 직접 실행
npm run dev-sit      # SIT 환경 (개발)
npm run dev-uat      # UAT 환경 (테스트)
npm run dev-prod     # 운영 환경 (운영)

# 배포 환경 디버깅 모드 (운영 환경 버그 재현용)
npm run dev-sit:deploy
npm run dev-uat:deploy
npm run dev-prod:deploy
```

### 환경별 빌드

```sh
# 대화형 빌드 도구 실행 (권장)
npm run build

# Major 빌드 (전체 업데이트 - fonts 포함)
npm run build-sit:major
npm run build-uat:major
npm run build-prod:major

# Minor 빌드 (경량 업데이트 - fonts 제외)
npm run build-sit:minor
npm run build-uat:minor
npm run build-prod:minor
```

### 환경 변수 파일

프로젝트는 다음 환경 변수 파일들을 사용합니다:

- **`.env`** - 공통 환경변수 (전체 환경에서 공통으로 사용)
- **`.env.sit`** - SIT 환경 전용 설정
- **`.env.uat`** - UAT 환경 전용 설정
- **`.env.prod`** - 운영 환경 전용 설정

#### 환경 변수 파일 우선순위

Vite는 다음 순서로 환경 변수를 로드합니다:

1. `.env` (모든 환경에서 로드)
2. `.env.[mode]` (현재 모드에 해당하는 파일)
3. 명령어에서 설정한 환경변수

동일한 변수가 있을 경우, 나중에 로드된 값이 우선적용됩니다.

#### 보안 주의사항

⚠️ **중요**:

- `.env.*` 파일들은 `.gitignore`에 포함되어 있어 git에 커밋되지 않습니다
- `VITE_` 접두사가 있는 변수만 클라이언트에서 접근 가능합니다
- 민감한 정보(앱 키, API 키 등)는 각 환경에서 별도로 관리하세요

## 🔧 ES5 호환성 및 Legacy 브라우저 지원

이 프로젝트는 **ES5 타겟**으로 빌드되어 구형 브라우저와 모바일 WebView에서도 안정적으로 동작합니다.

### TypeScript 컴파일 설정

#### `tsconfig.app.json` - ES5 타겟 설정

```jsonc
{
  "compilerOptions": {
    "target": "ES5",                    // ES5까지 다운레벨 변환
    "lib": ["ES5", "ES2015", "DOM"],    // ES5 + 필수 ES2015 기능
    "module": "ESNext"                  // 모듈은 최신 방식 (Vite에서 처리)
  }
}
```

### Vite Legacy 플러그인 설정

#### 지원 브라우저 범위

```typescript
legacy({
  targets: [
    'defaults',           // Browserslist 기본 설정
    'Android >= 4.4',     // Android 4.4 이상
    'iOS >= 9',           // iOS 9 이상
    'not IE 11'           // IE 11 제외
  ]
})
```

### ES5 호환성 특징

#### ✅ 지원되는 최신 기능들

- **Async/Await**: `regenerator-runtime`으로 polyfill 제공
- **Arrow Functions**: ES5 function으로 자동 변환
- **Template Literals**: 문자열 연결로 변환
- **Destructuring**: 개별 할당문으로 변환
- **Spread Operator**: ES5 호환 방식으로 변환
- **Classes**: prototype 기반 함수로 변환

#### 🔄 자동 Polyfill 제공

```typescript
// 자동으로 포함되는 polyfill들
additionalLegacyPolyfills: [
  'regenerator-runtime/runtime'  // async/await, generator 지원
]
```

#### 📱 모바일 WebView 호환성

- **Android WebView 4.4+**: 완전 지원
- **iOS UIWebView/WKWebView 9+**: 완전 지원
- **하이브리드 앱 환경**: BizMOB WebView 최적화

### 브라우저별 지원 현황

| 브라우저 | 최소 버전 | 지원 상태 |
|---------|----------|----------|
| Chrome | 49+ | ✅ 완전 지원 |
| Firefox | 44+ | ✅ 완전 지원 |
| Safari | 10+ | ✅ 완전 지원 |
| Edge | 14+ | ✅ 완전 지원 |
| Android | 4.4+ | ✅ 완전 지원 |
| iOS | 9+ | ✅ 완전 지원 |
| IE | ❌ | 지원 안함 |

### 성능 최적화

#### Modern/Legacy 번들 분리

Vite Legacy 플러그인은 자동으로 두 가지 번들을 생성합니다:

- **Modern Bundle**: 최신 브라우저용 (ES2015+)
- **Legacy Bundle**: 구형 브라우저용 (ES5)

브라우저가 자동으로 적합한 번들을 선택하여 로드합니다.

#### 번들 크기 최적화

```typescript
// 최신 브라우저에도 최소한의 polyfill 제공
modernPolyfills: true
```

### 개발 시 주의사항

#### ⚠️ ES5 제약사항

1. **const/let**: `var`로 변환됨 (블록 스코프 주의)
2. **Default Parameters**: 수동 체크 로직으로 변환
3. **for...of**: 전통적인 for 루프로 변환
4. **Symbol**: polyfill 필요 시 수동 추가

#### 🔧 권장 개발 방식

```typescript
// ❌ 피해야 할 패턴
const myFunc = (param = 'default') => { /* ... */ };

// ✅ 권장 패턴
function myFunc(param) {
  param = param || 'default';
  // ...
}
```

## 📂 프로젝트 루트 파일 구조

프로젝트 루트 경로의 주요 파일들과 그 역할에 대한 설명입니다:

### 🔧 설정 파일

- **`vite.config.ts`** - Vite 빌드 도구 설정 (프록시, 플러그인, 빌드 옵션)
- **`package.json`** - npm 패키지 정보 및 스크립트 정의
- **`tsconfig.json`** - TypeScript 컴파일러 설정 (전체 프로젝트)
- **`tsconfig.app.json`** - 앱 소스코드용 TypeScript 설정
- **`tsconfig.node.json`** - Node.js 환경용 TypeScript 설정 (Vite 설정 등)
- **`eslint.config.ts`** - ESLint 코드 품질 검사 규칙 설정

### 🌐 웹 관련 파일

- **`index.html`** - 메인 HTML 템플릿 (SPA 진입점)
- **`.editorconfig`** - 에디터 간 코드 스타일 통일 설정

### 📝 환경 및 타입 정의

- **`.env`** - 공통 환경변수
- **`.env.sit`** - SIT 환경 전용 변수
- **`.env.uat`** - UAT 환경 전용 변수
- **`.env.prod`** - 운영 환경 전용 변수
- **`env.d.ts`** - Vite 환경변수 TypeScript 타입 정의

### 🔒 Git 및 보안

- **`.gitignore`** - Git 추적 제외 파일 목록
- **`.gitattributes`** - Git 파일 속성 설정 (줄바꿈, 병합 전략 등)

### 📦 의존성 관리

- **`package-lock.json`** - npm 패키지 정확한 버전 잠금 파일

### 📁 주요 디렉토리

- **`src/`** - 소스코드 메인 디렉토리
- **`public/`** - 정적 파일 (빌드 시 그대로 복사)
- **`dist/`** - 빌드 출력 디렉토리 (자동 생성)
- **`.scripts/`** - 대화형 개발/빌드 스크립트
- **`.vscode/`** - VS Code 에디터 설정
- **`docs/`** - 프로젝트 문서

#### 파일 수정 시 주의사항

🔄 **자주 수정하는 파일**:

- `package.json` - 프로젝트명, 의존성 변경 시
- `.env.*` - 환경별 설정 변경 시
- `vite.config.ts` - 빌드 설정 커스터마이징 시
- `index.html` - 앱 타이틀, 메타 정보 변경 시

⚠️ **신중하게 수정해야 하는 파일**:

- `tsconfig.*.json` - TypeScript 설정 변경 시
- `eslint.config.ts` - 코딩 규칙 변경 시
- `.gitignore` - 버전 관리 정책 변경 시

## 📁 src 폴더 구조

프로젝트의 메인 소스코드가 위치하는 `src/` 디렉토리의 구조와 각 폴더의 역할입니다.

### 🎯 핵심 파일

- **`App.vue`** - Vue 앱의 루트 컴포넌트
- **`main.ts`** - 앱의 진입점 (Vue 앱 초기화 및 플러그인 등록)

### 📂 주요 디렉토리 구조

#### `assets/` - 정적 리소스

- **`css/`** - 전역 스타일시트 (SCSS 파일)
- **`images/`** - 이미지 리소스 (로고, 아이콘 등)

#### `bizMOB/` - BizMOB 네이티브 연동

- **`bizmob.d.ts`** - BizMOB TypeScript 타입 정의
- **`BzClass/`** - BizMOB 유틸리티 클래스 (암호화, 다국어, 토큰 등)
- **`i18n/`** - 다국어 처리 시스템
- **`Xross/`** - BizMOB 네이티브 API 래퍼 클래스들

#### `locales/` - 다국어 리소스

- **`ko.json`** - 한국어 번역 파일
- **`en.json`** - 영어 번역 파일
- 추가 언어 파일 확장 가능

#### `bizMOB.vue/` - Vue 전용 BizMOB 컴포넌트

- **`index.ts`** - Vue 컴포넌트 내보내기
- **`composables/`** - Vue Composition API 기반 BizMOB 기능들
- **`plugins/`** - Vue 플러그인 (BizMOB, Ionic 등)
- **`stores/`** - BizMOB 관련 상태 관리
- **`types/`** - BizMOB Vue 컴포넌트 타입
- **`utils/`** - BizMOB Vue 유틸리티

#### `plugins/` - Vue 플러그인

- 프로젝트별 플러그인 추가 예정

#### `router/` - 라우팅 설정

- **`index.ts`** - Vue Router 메인 설정
- **`guards/`** - 라우터 가드 (인증, 권한 체크 등)
- **`routes/`** - 페이지별 라우트 정의

#### `shared/` - 공통 유틸리티

- **`index.ts`** - 공통 유틸리티 내보내기
- **`composables/`** - Vue Composition API 기반 재사용 로직
- **`utils/`** - 범용 유틸리티 함수들 (날짜, 포맷터, 검증 등)

#### `stores/` - 상태 관리 (Pinia)

- **`index.ts`** - Pinia 스토어 설정 및 내보내기
- **`modules/`** - 기능별 상태 모듈

#### `types/` - TypeScript 타입 정의

- **`component.d.ts`** - 컴포넌트 관련 타입
- **`type.d.ts`** - 기타 공통 타입

#### `views/` - 페이지 컴포넌트

- **`tests/`** - 개발 및 테스트용 화면들
- 기타 화면들은 프로젝트 진행에 따라 정리 예정

### 🔧 폴더별 활용 가이드

#### 새 기능 추가 시

1. **`views/`** - 새 페이지 컴포넌트 추가
2. **`router/routes/`** - 라우트 정의 추가
3. **`stores/modules/`** - 필요 시 상태 관리 추가
4. **`types/`** - 관련 타입 정의 추가

#### 공통 기능 개발 시

1. **`shared/composables/`** - 재사용 가능한 로직
2. **`shared/utils/`** - 유틸리티 함수
3. **`stores/modules/`** - 공통 상태 관리

#### 다국어 지원 (내용 수정 필요)

1. **`locales/`** - 번역 텍스트 추가
2. **`bizMOB/i18n/`** - 다국어 처리 로직

#### BizMOB 네이티브 기능 확장

1. **`bizMOB/Xross/`** - 기존 bizMOB javascript를 typescript로 래퍼 함수
2. **`bizMOB/BzClass/`** - 유틸리티 클래스 확장

### 주요 환경 변수

```properties
# 클라이언트 루트 경로
BASE_URL=/

# 웹팩 컴파일러 환경
NODE_ENV=development|production

# 프록시 설정 (개발용 CORS 해결)
VITE_PROXY=on|off
VITE_PROXY_CONTEXT=/bizmob.proxy

# BizMOB 설정
VITE_APPLICATION_KEY=your-app-key
VITE_SERVER_CONTEXT=/your-server-context
```

### BizMOB 플러그인 설정

BizMOB 네이티브 기능을 사용하기 위한 설정:

- **플러그인 파일**: `src/bizMOB.vue/plugins/bizmob.plugin.ts`
- **타입 정의**: `src/bizMOB/bizmob.d.ts`
- **네이티브 API**: `src/bizMOB/Xross/` 디렉토리

### 개발 도구

- **대화형 개발 스크립트**: `.scripts/dev-interactive.js`
- **대화형 빌드 스크립트**: `.scripts/build-interactive.js`
- **Vite 설정**: `vite.config.ts`
- **TypeScript 설정**: `tsconfig.json`, `tsconfig.app.json`

### 멀티 환경 지원 특징

- 🔄 **프록시 설정**: 개발 시 CORS 문제 자동 해결
- 🌍 **Base URL**: GitHub Pages 등 서브경로 배포 지원
- 📦 **경량 빌드**: fonts 제외한 minor 빌드 옵션
- 🔧 **환경별 설정**: SIT/UAT/PROD 환경별 독립적 설정

## 🎯 프로젝트별 환경 설정 가이드

새로운 프로젝트에 이 베이스 템플릿을 적용할 때 수정해야 하는 부분들입니다.

### 1. 프로젝트 기본 정보 수정

#### `package.json`

```json
{
  "name": "your-project-name",           // 프로젝트 이름 변경
  "version": "1.0.0",                    // 버전 정보
  "description": "프로젝트 설명",         // 프로젝트 설명 추가
}
```

#### `index.html`

```html
<title>Your App Title</title>           <!-- 앱 타이틀 변경 -->
```

### 2. 환경별 서버 설정

각 환경 파일에서 서버 정보를 프로젝트에 맞게 수정하세요:

#### `.env.sit` (개발 환경)

```properties
VITE_APPLICATION_KEY=your-sit-app-key
VITE_SERVER_CONTEXT=/your-sit-server-context
BASE_URL=/your-sit-base-url/
```

#### `.env.uat` (테스트 환경)

```properties
VITE_APPLICATION_KEY=your-uat-app-key
VITE_SERVER_CONTEXT=/your-uat-server-context
BASE_URL=/your-uat-base-url/
```

#### `.env.prod` (운영 환경)

```properties
VITE_APPLICATION_KEY=your-prod-app-key
VITE_SERVER_CONTEXT=/your-prod-server-context
BASE_URL=/your-prod-base-url/
```

### 3. BizMOB 앱 키 설정

BizMOB 관리자에서 발급받은 앱 키를 환경별로 설정:

1. **BizMOB 관리자 콘솔**에서 앱 등록
2. **환경별 앱 키 발급** (SIT/UAT/PROD)
3. 각 `.env.*` 파일의 `VITE_APPLICATION_KEY`에 설정

### 4. 서버 API 엔드포인트 설정

#### `vite.config.ts` - 프록시 설정

```typescript
proxy: {
  '/bizmob.proxy': {
    target: 'https://your-api-server.com',  // 실제 API 서버 주소로 변경
    changeOrigin: true,
    rewrite: (path) => path.replace(/^\/bizmob\.proxy/, '')
  }
}
```

### 5. 배포 경로 설정

GitHub Pages나 특정 서브 디렉토리에 배포하는 경우:

```properties
# GitHub Pages 예시
BASE_URL=/your-repository-name/

# 서브 디렉토리 배포 예시
BASE_URL=/apps/your-app-name/
```

### 6. 앱 아이콘 및 리소스 교체

#### 교체할 파일들

- `public/favicon.ico` - 파비콘
- `public/fonts/` - 커스텀 폰트 (필요 시)

### 7. 프로젝트별 커스터마이징

#### 테마 및 스타일

- `src/assets/css/global.scss` - 전역 스타일 수정
- CSS 변수를 통한 테마 색상 조정

#### 라우팅 설정

- `src/router/routes/` - 프로젝트별 라우트 추가/수정
- 기본 라우트 경로 변경

#### 다국어 설정

- `src/locales/ko.json`, `src/locales/en.json` - 번역 텍스트 수정
- 필요한 언어 추가

### 8. 빌드 및 배포 설정

#### 빌드 출력 디렉토리 변경 (필요 시)

```typescript
// vite.config.ts
export default defineConfig({
  build: {
    outDir: 'your-custom-dist-folder'  // 기본값: dist
  }
})
```

#### CI/CD 파이프라인 설정

- GitHub Actions, GitLab CI 등 배포 자동화 설정
- 환경별 배포 스크립트 작성

### ⚠️ 주의사항

1. **환경별 앱 키**: 각 환경마다 다른 앱 키를 사용해야 합니다
2. **보안 정보**: `.env.*` 파일은 git에 커밋하지 마세요 (`.gitignore` 확인)
3. **CORS 설정**: 운영 환경에서는 서버 측 CORS 설정이 필요합니다
4. **BASE_URL**: 배포 경로에 맞춰 정확히 설정해야 합니다

### 🔄 설정 완료 후 확인사항

```sh
# 1. 의존성 설치
npm install

# 2. 환경별 개발 서버 실행 테스트
npm run dev-sit
npm run dev-uat
npm run dev-prod

# 3. 환경별 빌드 테스트
npm run build-sit:major
npm run build-uat:major
npm run build-prod:major
```

## ⚙️ Vite 설정 커스터마이징 가이드

프로젝트 요구사항에 따라 `vite.config.ts`에서 수정하거나 추가할 수 있는 설정들입니다.

### 1. 기본 환경 설정

#### 포트 번호 변경

```typescript
// .env 파일에서 설정
VITE_PORT=3000

// 또는 vite.config.ts에서 직접 설정
server: {
  port: 3000,  // 기본값: 8080
}
```

#### 빌드 출력 디렉토리 변경

```typescript
// .env 파일에서 설정
VITE_BUILD_DIR=build

// 또는 vite.config.ts에서 직접 설정
build: {
  outDir: 'build',  // 기본값: dist
}
```

### 2. 프록시 설정 커스터마이징

#### 다중 API 서버 프록시

```typescript
server: {
  proxy: {
    '/api': {
      target: 'https://api1.example.com',
      changeOrigin: true,
    },
    '/auth': {
      target: 'https://auth.example.com',
      changeOrigin: true,
    },
    [env.VITE_PROXY_CONTEXT]: proxyCookieHandler()
  }
}
```

#### 프록시 쿠키 처리 커스터마이징

```typescript
// 현재 설정: LOGIN.json, BM4001.json, BM4002.json에서 쿠키 저장
// 프로젝트에 맞게 수정 필요
const saveList = ['YOUR_LOGIN_API.json', 'YOUR_AUTH_API.json'];
const clearList = ['YOUR_LOGOUT_API.json'];
```

### 3. 빌드 최적화 설정

#### 청크 분리 전략

```typescript
build: {
  rollupOptions: {
    output: {
      manualChunks: {
        // 벤더 라이브러리 분리
        vendor: ['vue', 'vue-router', 'pinia'],
        // UI 라이브러리 분리
        ui: ['@ionic/vue'],
        // 유틸리티 분리
        utils: ['lodash', 'dayjs']
      }
    }
  }
}
```

#### 파일명 전략 변경

```typescript
build: {
  rollupOptions: {
    output: {
      // 해시가 포함된 파일명 (캐시 무효화)
      assetFileNames: 'assets/[name].[hash].[ext]',
      chunkFileNames: 'assets/[name].[hash].js',
      entryFileNames: 'assets/[name].[hash].js',
    }
  }
}
```

### 4. Legacy 브라우저 지원 조정

#### 타겟 브라우저 변경

```typescript
legacy({
  targets: [
    'defaults',
    'Android >= 5.0',    // Android 버전 조정
    'iOS >= 10',         // iOS 버전 조정
    'Chrome >= 60',      // 특정 브라우저 버전 지정
  ]
})
```

#### Polyfill 추가/제거

```typescript
legacy({
  additionalLegacyPolyfills: [
    'regenerator-runtime/runtime',
    'core-js/features/promise',     // Promise polyfill 추가
    'core-js/features/array/includes'  // Array.includes polyfill 추가
  ]
})
```

### 5. 개발 환경 최적화

#### HMR (Hot Module Replacement) 설정

```typescript
server: {
  hmr: {
    overlay: false,  // 오류 오버레이 비활성화
    clientPort: 8080 // HMR 포트 지정
  }
}
```

#### 소스맵 설정

```typescript
build: {
  sourcemap: 'hidden',  // 소스맵 숨김
  // sourcemap: true,   // 인라인 소스맵
  // sourcemap: false,  // 소스맵 비활성화
}
```

### 6. 경로 별칭 추가

#### 추가 별칭 설정

```typescript
resolve: {
  alias: {
    '@': path.resolve(__dirname, 'src'),
    '@components': path.resolve(__dirname, 'src/components'),
    '@views': path.resolve(__dirname, 'src/views'),
    '@stores': path.resolve(__dirname, 'src/stores'),
    '@utils': path.resolve(__dirname, 'src/shared/utils'),
    '@assets': path.resolve(__dirname, 'src/assets')
  }
}
```

### 7. CSS 처리 설정

#### CSS 모듈 활성화

```typescript
css: {
  modules: {
    localsConvention: 'camelCase',
    generateScopedName: '[name]__[local]___[hash:base64:5]'
  }
}
```

#### PostCSS 플러그인 추가

```typescript
css: {
  postcss: {
    plugins: [
      require('autoprefixer'),
      require('cssnano')
    ]
  }
}
```

### 8. 환경별 플러그인 설정

#### 개발/운영 환경별 플러그인

```typescript
plugins: [
  vue(),

  // 개발 환경에서만 활성화
  ...(mode === 'development' ? [vueDevTools()] : []),

  // 운영 환경에서만 활성화
  ...(mode === 'production' ? [
    // Bundle Analyzer
    // ESLint
  ] : []),

  htmlBaseUrlPlugin(),
  legacy({ /* ... */ }),
  vueI18n({ /* ... */ })
]
```

### 9. 성능 최적화 설정

#### 압축 설정

```typescript
build: {
  minify: 'terser',  // 또는 'esbuild'
  terserOptions: {
    compress: {
      drop_console: true,    // console.log 제거
      drop_debugger: true,   // debugger 제거
    }
  }
}
```

#### 번들 크기 분석

```typescript
import { visualizer } from 'rollup-plugin-visualizer';

plugins: [
  // 운영 빌드에서 번들 분석 리포트 생성
  ...(mode === 'production' ? [
    visualizer({
      filename: 'dist/stats.html',
      open: true
    })
  ] : [])
]
```

### 🎯 환경별 권장 설정

#### 개발 환경 (SIT)

- 소스맵 활성화
- Vue DevTools 활성화
- HMR 오버레이 활성화
- Console 로그 유지

#### 테스트 환경 (UAT)

- 소스맵 hidden 모드
- 운영과 동일한 빌드 설정
- 성능 테스트를 위한 최적화

#### 운영 환경 (PROD)

- 소스맵 비활성화
- Console 로그 제거
- 최대 압축 및 최적화
- 번들 크기 분석
