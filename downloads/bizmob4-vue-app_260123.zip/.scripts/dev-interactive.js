// .scripts/dev-interactive.js
import inquirer from 'inquirer';
import { spawn } from 'child_process';

// Windows 터미널 인코딩 문제 해결을 위한 설정
if (process.platform === 'win32') {
  if (process.stdout.setDefaultEncoding) {
    process.stdout.setDefaultEncoding('utf8');
  }
  if (process.stderr.setDefaultEncoding) {
    process.stderr.setDefaultEncoding('utf8');
  }
}

const questions = [
  {
    type: 'list',
    name: 'environment',
    message: 'Select development environment:',
    choices: [
      { name: 'SIT (Development)', value: 'sit' },
      { name: 'UAT (Staging)', value: 'uat' },
      { name: 'PROD (Production)', value: 'prod' }
    ]
  },
  {
    type: 'list',
    name: 'mode',
    message: 'Select execution mode:',
    choices: [
      {
        name: 'Development mode (for general development)',
        value: 'dev',
        short: 'Dev mode'
      },
      {
        name: 'Deploy mode (for production debugging)',
        value: 'deploy',
        short: 'Deploy mode'
      }
    ]
  },
  {
    type: 'confirm',
    name: 'openBrowser',
    message: 'Open browser automatically?',
    default: true,
    when: function (answers) {
      // 배포 모드일 때만 물어보기 (일반 개발에서는 기본적으로 열림)
      return answers.mode === 'deploy';
    }
  }
];

async function devInteractive() {
  try {
    // Windows에서 UTF-8 코드페이지 설정
    if (process.platform === 'win32') {
      try {
        await new Promise((resolve) => {
          const chcp = spawn('chcp', ['65001'], { shell: true, stdio: 'pipe' });
          chcp.on('close', resolve);
        });
      } catch {
        // chcp 실패해도 계속 진행
      }
    }

    console.log('\nBizMOB4 Development Server\n');

    const answers = await inquirer.prompt(questions);
    const { environment, mode } = answers;

    let command;
    if (mode === 'dev') {
      command = `dev-${environment}`;
    } else {
      command = `dev-${environment}:deploy`;
    }

    console.log(`\nExecuting: npm run ${command}`);

    if (mode === 'deploy') {
      console.log('Deploy mode: Running with production environment variables.');
      console.log('   -> Source optimization and production settings applied.');
      console.log('   -> Use this for debugging production-only issues.\n');
    } else {
      console.log('Development mode: Running with standard development environment.\n');
    }

    // npm run 명령 실행
    const child = spawn('npm', ['run', command], {
      stdio: 'inherit',
      shell: true
    });

    child.on('close', (code) => {
      if (code === 0) {
        console.log(`\n${environment.toUpperCase()} ${mode} server terminated successfully.`);
      } else {
        console.log(`\nServer execution failed (exit code: ${code})`);
      }
    });

  } catch (error) {
    console.error('Error occurred:', error);
  }
}

devInteractive();
