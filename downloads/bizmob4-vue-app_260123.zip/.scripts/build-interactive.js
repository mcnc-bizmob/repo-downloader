// .scripts/build-interactive.js
import inquirer from 'inquirer';
import { spawn } from 'child_process';

// Windows 터미널 인코딩 문제 해결을 위한 설정
if (process.platform === 'win32') {
  if (process.stdout.setDefaultEncoding) {
    process.stdout.setDefaultEncoding('utf8');
  }
  if (process.stderr.setDefaultEncoding) {
    process.stderr.setDefaultEncoding('utf8');
  }
}

const questions = [
  {
    type: 'list',
    name: 'environment',
    message: 'Select build environment:',
    choices: [
      { name: 'SIT (Development)', value: 'sit' },
      { name: 'UAT (Staging)', value: 'uat' },
      { name: 'PROD (Production)', value: 'prod' }
    ]
  },
  {
    type: 'list',
    name: 'buildType',
    message: 'Select build type:',
    choices: [
      { name: 'Minor - Lightweight update (fonts excluded, frequent deploy)', value: 'minor' },
      { name: 'Major - Full update (fonts included, major version release)', value: 'major' }
    ]
  }
];

async function buildInteractive() {
  try {
    // Windows에서 UTF-8 코드페이지 설정
    if (process.platform === 'win32') {
      try {
        await new Promise((resolve) => {
          const chcp = spawn('chcp', ['65001'], { shell: true, stdio: 'pipe' });
          chcp.on('close', resolve);
        });
      } catch {
        // chcp 실패해도 계속 진행
      }
    }

    console.log('\nBizMOB4 Build Tool\n');

    const answers = await inquirer.prompt(questions);
    const { environment, buildType } = answers;

    const command = `build-${environment}:${buildType}`;

    console.log(`\nExecuting: npm run ${command}\n`);

    // npm run 명령 실행
    const child = spawn('npm', ['run', command], {
      stdio: 'inherit',
      shell: true
    });

    child.on('close', (code) => {
      if (code === 0) {
        console.log(`\n${environment.toUpperCase()} ${buildType} build completed successfully!`);
      } else {
        console.log(`\nBuild failed (exit code: ${code})`);
      }
    });

  } catch (error) {
    console.error('Error occurred:', error);
  }
}

buildInteractive();
