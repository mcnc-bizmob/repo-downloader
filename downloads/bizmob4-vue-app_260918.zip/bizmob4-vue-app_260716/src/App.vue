<template>
  <ion-app>
    <!-- MenuTest.vue 파일에서 작성한 메뉴 테스트용 -->
    <!-- FIXME 프로젝트 환경에 맞춰서 변경 필요 -->
    <ion-menu menu-id="main-menu" content-id="ion-router-outlet" type="overlay" role="navigation" side="end"
      aria-label="메인 메뉴" :swipe-gesture="false">
      <MenuComponent />
    </ion-menu>

    <!-- Ion Router -->
    <ion-router-outlet id="ion-router-outlet" ref="routerOutlet" />
  </ion-app>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { IonApp, IonRouterOutlet, IonMenu } from '@ionic/vue';
import { Event, Device } from '@bizMOB';
import { useApp } from '@bizMOB/vue';

import MenuComponent from '@/views/tests/menu/MenuComponent.vue';

const { back } = useApp();

onMounted(async () => {
  // bizMOB App Ready Event
  Event.setEvent('ready', () => {
    console.log('App initialized');
    setFullScreen();
  });

  // bizMOB App BackButton Event
  Device.isApp() && Event.setEvent('backbutton', () => back());

 /**
  * 풀 스크린 설정
  * 단말기 최상단 상태바 까지 full screen으로 webview 영역을 잡은 후 
  * 상태바 영역에 컨텐츠가 겹치지 않도록 padding-top을 설정한다.
  */
function setFullScreen() {
  const isApp = Device.isApp();

  if (isApp) {

    const device = Device.getInfo();

    let safe_top = "0px";

    if (device.status_height) {
      if (window.innerWidth) {
        safe_top = Math.round(device.status_height / (device.screen_width / window.innerWidth)) + "px";
      } else {
        safe_top = device.status_height + "px";
      }
    }

    document.documentElement.style.setProperty("--safe-top", safe_top);
  }
}
});
</script>

<style lang="scss">
// ============================================================================
// ⏳ Loading 컴포넌트 스타일 샘플 -- scoped 없이 전역에 적용 필요
// ============================================================================
ion-loading {
  --background: transparent !important;
  --spinner-color: #062f87 !important;

  .loading-wrapper {
    box-shadow: none !important;
  }

  ion-backdrop {
    background: rgba(255, 255, 255, 0.7) !important;
  }

  ion-spinner {
    width: 50px;
    height: 50px;
  }
}

// ============================================================================
// 🍞 Toast 컴포넌트 스타일 샘플 -- scoped 없이 전역에 적용 필요
// ============================================================================
ion-toast {
  --border-radius: 15px;
  --background: rgba(32, 32, 32, 0.8);
  --color: #fff;
  --box-shadow: none;
  --start: 16px;
  --end: 16px;
  --ion-safe-area-bottom: calc(env(safe-area-inset-bottom) + 8px);

  &::part(message) {
    margin-top: -14px;
    margin-bottom: -14px;
    padding-top: 19px;
    padding-bottom: 18px;
    font-size: 16px;
    line-height: 19px;
    font-weight: 400;
    text-align: center;
  }
}

// ============================================================================
// 📱 Modal 시스템 스타일 샘플 -- scoped 없이 전역에 적용 필요
// ============================================================================

// 기본 Modal 스타일
ion-modal {
  --background: #fff;

  &::part(handle) {
    top: 12px;
    border-radius: 3.5px;
    width: 60px;
    height: 7px;
    background-color: #2f4592;
  }

  ion-footer {
    .button-group {
      .button {
        &-line {
          flex-basis: 130px;
          min-width: 130px;
        }
      }
    }
  }
}

// Sheet 스타일 (바텀 시트)
.ion-sheet-wrapper {
  --border-radius: 22px 22px 0 0;

  &.sheet-medium {
    --height: 60vh;
  }

  ion-content {
    &::part(scroll) {
      padding: 0 0;
    }
  }
}

// Modal 스타일 (일반 모달)
.ion-modal-wrapper {
  --border-radius: 20px;

  &.modal-medium {
    --height: 60vh;
  }

  &::part(content) {
    margin-left: 16px;
    margin-right: 16px;
  }

  ion-content {
    &::part(scroll) {
      padding: 12px 0 0;
    }
  }
}

// 전체화면 Modal 스타일
.ion-modal-fullscreen {
  --border-radius: 0;
  --width: 100%;
  --height: 100%;
  --max-width: none;
  --max-height: none;
  --top: 0;
  --left: 0;
  --right: 0;
  --bottom: 0;

  // 전체화면이므로 마진/패딩 제거
  &::part(content) {
    margin: 0;
    padding: 0;
  }

  // backdrop 제거 (전체화면이므로)
  &::part(backdrop) {
    display: none;
  }

  ion-content {
    &::part(scroll) {
      padding: 0;
    }
  }
}
</style>