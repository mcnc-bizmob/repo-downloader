/**
 * @namespace useAppLoading
 * @description
 * Ionic Loading 컴포저블
 *
 * **주요 기능:**
 * - Ionic loadingController 활용한 Loading 오버레이 표시/닫기
 * - useLoadingStore와 연동한 동시 요청 안전 처리
 * - 싱글톤 패턴으로 중복 Loading 인스턴스 방지
 * - Debounce 패턴으로 연속 호출 최적화 (100ms 지연)
 * - withLoading 래퍼를 통한 자동 Loading 상태 관리
 *
 * @returns {Object} Loading을 제어하는 API 객체
 * @property {function<T>(asyncFunction: () => Promise<T>, description?: string): Promise<T>} withLoading 비동기 함수 실행 중 자동 로딩 관리 (권장)
 * @property {Ref<boolean>} isLoading 현재 로딩 상태 (읽기 전용)
 * @property {Ref<number>} loadingCount 활성 로딩 작업 수 (읽기 전용)
 * @property {function(component?, type?, description?): string} start 로딩 시작 (수동 제어용)
 * @property {function(taskId: string): boolean} stop 로딩 중지 (수동 제어용)
 * @property {function(): void} stopAll 모든 로딩 중지 (수동 제어용)
 *
 * @remarks
 * **싱글톤 로딩 매니저:**
 * - 전역에서 하나의 Loading 인스턴스만 관리
 * - 첫 번째 useAppLoading() 호출 시 매니저 초기화
 * - watch를 통한 isLoading 상태 감시 및 UI 자동 제어
 *
 * @remarks
 * **Debounce 최적화:**
 * - 로딩 해제 시 100ms 지연 후 실제 dismiss 실행
 * - 연속 API 호출 시 깜빡임 현상 방지
 * - 타이머 중 새로운 로딩 요청 시 타이머 취소 및 인스턴스 재사용
 *
 * @remarks
 * **Store 연동:**
 * - useLoadingStore를 통한 로딩 작업 카운팅
 * - 동시 다발적 API 호출 시 안전한 상태 관리
 * - taskId 기반 개별 작업 추적 및 정리
 *
 * @example
 * <caption><b>withLoading 사용법 (권장)</b></caption>
 * ```typescript
 * import { useAppLoading } from '@bizMOB/vue';
 *
 * const { withLoading } = useAppLoading();
 *
 * // 1. 기본 사용법
 * const result = await withLoading(async () => {
 *   return await apiCall();
 * });
 *
 * // 2. 설명과 함께 사용
 * const userData = await withLoading(async () => {
 *   const response = await fetch('/api/user');
 *   return await response.json();
 * }, '사용자 정보 로딩 중...');
 *
 * // 3. 에러 처리
 * try {
 *   const result = await withLoading(async () => {
 *     return await riskyApiCall();
 *   }, '위험한 API 호출');
 * } catch (error) {
 *   console.error('API 호출 실패:', error);
 *   // 로딩은 자동으로 해제됨
 * }
 * ```
 *
 * @example
 * <caption><b>수동 제어 사용법</b></caption>
 * ```typescript
 * import { useAppLoading } from '@bizMOB/vue';
 *
 * const { start, stop, stopAll, isLoading, loadingCount } = useAppLoading();
 *
 * // 1. 수동 로딩 시작/중지
 * const taskId = start(null, 'api', '데이터 로딩 중...');
 * try {
 *   await someAsyncWork();
 * } finally {
 *   stop(taskId);
 * }
 *
 * // 2. 로딩 상태 감시
 * watch(isLoading, (loading) => {
 *   console.log('Loading state:', loading);
 * });
 *
 * // 3. 활성 작업 수 확인
 * console.log('Active loading tasks:', loadingCount.value);
 *
 * // 4. 모든 로딩 강제 중지 (비상시)
 * stopAll();
 * ```
 *
 * @example
 * <caption><b>동시 다발적 API 호출</b></caption>
 * ```typescript
 * import { useAppLoading } from '@bizMOB/vue';
 *
 * const { withLoading } = useAppLoading();
 *
 * // 여러 API를 동시에 호출해도 하나의 로딩만 표시됨
 * const [userData, profileData, settingsData] = await Promise.all([
 *   withLoading(() => fetchUser(), '사용자 정보'),
 *   withLoading(() => fetchProfile(), '프로필 정보'),
 *   withLoading(() => fetchSettings(), '설정 정보')
 * ]);
 *
 * // 모든 API가 완료될 때까지 로딩이 유지됨
 * console.log('모든 데이터 로딩 완료');
 * ```
 */

// src/bizMOB.vue/composables/useApp.loading.ts

import { watch } from 'vue';
import { loadingController, type LoadingOptions } from '@ionic/vue';
import { useLoadingStore } from '../stores/useLoadingStore';
import { storeToRefs } from 'pinia';

// ════════════════════════════════════════════════════════════
// 🎨 커스터마이즈 영역 — 프로젝트별로 자유롭게 수정하세요.
//    (아래 reconcile 코어 로직은 가급적 수정하지 마세요)
// ════════════════════════════════════════════════════════════

/** 로딩 오버레이 표시 옵션. spinner/message/cssClass/backdrop 등을 프로젝트에 맞게 변경. */
const LOADING_OPTIONS: LoadingOptions = {
  spinner: 'dots',
  backdropDismiss: false,
  duration: 0,
  // message: '로딩 중...',      // 필요 시 메시지 노출
  // cssClass: 'app-loading',    // 필요 시 커스텀 스타일 클래스
};

/** 로딩 해제 지연(ms). 연속 호출 시 깜빡임 방지. 0이면 즉시 해제. */
const DISMISS_DELAY = 100;

// ════════════════════════════════════════════════════════════
// ⚙️ reconcile 코어 — 동시/연속 호출 안전성 보장 (수정 주의)
//    목표 상태(isLoading)와 실제 오버레이를 항상 일치시킨다.
//    create()/present()/dismiss() 의 비동기 경합으로 오버레이가
//    멈추지 않도록, 매 await 사이마다 최신 상태를 재확인한다.
// ════════════════════════════════════════════════════════════

let isInitialized = false;
let loadingInstance: HTMLIonLoadingElement | null = null;
let dismissTimer: ReturnType<typeof setTimeout> | null = null;
let isReconciling = false; // reconcile 동시 실행 방지 락
let pending = false;        // 실행 중 들어온 재요청 표시

/**
 * 로딩 매니저를 초기화합니다 (한 번만 실행됨)
 */
function initializeLoadingManager() {
  if (isInitialized) return;

  const loadingStore = useLoadingStore();
  const { isLoading } = storeToRefs(loadingStore);

  // 실제 오버레이를 목표 상태(isLoading)에 맞춰 수렴시킨다.
  // - present() 직후 이미 로딩이 끝났으면 같은 루프에서 즉시 dismiss
  // - dismiss() 직후 다시 로딩이 필요하면 같은 루프에서 재present
  // - 실행 중 새 요청이 들어오면 pending 플래그로 루프를 한 번 더 돈다
  const reconcile = async () => {
    if (isReconciling) {
      pending = true;
      return;
    }
    isReconciling = true;

    try {
      pending = true;
      while (pending) {
        pending = false;
        const shouldShow = isLoading.value;

        if (shouldShow && !loadingInstance) {
          // 표시해야 하는데 인스턴스가 없음 → 생성 후 표시
          try {
            const inst = await loadingController.create(LOADING_OPTIONS);
            loadingInstance = inst;
            await inst.present();
          } catch (error) {
            console.error('❌ 로딩 표시에 실패했습니다.', error);
            loadingInstance = null;
          }
          pending = true; // present 후 상태 재확인 (이미 끝났으면 다음 루프에서 dismiss)
        } else if (!shouldShow && loadingInstance) {
          // 더 이상 표시할 필요 없는데 인스턴스가 있음 → 해제
          const inst = loadingInstance;
          loadingInstance = null;
          try {
            await inst.dismiss();
          } catch {
            /* 이미 닫힘 */
          }
          pending = true; // dismiss 후 상태 재확인 (다시 필요하면 다음 루프에서 present)
        }
      }
    } finally {
      isReconciling = false;
    }
  };

  // 로딩 상태가 변경될 때 reconcile 트리거 시점만 결정한다 - 한 번만 등록
  watch(isLoading, (newIsLoading) => {
    if (newIsLoading) {
      // 즉시 표시: 예약된 지연 해제가 있으면 취소
      if (dismissTimer) {
        clearTimeout(dismissTimer);
        dismissTimer = null;
      }
      void reconcile();
    } else if (DISMISS_DELAY > 0) {
      // 깜빡임 방지: 디바운스 후 해제 (그 사이 재요청되면 reconcile이 유지 판단)
      if (!dismissTimer) {
        dismissTimer = setTimeout(() => {
          dismissTimer = null;
          void reconcile();
        }, DISMISS_DELAY);
      }
    } else {
      // 디바운스 0이면 즉시 해제
      void reconcile();
    }
  }, { immediate: true }); // 즉시 실행으로 초기 상태 처리

  isInitialized = true;
}

// ========================================
// 메인 컴포저블 함수
// ========================================

/**
 * 프로그래매틱 방식으로 로딩 오버레이를 관리하는 컴포저블입니다.
 * useLoadingStore와 연동하여 동시 요청을 안전하게 처리합니다.
 */
export function useAppLoading() {
  // 로딩 매니저 초기화 (첫 번째 호출 시에만 실행됨)
  initializeLoadingManager();

  const loadingStore = useLoadingStore();
  const { isLoading, loadingCount } = storeToRefs(loadingStore);  /**
   * 비동기 함수를 실행하는 동안 자동으로 로딩 상태를 관리합니다. (가장 권장)
   * @param asyncFunction 실행할 비동기 함수
   * @param description 로딩 작업에 대한 설명 (디버깅용)
   */
  const withLoading = async <T>(
    asyncFunction: () => Promise<T>,
    description?: string
  ): Promise<T> => {
    const taskId = loadingStore.startLoading(null, 'api', description);
    console.log('🎯 withLoading started:', { taskId, description, activeCount: loadingCount.value });

    try {
      const result = await asyncFunction();
      console.log('✅ withLoading completed:', { taskId, description });
      return result;
    } catch (error) {
      console.error('❌ withLoading error:', { taskId, description, error });
      throw error;
    } finally {
      const stopped = loadingStore.stopLoading(taskId);
      console.log('🔄 withLoading cleanup:', { taskId, stopped, remainingCount: loadingCount.value });
    }
  };

  return {
    withLoading,
    isLoading,
    loadingCount,
    start: loadingStore.startLoading,
    stop: loadingStore.stopLoading,
    stopAll: loadingStore.stopAllLoading,
  };
}
