module.exports = {
    "env": {
        "browser": true,
        "commonjs": true,
        "es6": true
    },
    "extends": "eslint:recommended",
    "globals": {
        "JSON": "readonly",
        "jQuery": "readonly",
        "$": "readonly",
        "define": "readonly",
        "CryptoJS": "readonly",

        "bizMOB": "readonly",
        "bizMOBCore": "readonly",

        "__namespace": "readonly",
        "lt": "readonly",
        "DatetimePicker": "readonly",
        "Chart": "readonly",
        "Swiper": "readonly",
    },
    "parserOptions": {
        "ecmaVersion": 2018
    },
    // Coding Conventions
    "rules": {
    // 문단 마지막 세미콜론
        "semi": [ "error", "always" ],

        // 쌍따움표 사용
        "quotes": [ "error", "double" ],

        // Tab은 Space 4칸으로 정의
        "indent": [ "error", 4, { "SwitchCase": 1 } ],

        // Function과 소괄호 사이의 공백 X
        "space-before-function-paren": ["error", "never"],

        // {} 앞에는 공백
        "space-before-blocks": [ "error",  "always" ],

        // 조건/반복문/제어문에 중괄호 사용
        "curly": "error",

        // 콜론(:)을 사용하는 경우에는 반드시 뒤에 공백을 삽입한다.
        "key-spacing": ["error", {
            "afterColon": true
        }],

        // 특정 키워드의 경우 뒤에 공백을 삽입한다.
        "keyword-spacing": ["error", {
            "before": true,
            "after": true,
            "overrides": {
                "return": { "after": true },
                "throw": { "after": true },
                "case": { "after": true }
            }
        }],

        // comma는 뒤에 삽입
        "comma-style": ["error", "last"],

        // new 생성자 금지 (Object, Array, Function)
        "no-new-object": "error",
        "no-array-constructor": "error",
        "no-new-func": "error"
    },

    "ignorePatterns": [
        "*.html",
        "node_modules/",
        "bizMOB/",
        "libs/"
    ]
};