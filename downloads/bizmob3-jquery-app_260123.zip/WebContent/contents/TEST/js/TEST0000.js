/**
 * @author author
 * @pages [ TEST0000 ]
 * @title TEST0000
 */
var page = {
    init: function(event) {
        // 화면 레이아웃 관련 정의
        page.initLayout();

        // 이벤트 정의
        page.initInterface();

        // 초기 화면 데이터 설정
        page.initData(page.props);
    },

    // init layout
    initLayout: function() {
        console.log("initLayout");
    },

    // init interface
    initInterface: function() {
        console.log("initInterface");
    },

    // init data
    initData: function(props) {
        console.log("initData");
    }
};