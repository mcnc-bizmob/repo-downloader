/**
 * @author author
 * @title common module code
 */
var sample = {};


// Attach MyModule to the window object
window.sample = sample;