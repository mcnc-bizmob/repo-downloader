# mcnc-bizmob4-web-backend

## 개발 환경 
- Java : 17

## 배포 환경
- Database : Supabase (PostgreSQL 기반) 
  - 접속정보는 properties 파일 참고
- Deployment : Render (Web Service)
  - Web Service로 배포 (자동 빌드 & 배포 파이프라인 지원)
- Build Tool : Maven
- Version Control : GitHub


## Render에서 서비스 테스트
 1)New + → Web Service
 2)Runtime: Docker
 3)Repository: (Dockerfile 포함된 Git 리포지토리)
 4)Auto-Deploy 설정완료.


## Health Check
Health Check Path: /v1/health (GET)

## Environment Variables
SPRING_PROFILES_ACTIVE=dev
Render는 Dockerfile을 그대로 빌드. 별도 Build Command 입력 불필요(Docker 런타임 선택 시).


## Render 사용시 참고사항
포트 불일치: 앱이 8080만 듣고 PORT 무시 →  server.port=${PORT:8080} &  Render env 설정으로 해결
헬스체크 404/500: Actuator 미추가 or 경로 틀림 → /health 경로 확인


## 클라이언트 소스 반영 방법
	1. 담당자에게서 dist.zip 파일을 전달받는다.  
	2. dist.zip 압축을 푼다.  
	3. 압축 해제된 파일들을 프로젝트의 아래 경로에 복사한다.
		bizmob_web\src\main\resources\static
		 
## API 엔드포인트 규칙	 
	 - 공통 Prefix : /v1
	 - 형식 : /v1/{리소스명}/{행위} ex) GET /v1/users/{id} → 특정 사용자 상세 조회
	 	 - 향후 버전 업그레이드 시 /v2/…, /v3/… 형태로 확장


