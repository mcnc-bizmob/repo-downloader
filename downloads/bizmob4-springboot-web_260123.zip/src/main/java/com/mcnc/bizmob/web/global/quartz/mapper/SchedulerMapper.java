package com.mcnc.bizmob.web.global.quartz.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SchedulerMapper {
	public void callProcedure();
}
