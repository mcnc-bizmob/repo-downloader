package com.mcnc.bizmob.web.global.quartz.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mcnc.bizmob.web.global.quartz.mapper.SchedulerMapper;

@Service
public class SchedulerService {

    @Autowired
    private SchedulerMapper schedulerMapper;

    @Transactional
    public void resetSequence() {
        schedulerMapper.callProcedure();
    }
}
