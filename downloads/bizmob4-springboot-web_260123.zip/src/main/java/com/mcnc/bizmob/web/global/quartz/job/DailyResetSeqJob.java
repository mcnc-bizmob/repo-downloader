package com.mcnc.bizmob.web.global.quartz.job;


import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.UnableToInterruptJobException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.mcnc.bizmob.web.global.quartz.service.SchedulerService;

import lombok.extern.slf4j.Slf4j;

/**
 * @title 배치
 * @description APP에서 결제 할때 쓰는 시퀀스 리셋
 */
@Slf4j(topic="QUARTZ")
@Component
public class DailyResetSeqJob  extends QuartzJobBean implements InterruptableJob{

    @Autowired
    private SchedulerService schedulerService;
    
    @Value("${spring.profiles.active:dev}")
    private String profile;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		
		log.info("DailyResetSeqJob Execute !!");
		
	    if ("qa".equals(profile)) {
	        log.info("Dev profile ::: 배치 실행 안 함");
	        return;
	    }

		try {

			schedulerService.resetSequence();
            log.info("DailyResetSeqJob Success !!");
            
		}catch(Exception e) {
            log.error("DailyResetSeqJob Failed !!", e);
			throw new JobExecutionException(e);
		}

	}
	
	
	@Override
	public void interrupt() throws UnableToInterruptJobException {
		log.info("DailyResetSeqJob is Interrupted !!");
	}



	
}
