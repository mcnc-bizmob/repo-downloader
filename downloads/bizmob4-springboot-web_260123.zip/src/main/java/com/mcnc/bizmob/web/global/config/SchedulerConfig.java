package com.mcnc.bizmob.web.global.config;


import javax.annotation.PostConstruct;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.mcnc.bizmob.web.global.quartz.job.DailyResetSeqJob;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class SchedulerConfig {

	@Autowired private Scheduler scheduler;

	
	@PostConstruct
	public void init() {
		
		log.info("Quartz Job Initialization");
		
		JobDetail dailyResetSeqJob = JobBuilder.newJob(DailyResetSeqJob.class)
				.withIdentity(JobKey.jobKey(DailyResetSeqJob.class.getSimpleName())).build();
		
		
		try {
			scheduler.scheduleJob(dailyResetSeqJob, buildJobTrigger("0 0 4 * * ?")); // 매일 새벽 4시

			
		}catch(SchedulerException e) {
			log.error(e.getMessage(), e);
		}
	}
	
	public Trigger buildJobTrigger(String scheduleExp) {
		return (Trigger) TriggerBuilder.newTrigger().withSchedule(CronScheduleBuilder.cronSchedule(scheduleExp)).build();
	}
	
	
}
