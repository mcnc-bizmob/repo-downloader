package com.mcnc.bizmob.web.global.util.constants;

public class CommonConstant {
	public static final String Y_FLAG = "Y";
	public static final String N_FLAG = "N";
}
