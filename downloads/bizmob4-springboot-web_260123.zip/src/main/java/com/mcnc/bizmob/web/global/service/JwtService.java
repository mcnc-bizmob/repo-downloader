package com.mcnc.bizmob.web.global.service;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import javax.crypto.SecretKey;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
	// 데모용, 실제로는 환경변수/설정 분리 + 256bit 이상 권장
	private static final String SECRET = "ChangeThisToYourVeryLongSecretKey_AtLeast32Chars";
	private final SecretKey key =  Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));
	
	public String createAccessToken(String username, List<String> roles) {
        Instant now = Instant.now();
        return Jwts.builder()
                .subject(username)
                .claim("roles", roles)
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(15, ChronoUnit.MINUTES)))
                .signWith(key) //키 타입으로 알고리즘 추론
                .compact();
    }
	
	public Claims parse(String token) {
		// 0.12.x: parser() + verifyWith(key)
		return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
	}

}
