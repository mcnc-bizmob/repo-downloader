package com.mcnc.bizmob.web.global.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;

@Configuration
@OpenAPIDefinition(
        servers = {
                @Server(url = "https://localhost:8281/web", description = "[DEV] bizMOB web https server url"),
                @Server(url = "http://localhost:8281/web", description = "[LOCAL] bizMOB web http")
        }
)
public class SwaggerConfig {
	@Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .components(new Components())
                .info(apiInfo());
    }
 
    private Info apiInfo() {
        return new Info()
                .title("bizMOB Web")
                .description("Spring boot 2.7.18 + java 17 + maven + swagger 2 + bizmob client")
                .version("1.0.0")
                .contact(new Contact().name("mobile C&C").email("test@mcnc.co.kr"));
    }
}
