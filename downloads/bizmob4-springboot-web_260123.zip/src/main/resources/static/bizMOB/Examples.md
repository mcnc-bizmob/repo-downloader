<product>xross</product>
<language>javascript</language>
<Namespace>bizMOB</Namespace>

<class name="Device">
  <description>Front화면 개발시 Native 앱 또는 디바이스 정보를 제공하는 Class.디바이스/앱 정보는 bizMOB Native app에서 직접 이 Class내 프로퍼트로 저장합니다. 저장 시점은 3.x에서는 웹뷰 생성시마다 loading complete 또는 Resume 이벤트시에 저장되며 4.x에서는 SPA방식의 환경으로 loading complete 초기1회만 정보를 저장합니다.</description>
  <method name="isIOS">
    <description>실행환경이 iOS인지 아닌지 유무 내용을 제공</description>
    <request>parameter 없음.</request>
    <response>
      <type>boolean</type>
      <value>true or false</value>
    </response>
    <example>
      if( bizMOB.Device.isIOS() ){
        requestTr.bioType = "face";
        }else{
        requestTr.bioType = "finger";
      }
    </example>
  </method>
</class>

<class name="Network">
  <description>Front화면 개발시 Native 앱 또는 디바이스 정보를 제공하는 Class.디바이스/앱 정보는 bizMOB Native app에서 직접 이 Class내 프로퍼트로 저장합니다. 저장 시점은 3.x에서는 웹뷰 생성시마다 loading complete 또는 Resume 이벤트시에 저장되며 4.x에서는 SPA방식의 환경으로 loading complete 초기1회만 정보를 저장합니다.</description>
  <method name="requestTr">
  <description>bizMOB Server 전문 통신 기능</description>
  <response>
    <type>JSON</type>
    <value>호출한 전문의 body필드내 response data와 프로젝트에서 정의한 header필드의 json데이터</value>
  </response>
  <request>
    <parameter name="_sTrcode" type="string">bizMOB Server 전문 코드(TrCode)</parameter>
    <parameter name="_oHeader" type="Object" Optional>bizMOB Server 전문 호출시 설정할 header object. 별도로 추가할 필드가 있을때 주로 사용하고 기본값으로는 프로젝트에서 설정코드(TrCode)
      <property name="result" type="boolean">
        <value>true 또는 false. 서버통신 후 처리 성공 여부값</value>
      </property>
      <property name="error_code" type="string">
        <value>bizMOB Server통신시 실패일 경우 서버에서 전달하는 에러코드값. eg)CDR1100</value>
      </property>
      <property name="error_text" type="string">
        <value>bizMOB Server통신시 실패일 경우 서버에서 전달하는 에러메세지. eg)카드잔액부족</value>
      </property>
      <property name="info_text" type="string">
        <value>bizMOB Server통신 후 서버에서 보넬 추가 메세지</value>
      </property> 
      <property name="message_version" type="string">
        <value>bizMOB Server통신 프로토콜 버전</value>
      </property>
      <property name="login_session_id" type="string">
        <value>bizMOB Server통신시 요청한 세션 id. 서버에 생성된 session값이 자동으로 설정됨</value>
      </property> 
      <property name="trcode" type="string">
        <value>bizMOB Server 전문 코드(TrCode). xross Core에서 자동으로 설정.</value>
      </property>            
    </parameter>
    <parameter name="_oBody" type="Object" Optional>Server 전문 코드(TrCode). Service Builder에 정의된 전문 json구조에 맞게 값을 설정.</parameter>
    <parameter name="_bMock" type="boolean" Optional version="4.x">true 또는 false. 개발환경에서 Server에 전문이 개발되지 않아 Front에서 직접 호출이 불가능 할경우 mock data내 정의된 값을 return하여 Front에서 처리로직을 개발하고 싶을 경우 true로 설정하여 사용.</parameter>
    <parameter name="_bProgressEnable" Optional type="boolean">true 또는 false. bizMOB Server 통신시 Native app에서 프로그래스바를 표시할지 여부. 
      <case _bProgressEnable="true">기본값. 서버전문 요청시 Native App에서 Progress bar창을 보여준다..사용자가 두번터치하여 중복요청하는 경우를 방지하기 위해 기본값은 true로 설정되어 있다.</case>
      <case _bProgressEnable="false">Native App에서 Progress bar창을 보여주지 않는다. 백그라운드로 데이터를 받아 저장해야 할경우 같은 비동기 데이터 처리에 사용할 때 설정한다.</case>
    </parameter>
    <parameter name="_fCallback" type="function" version="3.x">bizMOB Server 통신 후 Front에서 response data를 받아처리할 callback 함수</parameter>
  </request>
  <example>
    bizMOB.Network.requestTr({
      "_sTrcode" : "DM0002",
      "_oHeader" : {"userGrade" : "chief"},
      "_oBody" : {
        "startIndex" : 0,
        "endIndex" : 9
      },
      "_fCallback" : function(resDM0002){
        bizMOB.logger.log(JSON.stringify(resDM0002));
      }
    });
  </example>
  </method>

</class>
