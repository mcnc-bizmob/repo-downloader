# CLAUDE.md

이 파일은 Claude Code (claude.ai/code)가 이 저장소에서 작업할 때 참고하는 가이드입니다.

## 프로젝트 개요

Vue 3 + Vite + TypeScript + Ionic Vue 기반의 BizMOB4 하이브리드 모바일 앱 베이스 템플릿. 구형 브라우저/WebView 호환을 위해 ES5 타겟 빌드 (Android 4.4+, iOS 9+).

## 명령어

```sh
# 개발 서버 (대화형 스크립트 권장)
npm run dev                 # 대화형 환경 선택기
npm run dev-sit             # SIT 환경
npm run dev-uat             # UAT 환경
npm run dev-prod            # PROD 환경

# 빌드 (대화형 스크립트 권장)
npm run build               # 대화형 빌드 선택기
npm run build-sit:major     # 전체 빌드 (fonts 포함)
npm run build-sit:minor     # 경량 빌드 (fonts 제외)

# 품질 검사
npm run type-check          # vue-tsc 타입 체크
npm run lint-check          # ESLint 검사
npm run lint                # ESLint 자동 수정
```

## 아키텍처

### 경로 별칭

- `@bizMOB/vue` → `src/bizMOB.vue` (Vue 컴포저블, 플러그인, 스토어)
- `@bizMOB` → `src/bizMOB` (네이티브 API 래퍼)
- `@` → `src`

### 핵심 구조

- **`src/bizMOB.vue/`** - Vue 전용 BizMOB 통합 레이어
  - `composables/useApp.ts` - 알림, 토스트, 모달, 로딩, 라우팅, 메뉴 등 통합 API
  - `plugins/` - Vue 플러그인 (ionic, bizmob, crypto-storage)
  - `stores/` - 앱 레벨 스토어 (useAppStore, useLoadingStore)
- **`src/bizMOB/`** - BizMOB 네이티브 API 래퍼
  - `Xross/` - 네이티브 API TypeScript 래퍼 (Network, Device, Storage 등)
  - `BzClass/` - 유틸리티 클래스 (BzCrypto, BzLocale, BzToken)
- **`src/locales/`** - 다국어 파일 (`locale.{언어코드}.ts` 형식, 자동 감지)
- **`src/stores/modules/`** - 비즈니스 도메인 스토어 (프로젝트별)
- **`src/router/`** - Ionic 라우팅 기반 Vue Router, 라우터 가드는 `guards/`

### 핵심 패턴

**통합 API - UI 인터랙션은 반드시 `useApp()` 사용:**
```typescript
import { useApp } from '@bizMOB/vue';
const { alert, confirm, toast, withLoading, push, openModal, openMenu } = useApp();

await alert('메시지');
const ok = await confirm('삭제하시겠습니까?');
await toast('저장되었습니다');
const result = await withLoading(() => apiCall(), '로딩 중...');
push('/route', { params: { id: '1' } });
```

**암호화 스토어 영속성:**
```typescript
import { cryptoLocalStorage } from '@bizMOB/vue';
// Pinia persist 옵션에서 사용
persist: { storage: cryptoLocalStorage }
```

**다국어(i18n) 사용:**
```vue
<template>{{ $t('message.key') }}</template>
<script setup>
const { t, changeLocale } = useApp();
const msg = t('message.key', { name: 'value' });
await changeLocale('en');
</script>
```

## 코드 스타일

- 작은따옴표(single quotes), 세미콜론 필수, 2칸 들여쓰기
- `@typescript-eslint/no-explicit-any`: off (any 타입 허용)
- `vue/multi-word-component-names`: off
- 프로덕션 빌드 시 console/debugger 사용에 대해 warn 표시

## 환경 설정

- `.env` - 공통 변수
- `.env.sit` / `.env.uat` / `.env.prod` - 환경별 설정
- 클라이언트에서 접근 가능한 변수는 반드시 `VITE_` 접두사 사용
- 주요 변수: `VITE_APPLICATION_KEY`, `VITE_SERVER_CONTEXT`, `BASE_URL`
