/// <reference types="vite/client" />

// src/types/pinia-persist.d.ts
import 'pinia';
import type { PersistedStateOptions } from 'pinia-plugin-persistedstate';

declare module 'pinia' {
  export interface DefineStoreOptionsBase<S, Store> {
    persist?: PersistedStateOptions | PersistedStateOptions[] | boolean
  }

  export interface DefineStoreOptions<Id extends string, S, G, A> extends DefineStoreOptionsBase<S, Store<Id, S, G, A>> {
    persist?: PersistedStateOptions | PersistedStateOptions[] | boolean
  }
}

interface ImportMetaEnv {
  readonly VITE_I18N_LOCALE?: string
  readonly VITE_I18N_FALLBACK_LOCALE?: string
  readonly VITE_APPLICATION_KEY?: string
  readonly VITE_SERVER_CONTEXT?: string
  readonly VITE_PROXY_CONTEXT?: string
  readonly VITE_PROXY?: string
  readonly VITE_WEB_ENCRYPTION_USE?: string
  readonly BASE_URL: string
  readonly MODE: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}

// Window 객체 확장
declare global {
  interface Window {
    forge: any;
  }
}
