import { defineConfig, loadEnv } from 'vite';
import vue from '@vitejs/plugin-vue';
import vueDevTools from 'vite-plugin-vue-devtools';
import legacy from '@vitejs/plugin-legacy';
import vueI18n from '@intlify/unplugin-vue-i18n/vite';
import path from 'path';

// Vite 설정을 반환하는 함수. 모드(mode: development, production)에 따라 .env 값 로드
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd());

  const publicDir = 'public';

  // 프록시 설정 핸들러 함수. API 요청에 대한 쿠키 주입 및 관리
  const proxyCookieHandler = () => {
    let cookie: any = undefined;

    const proxyOptions: any = {
      target: env.VITE_SERVER_URL,
      changeOrigin: true,
      secure: false,

      rewrite: (path: string) =>
        path.replace(
          new RegExp(`^${env.VITE_PROXY_CONTEXT}`),
          env.VITE_SERVER_CONTEXT || ''
        ),

      configure: (proxy: any) => {
        proxy.on('proxyReq', (proxyReq: any, req: any) => {
          const urlPath = req.url?.split('/').pop();
          if (urlPath !== 'BM4001.json' && cookie) {
            const existing = proxyReq.getHeader('cookie') ?? '';
            proxyReq.setHeader('cookie', `${existing}; ${cookie.join('; ')}`);
            console.log('[bizMOB] Cookie is set:', cookie);
          }
        });

        proxy.on('proxyRes', (proxyRes: any, req: any) => {
          const urlPath = req.url?.split('/').pop();
          const saveList = ['LOGIN.json', 'BM4001.json', 'BM4002.json'];
          const clearList = ['ZZ0007.json'];

          if (saveList.includes(urlPath || '')) {
            cookie = proxyRes.headers['set-cookie'];
            console.log('[bizMOB] Cookie is saved:', cookie);
          } else if (clearList.includes(urlPath || '')) {
            cookie = undefined;
            console.log('[bizMOB] Cookie is cleared.');
          }
        });
      }
    };

    return proxyOptions;
  };

  // HTML에서 BASE_URL 변수를 치환하는 커스텀 플러그인
  const htmlBaseUrlPlugin = () => ({
    name: 'html-base-url',
    transformIndexHtml: (html: string) => {
      const baseUrl = env.BASE_URL || '/';
      return html.replace(/<%= BASE_URL %>/g, baseUrl);
    }
  });

  return {
    // [빌드 대상 기준 경로] 기본 '/' → GitHub Pages 등의 서브 경로 배포 시 변경
    base: env.BASE_URL || '/',

    build: {
      // [출력 폴더] 기본 'dist' → VITE_BUILD_DIR에서 동적으로 지정 가능
      outDir: env.VITE_BUILD_DIR || 'dist',

      // [소스맵 생성 여부] 개발 모드에서만 활성화
      sourcemap: mode === 'development',

      rollupOptions: {
        output: {
          // [청크 분리] Webpack splitChunks(chunks: 'all')와 동일한 효과
          manualChunks: undefined,

          // [번들 파일명 설정] 해시 제거, 고정된 이름으로 파일 생성
          assetFileNames: 'assets/[name].[ext]',
          chunkFileNames: 'assets/[name].js',
          entryFileNames: 'assets/[name].js',
        }
      }
    },

    server: {
      // [로컬 서버 호스트] 외부 네트워크 접근 가능
      host: '0.0.0.0',

      // [포트 번호] 개발 서버 포트를 환경변수에서 로드 (기본값: 8080)
      port: parseInt(env.VITE_PORT) || 8080,

      // [API 프록시 설정] devServer.proxy 와 동일, 쿠키 주입까지 처리
      proxy: {
        [env.VITE_PROXY_CONTEXT]: proxyCookieHandler()
      }
    },

    css: {
      // [SCSS 소스맵] 개발 모드에서만 활성화
      devSourcemap: mode === 'development',
    },

    resolve: {
      // [경로 별칭] @ → /src -- 순서 중요함
      alias: {
        '@bizMOB/vue': path.resolve(__dirname, 'src/bizMOB.vue'),
        '@bizMOB': path.resolve(__dirname, 'src/bizMOB'),
        '@': path.resolve(__dirname, 'src')
      }
    },

    define: {
      // [Vue 전역 플래그] Vue2 옵션 API 활성화 여부
      __VUE_OPTIONS_API__: true,

      // [개발자 도구 지원] production 환경에서 devtools 비활성화
      __VUE_PROD_DEVTOOLS__: false,

      // [SSR mismatch 디버그 플래그] 오류 디테일 표시 여부
      __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: false
    },

    publicDir: publicDir, // 기본 public 폴더 활성화

    plugins: [
      vue(), // Vue SFC 지원

      vueDevTools(), // 개발 시 Vue Devtools 활성화

      // HTML에서 BASE_URL 동적 치환
      htmlBaseUrlPlugin(),

      legacy({
        // [ES5 대상 브라우저 설정] 모바일 WebView 등도 포함
        targets: [
          'defaults',
          'Android >= 4.4',
          'iOS >= 9',
          'not IE 11'
        ],
        // async/await 및 generator 대응
        additionalLegacyPolyfills: ['regenerator-runtime/runtime'],

        // 최신 브라우저에도 최소 polyfill 주입
        modernPolyfills: true
      }),

      vueI18n({
        // [i18n 디렉토리 위치] 다국어 리소스 자동 인식
        include: path.resolve(__dirname, './src/locales/**'),

        // Vue CLI 설정 대응 옵션
        runtimeOnly: false,
        compositionOnly: false,
        fullInstall: true
      })
    ]
  };
});
