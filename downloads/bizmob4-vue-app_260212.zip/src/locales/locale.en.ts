export default {
  message: {
    welcome: 'Welcome to bizMOB sample project',
    greeting: 'Hello',
    user: {
      welcome: 'Hello {name}',
      profile_greeting: 'This is {0}\'s profile'
    },
    loading: {
      full: 'Loading data. Please wait a moment.',
      short: 'Loading...'
    }
  },
  button: {
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm'
  },
  error: {
    network: 'Network error occurred',
    validation: 'Please check your input'
  }
};
