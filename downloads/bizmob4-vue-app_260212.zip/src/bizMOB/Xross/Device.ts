export default class Device {
  /** 단말기 정보 조회 */
  static getInfo(arg?: {
    _sKey: string // Device Info Key
  }) {
    return arg ? window.bizMOB.Device.getInfo(arg) : window.bizMOB.Device.getInfo();
  }

  /** 현재 환경이 App 환경인지 판별 */
  static isApp() {
    return window.bizMOB.Device.isApp();
  }

  /** 현재 환경이 Web 환경인지 판별 */
  static isWeb() {
    return window.bizMOB.Device.isWeb();
  }

  /** 현재 디바이스가 모바일 기기인지 판별 */
  static isMobile() {
    return window.bizMOB.Device.isMobile();
  }

  /** 현재 디바이스가 PC인지 판별 */
  static isPC() {
    return window.bizMOB.Device.isPC();
  }

  /** 현재 디바이스가 Android 기기인지 판별 */
  static isAndroid() {
    return window.bizMOB.Device.isAndroid();
  }

  /** 현재 디바이스가 iOS 기기인지 판별 */
  static isIOS() {
    return window.bizMOB.Device.isIOS();
  }

  /** 현재 디바이스가 태블릿인지 판별 */
  static isTablet() {
    return window.bizMOB.Device.isTablet();
  }

  /** 현재 디바이스가 스마트폰인지 판별 */
  static isPhone() {
    return window.bizMOB.Device.isPhone();
  }
}
