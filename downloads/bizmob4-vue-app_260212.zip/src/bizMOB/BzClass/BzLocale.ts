import Network from '../Xross/Network';
import Localization from '../Xross/Localization';

export default class BzLocale {
  public static async initLocale() {
    const res = await Localization.getLocale();

    if (res.locale !== '') {
      Network.changeLocale({ _sLocaleCd: res.locale });
      return res.locale; // 로케일 정보 반환
    }
    return null;
  }

  public static async getLocale() {
    return Localization.getLocale();
  }

  public static changeLocale(newLocaleCd: string) {
    Network.changeLocale({ _sLocaleCd: newLocaleCd });
    Localization.setLocale({ _sLocaleCd: newLocaleCd });
  }
}
