<!--
=== TestDashboard.vue ===
bizMOB.vue 컴포저블들의 테스트 화면 메인 대시보드

** 개발 가이드라인 (주니어 개발자용) **

1. 구조 설명:
  - Ionic의 기본 페이지 구조 (ion-page > ion-header > ion-content)
  - 각 컴포저블별 테스트 화면으로 이동하는 네비게이션 링크 제공
  - vue-router의 router-link를 사용한 페이지 이동

2. 스타일링 원칙:
  - Ionic 컴포넌트는 페이지 구조용으로만 사용 (ion-page, ion-header, ion-content, ion-footer)
  - 내부 콘텐츠는 순수 HTML 태그 사용
  - 최소한의 CSS로 깔끔한 UI 구성

3. 확장 방법:
  - 새로운 컴포저블 테스트 화면 추가 시:
    a) testItems 배열에 새 항목 추가
    b) 해당 테스트 화면 파일 생성
    c) router에 라우트 추가

4. 데이터 구조:
  - testItems: 각 테스트 화면의 정보를 담은 배열
  - id: 라우트 경로에 사용
  - title: 화면에 표시될 제목
  - description: 해당 컴포저블의 간단한 설명
  - route: vue-router 경로
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>bizMOB.vue 컴포저블 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="dashboard-container">
        <h1>테스트 대시보드</h1>
        <p class="description">
          테스트 결과는 개발자 도구 Console에서 확인
        </p>

        <!-- 테스트 화면 목록 -->
        <div class="test-grid">
          <div v-for="item in testItems" :key="item.id" class="test-card">
            <h3>{{ item.title }}</h3>
            <p>{{ item.description }}</p>
            <ion-button @click="navigateToTest(item.route)" class="test-button" fill="outline" expand="block">
              테스트 화면 이동 →
            </ion-button>
          </div>
        </div>

        <!-- 사용 안내 -->
        <div class="usage-guide">
          <h2>사용 방법</h2>
          <ol>
            <li>위의 카드에서 테스트하고 싶은 컴포저블을 선택하세요</li>
            <li>각 테스트 화면에서 버튼을 클릭하여 기능을 테스트하세요</li>
            <li>브라우저 개발자 도구(F12)의 Console 탭에서 결과를 확인하세요</li>
            <li>각 테스트 화면의 주석에서 추가 테스트 케이스를 확인하세요</li>
          </ol>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';

/*
=== 개발 참고사항 ===

1. Vue 3 Composition API 사용:
  - <script setup> 문법으로 간결한 코드 작성
  - ref, reactive 등 필요시에만 사용

2. 데이터 관리:
  - testItems 배열로 모든 테스트 화면 정보 중앙 관리
  - 새로운 테스트 화면 추가 시 이 배열만 수정하면 됨

3. 라우팅:
  - Ionic Router의 ionRouter.push() 사용
  - 각 테스트 화면으로의 프로그래밍적 네비게이션
*/

const { back, push } = useApp();

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

// 테스트 화면으로 이동하는 함수
const navigateToTest = (route: string) => {
  console.log(`%c🚀 테스트 화면 이동: ${route}`, 'color: blue; font-weight: bold;');
  push(route);
};

// 테스트 화면 목록 데이터
const testItems = [
  {
    id: 'appstore',
    title: 'App Store 테스트',
    description: 'Pinia 기반 통합 스토어 시스템 테스트 (메모리/로컬/세션/Properties)',
    route: '/tests/appstore'
  },
  {
    id: 'loading',
    title: 'Loading 테스트',
    description: '프로그래매틱 로딩 오버레이 관리 및 withLoading 패턴 테스트',
    route: '/tests/loading'
  },
  {
    id: 'router',
    title: 'Router 테스트',
    description: 'Ionic Router를 활용한 네비게이션 및 라우팅 기능 테스트',
    route: '/tests/router'
  },
  {
    id: 'backbutton',
    title: 'BackButton 테스트',
    description: '10단계 백버튼 처리 체인 및 핸들러 등록 시스템 테스트',
    route: '/tests/backbutton'
  },
  {
    id: 'menu',
    title: 'Menu 테스트',
    description: 'Ionic Menu를 활용한 사이드 메뉴 제어 기능 테스트',
    route: '/tests/menu'
  },
  {
    id: 'modal',
    title: 'Modal 테스트',
    description: 'Ionic Modal을 활용한 모달 다이얼로그 및 Sheet Modal 기능 테스트',
    route: '/tests/modal'
  },
  {
    id: 'popover',
    title: 'Popover 테스트',
    description: 'Select 최적화된 Ionic Popover 기능 및 Stack 관리 테스트',
    route: '/tests/popover'
  },
  {
    id: 'alert',
    title: 'Alert & Confirm 테스트',
    description: 'Ionic Alert를 활용한 알림/확인 다이얼로그 기능 테스트',
    route: '/tests/alert'
  },
  {
    id: 'actionsheet',
    title: 'ActionSheet 테스트',
    description: 'Ionic ActionSheet를 활용한 선택 메뉴 기능 테스트',
    route: '/tests/actionsheet'
  },
  {
    id: 'toast',
    title: 'Toast 테스트',
    description: 'Ionic Toast를 활용한 알림 메시지 표시 기능 테스트',
    route: '/tests/toast'
  },
];
</script>

<style scoped>
/*
=== 스타일링 가이드라인 ===

1. 최소한의 스타일링 원칙:
  - 기능 테스트에 집중, 불필요한 디자인 요소 배제
  - 가독성과 사용성 위주의 간단한 스타일

2. 반응형 고려:
  - 모바일과 데스크톱 모두에서 사용 가능
  - Grid 레이아웃으로 유연한 카드 배치

3. 확장성:
  - 새로운 테스트 카드 추가 시에도 자동으로 Grid에 배치
  - 일관된 카드 스타일 유지
*/

.dashboard-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.dashboard-container h1 {
  text-align: center;
  color: #333;
  margin-bottom: 10px;
}

.description {
  text-align: center;
  color: #666;
  margin-bottom: 40px;
  line-height: 1.6;
}

.test-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
}

.test-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  background: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.test-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.test-card h3 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 1.2em;
}

.test-card p {
  margin: 0 0 15px 0;
  color: #666;
  line-height: 1.5;
  font-size: 0.9em;
}

.test-button {
  --color: #007bff;
  --border-color: #007bff;
  --border-width: 2px;
  --border-radius: 8px;
  --padding-top: 12px;
  --padding-bottom: 12px;
  margin-top: 4px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.test-button:hover {
  --background: #007bff;
  --color: white;
}

.usage-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #007bff;
}

.usage-guide h2 {
  margin: 0 0 15px 0;
  color: #333;
}

.usage-guide ol {
  margin: 0;
  padding-left: 20px;
}

.usage-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>