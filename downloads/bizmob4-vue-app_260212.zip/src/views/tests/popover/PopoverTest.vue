<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>Popover 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <h2>🎯 Popover 기능 테스트</h2>
      <p>Select 최적화된 Popover 컴포저블을 테스트합니다.</p>

      <!-- 기본 Select Popover -->
      <div class="test-section">
        <h3>1. 기본 Select Popover</h3>
        <p>선택된 값: <strong>{{ selectedOption || '없음' }}</strong></p>
        <ion-button @click="openBasicSelect" expand="block">
          기본 Select 열기
        </ion-button>
      </div>

      <!-- 커스텀 위치 Popover -->
      <div class="test-section">
        <h3>2. 커스텀 위치 Popover</h3>
        <p>선택된 값: <strong>{{ selectedCustomOption || '없음' }}</strong></p>
        <ion-button @click="openCustomPositionSelect" expand="block">
          위쪽 Select 열기
        </ion-button>
      </div>

      <!-- 다중 선택 Popover -->
      <div class="test-section">
        <h3>3. 다중 선택 Popover</h3>
        <p>선택된 값들: <strong>{{ selectedMultiOptions.join(', ') || '없음' }}</strong></p>
        <ion-button @click="openMultiSelect" expand="block">
          다중 Select 열기
        </ion-button>
      </div>

      <!-- 로그 출력 -->
      <div class="test-section">
        <h3>4. 테스트 로그</h3>
        <ion-textarea v-model="logOutput" readonly :rows="8" placeholder="테스트 결과가 여기에 표시됩니다."></ion-textarea>
        <ion-button @click="clearLog" size="small" color="light">
          로그 지우기
        </ion-button>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButton,
  IonButtons, IonBackButton, IonTextarea
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';
import SelectOptions from './SelectOptions.vue';

const {
  openPopover,
  back
} = useApp();

// 상태 관리
const selectedOption = ref<string>('');
const selectedCustomOption = ref<string>('');
const selectedMultiOptions = ref<string[]>([]);
const logOutput = ref<string>('');

// 테스트용 옵션들
const basicOptions = [
  { value: 'option1', label: '옵션 1' },
  { value: 'option2', label: '옵션 2' },
  { value: 'option3', label: '옵션 3' },
  { value: 'option4', label: '옵션 4' },
];

const customOptions = [
  { value: 'custom1', label: '커스텀 1' },
  { value: 'custom2', label: '커스텀 2' },
  { value: 'custom3', label: '커스텀 3' },
];

const multiOptions = [
  { value: 'multi1', label: '다중 옵션 1' },
  { value: 'multi2', label: '다중 옵션 2' },
  { value: 'multi3', label: '다중 옵션 3' },
  { value: 'multi4', label: '다중 옵션 4' },
  { value: 'multi5', label: '다중 옵션 5' },
];

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

// 로그 출력 함수
const addLog = (message: string) => {
  const timestamp = new Date().toLocaleTimeString();
  logOutput.value += `[${timestamp}] ${message}\n`;
};

const clearLog = () => {
  logOutput.value = '';
};

// 1. 기본 Select Popover
const openBasicSelect = async (event: Event) => {
  try {
    addLog('기본 Select Popover 열기 시도...');

    const result = await openPopover(SelectOptions, {
      event, // event를 options에 포함
      props: {
        options: basicOptions,
        selected: selectedOption.value,
        title: '기본 옵션 선택'
      }
    });

    if (result.result) {
      selectedOption.value = result.data;
      addLog(`기본 Select 선택됨: ${result.data}`);
    } else {
      addLog('기본 Select 취소됨');
    }
  } catch (error) {
    addLog(`기본 Select 에러: ${error}`);
  }
};

// 2. 커스텀 위치 Select Popover
const openCustomPositionSelect = async (event: Event) => {
  try {
    addLog('커스텀 위치 Select Popover 열기 시도...');

    const result = await openPopover(SelectOptions, {
      event, // event를 options에 포함
      props: {
        options: customOptions,
        selected: selectedCustomOption.value,
        title: '커스텀 옵션 선택'
      },
      side: 'top', // 위쪽에 표시
      alignment: 'center', // 중앙 정렬
      size: 'auto', // 자동 크기
      cssClass: ['custom-select', 'large-options']
    });

    if (result.result) {
      selectedCustomOption.value = result.data;
      addLog(`커스텀 Select 선택됨: ${result.data}`);
    } else {
      addLog('커스텀 Select 취소됨');
    }
  } catch (error) {
    addLog(`커스텀 Select 에러: ${error}`);
  }
};

// 3. 다중 선택 Select Popover
const openMultiSelect = async (event: Event) => {
  try {
    addLog('다중 선택 Select Popover 열기 시도...');

    const result = await openPopover(SelectOptions, {
      event, // event를 options에 포함
      props: {
        options: multiOptions,
        selected: selectedMultiOptions.value,
        title: '다중 옵션 선택',
        multiple: true
      },
      dismissOnSelect: false, // 다중 선택시 자동 닫기 비활성화
      showBackdrop: true, // 다중 선택시 backdrop 표시
      cssClass: ['multi-select-popover']
    });

    if (result.result) {
      selectedMultiOptions.value = result.data || [];
      addLog(`다중 Select 선택됨: ${result.data?.join(', ')}`);
    } else {
      addLog('다중 Select 취소됨');
    }
  } catch (error) {
    addLog(`다중 Select 에러: ${error}`);
  }
};

// 초기화
onMounted(() => {
  addLog('PopoverTest 컴포넌트 초기화 완료');
});
</script>

<style scoped>
.test-section {
  margin-bottom: 2rem;
}

.test-section h3 {
  color: var(--ion-color-primary);
  margin-bottom: 0.5rem;
}

.test-section p {
  margin-bottom: 1rem;
  color: var(--ion-color-medium);
}

pre {
  background: var(--ion-color-light);
  padding: 0.5rem;
  border-radius: 4px;
  font-size: 0.8rem;
  overflow-x: auto;
}
</style>