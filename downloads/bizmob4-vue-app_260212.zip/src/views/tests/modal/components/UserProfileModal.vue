<!--
=== UserProfileModal.vue ===
사용자 프로필을 표시하는 Modal 컴포넌트

** 기능 **
- 사용자 정보 표시 (이름, 이메일, 전화번호, 부서)
- 프로필 편집 기능
- 사용자 액션 (메시지 보내기, 전화걸기 등)
-->

<template>
  <ion-header>
    <ion-toolbar>
      <ion-title>사용자 프로필</ion-title>
      <ion-buttons slot="end">
        <ion-button @click="closeModal" fill="clear">
          <ion-icon :icon="close"></ion-icon>
        </ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>

  <ion-content class="ion-padding">
    <div class="profile-content">
      <!-- 프로필 헤더 -->
      <div class="profile-header">
        <div class="avatar">
          <ion-icon :icon="person" size="large"></ion-icon>
        </div>
        <div class="basic-info">
          <h2 class="user-name">{{ user.name }}</h2>
          <p class="user-department">{{ user.department }}</p>
        </div>
      </div>

      <!-- 연락처 정보 -->
      <div class="contact-section">
        <h3>연락처 정보</h3>

        <div class="contact-item">
          <ion-icon :icon="mail" color="primary"></ion-icon>
          <div class="contact-info">
            <span class="label">이메일</span>
            <span class="value">{{ user.email }}</span>
          </div>
          <ion-button @click="sendEmail" fill="clear" size="small">
            <ion-icon :icon="send"></ion-icon>
          </ion-button>
        </div>

        <div class="contact-item">
          <ion-icon :icon="call" color="primary"></ion-icon>
          <div class="contact-info">
            <span class="label">전화번호</span>
            <span class="value">{{ user.phone }}</span>
          </div>
          <ion-button @click="makeCall" fill="clear" size="small">
            <ion-icon :icon="call"></ion-icon>
          </ion-button>
        </div>
      </div>

      <!-- 액션 섹션 -->
      <div class="action-section">
        <h3>액션</h3>

        <div class="action-buttons">
          <ion-button @click="editProfile" expand="block" color="primary">
            <ion-icon :icon="create" slot="start"></ion-icon>
            프로필 편집
          </ion-button>

          <ion-button @click="sendMessage" expand="block" fill="outline" color="secondary">
            <ion-icon :icon="chatbubble" slot="start"></ion-icon>
            메시지 보내기
          </ion-button>

          <ion-button @click="addToFavorites" expand="block" fill="outline" color="tertiary">
            <ion-icon :icon="star" slot="start"></ion-icon>
            즐겨찾기 추가
          </ion-button>
        </div>
      </div>

      <!-- 하단 버튼 -->
      <div class="bottom-actions">
        <ion-button @click="saveProfile" color="success">
          저장
        </ion-button>
        <ion-button @click="cancelModal" fill="outline" color="medium">
          취소
        </ion-button>
      </div>
    </div>
  </ion-content>
</template>

<script setup lang="ts">
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonButton,
  IonIcon,
  IonContent,
  modalController,
  alertController,
  toastController
} from '@ionic/vue';
import {
  close,
  person,
  mail,
  call,
  send,
  create,
  chatbubble,
  star
} from 'ionicons/icons';

interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  department: string;
}

interface Props {
  user: User;
}

const props = defineProps<Props>();

// Modal 닫기
const closeModal = () => {
  modalController.dismiss(null, 'close');
};

// 이메일 보내기
const sendEmail = async () => {
  console.log('%c📧 이메일 보내기:', 'color: blue; font-weight: bold;', props.user.email);

  const toast = await toastController.create({
    message: `${props.user.email}로 이메일을 보냅니다.`,
    duration: 2000,
    position: 'bottom',
    color: 'primary'
  });

  await toast.present();
};

// 전화걸기
const makeCall = async () => {
  console.log('%c📞 전화걸기:', 'color: blue; font-weight: bold;', props.user.phone);

  const toast = await toastController.create({
    message: `${props.user.phone}로 전화를 겁니다.`,
    duration: 2000,
    position: 'bottom',
    color: 'success'
  });

  await toast.present();
};

// 프로필 편집
const editProfile = async () => {
  console.log('%c✏️ 프로필 편집:', 'color: blue; font-weight: bold;', props.user);

  const alert = await alertController.create({
    header: '프로필 편집',
    message: '프로필 편집 기능은 개발 중입니다.',
    buttons: ['확인']
  });

  await alert.present();
};

// 메시지 보내기
const sendMessage = async () => {
  console.log('%c💬 메시지 보내기:', 'color: blue; font-weight: bold;', props.user.name);

  const toast = await toastController.create({
    message: `${props.user.name}에게 메시지를 보냅니다.`,
    duration: 2000,
    position: 'bottom',
    color: 'secondary'
  });

  await toast.present();
};

// 즐겨찾기 추가
const addToFavorites = async () => {
  console.log('%c⭐ 즐겨찾기 추가:', 'color: blue; font-weight: bold;', props.user.name);

  const toast = await toastController.create({
    message: `${props.user.name}을 즐겨찾기에 추가했습니다.`,
    duration: 2000,
    position: 'bottom',
    color: 'warning'
  });

  await toast.present();
};

// 프로필 저장
const saveProfile = () => {
  const result = {
    action: 'save',
    user: props.user,
    timestamp: Date.now()
  };

  console.log('%c💾 프로필 저장:', 'color: green; font-weight: bold;', result);
  modalController.dismiss(result, 'save');
};

// Modal 취소
const cancelModal = () => {
  const result = {
    action: 'cancel',
    timestamp: Date.now()
  };

  console.log('%c❌ 프로필 Modal 취소:', 'color: red; font-weight: bold;', result);
  modalController.dismiss(result, 'cancel');
};
</script>

<style scoped lang="scss">
// ============================================================================
// 프로필 Modal 스타일
// ============================================================================
.profile-content {
  display: flex;
  flex-direction: column;
  gap: 24px;
  min-height: 400px;
}

// 프로필 헤더
.profile-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  color: white;

  .avatar {
    width: 60px;
    height: 60px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid rgba(255, 255, 255, 0.3);

    ion-icon {
      --color: white;
    }
  }

  .basic-info {
    flex: 1;

    .user-name {
      margin: 0 0 4px 0;
      font-size: 24px;
      font-weight: 600;
    }

    .user-department {
      margin: 0;
      font-size: 14px;
      opacity: 0.9;
    }
  }
}

// 연락처 섹션
.contact-section {
  h3 {
    margin: 0 0 16px 0;
    color: #333;
    font-size: 18px;
    font-weight: 600;
  }
}

.contact-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;

  &:last-child {
    border-bottom: none;
  }

  ion-icon {
    width: 24px;
    height: 24px;
  }

  .contact-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 2px;

    .label {
      font-size: 12px;
      color: #666;
      font-weight: 500;
    }

    .value {
      font-size: 14px;
      color: #333;
    }
  }
}

// 액션 섹션
.action-section {
  h3 {
    margin: 0 0 16px 0;
    color: #333;
    font-size: 18px;
    font-weight: 600;
  }
}

.action-buttons {
  display: flex;
  flex-direction: column;
  gap: 12px;

  ion-button {
    --padding-start: 16px;
    --padding-end: 16px;
    --border-radius: 8px;
    text-transform: none;
    font-weight: 500;
  }
}

// 하단 액션
.bottom-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  margin-top: auto;
  padding-top: 20px;
  border-top: 1px solid #f0f0f0;

  ion-button {
    --padding-start: 24px;
    --padding-end: 24px;
    --border-radius: 6px;
    font-weight: 500;
  }
}

// 반응형 디자인
@media (max-width: 600px) {
  .profile-header {
    padding: 16px;

    .basic-info .user-name {
      font-size: 20px;
    }
  }

  .bottom-actions {
    flex-direction: column;

    ion-button {
      width: 100%;
    }
  }

  .action-buttons ion-button {
    --padding-top: 12px;
    --padding-bottom: 12px;
  }
}
</style>
