<!--
=== ModalTest.vue ===
useApp.modal 컴포저블의 주요 기능 테스트 화면

** 테스트 범위 **
- 실제 구현: openModal, closeModal
- Modal 타입: 기본 Modal, Sheet Modal
- Modal 내부 컴포넌트: UserProfileModal, SettingsModal, SimpleModal
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>Modal 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">

        <h1>Modal 기능 테스트</h1>
        <p class="test-description">
          브라우저 개발자 도구의 Console에서 테스트 결과를 확인하세요.
        </p>

        <!-- 기본 Modal 테스트 -->
        <div class="test-section">
          <h2>기본 Modal 테스트</h2>

          <div class="button-group">
            <button @click="testBasicModal" class="test-button">
              기본 Modal 열기
            </button>

            <button @click="testUserProfileModal" class="test-button">
              사용자 프로필 Modal
            </button>

            <button @click="testSettingsModal" class="test-button">
              설정 Modal
            </button>

            <button @click="testNestedModal" class="test-button">
              중첩 Modal 테스트
            </button>
          </div>
        </div>

        <!-- Sheet Modal 테스트 -->
        <div class="test-section">
          <h2>Sheet Modal 테스트</h2>

          <div class="button-group">
            <button @click="testBasicSheet" class="test-button">
              기본 Sheet Modal
            </button>

            <button @click="testCustomSheet" class="test-button">
              커스텀 Sheet Modal
            </button>

            <button @click="testFullHeightSheet" class="test-button">
              전체 높이 Sheet
            </button>
          </div>
        </div>

        <!-- Modal 설정 테스트 -->
        <div class="test-section">
          <h2>Modal 관리 테스트</h2>

          <div class="button-group">
            <button @click="testCloseCurrentModal" class="test-button">
              현재 Modal 닫기
            </button>
          </div>
        </div>

        <!-- 고급 테스트 -->
        <div class="test-section">
          <h2>고급 기능 테스트</h2>

          <div class="button-group">
            <button @click="testModalWithProps" class="test-button">
              Props 전달 Modal
            </button>

            <button @click="testModalWithResult" class="test-button">
              결과 반환 Modal
            </button>

            <button @click="testCustomCssModal" class="test-button">
              커스텀 CSS Modal
            </button>
          </div>
        </div>

        <!-- 테스트 안내 -->
        <div class="test-guide">
          <h3>테스트 방법</h3>
          <ul>
            <li>각 버튼을 클릭하여 해당 Modal 기능을 테스트하세요</li>
            <li>Modal이 열린 후 다양한 방법으로 닫아보세요</li>
            <li>Console에서 결과 로그를 확인하세요</li>
            <li>중첩 Modal과 Sheet Modal의 동작을 확인하세요</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';

// Modal 내부에서 사용할 컴포넌트들 import
import SimpleModal from './components/SimpleModal.vue';
import UserProfileModal from './components/UserProfileModal.vue';
import SettingsModal from './components/SettingsModal.vue';

// bizMOB.vue 통합 API에서 Modal 기능들 가져오기
const {
  openModal,
  closeModal,
  back
} = useApp();

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

/*
=== 기본 Modal 테스트 ===
*/

// 1. 기본 Modal 테스트
const testBasicModal = async () => {
  console.log('%c📋 기본 Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(SimpleModal, {
      props: {
        title: '기본 Modal',
        message: '이것은 기본 Modal입니다.'
      }
    });

    console.log('%c✅ 기본 Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 기본 Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 2. 사용자 프로필 Modal 테스트
const testUserProfileModal = async () => {
  console.log('%c📋 사용자 프로필 Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(UserProfileModal, {
      props: {
        user: {
          id: 1,
          name: '홍길동',
          email: 'hong@example.com',
          phone: '010-1234-5678',
          department: '개발팀'
        }
      },
      cssClass: ['user-profile-modal']
    });

    console.log('%c✅ 사용자 프로필 Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 사용자 프로필 Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 3. 설정 Modal 테스트
const testSettingsModal = async () => {
  console.log('%c📋 설정 Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(SettingsModal, {
      props: {
        currentSettings: {
          theme: 'dark',
          notifications: true,
          autoSave: false
        }
      },
      backdropDismiss: false
    });

    console.log('%c✅ 설정 Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 설정 Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 4. 중첩 Modal 테스트
const testNestedModal = async () => {
  console.log('%c📋 중첩 Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    // 첫 번째 Modal 열기
    const firstResult = await openModal(SimpleModal, {
      props: {
        title: '첫 번째 Modal',
        message: '이 Modal에서 또 다른 Modal을 열어보세요.'
      }
    });

    console.log('%c✅ 중첩 Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 첫 번째 Modal 결과:', 'color: purple; font-weight: bold;', firstResult);
  } catch (error) {
    console.log('%c❌ 중첩 Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== Sheet Modal 테스트 ===
*/

// 5. 기본 Sheet Modal 테스트
const testBasicSheet = async () => {
  console.log('%c📋 기본 Sheet Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(SimpleModal, {
      props: {
        title: 'Sheet Modal',
        message: '이것은 기본 Sheet Modal입니다.'
      }
    }, 'sheet');

    console.log('%c✅ 기본 Sheet Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 기본 Sheet Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 6. 커스텀 Sheet Modal 테스트
const testCustomSheet = async () => {
  console.log('%c📋 커스텀 Sheet Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(UserProfileModal, {
      props: {
        user: {
          id: 2,
          name: '김철수',
          email: 'kim@example.com',
          phone: '010-9876-5432',
          department: '디자인팀'
        }
      },
      initialBreakpoint: 0.8,
      breakpoints: [0.3, 0.5, 0.8, 1],
      showHandle: true
    }, 'sheet');

    console.log('%c✅ 커스텀 Sheet Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 커스텀 Sheet Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 7. 전체 높이 Sheet 테스트
const testFullHeightSheet = async () => {
  console.log('%c📋 전체 높이 Sheet Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(SettingsModal, {
      props: {
        currentSettings: {
          theme: 'light',
          notifications: false,
          autoSave: true
        }
      },
      initialBreakpoint: 1,
      breakpoints: [0, 1],
      showHandle: false
    }, 'sheet');

    console.log('%c✅ 전체 높이 Sheet Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 전체 높이 Sheet Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== Modal 관리 테스트 ===
*/

// 8. 현재 Modal 닫기 테스트
const testCloseCurrentModal = async () => {
  console.log('%c📋 현재 Modal 닫기 테스트', 'color: blue; font-weight: bold;');

  try {
    // 먼저 Modal을 열고
    const modalPromise = openModal(SimpleModal, {
      props: {
        title: '자동으로 닫힐 Modal',
        message: '3초 후에 자동으로 닫힙니다.'
      }
    });

    // 3초 후에 닫기
    setTimeout(() => {
      closeModal(true, { reason: 'auto_close', timestamp: Date.now() });
    }, 3000);

    const result = await modalPromise;

    console.log('%c✅ 현재 Modal 닫기 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 현재 Modal 닫기 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== 고급 기능 테스트 ===
*/

// 8. Props 전달 Modal 테스트
const testModalWithProps = async () => {
  console.log('%c📋 Props 전달 Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const complexData = {
      list: ['항목1', '항목2', '항목3'],
      config: { mode: 'test', debug: true },
      callback: (data: any) => console.log('Callback 호출:', data)
    };

    const result = await openModal(SimpleModal, {
      props: {
        title: 'Props 테스트',
        message: '복잡한 데이터가 전달되었습니다.',
        data: complexData
      }
    });

    console.log('%c✅ Props 전달 Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ Props 전달 Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 9. 결과 반환 Modal 테스트
const testModalWithResult = async () => {
  console.log('%c📋 결과 반환 Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(SettingsModal, {
      props: {
        currentSettings: {
          theme: 'auto',
          notifications: true,
          autoSave: true
        }
      }
    });

    if (result.result) {
      console.log('%c✅ 결과 반환 Modal 테스트 성공', 'color: green; font-weight: bold;');
      console.log('%c📊 반환된 데이터:', 'color: purple; font-weight: bold;', result.data);
    } else {
      console.log('%c⚠️ Modal이 취소되었습니다', 'color: orange; font-weight: bold;');
    }
  } catch (error) {
    console.log('%c❌ 결과 반환 Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 10. 커스텀 CSS Modal 테스트
const testCustomCssModal = async () => {
  console.log('%c📋 커스텀 CSS Modal 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openModal(SimpleModal, {
      props: {
        title: '커스텀 스타일 Modal',
        message: '이 Modal은 커스텀 CSS가 적용되었습니다.'
      },
      cssClass: ['custom-modal', 'large-modal', 'rounded-modal'],
      showBackdrop: true,
      backdropDismiss: true
    });

    console.log('%c✅ 커스텀 CSS Modal 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', result);
  } catch (error) {
    console.log('%c❌ 커스텀 CSS Modal 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};
</script>

<style scoped lang="scss">
// ============================================================================
// 화면 스타일
// ============================================================================
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.back-link {
  margin-bottom: 20px;
}

.back-button {
  --color: #007bff;
  --padding-start: 0;
  --padding-end: 0;
  margin: 0;
  font-weight: 500;
  text-decoration: none;
}

.back-button:hover {
  --color: #0056b3;
  text-decoration: underline;
}

.test-container h1 {
  color: #333;
  margin-bottom: 10px;
}

.test-description {
  color: #666;
  margin-bottom: 30px;
  font-style: italic;
}

.test-section {
  margin-bottom: 30px;
}

.test-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #007bff;
  padding-bottom: 5px;
}

.button-group {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
}

.test-button {
  padding: 12px 20px;
  background: #28a745;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.test-button:hover {
  background: #218838;
}

.test-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
}

.test-guide h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.test-guide ul {
  margin: 0;
  padding-left: 20px;
}

.test-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>