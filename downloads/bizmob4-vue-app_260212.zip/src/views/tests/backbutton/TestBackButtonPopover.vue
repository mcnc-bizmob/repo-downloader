<!--
=== TestBackButtonPopover.vue ===
백버튼 테스트용 Popover 컴포넌트

** 기능 **
- Popover 내에서 백버튼 핸들러 등록/해제
- 선택 상태 시뮬레이션
- 백버튼 시 선택 상태 저장 후 닫기
-->

<template>
  <ion-content class="ion-padding">
    <div class="popover-content">
      <h3>{{ title }}</h3>

      <div class="selection-section">
        <h4>옵션 선택</h4>
        <ion-radio-group v-model="selectedOption" @ionChange="onSelectionChange">
          <ion-item v-for="option in options" :key="option">
            <ion-label>{{ option }}</ion-label>
            <ion-radio slot="start" :value="option"></ion-radio>
          </ion-item>
        </ion-radio-group>

        <div class="status-info">
          <p><strong>선택된 옵션:</strong> {{ selectedOption || '없음' }}</p>
          <p><strong>변경사항:</strong> {{ hasSelectionChanged ? '있음' : '없음' }}</p>
          <p><strong>Popover 핸들러:</strong> {{ handlerActive ? '활성' : '비활성' }}</p>
        </div>
      </div>

      <div class="button-section">
        <ion-button @click="enablePopoverHandler" expand="block" fill="outline" size="small">
          Popover 백버튼 핸들러 활성화
        </ion-button>

        <ion-button @click="disablePopoverHandler" expand="block" fill="outline" size="small">
          Popover 백버튼 핸들러 비활성화
        </ion-button>

        <ion-button @click="confirmSelection" expand="block" fill="solid" color="primary" size="small">
          선택 확인
        </ion-button>

        <ion-button @click="closePopover(false)" expand="block" fill="outline" color="medium" size="small">
          취소
        </ion-button>
      </div>

      <div class="test-guide">
        <h5>🔍 테스트 방법</h5>
        <ol>
          <li>옵션을 선택하여 변경사항을 만드세요</li>
          <li>"Popover 백버튼 핸들러 활성화" 버튼을 클릭하세요</li>
          <li>브라우저의 뒤로가기 버튼을 누르세요</li>
          <li>선택 상태가 자동으로 저장되고 Popover가 닫힙니다</li>
        </ol>
      </div>
    </div>
  </ion-content>
</template>

<script setup lang="ts">
import {
  IonContent,
  IonItem,
  IonLabel,
  IonRadio,
  IonRadioGroup,
  IonButton,
  popoverController
} from '@ionic/vue';
import { ref, onMounted } from 'vue';
import { useApp } from '@bizMOB/vue';

// Props 정의
interface Props {
  title?: string;
  options?: string[];
}

const props = withDefaults(defineProps<Props>(), {
  title: '테스트 Popover',
  options: () => ['옵션 1', '옵션 2', '옵션 3']
});

// useApp에서 필요한 기능들 가져오기
const { onPopoverBack, closePopover, offBack, confirm, alert } = useApp();

// 상태 관리
const selectedOption = ref('');
const hasSelectionChanged = ref(false);
const handlerActive = ref(false);
const initialSelection = ref('');

// 선택 변경 처리
const onSelectionChange = () => {
  hasSelectionChanged.value = selectedOption.value !== initialSelection.value;
  console.log(`%c📝 Popover 선택 변경: ${selectedOption.value}`, 'color: purple;');
  console.log(`%c📝 변경사항: ${hasSelectionChanged.value ? '있음' : '없음'}`, 'color: purple;');
};

// Popover 백버튼 핸들러 활성화
const enablePopoverHandler = () => {
  console.log('%c🎯 Popover 백버튼 핸들러 등록', 'color: blue; font-weight: bold;');

  onPopoverBack(async () => {
    console.log('%c📱 Popover 백버튼 핸들러 실행됨', 'color: green; font-weight: bold;');

    if (hasSelectionChanged.value) {
      const confirmed = await confirm('저장 후 나가시겠습니까?');

      if (confirmed) {
        await saveSelectionState();
      }

      return confirmed;
    }
    else {
      await alert('변경사항이 없습니다.');
      return true;
    }
  });

  handlerActive.value = true;
  console.log('%c✅ Popover 핸들러 등록 완료', 'color: green;');
};

// Popover 백버튼 핸들러 비활성화
const disablePopoverHandler = () => {
  console.log('%c🎯 Popover 백버튼 핸들러 해제', 'color: blue; font-weight: bold;');

  offBack('popover');
  handlerActive.value = false;

  console.log('%c✅ Popover 핸들러 해제 완료', 'color: green;');
};

// 선택 상태 저장 (시뮬레이션)
const saveSelectionState = async () => {
  console.log('%c💾 선택 상태 저장 중...', 'color: green;');
  // 실제로는 여기서 API 호출이나 상태 저장을 수행
  await new Promise(resolve => setTimeout(resolve, 100));
  initialSelection.value = selectedOption.value;
  hasSelectionChanged.value = false;
  console.log('%c✅ 선택 상태 저장 완료', 'color: green;');
};

// 선택 확인
const confirmSelection = async () => {
  console.log('%c✅ 선택 확인:', 'color: green;', selectedOption.value);
  await saveSelectionState();
  closePopover(true, selectedOption.value);
};

// 컴포넌트 마운트 시 초기화
onMounted(() => {
  console.log('%c🚀 TestBackButtonPopover 마운트됨', 'color: blue; font-weight: bold;');
  console.log('%c💡 이 Popover에서 백버튼 핸들러 테스트를 진행해보세요', 'color: orange;');

  enablePopoverHandler();
});
</script>

<style scoped>
.popover-content {
  max-width: 300px;
  padding: 10px;
}

.popover-content h3 {
  margin: 0 0 15px 0;
  color: #333;
  font-size: 1.1em;
  text-align: center;
}

.selection-section {
  margin-bottom: 15px;
}

.selection-section h4 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 1em;
}

.status-info {
  margin-top: 10px;
  padding: 10px;
  background: #f8f9fa;
  border-radius: 6px;
  border-left: 3px solid #007bff;
}

.status-info p {
  margin: 3px 0;
  font-size: 0.8em;
  color: #666;
}

.button-section {
  margin: 15px 0 10px 0;
}

.button-section ion-button {
  margin: 3px 0;
}

.test-guide {
  background: #d1ecf1;
  padding: 10px;
  border-radius: 6px;
  border-left: 3px solid #17a2b8;
  margin-top: 10px;
}

.test-guide h5 {
  margin: 0 0 8px 0;
  color: #333;
  font-size: 0.9em;
}

.test-guide ol {
  margin: 0;
  padding-left: 15px;
}

.test-guide li {
  margin-bottom: 4px;
  line-height: 1.3;
  font-size: 0.8em;
  color: #555;
}
</style>