<!--
=== TestBackButton.vue ===
백버튼 컴포저블 테스트 메인 화면

** 테스트 시나리오 **
1. ✅ Page 백버튼 핸들러 테스트 (onPageBack)
2. ✅ Modal 백버튼 핸들러 테스트 (onModalBack)
3. ✅ Popover 백버튼 핸들러 테스트 (onPopoverBack)
4. ✅ 핸들러 관리 테스트 (offBack, clearAllBack)

** 추가 필요한 테스트 (주석으로 명시) **
- 중첩 Modal 테스트
- Modal + Popover 조합 테스트
- Loading 상태 테스트
- Alert/ActionSheet preventBackButton 테스트
- Menu 열린 상태 테스트
- 딥링킹 시나리오 테스트
- 에러 복구 테스트
- 디바운싱 테스트
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>BackButton 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">
        <h1>백버튼 컴포저블 테스트</h1>
        <p class="description">
          10단계 백버튼 처리 체인 및 핸들러 등록 시스템을 테스트합니다.<br>
          각 테스트 후 브라우저의 뒤로가기 버튼을 눌러 동작을 확인하세요.
        </p>

        <!-- 현재 페이지 상태 -->
        <div class="status-section">
          <h2>현재 페이지 상태</h2>
          <div class="status-info">
            <p><strong>페이지 핸들러:</strong> {{ pageHandlerActive ? '활성' : '비활성' }}</p>
            <p><strong>변경사항:</strong> {{ hasUnsavedChanges ? '있음' : '없음' }}</p>
            <p><strong>마지막 테스트:</strong> {{ lastTest }}</p>
          </div>
        </div>

        <!-- 1. Page 백버튼 핸들러 테스트 -->
        <div class="test-section">
          <h2>1. Page 백버튼 핸들러 테스트</h2>
          <p class="test-description">
            현재 페이지에서 백버튼 핸들러를 등록하고 저장 확인 다이얼로그를 테스트합니다.
          </p>

          <ion-button @click="enablePageHandler" expand="block" fill="outline" class="test-button">
            페이지 핸들러 활성화 (저장 확인)
          </ion-button>

          <ion-button @click="toggleUnsavedChanges" expand="block" fill="outline" class="test-button">
            변경사항 토글 ({{ hasUnsavedChanges ? '저장됨으로 변경' : '변경됨으로 변경' }})
          </ion-button>

          <ion-button @click="disablePageHandler" expand="block" fill="outline" class="test-button">
            페이지 핸들러 비활성화
          </ion-button>
        </div>

        <!-- 2. Modal 백버튼 핸들러 테스트 -->
        <div class="test-section">
          <h2>2. Modal 백버튼 핸들러 테스트</h2>
          <p class="test-description">
            Modal을 열고 Modal 내에서 백버튼 핸들러 동작을 테스트합니다.
          </p>

          <ion-button @click="openTestModal" expand="block" fill="outline" class="test-button">
            테스트 Modal 열기
          </ion-button>
        </div>

        <!-- 3. Popover 백버튼 핸들러 테스트 -->
        <div class="test-section">
          <h2>3. Popover 백버튼 핸들러 테스트</h2>
          <p class="test-description">
            Popover를 열고 Popover 내에서 백버튼 핸들러 동작을 테스트합니다.
          </p>

          <ion-button @click="openTestPopover" expand="block" fill="outline" class="test-button" id="popover-trigger">
            테스트 Popover 열기
          </ion-button>
        </div>

        <!-- 4. 핸들러 관리 테스트 -->
        <div class="test-section">
          <h2>4. 핸들러 관리 테스트</h2>
          <p class="test-description">
            등록된 핸들러들을 수동으로 해제하거나 초기화합니다.
          </p>

          <ion-button @click="clearPageHandler" expand="block" fill="outline" class="test-button">
            페이지 핸들러만 해제
          </ion-button>

          <ion-button @click="clearAllHandlers" expand="block" fill="outline" class="test-button">
            모든 핸들러 초기화
          </ion-button>
        </div>

        <!-- 추가 테스트 케이스 (주석으로 설명) -->
        <div class="additional-tests">
          <h2>📝 추가 테스트 케이스 (구현 예정)</h2>
          <ul>
            <li><strong>중첩 Modal 테스트:</strong> Modal 안에서 또 다른 Modal을 열고 백버튼 처리 순서 확인</li>
            <li><strong>Modal + Popover 조합:</strong> Modal 내에서 Popover 열고 백버튼 우선순위 확인</li>
            <li><strong>Loading 상태 테스트:</strong> Loading 중일 때 백버튼 차단 동작 확인</li>
            <li><strong>Alert/ActionSheet 테스트:</strong> preventBackButton 속성에 따른 백버튼 동작</li>
            <li><strong>Menu 열린 상태:</strong> 사이드 메뉴가 열려있을 때 백버튼으로 닫기 테스트</li>
            <li><strong>딥링킹 시나리오:</strong> 히스토리 없는 상태에서 백버튼 동작 테스트</li>
            <li><strong>에러 복구 테스트:</strong> 핸들러에서 예외 발생시 fallback 동작 확인</li>
            <li><strong>디바운싱 테스트:</strong> 빠른 연속 백버튼 클릭시 중복 실행 방지 확인</li>
          </ul>
        </div>

        <!-- 사용 가이드 -->
        <div class="usage-guide">
          <h2>🔍 테스트 방법</h2>
          <ol>
            <li>원하는 테스트 버튼을 클릭하여 핸들러를 설정하세요</li>
            <li>브라우저의 뒤로가기 버튼을 클릭하거나 하드웨어 백버튼을 누르세요</li>
            <li>Console 로그에서 각 단계별 처리 과정을 확인하세요</li>
            <li>Modal이나 Popover가 열린 상태에서 백버튼 동작을 테스트하세요</li>
            <li>다양한 조합으로 복합 시나리오를 테스트해보세요</li>
          </ol>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { ref } from 'vue';
import { onIonViewWillEnter } from '@ionic/vue';
import { useApp } from '@bizMOB/vue';

// useApp 컴포저블에서 필요한 기능들 가져오기
const {
  onPageBack,
  offBack,
  clearAllBack,
  confirm,
  alert,
  openModal,
  openPopover,
  back
} = useApp();

// 테스트 상태 관리
const pageHandlerActive = ref(false);
const hasUnsavedChanges = ref(false);
const lastTest = ref('없음');

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

// 페이지 핸들러 활성화
const enablePageHandler = () => {
  console.log('%c🎯 페이지 백버튼 핸들러 등록', 'color: blue; font-weight: bold;');

  onPageBack(async () => {
    console.log('%c📱 페이지 백버튼 핸들러 실행됨', 'color: green; font-weight: bold;');

    if (hasUnsavedChanges.value) {
      const confirmed = await confirm('저장하지 않은 변경사항이 있습니다. 정말 나가시겠습니까?');
      return confirmed;
    }
    else {
      await alert('변경사항이 없습니다.');
      return true;
    }
  });

  pageHandlerActive.value = true;
  lastTest.value = '페이지 핸들러 활성화';
  console.log('%c✅ 페이지 핸들러 등록 완료', 'color: green;');
};

// 페이지 핸들러 비활성화
const disablePageHandler = () => {
  console.log('%c🎯 페이지 백버튼 핸들러 해제', 'color: blue; font-weight: bold;');

  offBack('page', '/tests/backbutton');
  pageHandlerActive.value = false;
  lastTest.value = '페이지 핸들러 비활성화';

  console.log('%c✅ 페이지 핸들러 해제 완료', 'color: green;');
};

// 변경사항 상태 토글
const toggleUnsavedChanges = () => {
  hasUnsavedChanges.value = !hasUnsavedChanges.value;
  lastTest.value = `변경사항 ${hasUnsavedChanges.value ? '생성' : '저장'}`;

  console.log(`%c📝 변경사항 상태: ${hasUnsavedChanges.value ? '있음' : '없음'}`, 'color: purple;');
};

// 테스트 Modal 열기
const openTestModal = async () => {
  console.log('%c🎯 테스트 Modal 열기', 'color: blue; font-weight: bold;');
  lastTest.value = 'Modal 테스트 시작';

  // Modal 컴포넌트를 동적으로 import
  const TestModalComponent = (await import('./TestBackButtonModal.vue')).default;

  try {
    const result = await openModal(TestModalComponent, {
      props: {
        title: '백버튼 테스트 Modal',
        message: '이 Modal에서 백버튼을 눌러보세요.'
      },
      cssClass: ['test-modal']
    });

    console.log('%c📱 Modal 결과:', 'color: green;', result);
    lastTest.value = `Modal 테스트 완료 - ${result.result ? '확인' : '취소'}`;
  } catch (error) {
    console.error('%c❌ Modal 테스트 오류:', 'color: red;', error);
    lastTest.value = 'Modal 테스트 오류';
  }
};

// 테스트 Popover 열기
const openTestPopover = async (event: Event) => {
  console.log('%c🎯 테스트 Popover 열기', 'color: blue; font-weight: bold;');
  lastTest.value = 'Popover 테스트 시작';

  // Popover 컴포넌트를 동적으로 import
  const TestPopoverComponent = (await import('./TestBackButtonPopover.vue')).default;

  try {
    const result = await openPopover(TestPopoverComponent, {
      event,
      props: {
        options: ['옵션 1', '옵션 2', '옵션 3'],
        title: '백버튼 테스트 Popover'
      },
      dismissOnSelect: false, // 선택시 자동 닫기 (default: true)
    });

    console.log('%c📱 Popover 결과:', 'color: green;', result);
    lastTest.value = `Popover 테스트 완료 - ${result.result ? result.data || '선택됨' : '취소'}`;
  } catch (error) {
    console.error('%c❌ Popover 테스트 오류:', 'color: red;', error);
    lastTest.value = 'Popover 테스트 오류';
  }
};

// 페이지 핸들러만 해제
const clearPageHandler = () => {
  console.log('%c🎯 페이지 핸들러만 해제', 'color: blue; font-weight: bold;');

  offBack('page');
  pageHandlerActive.value = false;
  lastTest.value = '페이지 핸들러 해제';

  console.log('%c✅ 페이지 핸들러 해제 완료', 'color: green;');
};

// 모든 핸들러 초기화
const clearAllHandlers = () => {
  console.log('%c🎯 모든 핸들러 초기화', 'color: blue; font-weight: bold;');

  clearAllBack();
  pageHandlerActive.value = false;
  hasUnsavedChanges.value = false;
  lastTest.value = '전체 핸들러 초기화';

  console.log('%c✅ 모든 핸들러 초기화 완료', 'color: green;');
};

// 페이지 진입시 초기 상태 설정
onIonViewWillEnter(() => {
  console.log('%c🚀 BackButton 테스트 페이지 진입', 'color: blue; font-weight: bold;');
  console.log('%c💡 브라우저 개발자 도구 Console을 열어 로그를 확인하세요', 'color: orange;');
});
</script>

<style scoped>
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.test-container h1 {
  text-align: center;
  color: #333;
  margin-bottom: 10px;
}

.description {
  text-align: center;
  color: #666;
  margin-bottom: 30px;
  line-height: 1.6;
}

.status-section {
  background: #f0f8ff;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 30px;
  border-left: 4px solid #007bff;
}

.status-section h2 {
  margin: 0 0 15px 0;
  color: #333;
  font-size: 1.1em;
}

.status-info {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 10px;
}

.status-info p {
  margin: 5px 0;
  font-size: 0.9em;
}

.test-section {
  margin-bottom: 30px;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #fff;
}

.test-section h2 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 1.1em;
}

.test-description {
  color: #666;
  font-size: 0.9em;
  margin-bottom: 15px;
  line-height: 1.5;
}

.test-button {
  --color: #007bff;
  --border-color: #007bff;
  --border-width: 2px;
  --border-radius: 8px;
  --padding-top: 12px;
  --padding-bottom: 12px;
  margin: 5px 0;
  font-weight: 500;
}

.test-button:hover {
  --background: #007bff;
  --color: white;
}

.additional-tests {
  background: #fff3cd;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 30px;
  border-left: 4px solid #ffc107;
}

.additional-tests h2 {
  margin: 0 0 15px 0;
  color: #333;
}

.additional-tests ul {
  margin: 0;
  padding-left: 20px;
}

.additional-tests li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}

.usage-guide {
  background: #d1ecf1;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #17a2b8;
}

.usage-guide h2 {
  margin: 0 0 15px 0;
  color: #333;
}

.usage-guide ol {
  margin: 0;
  padding-left: 20px;
}

.usage-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>