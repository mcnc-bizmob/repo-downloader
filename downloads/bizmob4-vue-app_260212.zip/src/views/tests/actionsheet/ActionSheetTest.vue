<!--
=== ActionSheetTest.vue ===
useApp.actionSheet 컴포저블의 주요 기능 테스트 화면

** 테스트 범위 **
- 실제 구현: 기본 ActionSheet, 커스텀 ActionSheet, ActionSheet 상태 확인 (3개 핵심 기능)
- 주석 설명: 나머지 고급 기능들의 테스트 케이스
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>ActionSheet 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">

        <h1>ActionSheet 기능 테스트</h1>
        <p class="test-description">
          브라우저 개발자 도구의 Console에서 테스트 결과를 확인하세요.
        </p>

        <!-- 핵심 기능 테스트 버튼들 -->
        <div class="test-section">
          <h2>핵심 기능 테스트</h2>

          <div class="button-group">
            <button @click="testBasicActionSheet" class="test-button">
              기본 ActionSheet 테스트
            </button>

            <button @click="testCustomActionSheet" class="test-button">
              커스텀 ActionSheet 테스트
            </button>

            <button @click="testActionSheetStatus" class="test-button">
              ActionSheet 상태 테스트
            </button>
          </div>
        </div>

        <!-- 테스트 안내 -->
        <div class="test-guide">
          <h3>테스트 방법</h3>
          <ul>
            <li>각 버튼을 클릭하여 해당 기능을 테스트하세요</li>
            <li>ActionSheet가 나타나면 옵션을 선택해보세요</li>
            <li>Console에서 결과 로그를 확인하세요</li>
            <li>다양한 ActionSheet 옵션들의 동작을 확인해보세요</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';
// 🔧 아이콘 import 추가
import { downloadOutline, shareOutline, trashOutline } from 'ionicons/icons';

// bizMOB.vue 통합 API에서 ActionSheet 기능들 가져오기
const { openActionSheet, isActionSheetOpen, back } = useApp();

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

/*
=== 핵심 기능 테스트 구현 ===
*/

// 1. 기본 ActionSheet 테스트 (배열 입력)
const testBasicActionSheet = async () => {
  console.log('%c📋 기본 ActionSheet 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openActionSheet([
      { text: '편집', value: 'edit' },
      { text: '공유', value: 'share' },
      { text: '삭제', value: 'delete', role: 'destructive' },
      { text: '취소', role: 'cancel' }
    ]);

    console.log('%c✅ 기본 ActionSheet 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      선택값: result.value,
      닫힘여부: result.dismissed,
      역할: result.role,
      선택된액션: result.value ? `${result.value} 작업 선택됨` : '취소됨'
    });
  } catch (error) {
    console.log('%c❌ 기본 ActionSheet 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 2. 커스텀 ActionSheet 테스트
const testCustomActionSheet = async () => {
  console.log('%c📋 커스텀 ActionSheet 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await openActionSheet({
      header: '파일 작업 선택',
      subHeader: '원하는 작업을 선택하세요',
      buttons: [
        {
          text: '다운로드 파일을 로컬에 저장',
          value: 'download',
          icon: downloadOutline,
          cssClass: 'custom-css'
        },
        {
          text: '공유하기 다른 사람과 공유',
          value: 'share',
          icon: shareOutline,
          cssClass: 'custom-css'
        },
        {
          text: '삭제',
          icon: trashOutline,
          role: 'destructive',
          handler: async () => {
            console.log('%c📋 삭제 핸들러 실행됨', 'color: blue; font-weight: bold;');
            return true;
          }
        },
        { text: '취소', role: 'cancel' }
      ],
      preventBackButton: true,
      cssClass: 'custom-action-sheet',
      animated: true,
      backdropDismiss: false
    });

    console.log('%c✅ 커스텀 ActionSheet 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      선택값: result.value,
      닫힘여부: result.dismissed,
      역할: result.role,
      백버튼차단: '설정됨',
      커스텀옵션: '적용됨'
    });

    // 선택된 값에 따른 추가 처리
    if (result.value === 'download') {
      console.log('%c📋 다운로드 작업 시뮬레이션', 'color: blue; font-weight: bold;');
    } else if (result.value === 'share') {
      console.log('%c📋 공유 작업 시뮬레이션', 'color: blue; font-weight: bold;');
    }

  } catch (error) {
    console.log('%c❌ 커스텀 ActionSheet 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 3. ActionSheet 상태 테스트
const testActionSheetStatus = async () => {
  console.log('%c📋 ActionSheet 상태 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    // 현재 상태 확인
    const initialStatus = isActionSheetOpen();
    console.log('%c📋 초기 상태:', 'color: blue; font-weight: bold;', { isOpen: initialStatus });

    // ActionSheet 표시 (자동으로 닫히지 않도록 긴 지속시간 설정)
    console.log('%c📋 ActionSheet 표시 중...', 'color: blue; font-weight: bold;');

    // 비동기로 ActionSheet 표시하고 상태 확인
    const actionSheetPromise = openActionSheet([
      { text: '상태 테스트 중', value: 'testing' },
      { text: '닫기', role: 'cancel' }
    ]);

    // 잠시 후 상태 확인 (ActionSheet가 완전히 표시된 후)
    setTimeout(() => {
      const activeStatus = isActionSheetOpen();
      console.log('%c📋 활성 상태:', 'color: blue; font-weight: bold;', { isOpen: activeStatus });
    }, 500);

    // ActionSheet 결과 대기
    const result = await actionSheetPromise;

    // 닫힌 후 상태 확인
    const finalStatus = isActionSheetOpen();

    console.log('%c✅ ActionSheet 상태 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      초기상태: initialStatus,
      최종상태: finalStatus,
      선택결과: result.value,
      상태변화: '정상적으로 변경됨'
    });

  } catch (error) {
    console.log('%c❌ ActionSheet 상태 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== 추가 테스트 필요한 기능들 ===

1. 줄바꿈 포함 버튼 텍스트 테스트:
   - 테스트 케이스: 버튼 텍스트에 \n이 포함된 ActionSheet 표시
   - 확인 포인트: \n이 <br> 태그로 정확히 변환되어 줄바꿈 표시되는지
   - 예상 결과: 버튼 텍스트가 여러 줄로 표시됨

2. 다양한 버튼 역할 테스트:
   - 테스트 케이스: role을 'cancel', 'destructive', undefined로 각각 설정
   - 확인 포인트: 각 역할에 따른 버튼 스타일링과 동작 확인
   - 예상 결과: Cancel은 하단, Destructive는 빨간색, 일반은 기본 스타일

3. 버튼 핸들러 테스트:
   - 테스트 케이스: 버튼에 handler 함수 설정하여 커스텀 로직 실행
   - 확인 포인트: 핸들러 함수가 정상적으로 실행되고 반환값이 처리되는지
   - 예상 결과: 핸들러 실행 후 ActionSheet 닫힘 여부 결정

4. 버튼 value와 handler 혼용 테스트:
   - 테스트 케이스: 일부 버튼은 value, 일부는 handler로 설정
   - 확인 포인트: 각각의 동작 방식이 올바르게 구분되는지
   - 예상 결과: value 버튼은 반환값, handler 버튼은 함수 실행

5. preventBackButton 동작 테스트:
   - 테스트 케이스: preventBackButton: true 설정 후 하드웨어 백버튼 테스트
   - 확인 포인트: 백버튼이 실제로 차단되는지 확인
   - 예상 결과: 백버튼 눌러도 ActionSheet가 닫히지 않음

6. backdropDismiss 테스트:
   - 테스트 케이스: backdropDismiss: false 설정 후 배경 클릭
   - 확인 포인트: 배경 클릭으로 닫히지 않는지 확인
   - 예상 결과: 배경 클릭해도 ActionSheet 유지

7. CSS 클래스 커스터마이징 테스트:
   - 테스트 케이스: cssClass로 커스텀 스타일 클래스 적용
   - 확인 포인트: 지정한 CSS 클래스가 적용되는지
   - 예상 결과: 커스텀 스타일이 ActionSheet에 적용됨

8. 아이콘 표시 테스트:
   - 테스트 케이스: 버튼에 다양한 Ionic 아이콘 설정
   - 확인 포인트: 지정한 아이콘이 버튼에 표시되는지
   - 예상 결과: 버튼 텍스트와 함께 아이콘 표시

9. 애니메이션 테스트:
   - 테스트 케이스: animated: true/false로 애니메이션 활성화/비활성화
   - 확인 포인트: 애니메이션 설정에 따른 표시/숨김 효과 확인
   - 예상 결과: 설정에 따라 애니메이션 있음/없음

10. 강제 닫기 테스트:
    - 테스트 케이스: ActionSheet 표시 중 closeActionSheet() 호출
    - 확인 포인트: 프로그래밍적으로 ActionSheet가 닫히는지
    - 예상 결과: 사용자 선택 없이 ActionSheet 닫힘

11. 중복 ActionSheet 방지 테스트:
    - 테스트 케이스: ActionSheet 표시 중 또 다른 ActionSheet 호출
    - 확인 포인트: 기존 ActionSheet가 닫히고 새로운 것이 표시되는지
    - 예상 결과: 단일 인스턴스만 유지됨

12. 에러 상황 테스트:
    - 테스트 케이스: 잘못된 옵션이나 빈 버튼 배열로 ActionSheet 호출
    - 확인 포인트: 에러가 적절히 처리되는지
    - 예상 결과: Console에 에러 로그 출력, 기본값으로 동작

13. WeakMap 백버튼 설정 관리 테스트:
    - 테스트 케이스: 연속으로 다른 백버튼 설정의 ActionSheet 표시
    - 확인 포인트: 각 ActionSheet의 백버튼 설정이 독립적으로 관리되는지
    - 예상 결과: 각 ActionSheet마다 설정된 백버튼 동작이 다르게 적용됨

14. 백버튼 연동 함수 테스트:
    - 테스트 케이스: getActionSheetBackButtonSetting(), closeCurrentActionSheet() 동작 확인
    - 확인 포인트: useApp.backButton.ts에서 호출되는 함수들이 정상 동작하는지
    - 예상 결과: 현재 ActionSheet의 백버튼 설정 반환, ActionSheet 닫기 성공
*/
</script>

<style scoped>
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.back-link {
  margin-bottom: 20px;
}

.back-button {
  --color: #007bff;
  --padding-start: 0;
  --padding-end: 0;
  margin: 0;
  font-weight: 500;
  text-decoration: none;
}

.back-button:hover {
  --color: #0056b3;
  text-decoration: underline;
}

.test-container h1 {
  color: #333;
  margin-bottom: 10px;
}

.test-description {
  color: #666;
  margin-bottom: 30px;
  font-style: italic;
}

.test-section {
  margin-bottom: 30px;
}

.test-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #007bff;
  padding-bottom: 5px;
}

.button-group {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 15px;
}

.test-button {
  padding: 12px 20px;
  background: #fd7e14;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.test-button:hover {
  background: #e8660c;
}

.test-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
}

.test-guide h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.test-guide ul {
  margin: 0;
  padding-left: 20px;
}

.test-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>