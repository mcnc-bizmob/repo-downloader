// ============================================================================
// 🎨 Formatters - 포맷팅 함수들
// ============================================================================

/**
 * 숫자 천단위 콤마 포맷팅
 * @param num - 포맷할 숫자
 * @param decimals - 소수점 자릿수 (선택사항)
 * @returns 천단위 콤마가 적용된 문자열
 * @example
 * formatNumber(1234567) // '1,234,567'
 * formatNumber(1234.567, 2) // '1,234.57'
 */
export const formatNumber = (num: number, decimals?: number): string => {
  if (isNaN(num)) {
    return '0';
  }

  const options: Intl.NumberFormatOptions = {};

  if (decimals !== undefined) {
    options.minimumFractionDigits = decimals;
    options.maximumFractionDigits = decimals;
  }

  return new Intl.NumberFormat('ko-KR', options).format(num);
};

/**
 * 통화 포맷팅
 * @param amount - 금액
 * @param currency - 통화 코드 ('KRW', 'USD', 'JPY' 등)
 * @returns 통화 형식이 적용된 문자열
 * @example
 * formatCurrency(1234567, 'KRW') // '₩1,234,567'
 * formatCurrency(1234.56, 'USD') // '$1,234.56'
 */
// export const formatCurrency = (
//   amount: number,
//   currency: string = 'KRW'
// ): string => {
//   if (isNaN(amount)) {
//     return currency === 'KRW' ? '₩0' : '$0';
//   }
//
//   return new Intl.NumberFormat('ko-KR', {
//     style: 'currency',
//     currency: currency
//   }).format(amount);
// };

/**
 * 전화번호 포맷팅 (한국)
 * @param phone - 전화번호 (숫자만 또는 하이픈 포함)
 * @returns 하이픈이 적용된 전화번호
 * @example
 * formatPhoneKR('01012345678') // '010-1234-5678'
 * formatPhoneKR('0212345678') // '02-1234-5678'
 */
// export const formatPhoneKR = (phone: string): string => {
//   const cleaned = phone.replace(/\D/g, '');
//
//   if (cleaned.length === 11 && cleaned.startsWith('010')) {
//     return `${cleaned.slice(0, 3)}-${cleaned.slice(3, 7)}-${cleaned.slice(7)}`;
//   } else if (cleaned.length === 10 && cleaned.startsWith('02')) {
//     return `${cleaned.slice(0, 2)}-${cleaned.slice(2, 6)}-${cleaned.slice(6)}`;
//   } else if (cleaned.length === 11 && (cleaned.startsWith('031') || cleaned.startsWith('032'))) {
//     return `${cleaned.slice(0, 3)}-${cleaned.slice(3, 7)}-${cleaned.slice(7)}`;
//   }
//
//   return phone; // 형식을 알 수 없는 경우 원본 반환
// };

/**
 * 전화번호 하이픈 제거
 * @param phone - 하이픈이 포함된 전화번호
 * @returns 숫자만 있는 전화번호
 * @example
 * removePhoneHyphens('010-1234-5678') // '01012345678'
 */
// export const removePhoneHyphens = (phone: string): string => {
//   return phone.replace(/\D/g, '');
// };

/**
 * 파일 크기 포맷팅
 * @param bytes - 바이트 크기
 * @param decimals - 소수점 자릿수
 * @returns 단위가 적용된 파일 크기 문자열
 * @example
 * formatFileSize(1024) // '1 KB'
 * formatFileSize(1536, 1) // '1.5 KB'
 * formatFileSize(1048576) // '1 MB'
 */
// export const formatFileSize = (bytes: number, decimals: number = 0): string => {
//   if (bytes === 0) return '0 Bytes';
//
//   const k = 1024;
//   const dm = decimals < 0 ? 0 : decimals;
//   const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
//
//   const i = Math.floor(Math.log(bytes) / Math.log(k));
//
//   return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
// };

/**
 * 텍스트 앞뒤 공백 제거
 * @param text - 처리할 텍스트
 * @returns 공백이 제거된 텍스트
 * @example
 * trimText('  Hello World  ') // 'Hello World'
 */
// export const trimText = (text: string): string => {
//   return text ? text.trim() : '';
// };

/**
 * 텍스트 대문자 변환
 * @param text - 변환할 텍스트
 * @returns 대문자로 변환된 텍스트
 * @example
 * toUpperCase('hello world') // 'HELLO WORLD'
 */
// export const toUpperCase = (text: string): string => {
//   return text ? text.toUpperCase() : '';
// };

/**
 * 텍스트 소문자 변환
 * @param text - 변환할 텍스트
 * @returns 소문자로 변환된 텍스트
 * @example
 * toLowerCase('HELLO WORLD') // 'hello world'
 */
// export const toLowerCase = (text: string): string => {
//   return text ? text.toLowerCase() : '';
// };

/**
 * 텍스트 첫 글자만 대문자 변환
 * @param text - 변환할 텍스트
 * @returns 첫 글자가 대문자로 변환된 텍스트
 * @example
 * capitalizeFirst('hello world') // 'Hello world'
 */
// export const capitalizeFirst = (text: string): string => {
//   if (!text) return '';
//   return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
// };

/**
 * 이메일 마스킹 처리
 * @param email - 마스킹할 이메일
 * @returns 마스킹된 이메일
 * @example
 * maskEmail('user@example.com') // 'u***@example.com'
 */
// export const maskEmail = (email: string): string => {
//   if (!email || !email.includes('@')) {
//     return email;
//   }
//
//   const [username, domain] = email.split('@');
//   const maskedUsername = username.charAt(0) + '*'.repeat(username.length - 1);
//
//   return `${maskedUsername}@${domain}`;
// };

/**
 * 전화번호 마스킹 처리
 * @param phone - 마스킹할 전화번호
 * @returns 마스킹된 전화번호
 * @example
 * maskPhone('010-1234-5678') // '010-****-5678'
 */
// export const maskPhone = (phone: string): string => {
//   if (!phone) return phone;
//
//   const cleaned = phone.replace(/\D/g, '');
//
//   if (cleaned.length === 11 && cleaned.startsWith('010')) {
//     return `${cleaned.slice(0, 3)}-****-${cleaned.slice(7)}`;
//   } else if (cleaned.length === 10 && cleaned.startsWith('02')) {
//     return `${cleaned.slice(0, 2)}-****-${cleaned.slice(6)}`;
//   }
//
//   return phone;
// };

/**
 * 이름 마스킹 처리
 * @param name - 마스킹할 이름
 * @returns 마스킹된 이름
 * @example
 * maskName('홍길동') // '홍*동'
 * maskName('김철수') // '김*수'
 */
// export const maskName = (name: string): string => {
//   if (!name || name.length < 2) {
//     return name;
//   }
//
//   if (name.length === 2) {
//     return name.charAt(0) + '*';
//   }
//
//   return name.charAt(0) + '*'.repeat(name.length - 2) + name.charAt(name.length - 1);
// };

/**
 * 퍼센트 포맷팅
 * @param value - 값 (0.5 = 50%)
 * @param decimals - 소수점 자릿수
 * @returns 퍼센트 형식 문자열
 * @example
 * formatPercent(0.156, 1) // '15.6%'
 * formatPercent(0.5) // '50%'
 */
// export const formatPercent = (value: number, decimals: number = 0): string => {
//   if (isNaN(value)) {
//     return '0%';
//   }
//
//   return `${(value * 100).toFixed(decimals)}%`;
// };
