import { defineStore } from 'pinia';
import { propertiesAdapter } from '../utils/properties';
import { cryptoLocalStorage, cryptoSessionStorage } from '../plugins/crypto-storage.plugin';

// 프로젝트 스토리지 인터페이스
export interface IAppStorage {
  set(key: string, value: any): void
  get<T = any>(key: string): T | undefined
  remove(key: string): void
  clear(): void
  has(key: string): boolean
  keys(): string[]
  getAll<T = Record<string, any>>(): T
}

// 전체 프로젝트 스토어 인터페이스
export interface IAppStore extends IAppStorage {
  local: IAppStorage
  session: IAppStorage
  properties: IAppStorage
}


// 공통 store 설정
const baseStoreConfig = {
  state: () => ({ data: {} as Record<string, any> })
};

// 메모리 전용 store (persist 없음)
const useAppMemoryStore = defineStore('app-memory', baseStoreConfig);

// localStorage 전용 store
const useAppLocalStore = defineStore('app-local', {
  ...baseStoreConfig,
  persist: {
    storage: cryptoLocalStorage,
    key: 'app-local'
  }
});

// sessionStorage 전용 store
const useAppSessionStore = defineStore('app-session', {
  ...baseStoreConfig,
  persist: {
    storage: cryptoSessionStorage,
    key: 'app-session'
  }
});

// Properties 전용 store
const useAppPropertiesStore = defineStore('app-properties', {
  ...baseStoreConfig,
  persist: {
    storage: propertiesAdapter,
    key: 'app-properties'
  }
});

/**
 * 통합 프로젝트 스토어 - 간단한 key-value 저장소
 *
 * @example
 * import { useAppStore } from '@bizMOB/vue';
 *
 * const appStore = useAppStore()
 *
 * // 메모리 저장 (기본)
 * appStore.set('key', 'value')
 *
 * // localStorage
 * appStore.local.set('key', 'value')
 *
 * // sessionStorage
 * appStore.session.set('key', 'value')
 *
 * // Properties (앱 내부)
 * appStore.properties.set('key', 'value')
 */
export function useAppStore(): IAppStore {
  const memoryStore = useAppMemoryStore();
  const localStore = useAppLocalStore();
  const sessionStore = useAppSessionStore();
  const propertiesStore = useAppPropertiesStore();

  // 최적화된 스토리지 생성 함수
  const createStorage = (store: any): IAppStorage => ({
    set: (key: string, value: any) => store.data[key] = value,
    get: <T = any>(key: string) => store.data[key] as T,
    remove: (key: string) => delete store.data[key],
    clear: () => store.data = {},
    has: (key: string) => key in store.data,
    keys: () => Object.keys(store.data),
    getAll: <T = Record<string, any>>() => ({ ...store.data } as T)
  });

  // 메모리 스토리지 (기본)
  const memoryStorage = createStorage(memoryStore);

  return {
    // 기본 메서드들 (메모리)
    ...memoryStorage,

    // 각 스토리지 접근자
    local: createStorage(localStore),
    session: createStorage(sessionStore),
    properties: createStorage(propertiesStore)
  };
}
