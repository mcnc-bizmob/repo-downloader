import { computed } from 'vue';
import { createI18n, useI18n as useVueI18n } from 'vue-i18n';
import type { LocaleMessages, VueMessageType } from 'vue-i18n';
import { BzLocale } from '@bizMOB';

// Webpack require.context 타입 선언  
declare const require: {
  context: (directory: string, useSubdirectories: boolean, regExp: RegExp) => {
    keys(): string[];
    (id: string): { default: any };
  };
};

/**
 * 기본 로케일 메시지 로드 (src/locales/*.ts)
 * 비즈니스 프로젝트에서 TS 파일 추가/수정 가능
 */
function loadLocaleMessages(): LocaleMessages<any> {
  const locales = require.context('@/locales', true, /locale\.[A-Za-z0-9-_,\s]+\.ts$/i);
  const messages: LocaleMessages<VueMessageType> = {};
  locales.keys().forEach((key: string) => {
    const matched = key.match(/locale\.([A-Za-z0-9-_]+)\./i);
    if (matched && matched.length > 1) {
      const locale = matched[1];
      messages[locale] = locales(key).default;
    }
  });
  return messages;
}

// i18n 인스턴스 생성 (main.ts에서 사용)
export const i18n = createI18n({
  legacy: false,
  globalInjection: true,
  locale: import.meta.env.VITE_I18N_LOCALE || 'ko',
  fallbackLocale: import.meta.env.VITE_I18N_FALLBACK_LOCALE || 'ko',
  messages: loadLocaleMessages()
});

/**
 * bizMOB Vue i18n 컴포저블
 * 
 * 기본 기능:
 * - Vue-i18n 기본 기능 (번역, 언어 변경)
 * - BzLocale과 연동
 * - src/locales/*.json 자동 로드
 * 
 * 확장 기능:
 * - 서버에서 언어 데이터 동적 로드
 * - 커스텀 언어 데이터 병합
 * - 언어별 캐싱 등
 */
export function useI18n() {
  const { t: vueT, locale: vueLocale } = useVueI18n();

  return {
    // ========================================
    // 기본 기능
    // ========================================
    
    // 번역 함수
    t: vueT,

    // 현재 locale (반응형)
    locale: computed(() => vueLocale.value),

    // locale 변경 (Vue-i18n + BzLocale 동시 업데이트)
    changeLocale: async (newLocale: string) => {
      const localeCode = newLocale.substring(0, 2);
      
      // Vue-i18n 업데이트
      vueLocale.value = localeCode;
      
      // BzLocale 업데이트 (네트워크/로컬 저장소)
      BzLocale.changeLocale(newLocale);
    },

    // locale 초기화 (네이티브에서 가져와서 Vue-i18n 업데이트)
    initLocale: async () => {
      const localeInfo = await BzLocale.initLocale();
      if (localeInfo?.locale) {
        const localeCode = localeInfo.locale.substring(0, 2);
        vueLocale.value = localeCode;
      }
      return localeInfo;
    },

    // locale 정보 조회
    getLocale: () => BzLocale.getLocale(),

    // ========================================
    // 확장 포인트 (비즈니스 프로젝트에서 사용)
    // ========================================

    // 언어별 메시지 완전 교체
    setLocaleMessage: (locale: string, messages: Record<string, any>) => {
      i18n.global.setLocaleMessage(locale, messages);
    },

    // 언어별 메시지 병합 (기존 + 새로운 데이터)
    mergeLocaleMessage: (locale: string, messages: Record<string, any>) => {
      i18n.global.mergeLocaleMessage(locale, messages);
    },

    // 현재 언어의 모든 메시지 조회
    getLocaleMessage: (locale?: string) => {
      return i18n.global.getLocaleMessage(locale || vueLocale.value);
    },

    // 지원되는 언어 목록 조회
    getAvailableLocales: () => {
      return i18n.global.availableLocales;
    },

    // i18n 인스턴스 직접 접근 (고급 사용)
    i18nInstance: i18n.global
  };
}
