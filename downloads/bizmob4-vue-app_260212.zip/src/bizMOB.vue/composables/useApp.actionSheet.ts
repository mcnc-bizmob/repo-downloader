/**
 * @description
 * Ionic ActionSheet 컴포저블
 *
 * **주요 기능:**
 * - Ionic actionSheetController 활용한 ActionSheet 표시/닫기
 * - preventBackButton 옵션으로 백버튼 차단 제어
 * - 버튼 목록 기반 선택 UI 제공
 * - ionicFocusManager를 통한 단순 포커스 제거 (aria-hidden 경고 방지)
 *
 * @returns {Object} ActionSheet를 제어하는 API 객체
 * @property {function(ActionSheetInput): Promise<ActionSheetResult>} openActionSheet ActionSheet 표시
 * @property {function(): Promise<boolean>} closeActionSheet 현재 활성 ActionSheet 닫기
 * @property {function(): boolean} isActionSheetOpen 현재 ActionSheet 활성 상태 확인
 *
 * @remarks
 * **백버튼 처리:**
 * - preventBackButton: true → 백버튼 차단
 * - preventBackButton: false/undefined → ActionSheet 닫기 후 네비게이션 진행
 *
 * **특징:**
 * - 커스텀 컴포넌트 불가능 (고정된 버튼 구조만 사용)
 * - Stack 관리 불필요 (중첩 불가능)
 *
 * @example
 * <caption><b>ActionSheet 사용법</b></caption>
 * ```typescript
 * import { useActionSheet } from '@bizMOB/vue';
 *
 * const { openActionSheet } = useActionSheet();
 *
 * // 1. 간단한 선택 ActionSheet (반환값 활용)
 * const handleSortOptions = async () => {
 *   const result = await openActionSheet({
 *     header: '정렬 기준',
 *     buttons: [
 *       { text: '이름순', value: 'name' },
 *       { text: '날짜순', value: 'date' },
 *       { text: '크기순', value: 'size' },
 *     ]
 *   });
 *
 *   if (result.value) {
 *     sortBy(result.value); // 'name', 'date', 'size' 중 하나
 *   }
 * };
 *
 * // 2. 간단한 선택 ActionSheet (header 없음)
 * const handleSortOptions = async () => {
 *   const result = await openActionSheet([
 *     { text: '이름순', value: 'name' },
 *     { text: '날짜순', value: 'date' },
 *     { text: '크기순', value: 'size' },
 *   ]);
 *
 *   if (result.value) {
 *     sortBy(result.value); // 'name', 'date', 'size' 중 하나
 *   }
 * };
 *
 * // 3. 기본 icon 설정된 선택 ActionSheet
 * const handleColorSelection = async () => {
 *   const result = await openActionSheet({
 *     header: '테마 색상',
 *     buttons: [
 *       { text: '파란색', value: 'blue', icon: 'color-palette' },
 *       { text: '빨간색', value: 'red', icon: 'color-palette' },
 *       { text: '초록색', value: 'green', icon: 'color-palette' },
 *     ]
 *   });
 *
 *   if (result.value) {
 *     changeThemeColor(result.value);
 *   }
 * };
 *
 * // 4. 줄바꿈이 포함된 ActionSheet
 * const handleDetailOptions = async () => {
 *   const result = await openActionSheet([
 *     { text: '상세 보기\n전체 정보 표시', value: 'detail' },
 *     { text: '간단 보기\n요약 정보만', value: 'summary' },
 *     { text: '편집 모드\n수정 가능', value: 'edit' }
 *   ]);
 *
 *   if (result.value) {
 *     changeViewMode(result.value);
 *   }
 * };
 *
 * // 5. 파일 작업 ActionSheet (핸들러와 값 혼용)
 * const handleFileOptions = async (fileId: string) => {
 *   const result = await openActionSheet({
 *     header: '파일 작업',
 *     buttons: [
 *       { text: '다운로드', value: 'download', icon: 'download' },
 *       { text: '공유하기', value: 'share', icon: 'share' },
 *       {
 *         text: '삭제',
 *         icon: 'trash',
 *         role: 'destructive',
 *         handler: async () => {
 *           // 삭제는 확인이 필요한 복잡한 로직
 *           const confirmed = await confirmDelete();
 *           if (confirmed) {
 *             await deleteFile(fileId);
 *           }
 *           return true;
 *         }
 *       },
 *       { text: '취소', role: 'cancel' } // 파괴적 작업이 있어서 취소 버튼 필요
 *     ],
 *     preventBackButton: true, // 백버튼 막기
 *   });
 *
 *   // 간단한 작업은 반환값으로 처리
 *   if (result.value === 'download') {
 *     downloadFile(fileId);
 *   } else if (result.value === 'share') {
 *     shareFile(fileId);
 *   }
 * };
 * ```
 */

import { actionSheetController, type ActionSheetOptions as IonicActionSheetOptions } from '@ionic/vue';
import { withActionSheetFocus } from '../utils/ionicFocusManager';

// ========================================
// 타입 정의
// ========================================

interface ActionSheetButton {
  text: string;
  value?: any;
  icon?: string;
  role?: 'cancel' | 'destructive';
  cssClass?: string | string[];
  handler?: () => boolean | void | Promise<boolean | void>;
}

interface ActionSheetOptions {
  header?: string;
  subHeader?: string;
  buttons: ActionSheetButton[];
  preventBackButton?: boolean;
  cssClass?: string | string[];
  animated?: boolean;
  backdropDismiss?: boolean;
}

interface ActionSheetResult {
  value?: any;
  dismissed: boolean;
  role?: string;
}

// 오버로드 지원을 위한 타입들
type ActionSheetInput = ActionSheetOptions | ActionSheetButton[];

// ========================================
// 상태 관리
// ========================================

/**
 * 현재 활성화된 ActionSheet 인스턴스 (단일 인스턴스만 지원)
 */
let currentActionSheet: HTMLIonActionSheetElement | null = null;

/**
 * ActionSheet 인스턴스별 백버튼 설정 추적
 */
const actionSheetBackButtonSettings = new WeakMap<HTMLIonActionSheetElement, boolean>();

// ========================================
// 유틸리티 함수들
// ========================================

/**
 * 버튼 텍스트에서 \n을 <br> 태그로 변환
 * @param text 원본 텍스트
 * @returns HTML 태그로 변환된 텍스트
 */
function formatButtonText(text: string): string {
  return text.replace(/\n/g, '<br>');
}

/**
 * ActionSheet 입력을 ActionSheetOptions로 정규화
 */
function normalizeActionSheetInput(input: ActionSheetInput): ActionSheetOptions {
  // 배열 입력인 경우 객체로 변환
  if (Array.isArray(input)) {
    return {
      buttons: input.map(button => ({
        ...button,
        text: formatButtonText(button.text)
      })),
      preventBackButton: false,
      animated: true,
      backdropDismiss: true
    };
  }

  // 객체 입력인 경우 기본값 적용 및 버튼 텍스트 변환
  return {
    animated: true,
    backdropDismiss: true,
    preventBackButton: false,
    ...input,
    buttons: input.buttons.map(button => ({
      ...button,
      text: formatButtonText(button.text)
    }))
  };
}

/**
 * Ionic ActionSheet 설정 객체 생성
 */
function createIonicActionSheetConfig(options: ActionSheetOptions): IonicActionSheetOptions {
  const config: IonicActionSheetOptions = {
    buttons: [],
    animated: options.animated,
    backdropDismiss: options.backdropDismiss
  };

  // 기본 속성들
  if (options.header) config.header = options.header;
  if (options.subHeader) config.subHeader = options.subHeader;

  // CSS 클래스 설정
  if (options.cssClass) {
    if (Array.isArray(options.cssClass)) {
      config.cssClass = options.cssClass.join(' ');
    } else {
      config.cssClass = options.cssClass;
    }
  }

  // 버튼 설정
  config.buttons = options.buttons.map(button => ({
    text: button.text,
    icon: button.icon,
    role: button.role,
    cssClass: Array.isArray(button.cssClass)
      ? button.cssClass.join(' ')
      : button.cssClass,
    handler: () => {
      // 핸들러가 있는 경우 실행
      if (button.handler) {
        try {
          const result = button.handler();
          return result;
        } catch (error) {
          console.error('[useActionSheet] 버튼 핸들러 오류:', error);
          return false;
        }
      }

      // value가 있는 경우 반환을 위해 true 반환
      if (button.value !== undefined) {
        return true;
      }

      return true;
    }
  }));

  return config;
}

// ========================================
// 백버튼 연동 함수 (useApp.backButton.ts에서 사용)
// ========================================

/**
 * 현재 활성화된 ActionSheet이 있는지 확인하는 함수
 * useApp.backButton.ts에서 호출됨
 *
 * @returns {HTMLIonActionSheetElement | null} 활성화된 ActionSheet 엘리먼트 또는 null
 */
export const getActiveActionSheet = (): HTMLIonActionSheetElement | null => {
  return currentActionSheet;
};

/**
 * 현재 ActionSheet의 백버튼 설정을 확인하는 함수
 * useApp.backButton.ts에서 호출됨
 */
export const getActionSheetBackButtonSetting = (): boolean => {
  if (!currentActionSheet) {
    return false;
  }
  return actionSheetBackButtonSettings.get(currentActionSheet) ?? false;
};

/**
 * 현재 활성화된 ActionSheet의 백버튼 설정을 확인하는 함수
 * useApp.backButton.ts에서 호출됨
 *
 * @returns {{enabled: boolean, actionSheet: HTMLIonActionSheetElement | null}} 백버튼 설정과 ActionSheet 정보
 */
export const getActiveActionSheetBackButtonSetting = (): {
  enabled: boolean;
  actionSheet: HTMLIonActionSheetElement | null;
} => {
  const activeActionSheet = getActiveActionSheet();

  if (!activeActionSheet) {
    return { enabled: false, actionSheet: null };
  }

  const enabled = actionSheetBackButtonSettings.get(activeActionSheet) ?? false;
  return { enabled, actionSheet: activeActionSheet };
};

// ========================================
// 메인 컴포저블 함수
// ========================================

export function useActionSheet() {
  /**
   * ActionSheet 표시 (배열 입력)
   * @param buttons 버튼 배열
   * @returns Promise<ActionSheetResult> ActionSheet 결과
   */
  async function openActionSheet(buttons: ActionSheetButton[]): Promise<ActionSheetResult>;

  /**
   * ActionSheet 표시 (옵션 객체 입력)
   * @param options ActionSheet 옵션
   * @returns Promise<ActionSheetResult> ActionSheet 결과
   */
  async function openActionSheet(options: ActionSheetOptions): Promise<ActionSheetResult>;

  /**
   * ActionSheet 표시 구현
   */
  async function openActionSheet(input: ActionSheetInput): Promise<ActionSheetResult> {
    try {
      // 기존 ActionSheet가 있으면 닫기 (단일 인스턴스)
      if (currentActionSheet) {
        await currentActionSheet.dismiss();
      }

      // 입력 정규화
      const options = normalizeActionSheetInput(input);

      // Ionic ActionSheet 설정 생성
      const actionSheetConfig = createIonicActionSheetConfig(options);

      // ActionSheet 생성 (단순 포커스 제거만)
      const actionSheetElement = await withActionSheetFocus(
        actionSheetController.create(actionSheetConfig),
        { debug: false }
      );

      // 현재 ActionSheet 설정
      currentActionSheet = actionSheetElement;

      // WeakMap에 백버튼 설정 저장
      actionSheetBackButtonSettings.set(actionSheetElement, options.preventBackButton || false);

      // ActionSheet가 닫힐 때 정리
      actionSheetElement.addEventListener('didDismiss', () => {
        if (currentActionSheet === actionSheetElement) {
          currentActionSheet = null;
        }
        // WeakMap에서 백버튼 설정 제거 (메모리 해제)
        actionSheetBackButtonSettings.delete(actionSheetElement);
      });

      // ActionSheet 표시
      await actionSheetElement.present();

      // 사용자 응답 대기
      const { role, data } = await actionSheetElement.onDidDismiss();

      // 결과 처리
      const result: ActionSheetResult = {
        dismissed: true,
        role: role || undefined
      };

      // 버튼 클릭으로 닫힌 경우 value 찾기
      if (role !== 'backdrop' && role !== 'cancel') {
        // 클릭된 버튼의 value 찾기
        const clickedButton = options.buttons.find(button => {
          // handler가 있는 버튼은 이미 실행되었으므로 value는 없음
          if (button.handler) return false;

          // role이 있는 버튼은 role로 매칭
          if (button.role === role) return true;

          // 일반 버튼은 텍스트로 구분 (Ionic의 한계)
          return button.value !== undefined;
        });

        if (clickedButton && clickedButton.value !== undefined) {
          result.value = clickedButton.value;
        }
      }

      return result;

    } catch (error) {
      console.error('[useActionSheet] ActionSheet 표시 중 오류 발생:', error);
      return {
        dismissed: true,
        role: 'error'
      };
    }
  }

  /**
   * 현재 활성 ActionSheet 닫기 (포커스 자동 복원)
   * @returns Promise<boolean> 성공 여부
   */
  async function closeActionSheet(): Promise<boolean> {
    if (!currentActionSheet) {
      return false;
    }

    try {
      // dismiss 시 ionicFocusManager에서 프로젝트별 포커스 복원 로직 실행
      await currentActionSheet.dismiss();
      return true;
    } catch (error) {
      console.error('[useActionSheet] ActionSheet 닫기 실패:', error);
      return false;
    }
  }

  /**
   * 현재 ActionSheet 활성 상태 확인
   * @returns boolean 활성 상태
   */
  function isActionSheetOpen(): boolean {
    return currentActionSheet !== null;
  }

  return {
    openActionSheet,
    closeActionSheet,
    isActionSheetOpen
  };
}
