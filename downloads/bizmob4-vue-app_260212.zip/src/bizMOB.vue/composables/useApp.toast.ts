/**
 * @namespace useToast
 * @description
 * Ionic Toast 컴포저블
 *
 * **주요 기능:**
 * - Ionic toastController 활용한 Toast 표시/닫기
 * - 다양한 위치, 색상, 지속시간 옵션 지원
 * - 자동 닫힘 및 수동 닫기 지원
 *
 * @returns {Object} Toast를 제어하는 API 객체
 * @property {function(ToastInput): Promise<ToastResult>} toast Toast 표시
 * @property {function(CloseToastOptions): Promise<CloseToastResult>} closeToast Toast 닫기
 * @property {function(Partial<DefaultToastSettings>): void} setToastDefaults Toast 기본 설정 변경
 * @property {function(): DefaultToastSettings} getToastDefaults 현재 Toast 기본 설정 조회
 * @property {function(): number} getActiveToastCount 현재 활성화된 Toast 개수 조회
 * @property {function(): string[]} getActiveToastIds 현재 활성화된 Toast ID 목록 조회
 *
 * @remarks
 * **백버튼 처리:**
 * - Toast는 백버튼 처리에 포함되지 않음 (사용자 방해하지 않는 알림)
 *
 * @example
 * <caption><b>Toast 사용법</b></caption>
 * ```typescript
 * import { useToast } from '@bizMOB/vue';
 *
 * const { toast } = useToast();
 *
 * // 1. 간단한 토스트
 * toast('저장되었습니다');
 *
 * // 2. 줄바꿈이 포함된 토스트
 * toast('저장되었습니다.\n잠시만 기다려 주세요');
 *
 * // 3. 옵션을 가진 토스트
 * toast({
 *   message: '저장되었습니다',
 *   duration: 3000,
 *   position: 'top',
 *   color: 'success'
 * });
 *
 * // 4. 옵션과 줄바꿈이 포함된 토스트
 * toast({
 *   message: '파일 업로드 중입니다.\n잠시만 기다려 주세요',
 *   duration: 5000,
 *   position: 'middle',
 *   color: 'warning'
 * });
 *
 * // 5. 닫기 버튼이 있는 토스트
 * await toast({
 *   message: '중요한 알림입니다',
 *   showCloseButton: true,
 *   closeButtonText: '닫기',
 *   duration: 0 // 수동으로 닫을 때까지 표시
 * });
 * ```
 */

import { toastController, type ToastOptions } from '@ionic/vue';

// ========================================
// 타입 정의
// ========================================

interface ToastOptionsConfig {
  message: string;
  duration?: number;
  position?: 'top' | 'middle' | 'bottom';
  color?: 'primary' | 'secondary' | 'tertiary' | 'success' | 'warning' | 'danger' | 'light' | 'medium' | 'dark';
  showCloseButton?: boolean;
  closeButtonText?: string;
  cssClass?: string | string[];
  translucent?: boolean;
  animated?: boolean;
  icon?: string;
}

interface ToastResult {
  id: string;
  element: HTMLIonToastElement;
}

interface CloseToastOptions {
  id?: string;
  closeAll?: boolean;
}

interface CloseToastResult {
  closed: number;
  ids: string[];
}

// 오버로드 지원을 위한 타입들
type ToastInput = string | ToastOptionsConfig;

// ========================================
// Default 설정 관리
// ========================================

interface DefaultToastSettings {
  duration: number;
  position: 'top' | 'middle' | 'bottom';
  color: 'primary' | 'secondary' | 'tertiary' | 'success' | 'warning' | 'danger' | 'light' | 'medium' | 'dark';
  showCloseButton: boolean;
  closeButtonText: string;
  cssClass: string[];
  translucent: boolean;
  animated: boolean;
  icon: string;
}

/**
 * Toast 기본 설정
 */
const DEFAULT_TOAST_SETTINGS: DefaultToastSettings = {
  duration: 1500,
  position: 'bottom',
  color: 'medium',
  showCloseButton: false,
  closeButtonText: '닫기',
  cssClass: [],
  translucent: false,
  animated: true,
  icon: ''
};

/**
 * 현재 활성화된 Toast 인스턴스들을 추적하는 Set
 * WeakMap 대신 Set을 사용하는 이유: Toast ID 기반으로 찾기 위함
 */
const activeToasts = new Set<{ id: string; element: HTMLIonToastElement }>();

/**
 * Toast ID 생성을 위한 카운터
 */
let toastIdCounter = 0;

/**
 * 고유한 Toast ID 생성
 */
function generateToastId(): string {
  return `toast_${Date.now()}_${++toastIdCounter}`;
}

// ========================================
// 유틸리티 함수
// ========================================

/**
 * 메시지에서 \n을 <br> 태그로 변환
 * @param message 원본 메시지
 * @returns HTML 태그로 변환된 메시지
 */
function formatToastMessage(message: string): string {
  return message.replace(/\n/g, '<br>');
}

// ========================================
// 메인 컴포저블 함수
// ========================================

export function useToast() {
  /**
   * Toast 표시 (문자열 입력)
   * @param message 표시할 메시지
   * @returns Promise<ToastResult> Toast 정보
   */
  async function toast(message: string): Promise<ToastResult>;

  /**
   * Toast 표시 (옵션 객체 입력)
   * @param options Toast 옵션
   * @returns Promise<ToastResult> Toast 정보
   */
  async function toast(options: ToastOptionsConfig): Promise<ToastResult>;

  /**
   * Toast 표시 구현
   */
  async function toast(input: ToastInput): Promise<ToastResult> {
    // 입력 타입에 따라 옵션 구성
    const options: ToastOptionsConfig = typeof input === 'string'
      ? { message: input }
      : input;

    // 기본 설정과 병합
    const finalOptions: ToastOptionsConfig = {
      ...DEFAULT_TOAST_SETTINGS,
      ...options
    };

    // 메시지에서 \n을 <br>로 변환
    finalOptions.message = formatToastMessage(finalOptions.message);

    // Toast ID 생성
    const toastId = generateToastId();

    // Ionic Toast 옵션 구성
    const ionicOptions: ToastOptions = {
      message: finalOptions.message,
      duration: finalOptions.duration,
      position: finalOptions.position,
      color: finalOptions.color,
      translucent: finalOptions.translucent,
      animated: finalOptions.animated,
      cssClass: Array.isArray(finalOptions.cssClass)
        ? finalOptions.cssClass
        : finalOptions.cssClass ? [finalOptions.cssClass] : [],
      ...(finalOptions.icon && { icon: finalOptions.icon }),
      ...(finalOptions.showCloseButton && {
        buttons: [
          {
            text: finalOptions.closeButtonText,
            role: 'cancel'
          }
        ]
      })
    };

    try {
      // Toast 생성 및 표시
      const toastElement = await toastController.create(ionicOptions);

      // 활성 Toast Set에 추가
      const toastInfo = { id: toastId, element: toastElement };
      activeToasts.add(toastInfo);

      // Toast가 닫힐 때 Set에서 제거
      toastElement.addEventListener('didDismiss', () => {
        activeToasts.delete(toastInfo);
      });

      // Toast 표시
      await toastElement.present();

      return {
        id: toastId,
        element: toastElement
      };

    } catch (error) {
      console.error('Toast 표시 중 오류 발생:', error);
      throw error;
    }
  }

  /**
   * Toast 닫기
   * @param request 닫기 요청 (ID 지정 또는 전체 닫기)
   * @returns Promise<CloseToastResult> 닫기 결과
   */
  async function closeToast(request: CloseToastOptions = {}): Promise<CloseToastResult> {
    const { id, closeAll = false } = request;
    const closedIds: string[] = [];

    try {
      if (closeAll) {
        // 모든 Toast 닫기
        const toastsToClose = Array.from(activeToasts);

        for (const toastInfo of toastsToClose) {
          try {
            await toastInfo.element.dismiss();
            closedIds.push(toastInfo.id);
          } catch (error) {
            console.warn(`Toast ${toastInfo.id} 닫기 실패:`, error);
          }
        }
      } else if (id) {
        // 특정 ID의 Toast 닫기
        const toastInfo = Array.from(activeToasts).find(info => info.id === id);

        if (toastInfo) {
          await toastInfo.element.dismiss();
          closedIds.push(id);
        }
      } else {
        // 가장 최근 Toast 닫기
        const latestToast = Array.from(activeToasts).pop();

        if (latestToast) {
          await latestToast.element.dismiss();
          closedIds.push(latestToast.id);
        }
      }

      return {
        closed: closedIds.length,
        ids: closedIds
      };

    } catch (error) {
      console.error('Toast 닫기 중 오류 발생:', error);
      throw error;
    }
  }

  /**
   * Toast 기본 설정 변경
   * @param newSettings 새로운 기본 설정
   */
  function setToastDefaults(newSettings: Partial<DefaultToastSettings>): void {
    Object.assign(DEFAULT_TOAST_SETTINGS, newSettings);
  }

  /**
   * 현재 Toast 기본 설정 조회
   * @returns 현재 기본 설정 복사본
   */
  function getToastDefaults(): DefaultToastSettings {
    return { ...DEFAULT_TOAST_SETTINGS };
  }

  /**
   * 현재 활성화된 Toast 개수 조회
   * @returns 활성 Toast 개수
   */
  function getActiveToastCount(): number {
    return activeToasts.size;
  }

  /**
   * 현재 활성화된 Toast ID 목록 조회
   * @returns 활성 Toast ID 배열
   */
  function getActiveToastIds(): string[] {
    return Array.from(activeToasts).map(info => info.id);
  }

  return {
    toast,
    closeToast,
    setToastDefaults,
    getToastDefaults,
    getActiveToastCount,
    getActiveToastIds
  };
}
