/**
 * @namespace useMenu
 * @description
 * Ionic Menu 컴포저블
 *
 * **주요 기능:**
 * - Ionic menuController 활용한 Menu 제어
 * - 여러 Menu ID 지원
 * - Menu 상태 관리 및 토글 기능
 *
 * @returns {Object} Menu를 제어하는 API 객체
 * @property {function(string?): Promise<boolean>} openMenu Menu 열기
 * @property {function(string?): Promise<boolean>} closeMenu Menu 닫기
 * @property {function(string?): Promise<boolean>} toggleMenu Menu 토글
 * @property {function(string?): Promise<boolean>} isMenuOpen Menu 열림 상태 확인
 * @property {function(Partial<DefaultMenuSettings>): void} setMenuDefaults Menu 기본 설정 변경
 * @property {function(): DefaultMenuSettings} getMenuDefaults 현재 Menu 기본 설정 조회
 * @property {function(): number} getActiveMenuCount 현재 활성화된 Menu 개수 조회
 * @property {function(): string[]} getActiveMenuIds 현재 활성화된 Menu ID 목록 조회
 * @property {function(): Promise<boolean>} closeAllMenus 모든 Menu 닫기
 *
 * @remarks
 * **백버튼 처리:**
 * - Menu가 열려있을 때 백버튼으로 Menu 닫기 (7단계 백버튼 처리에 포함)
 *
 * **사용 준비사항:**
 * - 템플릿에 `<ion-menu>` 선언 필요
 * - menuId와 contentId 설정 필요
 *
 * @example
 * <caption><b>Menu 사용법</b></caption>
 *
 * ```typescript
 * // 1. 템플릿 구성 (개발자 책임)
 * <template>
 *   <ion-menu menu-id="main-menu" content-id="main-content">
 *     <ion-header>
 *       <ion-toolbar>
 *         <ion-title>Menu</ion-title>
 *       </ion-toolbar>
 *     </ion-header>
 *     <ion-content>
 *       <!-- 원하는 메뉴 내용 -->
 *     </ion-content>
 *   </ion-menu>
 *
 *   <ion-router-outlet id="main-content"></ion-router-outlet>
 * </template>
 *
 * // 2. 컴포저블 사용 (복사-붙여넣기 가능)
 * <script setup lang="ts">
 * import { useMenu } from '@bizMOB/vue';
 *
 * const { openMenu, closeMenu, toggleMenu, isMenuOpen } = useMenu();
 *
 * // 기본 Menu 제어 함수들
 * const handleOpenMenu = async () => {
 *   await openMenu();
 * };
 *
 * const handleCloseMenu = async () => {
 *   await closeMenu();
 * };
 *
 * const handleToggleMenu = async () => {
 *   await toggleMenu();
 * };
 *
 * // 특정 Menu 제어 (여러 Menu 사용 시)
 * const handleOpenSidebar = async () => {
 *   await openMenu('sidebar');
 * };
 *
 * const handleToggleSidebar = async () => {
 *   await toggleMenu('sidebar');
 * };
 *
 * // Menu 상태 확인
 * const checkMenuStatus = async () => {
 *   const isOpen = await isMenuOpen('main-menu');
 *   console.log('Menu 열림 상태:', isOpen);
 * };
 * </script>
 *
 * // 3. 템플릿에서 사용 (버튼 예시)
 * <template>
 *   <div>
 *     <ion-button @click="handleOpenMenu">메뉴 열기</ion-button>
 *     <ion-button @click="handleCloseMenu">메뉴 닫기</ion-button>
 *     <ion-button @click="handleToggleMenu">메뉴 토글</ion-button>
 *     <ion-button @click="checkMenuStatus">상태 확인</ion-button>
 *   </div>
 * </template>
 * ```
 */

import { menuController } from '@ionic/vue';
import { createMenuFocusManager } from '../utils/ionicFocusManager';

// ========================================
// 타입 정의
// ========================================

// ========================================
// 기본 설정 관리
// ========================================

interface DefaultMenuSettings {
  menuId: string;
  animated: boolean;
}

/**
 * Menu 기본 설정
 */
const DEFAULT_MENU_SETTINGS: DefaultMenuSettings = {
  menuId: 'main-menu',
  animated: true
};

/**
 * 현재 열려있는 Menu들을 추적하는 Set
 * 백버튼 처리를 위해 활성 Menu ID들을 관리
 */
const activeMenus = new Set<string>();

// ========================================
// 유틸리티 함수들
// ========================================

/**
 * Menu ID 정규화 (기본값 적용)
 */
function normalizeMenuId(menuId?: string): string {
  return menuId || DEFAULT_MENU_SETTINGS.menuId;
}

// ========================================
// 백버튼 연동 함수 (useApp.backButton.ts에서 사용)
// ========================================

/**
 * 현재 열려있는 Menu 목록을 반환하는 함수
 * useApp.backButton.ts에서 호출됨
 */
export const getActiveMenus = (): string[] => {
  return Array.from(activeMenus);
};

/**
 * 가장 최근에 열린 Menu를 닫는 함수
 * useApp.backButton.ts에서 호출됨
 */
export const closeLatestMenu = async (): Promise<boolean> => {
  if (activeMenus.size === 0) {
    return false;
  }

  // 가장 최근 Menu (Set의 마지막 요소)
  const menusArray = Array.from(activeMenus);
  const latestMenuId = menusArray[menusArray.length - 1];

  try {
    const result = await menuController.close(latestMenuId);
    if (result) {
      activeMenus.delete(latestMenuId);
    }
    return result;
  } catch (error) {
    console.error(`[useMenu] 최근 Menu ${latestMenuId} 닫기 실패:`, error);
    return false;
  }
};

// ========================================
// 메인 컴포저블 함수
// ========================================

export function useMenu() {
  // 포커스 매니저
  const menuFocus = createMenuFocusManager();

  /**
   * Menu 열기
   * @param menuId Menu ID (선택사항, 기본값: 'main-menu')
   * @returns Promise<boolean> 성공 여부
   */
  async function openMenu(menuId?: string): Promise<boolean> {
    const normalizedMenuId = normalizeMenuId(menuId);

    try {
      // 메뉴 오픈전 포커스 저장
      menuFocus.saveBeforeOpen();
      const result = await menuController.open(normalizedMenuId);

      if (result) {
        // 성공적으로 열린 Menu를 활성 목록에 추가
        activeMenus.add(normalizedMenuId);
      }

      return result;
    } catch (error) {
      console.error(`[useMenu] Menu ${normalizedMenuId} 열기 실패:`, error);
      return false;
    }
  }

  /**
   * Menu 닫기
   * @param menuId Menu ID (선택사항, 기본값: 'main-menu')
   * @returns Promise<boolean> 성공 여부
   */
  async function closeMenu(menuId?: string): Promise<boolean> {
    const normalizedMenuId = normalizeMenuId(menuId);

    try {
      const result = await menuController.close(normalizedMenuId);
      // 메뉴 닫히고 포커스 복원
      menuFocus.restoreAfterClose();

      if (result) {
        // 성공적으로 닫힌 Menu를 활성 목록에서 제거
        activeMenus.delete(normalizedMenuId);
      }

      return result;
    } catch (error) {
      console.error(`[useMenu] Menu ${normalizedMenuId} 닫기 실패:`, error);
      return false;
    }
  }  /**
   * Menu 토글 (열림/닫힘 상태 전환)
   * @param menuId Menu ID (선택사항, 기본값: 'main-menu')
   * @returns Promise<boolean> 성공 여부
   */
  async function toggleMenu(menuId?: string): Promise<boolean> {
    const normalizedMenuId = normalizeMenuId(menuId);

    try {
      const result = await menuController.toggle(normalizedMenuId);

      // 토글 후 현재 상태를 확인하여 활성 목록 업데이트
      const isCurrentlyOpen = await menuController.isOpen(normalizedMenuId);

      if (isCurrentlyOpen) {
        activeMenus.add(normalizedMenuId);
      } else {
        activeMenus.delete(normalizedMenuId);
      }

      return result;
    } catch (error) {
      console.error(`[useMenu] Menu ${normalizedMenuId} 토글 실패:`, error);
      return false;
    }
  }

  /**
   * Menu 열림 상태 확인
   * @param menuId Menu ID (선택사항, 기본값: 'main-menu')
   * @returns Promise<boolean> 열림 상태
   */
  async function isMenuOpen(menuId?: string): Promise<boolean> {
    const normalizedMenuId = normalizeMenuId(menuId);

    try {
      return await menuController.isOpen(normalizedMenuId);
    } catch (error) {
      console.error(`[useMenu] Menu ${normalizedMenuId} 상태 확인 실패:`, error);
      return false;
    }
  }

  /**
   * Menu 기본 설정 변경
   * @param newSettings 새로운 기본 설정
   */
  function setMenuDefaults(newSettings: Partial<DefaultMenuSettings>): void {
    Object.assign(DEFAULT_MENU_SETTINGS, newSettings);
  }

  /**
   * 현재 Menu 기본 설정 조회
   * @returns 현재 기본 설정 복사본
   */
  function getMenuDefaults(): DefaultMenuSettings {
    return { ...DEFAULT_MENU_SETTINGS };
  }

  /**
   * 현재 활성화된 Menu 개수 조회
   * @returns 활성 Menu 개수
   */
  function getActiveMenuCount(): number {
    return activeMenus.size;
  }

  /**
   * 현재 활성화된 Menu ID 목록 조회
   * @returns 활성 Menu ID 배열
   */
  function getActiveMenuIds(): string[] {
    return Array.from(activeMenus);
  }

  /**
   * 모든 Menu 닫기
   * @returns Promise<boolean> 성공 여부
   */
  async function closeAllMenus(): Promise<boolean> {
    try {
      let allClosed = true;
      const menusToClose = Array.from(activeMenus);

      for (const menuId of menusToClose) {
        try {
          const result = await menuController.close(menuId);
          if (result) {
            activeMenus.delete(menuId);
          } else {
            allClosed = false;
          }
        } catch (error) {
          console.warn(`[useMenu] Menu ${menuId} 닫기 실패:`, error);
          allClosed = false;
        }
      }

      return allClosed;
    } catch (error) {
      console.error('[useMenu] 모든 Menu 닫기 실패:', error);
      return false;
    }
  }

  return {
    openMenu,
    closeMenu,
    toggleMenu,
    isMenuOpen,
    setMenuDefaults,
    getMenuDefaults,
    getActiveMenuCount,
    getActiveMenuIds,
    closeAllMenus
  };
}
