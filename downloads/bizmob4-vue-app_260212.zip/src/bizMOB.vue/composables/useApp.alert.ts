/**
 * @namespace useAlert
 * @description
 * Ionic Alert 컴포저블
 *
 * **주요 기능:**
 * - Ionic alertController 활용한 Alert 표시/닫기
 * - preventBackButton 옵션으로 백버튼 차단 제어
 * - WeakMap을 사용한 Alert별 백버튼 설정 관리
 * - Default 설정 변경함수를 제공하여 취소/확인 버튼의 글자, preventBackButton, titleAlign, textAlign, cssClass 의 Default을 변경 가능
 * - ionicFocusManager를 통한 단순 포커스 제거 (aria-hidden 경고 방지)
 *
 * @returns {Object} 다이얼로그를 제어하는 API 객체
 * @property {function(string | AlertHandler | AlertOptions): Promise<boolean>} alert ionic alertController를 통해서 alert을 표시하는 함수
 * @property {function(string | AlertHandler | AlertOptions): Promise<boolean>} confirm ionic alertController를 통해서 confirm을 표시하는 함수
 * @property {function(Partial<DefaultSettings>): void} setAlertDefaults Default 설정 변경 함수
 * @property {function(): Readonly<DefaultSettings>} getAlertDefaults Default 설정 조회 함수
 *
 * @remarks
 * **백버튼 처리(./useApp.backButton.ts 에서 통합 관리):**
 * - preventBackButton: true → 백버튼 차단
 * - preventBackButton: false/undefined → 백버튼 허용 (Alert이 자동으로 닫힘)
 *
 * @example
 * <caption><b>Alert 사용법</b></caption>
 * ```typescript
 * import { useAlert } from '@bizMOB/vue';
 *
 * const { alert } = useAlert();
 *
 * // 1. 간단한 알림
 * const result = await alert('저장되었습니다');
 *
 * // 2. 줄바꿈이 포함된 알림
 * const result = await alert('저장되었습니다.\n잠시만 기다려 주세요');
 *
 * // 3. 간단한 알림 + 버튼 핸들러
 * const result = await alert('저장되었습니다', () => {
 *   console.log('사용자가 확인을 클릭했습니다');
 *   return true;
 * });
 *
 * // 4. 옵션 전체 적용
 * const result = await alert({
 *   title: '알림',
 *   message: '왼쪽 정렬 메시지입니다.\n두 번째 줄입니다',
 *   buttons: [
 *     {
 *       text: '확인',
 *       handler: () => {
 *         console.log('사용자가 확인을 클릭했습니다');
 *         return true;
 *       }
 *     }
 *   ],
 *   style: {
 *     titleAlign: 'left',
 *     textAlign: 'left',
 *     cssClass: 'custom-alert'
 *   },
 *   preventBackButton: true, // 백버튼 막기
 * });
 * ```
 *
 * @example
 * <caption><b>Confirm 사용법</b></caption>
 *
 * ```typescript
 * import { useAlert } from '@bizMOB/vue';
 *
 * const { confirm } = useAlert();
 *
 * // 1. 간단한 확인
 * const result = await confirm('정말 삭제하시겠습니까?');
 * if (result) {
 *   // 확인 선택됨
 *   deleteItem();
 * }
 *
 * // 2. 줄바꿈이 포함된 확인
 * const result = await confirm('정말 삭제하시겠습니까?\n삭제된 데이터는 복구할 수 없습니다');
 * if (result) {
 *   deleteItem();
 * }
 *
 * // 3. 간단한 확인 + 버튼 핸들러
 * const result = await confirm('정말 삭제하시겠습니까?', () => {
 *   console.log('사용자가 확인을 클릭했습니다');
 *   return true;
 * });
 * if (result) {
 *   // 확인 선택됨
 *   deleteItem();
 * }
 *
 * // 4. 옵션 전체 적용
 * const result = await confirm({
 *   title: '로그아웃',
 *   message: '정말 로그아웃 하시겠습니까?\n현재 작업 중인 내용이 저장되지 않을 수 있습니다',
 *   buttons: [
 *     {
 *       text: '취소',
 *       handler: () => {
 *         console.log('취소됨');
 *         return false;
 *       }
 *     },
 *     {
 *       text: '로그아웃',
 *       handler: () => {
 *         performLogout();
 *         return true;
 *       }
 *     }
 *   ],
 *   style: {
 *     titleAlign: 'left',
 *     textAlign: 'left',
 *     cssClass: 'custom-alert'
 *   },
 *   preventBackButton: true, // 백버튼 막기
 * });
 * ```
 */

import { alertController } from '@ionic/vue';
import { withAlertFocus } from '../utils/ionicFocusManager';

// ========================================
// 타입 정의
// ========================================

interface AlertStyle {
  titleAlign?: 'left' | 'center' | 'right';
  textAlign?: 'left' | 'center' | 'right';
  cssClass?: string;
}

interface AlertButton {
  text?: string;
  role?: string;
  cssClass?: string;
  handler?: () => boolean | void | Promise<boolean | void>;
}

interface AlertOptions {
  title?: string;
  message?: string;
  buttons?: AlertButton[];
  style?: AlertStyle;
  preventBackButton?: boolean;
}

// 오버로드 지원을 위한 타입들
type AlertHandler = (result?: any) => boolean | void | Promise<boolean | void>;
type AlertInput = string | AlertHandler | AlertOptions;
type ConfirmInput = string | AlertHandler | AlertOptions;

// ========================================
// Default 설정 관리
// ========================================

interface DefaultSettings {
  confirmText: string;
  cancelText: string;
  preventBackButton: boolean;
  titleAlign: 'left' | 'center' | 'right';
  textAlign: 'left' | 'center' | 'right';
  cssClass: string;
}

const defaultSettings: DefaultSettings = {
  confirmText: '확인',
  cancelText: '취소',
  preventBackButton: false,
  titleAlign: 'center',
  textAlign: 'center',
  cssClass: ''
};

// ========================================
// WeakMap 기반 백버튼 설정 관리
// ========================================

// Alert 인스턴스별 백버튼 설정 추적
const alertBackButtonSettings = new WeakMap<HTMLIonAlertElement, boolean>();

/**
 * 현재 활성화된 Alert 인스턴스 (우리가 관리하는 Alert만)
 */
let currentAlert: HTMLIonAlertElement | null = null;

// ========================================
// 유틸리티 함수들
// ========================================

/**
 * 메시지에서 \n을 <br> 태그로 변환
 * @param message 원본 메시지
 * @returns HTML 태그로 변환된 메시지
 */
function formatAlertMessage(message: string): string {
  return message.replace(/\n/g, '<br>');
}

/**
 * 입력 파라미터를 AlertOptions로 정규화
 */
const normalizeAlertInput = (input: AlertInput, isConfirm: boolean = false): AlertOptions => {
  if (typeof input === 'string') {
    // 문자열인 경우 - 줄바꿈 변환 적용
    return {
      message: formatAlertMessage(input),
      preventBackButton: defaultSettings.preventBackButton
    };
  }

  if (typeof input === 'function') {
    // 핸들러 함수인 경우
    return {
      message: '',
      buttons: [{
        text: defaultSettings.confirmText,
        handler: input
      }],
      preventBackButton: defaultSettings.preventBackButton
    };
  }

  // 객체인 경우 - default 설정과 병합하고 메시지 변환 적용
  const normalizedOptions = {
    ...input,
    preventBackButton: input.preventBackButton ?? defaultSettings.preventBackButton
  };

  // 메시지가 있으면 줄바꿈 변환 적용
  if (normalizedOptions.message) {
    normalizedOptions.message = formatAlertMessage(normalizedOptions.message);
  }

  return normalizedOptions;
};

/**
 * Confirm용 버튼 배열 생성
 */
const createConfirmButtons = (options: AlertOptions): AlertButton[] => {
  if (options.buttons && options.buttons.length > 0) {
    // 이미 버튼이 정의된 경우, 첫 번째 버튼에 role이 없으면 'cancel' 추가
    const buttons = [...options.buttons];

    // 첫 번째 버튼에 role이 없으면 'cancel' 역할 추가
    if (buttons[0] && !buttons[0].role) {
      buttons[0] = { ...buttons[0], role: 'cancel' };
    }

    return buttons;
  }

  // 기본 취소/확인 버튼 생성
  return [
    {
      text: defaultSettings.cancelText,
      role: 'cancel',
      handler: () => false
    },
    {
      text: defaultSettings.confirmText,
      handler: () => true
    }
  ];
};

/**
 * Ionic Alert 설정 객체 생성
 */
const createIonicAlertConfig = (options: AlertOptions) => {
  const config: any = {};

  // 기본 속성들
  if (options.title) config.header = options.title;
  if (options.message) config.message = options.message;

  // 버튼 설정 (핸들러 래핑)
  if (options.buttons) {
    config.buttons = options.buttons.map(button => ({
      ...button,
      handler: button.handler ? async () => {
        try {
          const result = await button.handler!();
          return result;
        } catch (error) {
          console.error('[useAlert] 버튼 핸들러 오류:', error);
          return false;
        }
      } : undefined
    }));
  }

  // 스타일 설정
  if (options.style) {
    const cssClasses = [];

    // CSS 클래스 추가
    if (options.style.cssClass) {
      cssClasses.push(options.style.cssClass);
    }
    if (defaultSettings.cssClass) {
      cssClasses.push(defaultSettings.cssClass);
    }

    // 정렬 클래스 추가
    const titleAlign = options.style.titleAlign || defaultSettings.titleAlign;
    const textAlign = options.style.textAlign || defaultSettings.textAlign;

    if (titleAlign !== 'center') {
      cssClasses.push(`alert-title-${titleAlign}`);
    }
    if (textAlign !== 'center') {
      cssClasses.push(`alert-text-${textAlign}`);
    }

    if (cssClasses.length > 0) {
      config.cssClass = cssClasses.join(' ');
    }
  }

  return config;
};

// ========================================
// 백버튼 연동 함수 (useApp.backButton.ts에서 사용)
// ========================================

/**
 * 현재 활성화된 Alert이 있는지 확인하는 함수
 * useApp.backButton.ts에서 호출됨
 *
 * @returns {HTMLIonAlertElement | null} 활성화된 Alert 엘리먼트 또는 null
 */
export const getActiveAlert = (): HTMLIonAlertElement | null => {
  return currentAlert;
};

/**
 * 현재 활성화된 Alert의 백버튼 설정을 확인하는 함수
 * useApp.backButton.ts에서 호출됨
 *
 * @returns {{enabled: boolean, alert: HTMLIonAlertElement | null}} 백버튼 설정과 Alert 정보
 */
export const getActiveAlertBackButtonSetting = (): {
  enabled: boolean;
  alert: HTMLIonAlertElement | null;
} => {
  const activeAlert = getActiveAlert();

  if (!activeAlert) {
    return { enabled: false, alert: null };
  }

  const enabled = alertBackButtonSettings.get(activeAlert) ?? false;
  return { enabled, alert: activeAlert };
};

// ========================================
// 메인 컴포저블 함수
// ========================================

export function useAlert() {
  const alert = async (input: AlertInput): Promise<boolean> => {
    let alertElement: HTMLIonAlertElement | null = null;

    try {
      // 1. 입력 파라미터 정규화
      const options = normalizeAlertInput(input, false);

      // 2. 기본 버튼이 없으면 확인 버튼 추가
      if (!options.buttons || options.buttons.length === 0) {
        options.buttons = [{
          text: defaultSettings.confirmText,
          handler: () => true
        }];
      }

      // 3. Ionic Alert 설정 생성
      const alertConfig = createIonicAlertConfig(options);

      // 4. Alert 생성 및 표시 (단순 포커스 제거만)
      alertElement = await withAlertFocus(
        alertController.create(alertConfig),
        { debug: false }
      );

      // 5. 현재 Alert 설정
      currentAlert = alertElement;

      // 6. WeakMap에 백버튼 설정 저장
      alertBackButtonSettings.set(alertElement, options.preventBackButton || false);

      // 7. Alert가 닫힐 때 정리
      alertElement.addEventListener('didDismiss', () => {
        if (currentAlert === alertElement) {
          currentAlert = null;
        }
        // WeakMap에서 백버튼 설정 제거 (메모리 해제)
        alertBackButtonSettings.delete(alertElement!);
      });

      // 8. Alert 표시
      await alertElement.present();

      // 9. 사용자 응답 대기
      const { role, data } = await alertElement.onDidDismiss();

      // 10. 핸들러 실행 결과 반환
      if (role === 'cancel' || role === 'backdrop') {
        return false;
      }

      // 버튼의 핸들러에서 반환된 값 확인
      return data !== false;

    } catch (error) {
      console.error('[useAlert] alert 오류:', error);
      // 에러 발생 시에도 정리 시도
      try {
        if (alertElement) {
          if (currentAlert === alertElement) {
            currentAlert = null;
          }
          alertBackButtonSettings.delete(alertElement);
        }
      } catch (cleanupError) {
        console.warn('[useAlert] 정리 중 오류:', cleanupError);
      }
      return false;
    }
  };

  const confirm = async (input: ConfirmInput): Promise<boolean> => {
    let alertElement: HTMLIonAlertElement | null = null;

    try {
      // 1. 입력 파라미터 정규화
      const options = normalizeAlertInput(input, true);

      // 2. Confirm용 버튼 생성
      options.buttons = createConfirmButtons(options);

      // 3. Ionic Alert 설정 생성
      const alertConfig = createIonicAlertConfig(options);

      // 4. Alert 생성 및 표시 (단순 포커스 제거만)
      alertElement = await withAlertFocus(
        alertController.create(alertConfig),
        { debug: false }
      );

      // 5. 현재 Alert 설정
      currentAlert = alertElement;

      // 6. WeakMap에 백버튼 설정 저장
      alertBackButtonSettings.set(alertElement, options.preventBackButton || false);

      // 7. Alert가 닫힐 때 정리
      alertElement.addEventListener('didDismiss', () => {
        if (currentAlert === alertElement) {
          currentAlert = null;
        }
        // WeakMap에서 백버튼 설정 제거 (메모리 해제)
        alertBackButtonSettings.delete(alertElement!);
      });

      // 8. Alert 표시
      await alertElement.present();

      // 9. 사용자 응답 대기
      const { role, data } = await alertElement.onDidDismiss();

      // 10. 결과 반환 (확인: true, 취소: false)
      if (role === 'cancel' || role === 'backdrop') {
        return false;
      }

      // 버튼의 핸들러에서 반환된 값이 명시적으로 false가 아니면 true
      return data !== false;

    } catch (error) {
      console.error('[useAlert] confirm 오류:', error);
      // 에러 발생 시에도 정리 시도
      try {
        if (alertElement) {
          if (currentAlert === alertElement) {
            currentAlert = null;
          }
          alertBackButtonSettings.delete(alertElement);
        }
      } catch (cleanupError) {
        console.warn('[useAlert] 정리 중 오류:', cleanupError);
      }
      return false;
    }
  };

  /**
   * Default 설정 변경 함수
   */
  const setAlertDefaults = (settings: Partial<DefaultSettings>): void => {
    Object.assign(defaultSettings, settings);
  };

  /**
   * 현재 Default 설정 조회 함수
   */
  const getAlertDefaults = (): Readonly<DefaultSettings> => {
    return { ...defaultSettings };
  };

  return {
    alert,
    confirm,
    setAlertDefaults,
    getAlertDefaults
  };
}
