/**
 * 포커스 관리 옵션
 */
export interface FocusOptions {
  // 디버그 로그 활성화
  debug?: boolean
}

/**
 * 현재 포커스 해제 (aria-hidden 경고 방지)
 * 오버레이가 표시되기 전에 현재 포커스를 안전하게 해제
 */
export function clearCurrentFocus(options: FocusOptions = {}): void {
  const { debug = false } = options;

  const currentElement = document.activeElement as HTMLElement;

  if (currentElement &&
    currentElement !== document.body &&
    typeof currentElement.blur === 'function') {

    if (debug) {
      console.log('[FocusManager] Clearing focus from:', currentElement);
    }

    currentElement.blur();
  }
}

/**
 * 프로젝트별 포커스 복원 함수 (확장 가능)
 * 기본적으로는 아무것도 하지 않음
 * 필요한 경우 개별 프로젝트에서 이 함수를 오버라이드하여 사용
 */
export function restoreFocus(options: FocusOptions = {}): void {
  const { debug = false } = options;

  if (debug) {
    console.log('[FocusManager] restoreFocus called - no default implementation');
  }

  // 기본 구현: 아무것도 하지 않음
  // 프로젝트에서 필요한 경우 이 함수를 오버라이드하여 사용
}

/**
 * Modal 포커스 관리 (단순화)
 * Modal 표시 전 현재 포커스 제거, 닫힌 후 프로젝트별 복원 로직 실행
 */
export function withModalFocus<T = any>(
  modalPromise: Promise<T>,
  options?: FocusOptions
): Promise<T> {
  // Modal 표시 전 현재 포커스 제거
  clearCurrentFocus(options);

  return modalPromise.then(modal => {
    // Modal이 닫힐 때 프로젝트별 복원 로직 실행
    (modal as any).onDidDismiss?.().then(() => {
      restoreFocus(options);
    });
    return modal;
  });
}

/**
 * Popover 포커스 관리 (단순화)
 * Popover 표시 전 현재 포커스 제거, 닫힌 후 프로젝트별 복원 로직 실행
 */
export function withPopoverFocus<T = any>(
  popoverPromise: Promise<T>,
  options?: FocusOptions
): Promise<T> {
  // Popover 표시 전 현재 포커스 제거
  clearCurrentFocus(options);

  return popoverPromise.then(popover => {
    // Popover가 닫힐 때 프로젝트별 복원 로직 실행
    (popover as any).onDidDismiss?.().then(() => {
      restoreFocus(options);
    });
    return popover;
  });
}

/**
 * Action Sheet 포커스 관리 (단순화)
 * ActionSheet 표시 전 현재 포커스 제거, 닫힌 후 프로젝트별 복원 로직 실행
 */
export function withActionSheetFocus<T = any>(
  actionSheetPromise: Promise<T>,
  options?: FocusOptions
): Promise<T> {
  // ActionSheet 표시 전 현재 포커스 제거
  clearCurrentFocus(options);

  return actionSheetPromise.then(actionSheet => {
    // ActionSheet가 닫힐 때 프로젝트별 복원 로직 실행
    (actionSheet as any).onDidDismiss?.().then(() => {
      restoreFocus(options);
    });
    return actionSheet;
  });
}

/**
 * Alert 포커스 관리 (단순화)
 * Alert 표시 전 현재 포커스 제거, 닫힌 후 프로젝트별 복원 로직 실행
 */
export function withAlertFocus<T = any>(
  alertPromise: Promise<T>,
  options?: FocusOptions
): Promise<T> {
  // Alert 표시 전 현재 포커스 제거
  clearCurrentFocus(options);

  return alertPromise.then(alert => {
    // Alert가 닫힐 때 프로젝트별 복원 로직 실행
    (alert as any).onDidDismiss?.().then(() => {
      restoreFocus(options);
    });
    return alert;
  });
}

/**
 * Menu 포커스 관리 (단순화)
 * Menu 열기/닫기 시 프로젝트별 포커스 관리 로직 실행
 */
export function createMenuFocusManager(options?: FocusOptions) {
  return {
    // 메뉴 열기 전 호출 - 현재 포커스 제거
    saveBeforeOpen(): void {
      clearCurrentFocus(options);
    },

    // 메뉴 닫기 후 호출 - 프로젝트별 복원 로직 실행
    restoreAfterClose(): void {
      restoreFocus(options);
    }
  };
}

/**
 * 일반적인 오버레이 포커스 관리 (단순화)
 * 오버레이 표시 전 현재 포커스 제거, 닫힌 후 프로젝트별 복원 로직 실행
 */
export function withOverlayFocus<T = any>(
  overlayPromise: Promise<T>,
  options?: FocusOptions
): Promise<T> {
  // 오버레이 표시 전 현재 포커스 제거
  clearCurrentFocus(options);

  return overlayPromise.then(overlay => {
    // onDidDismiss가 있는 경우에만 처리
    if (typeof (overlay as any).onDidDismiss === 'function') {
      (overlay as any).onDidDismiss().then(() => {
        restoreFocus(options);
      });
    }
    return overlay;
  });
}

/**
 * ============================================
 * 사용 가이드 및 프로젝트별 확장 방법
 * ============================================
 *
 * 이 포커스 매니저는 단순하게 현재 포커스를 제거하는 역할만 합니다.
 * 프로젝트별로 필요한 포커스 복원 로직은 restoreFocus() 함수를 오버라이드하여 구현하세요.
 *
 * @example 기본 사용법 (현재 포커스 제거만)
 * ```typescript
 * // Modal 열기 전 포커스 제거
 * export function useModal() {
 *   const openModal = async (component: any) => {
 *     const modal = await withModalFocus(
 *       modalController.create({ component }),
 *       { debug: true }  // 디버그 옵션만 제공
 *     )
 *     return await modal.present()
 *   }
 * }
 * ```
 *
 * @example 프로젝트별 포커스 복원 로직 구현
 * ```typescript
 * // 1. 전역 포커스 복원 로직 오버라이드
 * import { restoreFocus as originalRestoreFocus } from './ionicFocusManager'
 *
 * // 프로젝트 전용 포커스 복원 로직
 * export function setupProjectFocusManager() {
 *   // restoreFocus 함수 오버라이드
 *   window.customRestoreFocus = (options = {}) => {
 *     const { debug = false } = options
 *
 *     if (debug) {
 *       console.log('[ProjectFocus] 프로젝트별 포커스 복원 실행')
 *     }
 *
 *     // 프로젝트별 로직 구현
 *     const fallbackSelectors = [
 *       'ion-tab-button.tab-selected',
 *       'ion-back-button',
 *       'ion-button',
 *       'button'
 *     ]
 *
 *     for (const selector of fallbackSelectors) {
 *       const element = document.querySelector(selector)
 *       if (element && element.offsetParent !== null) {
 *         setTimeout(() => element.focus(), 100)
 *         break
 *       }
 *     }
 *   }
 * }
 *
 * // 2. 컴포넌트별 개별 포커스 관리
 * export function useCustomModal() {
 *   const openModalWithCustomFocus = async (component: any, targetElement?: HTMLElement) => {
 *     // 현재 포커스 저장
 *     const savedElement = document.activeElement as HTMLElement
 *
 *     // Modal 열기 (기본 포커스 제거)
 *     const modal = await withModalFocus(
 *       modalController.create({ component })
 *     )
 *
 *     // Modal 닫힌 후 커스텀 복원
 *     modal.onDidDismiss().then(() => {
 *       if (targetElement && targetElement.offsetParent !== null) {
 *         setTimeout(() => targetElement.focus(), 100)
 *       } else if (savedElement && savedElement !== document.body) {
 *         setTimeout(() => savedElement.focus(), 100)
 *       }
 *     })
 *
 *     return await modal.present()
 *   }
 * }
 *
 * // 3. 수동 포커스 관리
 * export function useManualFocus() {
 *   const openWithManualFocus = async () => {
 *     // 수동으로 포커스 제거
 *     clearCurrentFocus({ debug: true })
 *
 *     // 커스텀 오버레이 로직
 *     await someCustomOverlay.open()
 *
 *     // 수동으로 포커스 복원
 *     someCustomOverlay.onClose(() => {
 *       const targetElement = document.querySelector('#my-target-element')
 *       if (targetElement) {
 *         setTimeout(() => targetElement.focus(), 100)
 *       }
 *     })
 *   }
 * }
 * ```
 *
 * @summary 핵심 철학
 * - ionicFocusManager: 단순히 현재 포커스 제거만 담당 (aria-hidden 경고 방지)
 * - 프로젝트별 확장: restoreFocus() 오버라이드 또는 개별 컴포넌트에서 커스텀 로직 구현
 * - 유연성: 필요에 따라 전역/컴포넌트별/수동 방식 선택 가능
 */
