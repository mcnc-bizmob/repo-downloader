# 📘 Types 폴더 사용법 가이드

## 🎯 **타입 정의 방식 통일**

모든 타입 파일은 **직접 export** 방식을 사용합니다.

### ✅ **올바른 방식: 직접 export**

```typescript
// types/example.d.ts
export interface User {
  id: string;
  name: string;
}

export type UserRole = 'admin' | 'user';
```

### ❌ **피해야 할 방식: namespace + export =**

```typescript
// 이 방식은 사용하지 않습니다
declare namespace Example {
  interface User { ... }
}
export = Example;
```

## 📁 **파일 구조 및 역할**

### 1. `type.d.ts` - 전역 공통 타입 (⭐ 자동 사용 가능)

```typescript
// ✨ import 없이 바로 사용 가능!
const config: Json = {
  theme: 'dark',
  language: 'ko'
};

const userId: ID = '12345';
const emptyData: EmptyObject = {};
```

### 2. `loading.d.ts` - 로딩 관련 타입

```typescript
import type { LoadingTask, LoadingTaskType } from '@/types/loading';

// 사용 예시
const task: LoadingTask = {
  id: 'task-1',
  startTime: new Date(),
  type: 'api',
  description: '사용자 정보 로드 중...'
};
```

### 3. `api.d.ts` - API 통신 관련 타입
```typescript
import type { ApiConfig, ApiResponse } from '@/types/api';

// 사용 예시
const config: ApiConfig = {
  method: 'POST',
  url: '/api/users',
  data: { name: '홍길동' }
};

const response: ApiResponse<User> = {
  data: { id: '1', name: '홍길동' },
  status: 200,
  success: true
};
```

### 3. `type.d.ts` - 공통 유틸리티 타입
```typescript
import type { Json } from '@/types/type';

// 사용 예시
const config: Json = {
  theme: 'dark',
  language: 'ko'
};
```

### 4. `component.d.ts` - Vue 전역 컴포넌트 타입
```vue
<!-- 사용 예시: import 없이 바로 사용 가능 -->
<template>
  <ion-page>
    <ion-header>헤더</ion-header>
    <ion-content>내용</ion-content>
  </ion-page>
</template>
```

## 🚀 **사용법**

### **타입 사용 방식**

```typescript
// ⭐ 전역 타입 (import 불필요)
const config: Json = { theme: 'dark' };
const userId: ID = 123;
const empty: EmptyObject = {};

// 📦 개별 타입 (import 필요)
import type { LoadingTask } from '@/types/loading';
import type { ApiResponse } from '@/types/api';

const task: LoadingTask = { ... };
const response: ApiResponse<string> = { ... };
```

### **Import 방식 (도메인별 타입)**

```typescript
// 개별 import (권장)
import type { LoadingTask } from '@/types/loading';
import type { ApiResponse } from '@/types/api';

// 다중 import
import type {
  LoadingTask,
  LoadingTaskType,
  LoadingApiOptions
} from '@/types/loading';
```

### **타입 가드 사용**

```typescript
import type { ApiResponse, ApiErrorResponse } from '@/types/api';

function isApiError(response: any): response is ApiErrorResponse {
  return response && typeof response.message === 'string';
}
```

## 📝 **새 타입 추가 규칙**

### **1. 파일명 규칙**
- `*.d.ts` 확장자 사용
- kebab-case 명명: `user-profile.d.ts`

### **2. 타입명 규칙**
- Interface: PascalCase `UserProfile`
- Type: PascalCase `UserRole`
- 접두사 없이 명확한 이름 사용

### **3. 문서화 규칙**
```typescript
/**
 * 사용자 프로필 정보
 */
export interface UserProfile {
  /** 사용자 고유 ID */
  id: string;
  /** 사용자 이름 */
  name: string;
  /** 이메일 주소 (선택사항) */
  email?: string;
}
```

### **4. 파일 구조**
```typescript
// types/user.d.ts
// 사용자 관련 타입 정의

// 기본 인터페이스들
export interface User { ... }
export interface UserProfile { ... }

// 유니온 타입들
export type UserRole = 'admin' | 'user';
export type UserStatus = 'active' | 'inactive';

// 유틸리티 타입들
export type CreateUserRequest = Omit<User, 'id'>;
export type UpdateUserRequest = Partial<User>;
```

## ⚠️ **주의사항**

1. **namespace 사용 금지**: `declare namespace` 방식 사용 안 함
2. **export = 사용 금지**: 직접 export만 사용
3. **명확한 이름**: 타입명만 봐도 용도가 명확해야 함
4. **JSDoc 필수**: 모든 public 타입에 설명 추가

## 🎉 **장점**

- ✅ **IDE 지원 우수**: 자동완성, 타입 추론 완벽
- ✅ **학습 곡선 낮음**: 일반 JS 모듈과 동일한 패턴
- ✅ **명확한 의존성**: import 구문으로 명확한 관계
- ✅ **Tree-shaking**: 사용하지 않는 타입은 제외
