// types/type.d.ts
// 프로젝트 전역에서 자동으로 사용할 수 있는 공통 타입 정의

/**
 * JSON 값을 나타내는 타입
 * - 문자열, 숫자, 불린, null, 배열, 객체를 포함
 * - 전역에서 import 없이 사용 가능
 */
declare type Json = { [key: string]: any };

/**
 * 객체의 키 타입 (문자열, 숫자, 심볼)
 * - 전역에서 import 없이 사용 가능
 */
declare type ObjectKey = string | number | symbol;

/**
 * 빈 객체 타입
 * - 전역에서 import 없이 사용 가능
 */
declare type EmptyObject = Record<string, never>;

/**
 * 문자열 또는 숫자 ID 타입
 * - 전역에서 import 없이 사용 가능
 */
declare type ID = string | number;

/**
 * 옵셔널 콜백 함수 타입
 * - 전역에서 import 없이 사용 가능
 */
declare type OptionalCallback<T = void> = ((value: T) => void) | undefined;

// ===== 특정 도메인 타입들은 개별 파일에서 export 방식 사용 =====
// 전역 타입은 정말 공통적이고 자주 사용되는 것들만 여기에 정의
// 예: loading, api 관련 타입들은 각각의 파일에서 import 해서 사용
