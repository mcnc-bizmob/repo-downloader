export default class Database {
  /** DataBase Transaction 시작 */
  static beginTransaction(arg?: {
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.beginTransaction({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** DataBase Close */
  static closeDatabase(arg?: {
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.closeDatabase({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** DataBase Transaction Commit */
  static commitTransaction(arg?: {
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.commitTransaction({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** DataBase Transaction Commit */
  static executeBatchSql(arg: {
    _sQuery: string, // SQL 쿼리문
    _aBindingValues?: string, // SQL 쿼리문의 바인딩 값
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.executeBatchSql({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** SELECT SQL 쿼리문을 실행 */
  static executeSelect(arg: {
    _sQuery: string, // SQL 쿼리문
    _aBindingValues?: string, // SQL 쿼리문의 바인딩 값
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.executeSelect({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** SQL쿼리문을 실행 */
  static executeSql(arg: {
    _sQuery: string, // SQL 쿼리문
    _aBindingValues?: string, // SQL 쿼리문의 바인딩 값
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.executeSql({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** DataBase Open */
  static openDatabase(arg: {
    _sDbName: string, // 오픈할 대상 데이터베이스 이름
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.openDatabase({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }

  /** DataBase Transaction Rollback */
  static rollbackTransaction(arg?: {
    _bMock?: boolean, // Mock 데이터 사용 여부
  }): Promise<Record<string, any>> {
    return new Promise(resolve => {
      window.bizMOB.Database.rollbackTransaction({
        ...arg,
        _fCallback: function (res: any) {
          resolve(res);
        }
      });
    });
  }
}
