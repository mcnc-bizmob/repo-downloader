// localStorage와 동일
export default class Properties {
  /** Properties 데이터 조회 */
  static get(arg: {
    _sKey: string, // Property에서 가져올 키 값
  }): any {
    return window.bizMOB.Properties.get({
      ...arg,
    });
  }

  /** Properties 데이터 삭제 */
  static remove(arg: {
    _sKey: string, // Property에서 삭제할 키 값
  }): void {
    window.bizMOB.Properties.remove({
      ...arg,
    });
  }

  /** Properties 데이터 저장 */
  static set(arg: {
    _sKey: string, // Property에 저장할 키 값
    _vValue: any, // Property에 저장할 값
  }): void {
    window.bizMOB.Properties.set({
      ...arg,
    });
  }

  /** Properties 복수 데이터 저장 */
  static setList(arg: {
    _aList: {
      _sKey: string, // Property에 저장할 키 값
      _vValue: any, // Property에 저장할 값
    }[]
  }): void {
    window.bizMOB.Properties.setList({
      ...arg,
    });
  }
}
