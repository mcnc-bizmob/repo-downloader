export default {
  message: {
    welcome: 'bizMOB 샘플 프로젝트에 오신 것을 환영합니다',
    greeting: '안녕하세요',
    user: {
      welcome: '{name}님 환영합니다',
      profile_greeting: '{0}님의 프로필입니다'
    },
    loading: {
      full: '데이터를 불러오는 중입니다. 잠시만 기다려주세요.',
      short: '로딩 중...'
    }
  },
  button: {
    save: '저장',
    cancel: '취소',
    confirm: '확인'
  },
  error: {
    network: '네트워크 오류가 발생했습니다',
    validation: '입력값을 확인해주세요'
  },
  sample: {
    dashboard: {
      title: 'bizMOB Xross 4.0 샘플',
      description: '실사용 패턴(로그인/목록/상세/작성)을 바로 복사해 사용할 수 있는 샘플 모음입니다.',
      usage_title: '사용 방법',
      usage_1: '아래 카드에서 시작할 화면을 선택하세요.',
      usage_2: '각 화면 상단 주석에 시연 API와 확장 포인트가 정리되어 있습니다.',
      usage_3: '모든 데이터는 public/mock/SAMPLE_*.json Mock 으로 동작합니다.'
    },
    login: {
      title: '로그인',
      id: '아이디',
      pw: '비밀번호',
      id_placeholder: '아이디를 입력하세요',
      pw_placeholder: '비밀번호를 입력하세요',
      submit: '로그인',
      submitting: '로그인 중입니다...',
      failed: '로그인에 실패했습니다',
      empty: '아이디와 비밀번호를 모두 입력해주세요'
    },
    main: {
      title: '메인',
      welcome: '{name}님 환영합니다',
      dept: '{dept} 소속',
      go_board: '게시판 이동',
      change_locale: '언어 변경',
      current_locale: '현재 언어: {locale}',
      logout: '로그아웃',
      logout_confirm: '로그아웃 하시겠습니까?'
    },
    board: {
      title: '게시판',
      search_placeholder: '제목을 검색하세요',
      empty: '게시글이 없습니다',
      write: '글쓰기',
      more_loading: '더 불러오는 중...',
      detail_title: '게시글 상세',
      write_title: '게시글 작성',
      form: {
        title: '제목',
        title_placeholder: '제목을 입력하세요',
        category: '카테고리',
        category_placeholder: '카테고리를 선택하세요',
        content: '내용',
        content_placeholder: '내용을 입력하세요'
      },
      action: {
        edit: '수정',
        delete: '삭제',
        delete_confirm: '이 게시글을 삭제하시겠습니까?',
        deleted: '삭제되었습니다',
        saved: '저장되었습니다'
      },
      validation: {
        required: '필수 항목을 모두 입력해주세요'
      }
    }
  }
};
