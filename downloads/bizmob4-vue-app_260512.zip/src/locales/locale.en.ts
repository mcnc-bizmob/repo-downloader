export default {
  message: {
    welcome: 'Welcome to bizMOB sample project',
    greeting: 'Hello',
    user: {
      welcome: 'Hello {name}',
      profile_greeting: 'This is {0}\'s profile'
    },
    loading: {
      full: 'Loading data. Please wait a moment.',
      short: 'Loading...'
    }
  },
  button: {
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm'
  },
  error: {
    network: 'Network error occurred',
    validation: 'Please check your input'
  },
  sample: {
    dashboard: {
      title: 'bizMOB Xross 4.0 Samples',
      description: 'Real-world screen patterns (login/list/detail/form) you can copy into your new project.',
      usage_title: 'How to use',
      usage_1: 'Pick a screen to start from the cards below.',
      usage_2: 'Each file has a header comment describing the APIs demoed and extension points.',
      usage_3: 'All data is served from public/mock/SAMPLE_*.json mock files.'
    },
    login: {
      title: 'Sign in',
      id: 'User ID',
      pw: 'Password',
      id_placeholder: 'Enter your user ID',
      pw_placeholder: 'Enter your password',
      submit: 'Sign in',
      submitting: 'Signing in...',
      failed: 'Sign-in failed',
      empty: 'Please enter both ID and password'
    },
    main: {
      title: 'Home',
      welcome: 'Welcome, {name}',
      dept: '{dept}',
      go_board: 'Open board',
      change_locale: 'Change language',
      current_locale: 'Current: {locale}',
      logout: 'Sign out',
      logout_confirm: 'Are you sure you want to sign out?'
    },
    board: {
      title: 'Board',
      search_placeholder: 'Search by title',
      empty: 'No posts',
      write: 'Write',
      more_loading: 'Loading more...',
      detail_title: 'Post detail',
      write_title: 'New post',
      form: {
        title: 'Title',
        title_placeholder: 'Enter a title',
        category: 'Category',
        category_placeholder: 'Select a category',
        content: 'Content',
        content_placeholder: 'Enter the content'
      },
      action: {
        edit: 'Edit',
        delete: 'Delete',
        delete_confirm: 'Delete this post?',
        deleted: 'Deleted',
        saved: 'Saved'
      },
      validation: {
        required: 'Please fill in all required fields'
      }
    }
  }
};
