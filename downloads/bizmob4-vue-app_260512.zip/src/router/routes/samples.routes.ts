// bizMOB Xross 4.0 샘플 화면 라우터 설정
//
// 이 파일은 신규 프로젝트의 "첫 화면 작성 시 참고용 실사용 패턴 샘플"을 등록한다.
// tests.routes.ts 가 useApp 컴포저블 단위 테스트를 담는다면,
// 이 파일은 Network/Storage + useApp 을 조합한 실제 화면 흐름을 담는다.
export default [
  // 샘플 대시보드 (진입점)
  {
    path: '/samples',
    name: 'SampleDashboard',
    component: () => import('@/views/samples/SampleDashboard.vue')
  },

  // 로그인 샘플
  {
    path: '/samples/login',
    name: 'SampleLogin',
    component: () => import('@/views/samples/login/LoginSample.vue')
  },

  // 메인(홈) 샘플
  {
    path: '/samples/main',
    name: 'SampleMain',
    component: () => import('@/views/samples/main/MainSample.vue')
  },

  // 게시판 목록 샘플
  {
    path: '/samples/board',
    name: 'SampleBoardList',
    component: () => import('@/views/samples/board/BoardListSample.vue')
  },

  // 게시판 상세 샘플
  {
    path: '/samples/board/detail',
    name: 'SampleBoardDetail',
    component: () => import('@/views/samples/board/BoardDetailSample.vue')
  },

  // 게시판 작성 샘플
  {
    path: '/samples/board/write',
    name: 'SampleBoardWrite',
    component: () => import('@/views/samples/board/BoardWriteSample.vue')
  }
];
