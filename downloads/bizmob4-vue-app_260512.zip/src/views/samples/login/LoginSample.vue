<!--
=== LoginSample.vue ===
bizMOB Xross 4.0 로그인 화면 실사용 샘플

** 이 화면이 시연하는 것 **
- Network.requestLogin({ _bMock: true }) 로그인 전문 호출
- withLoading 으로 요청 중 로딩 오버레이 자동 제어
- Storage.set 으로 로그인 응답(user/token)을 세션 스토리지에 저장
- alert 로 실패 피드백, push('/samples/main', { direction: 'root' }) 로 스택 초기화 이동
- t() 로 i18n 레이블 적용 (sample.login.*)

** 확장 포인트 **
- 실제 환경 연동 시 _bMock: false 로 변경하고 _sTrcode 를 실 전문 코드로 교체
- Storage 대신 Pinia + persist 로 영속화하려면 src/stores/modules/ 에 auth 스토어 추가
- 2단계 인증/자동 로그인은 onMounted 시 Storage.get('user') 체크 후 리다이렉트 로직 추가

** 참고 **
- 기존 SI: bizMOB4Vue-SI/src/views/LOGIN/LOGIN0100.vue, README/README01.vue (requestLogin 예시)
- Mock 응답: public/mock/SAMPLE_LOGIN.json
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>{{ t('sample.login.title') }}</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="login-container">
        <div class="logo">
          <h1>bizMOB</h1>
          <p>Xross 4.0 Sample</p>
        </div>

        <!-- 로그인 폼 -->
        <form class="login-form" @submit.prevent="handleSubmit">
          <ion-list lines="full">
            <ion-item>
              <ion-input
                v-model="userId"
                :label="t('sample.login.id')"
                label-placement="stacked"
                :placeholder="t('sample.login.id_placeholder')"
                autocomplete="username"
                :clear-input="true"
              />
            </ion-item>

            <ion-item>
              <ion-input
                v-model="password"
                type="password"
                :label="t('sample.login.pw')"
                label-placement="stacked"
                :placeholder="t('sample.login.pw_placeholder')"
                autocomplete="current-password"
                :clear-input="true"
              />
            </ion-item>
          </ion-list>

          <ion-button
            type="submit"
            expand="block"
            class="submit-button"
            :disabled="!canSubmit"
          >
            {{ t('sample.login.submit') }}
          </ion-button>
        </form>

        <!-- 힌트 (샘플 전용) -->
        <div class="hint">
          <p>Mock 로그인 샘플입니다. 아무 아이디/비밀번호나 입력해도 성공합니다.</p>
          <p>예: tester / 1111</p>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton,
  IonList,
  IonItem,
  IonInput,
  IonButton
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';
import Network from '@bizMOB/Xross/Network';
import Storage from '@bizMOB/Xross/Storage';

// STEP 1: 필요한 useApp 기능을 구조 분해로 가져온다.
const { alert, withLoading, push, back, t } = useApp();

// STEP 2: 폼 상태 ref
const userId = ref<string>('');
const password = ref<string>('');

// 제출 가능 여부 (간단한 빈 값 체크)
const canSubmit = computed(() => !!userId.value && !!password.value);

const handleBackButtonClick = (event: Event) => {
  event.preventDefault();
  back();
};

// STEP 3: 제출 핸들러 - Network.requestLogin Mock 호출
const handleSubmit = async () => {
  if (!canSubmit.value) {
    await alert(t('sample.login.empty'));
    return;
  }

  // withLoading 으로 감싸면 요청 동안 전역 로딩 오버레이가 자동 표시된다.
  const res: any = await withLoading(async () =>
    Network.requestLogin({
      _bMock: true,                 // 샘플은 Mock 으로 동작
      _sTrcode: 'SAMPLE_LOGIN',     // public/mock/SAMPLE_LOGIN.json
      _sUserId: userId.value,
      _sPassword: password.value,
      _oBody: {
        userId: userId.value,
        passwd: password.value
      }
    })
  );

  // STEP 4: 응답 처리
  // - bizMOB 로그인 응답은 { result, ...body } 또는 { header, body } 형태로 전달된다.
  //   Mock 포맷(public/mock/SAMPLE_LOGIN.json)은 header.result + body 를 사용.
  const ok = res?.header?.result ?? res?.result;
  if (!ok) {
    await alert(t('sample.login.failed'));
    return;
  }

  const body = res?.body ?? res;

  // STEP 5: 세션 정보 저장 (Storage 는 sessionStorage 래퍼)
  Storage.set({ _sKey: 'sample.user', _vValue: body?.user ?? null });
  Storage.set({ _sKey: 'sample.accessToken', _vValue: body?.accessToken ?? '' });

  // STEP 6: 메인으로 이동. direction: 'root' 는 스택을 초기화하여 뒤로가기로 로그인에 돌아가지 못하게 한다.
  push('/samples/main', { direction: 'root' });
};
</script>

<style scoped>
.login-container {
  max-width: 420px;
  margin: 0 auto;
  padding: 24px 16px;
}

.logo {
  text-align: center;
  margin: 24px 0 32px;
}

.logo h1 {
  margin: 0;
  font-size: 2.4em;
  color: #007bff;
  letter-spacing: 2px;
}

.logo p {
  margin: 4px 0 0;
  color: #888;
  font-size: 0.9em;
}

.login-form {
  margin-top: 16px;
}

.submit-button {
  margin-top: 24px;
  --border-radius: 8px;
}

.hint {
  margin-top: 40px;
  padding: 16px;
  background: #f8f9fa;
  border-left: 4px solid #007bff;
  border-radius: 4px;
  font-size: 0.85em;
  color: #555;
}

.hint p {
  margin: 4px 0;
}
</style>
