<!--
=== SampleDashboard.vue ===
bizMOB Xross 4.0 실사용 패턴 샘플 모음의 진입점(대시보드)

** 이 화면이 시연하는 것 **
- useApp.push 를 이용한 샘플 화면 간 네비게이션
- useApp.t 를 이용한 i18n 문자열 로딩 (locale.{lang}.ts 의 sample.* 키)
- TestDashboard.vue 와 동일한 카드형 레이아웃 패턴

** 확장 포인트 **
- 새 샘플 화면을 추가할 경우:
  1) sampleItems 배열에 { id, title, description, route } 추가
  2) src/router/routes/samples.routes.ts 에 라우트 등록
  3) src/locales/locale.{ko,en}.ts 의 sample.* 그룹에 문자열 추가

** 참고 **
- 유사 구조 원본: src/views/tests/TestDashboard.vue
- 기존 SI 프로젝트: bizMOB4Vue-SI/src/views/README/README01.vue
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>{{ t('sample.dashboard.title') }}</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="dashboard-container">
        <h1>{{ t('sample.dashboard.title') }}</h1>
        <p class="description">{{ t('sample.dashboard.description') }}</p>

        <!-- 샘플 화면 카드 목록 -->
        <div class="sample-grid">
          <div v-for="item in sampleItems" :key="item.id" class="sample-card">
            <h3>{{ item.title }}</h3>
            <p>{{ item.description }}</p>
            <ion-button
              class="sample-button"
              fill="outline"
              expand="block"
              @click="navigateToSample(item.route)"
            >
              {{ item.enter }} →
            </ion-button>
          </div>
        </div>

        <!-- 사용 안내 -->
        <div class="usage-guide">
          <h2>{{ t('sample.dashboard.usage_title') }}</h2>
          <ol>
            <li>{{ t('sample.dashboard.usage_1') }}</li>
            <li>{{ t('sample.dashboard.usage_2') }}</li>
            <li>{{ t('sample.dashboard.usage_3') }}</li>
          </ol>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';

// useApp 통합 API 에서 필요한 기능만 구조 분해로 가져온다.
const { back, push, t } = useApp();

// ion-back-button 클릭 시 useApp.back() 으로 통합 백 처리 위임
const handleBackButtonClick = (event: Event) => {
  event.preventDefault();
  back();
};

// 샘플 화면으로 이동 (Ionic Router 네비게이션)
const navigateToSample = (route: string) => {
  push(route);
};

// 샘플 카드 목록
// - t() 는 setup 내부에서 호출 시점에 평가되므로 computed 로 감싸 언어 전환 반응성을 보장한다.
const sampleItems = computed(() => [
  {
    id: 'login',
    title: t('sample.login.title'),
    description: 'Network.requestLogin + Storage.set + withLoading + push(root)',
    enter: t('sample.login.submit'),
    route: '/samples/login'
  },
  {
    id: 'main',
    title: t('sample.main.title'),
    description: 'Storage.get 세션 유저 + changeLocale + confirm 기반 로그아웃',
    enter: t('sample.main.title'),
    route: '/samples/main'
  },
  {
    id: 'board-list',
    title: t('sample.board.title'),
    description: 'Network.requestTr 페이징 + 검색 + ion-refresher + ion-infinite-scroll',
    enter: t('sample.board.title'),
    route: '/samples/board'
  },
  {
    id: 'board-detail',
    title: t('sample.board.detail_title'),
    description: 'getQuery + Network.requestTr + openActionSheet + confirm + back',
    enter: t('sample.board.detail_title'),
    route: '/samples/board/detail?id=B00023'
  },
  {
    id: 'board-write',
    title: t('sample.board.write_title'),
    description: 'openModal 카테고리 픽커 + 폼 검증 + Network.requestTr + toast + back',
    enter: t('sample.board.write_title'),
    route: '/samples/board/write'
  }
]);
</script>

<style scoped>
.dashboard-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.dashboard-container h1 {
  text-align: center;
  color: #333;
  margin-bottom: 10px;
}

.description {
  text-align: center;
  color: #666;
  margin-bottom: 40px;
  line-height: 1.6;
}

.sample-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
}

.sample-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  background: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.sample-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.sample-card h3 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 1.2em;
}

.sample-card p {
  margin: 0 0 15px 0;
  color: #666;
  line-height: 1.5;
  font-size: 0.9em;
}

.sample-button {
  --color: #007bff;
  --border-color: #007bff;
  --border-width: 2px;
  --border-radius: 8px;
  --padding-top: 12px;
  --padding-bottom: 12px;
  margin-top: 4px;
  font-weight: 500;
}

.sample-button:hover {
  --background: #007bff;
  --color: white;
}

.usage-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #007bff;
}

.usage-guide h2 {
  margin: 0 0 15px 0;
  color: #333;
}

.usage-guide ol {
  margin: 0;
  padding-left: 20px;
}

.usage-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>
