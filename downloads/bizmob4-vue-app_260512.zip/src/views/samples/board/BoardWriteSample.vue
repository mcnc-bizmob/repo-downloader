<!--
=== BoardWriteSample.vue ===
게시판 작성 화면 실사용 샘플 (모달 폼 패턴)

** 이 화면이 시연하는 것 **
- ion-item + ion-input / ion-textarea 기반 기본 폼
- openModal 로 카테고리 선택 모달 표시 및 결과 수신 패턴
- 제출 전 빈 값 검증 + alert 피드백
- Network.requestTr({ _bMock: true }) 로 저장 전문 호출
- 성공 시 toast 피드백 + back() 으로 목록 복귀
- getQuery('id') 가 있으면 수정 모드로 분기 (상세 → 수정 진입 지점 대응)

** 확장 포인트 **
- 첨부파일 업로드는 File.upload 샘플 별도 작성 후 이 화면에 결합
- 리치 에디터 연동 시 ion-textarea 를 교체
- 카테고리/태그를 ion-select 로 단순화할지, 모달로 갈지 패턴 비교용으로 이 샘플은 모달 방식 사용

** 참고 **
- 기존 SI: bizMOB4Vue-SI/src/views/BOARD/BOARD0200.vue, BOARD0201.vue
- Mock 응답: public/mock/SAMPLE_BOARD_WRITE.json
- 카테고리 모달: ./_CategoryPickerModal.vue
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>{{ t('sample.board.write_title') }}</ion-title>
        <ion-buttons slot="end">
          <ion-button :disabled="!canSubmit" @click="handleSubmit">
            {{ t('button.save') }}
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-list lines="full">
        <!-- 제목 -->
        <ion-item>
          <ion-input
            v-model="form.title"
            :label="t('sample.board.form.title')"
            label-placement="stacked"
            :placeholder="t('sample.board.form.title_placeholder')"
            :clear-input="true"
          />
        </ion-item>

        <!-- 카테고리 (모달 선택) -->
        <ion-item button :detail="true" @click="pickCategory">
          <ion-label>
            <span class="label-head">{{ t('sample.board.form.category') }}</span>
            <p :class="{ placeholder: !form.category }">
              {{ form.category || t('sample.board.form.category_placeholder') }}
            </p>
          </ion-label>
        </ion-item>

        <!-- 본문 -->
        <ion-item>
          <ion-textarea
            v-model="form.content"
            :label="t('sample.board.form.content')"
            label-placement="stacked"
            :placeholder="t('sample.board.form.content_placeholder')"
            :auto-grow="true"
            :rows="8"
          />
        </ion-item>
      </ion-list>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { reactive, computed } from 'vue';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonButton,
  IonBackButton,
  IonList,
  IonItem,
  IonInput,
  IonTextarea,
  IonLabel
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';
import Network from '@bizMOB/Xross/Network';
import CategoryPickerModal from './_CategoryPickerModal.vue';

// STEP 1: useApp 기능
const { alert, toast, openModal, back, getQuery, t, withLoading } = useApp();

// STEP 2: 폼 상태
const form = reactive({
  title: '',
  category: '',
  content: ''
});

// 수정 모드: 상세에서 query.id 로 진입한 경우를 대비한 분기 예시
// 실 연동 시 onIonViewWillEnter 에서 requestTr 로 기존 값 로드해 form 에 채우면 된다.
const editingId = getQuery('id');

const canSubmit = computed(
  () => !!form.title.trim() && !!form.category && !!form.content.trim()
);

const handleBackButtonClick = (event: Event) => {
  event.preventDefault();
  back();
};

// STEP 3: 카테고리 선택 - openModal 로 모달 표시 후 결과 수신
const pickCategory = async () => {
  const result: any = await openModal(CategoryPickerModal, {
    props: { selected: form.category }
  });

  // openModal 응답: { result: boolean, data: any, role: string }
  if (result?.result && result?.data?.value) {
    form.category = result.data.value;
  }
};

// STEP 4: 제출 - 검증 → 전문 호출 → toast → back
const handleSubmit = async () => {
  if (!canSubmit.value) {
    await alert(t('sample.board.validation.required'));
    return;
  }

  const res: any = await withLoading(async () =>
    Network.requestTr({
      _bMock: true,
      _sTrcode: 'SAMPLE_BOARD_WRITE',
      _oBody: {
        boardSeq: editingId || null, // 수정이면 기존 식별자, 신규면 null
        title: form.title,
        category: form.category,
        content: form.content
      }
    })
  );

  if (res?.header?.result) {
    await toast(t('sample.board.action.saved'));
    back();
  } else {
    await alert(t('error.network'));
  }
};
</script>

<style scoped>
.label-head {
  display: block;
  font-size: 0.75em;
  color: #6c757d;
  margin-bottom: 4px;
}

ion-label p {
  margin: 0;
  color: #222;
  font-size: 1em;
}

ion-label p.placeholder {
  color: #aaa;
}
</style>
