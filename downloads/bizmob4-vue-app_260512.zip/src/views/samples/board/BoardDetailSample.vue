<!--
=== BoardDetailSample.vue ===
게시판 상세 화면 실사용 샘플

** 이 화면이 시연하는 것 **
- getQuery('id') 로 목록에서 전달받은 게시글 식별자 수신
- Network.requestTr({ _bMock: true }) 로 상세 전문 호출
- ion-toolbar 우상단 더보기 버튼 → openActionSheet 로 수정/삭제 메뉴 표시
- confirm 으로 삭제 최종 확인 후 toast 피드백 + back()
- whitespace-pre-wrap 으로 본문 개행 처리

** 확장 포인트 **
- 첨부파일 카드는 File.download 와 연계 (File Xross API 샘플 별도 작성 권장)
- 수정은 BoardWriteSample 을 재사용하되 query 로 boardSeq 를 전달해 "수정 모드" 분기
- 댓글 영역은 하위 컴포넌트로 분리

** 참고 **
- 기존 SI: bizMOB4Vue-SI/src/views/BOARD/BOARD0300.vue
- Mock 응답: public/mock/SAMPLE_BOARD_DETAIL.json
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>{{ t('sample.board.detail_title') }}</ion-title>
        <ion-buttons slot="end">
          <ion-button @click="openMoreMenu">
            <ion-icon slot="icon-only" :icon="ellipsisVertical" />
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div v-if="post" class="detail-container">
        <div class="meta">
          <span class="category">[{{ post.category }}]</span>
          <span class="writer">{{ post.writer }}</span>
          <span class="date">{{ post.regDate }}</span>
          <span class="views">조회 {{ post.viewCount }}</span>
        </div>
        <h1 class="title">{{ post.title }}</h1>
        <div class="content">{{ post.content }}</div>
      </div>

      <div v-else-if="!isLoading" class="empty">
        <p>게시글을 찾을 수 없습니다.</p>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton,
  IonButton,
  IonIcon,
  onIonViewWillEnter
} from '@ionic/vue';
import { ellipsisVertical } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';
import Network from '@bizMOB/Xross/Network';

// STEP 1: useApp 기능
const {
  confirm,
  toast,
  openActionSheet,
  push,
  back,
  getQuery,
  t,
  withLoading
} = useApp();

interface BoardDetail {
  boardSeq: string;
  category: string;
  title: string;
  writer: string;
  regDate: string;
  viewCount: number;
  content: string;
}

// STEP 2: 상태
const post = ref<BoardDetail | null>(null);
const isLoading = ref<boolean>(false);

const handleBackButtonClick = (event: Event) => {
  event.preventDefault();
  back();
};

// STEP 3: 화면 진입 시 상세 조회
onIonViewWillEnter(async () => {
  const id = getQuery('id');
  if (!id) {
    post.value = null;
    return;
  }

  isLoading.value = true;
  await withLoading(async () => {
    const res: any = await Network.requestTr({
      _bMock: true,
      _sTrcode: 'SAMPLE_BOARD_DETAIL',
      _oBody: { boardSeq: id }
    });

    if (res?.header?.result && res?.body) {
      post.value = res.body as BoardDetail;
    } else {
      post.value = null;
    }
  });
  isLoading.value = false;
});

// STEP 4: 더보기 메뉴 - openActionSheet 로 수정/삭제 선택지 표시
const openMoreMenu = async () => {
  const result: any = await openActionSheet([
    { text: t('sample.board.action.edit'), value: 'edit' },
    { text: t('sample.board.action.delete'), value: 'delete', role: 'destructive' },
    { text: t('button.cancel'), role: 'cancel' }
  ]);

  if (result?.value === 'edit') {
    handleEdit();
  } else if (result?.value === 'delete') {
    await handleDelete();
  }
};

// STEP 5: 수정 - 작성 화면으로 query 전달
// 작성 화면에서 query.id 가 있으면 "수정 모드" 로 분기 가능하도록 설계
const handleEdit = () => {
  if (!post.value) return;
  push('/samples/board/write', { query: { id: post.value.boardSeq } });
};

// STEP 6: 삭제 - confirm 후 toast + back
// Mock 이라 실제 삭제 전문 호출은 생략. 실 연동 시 Network.requestTr('SAMPLE_BOARD_DELETE') 추가.
const handleDelete = async () => {
  const ok = await confirm(t('sample.board.action.delete_confirm'));
  if (!ok) return;

  await toast(t('sample.board.action.deleted'));
  back();
};
</script>

<style scoped>
.detail-container {
  max-width: 720px;
  margin: 0 auto;
}

.meta {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  font-size: 0.8em;
  color: #888;
  margin-bottom: 8px;
}

.meta .category {
  color: #007bff;
  font-weight: 600;
}

.title {
  margin: 8px 0 16px;
  font-size: 1.3em;
  color: #222;
  line-height: 1.4;
}

.content {
  line-height: 1.7;
  white-space: pre-wrap;
  color: #333;
  padding-top: 12px;
  border-top: 1px solid #eee;
}

.empty {
  padding: 80px 20px;
  text-align: center;
  color: #888;
}
</style>
