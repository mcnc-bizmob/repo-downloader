<!--
=== _CategoryPickerModal.vue ===
BoardWriteSample 에서 openModal 로 열리는 카테고리 선택 모달

** 역할 **
- 카테고리 목록을 리스트로 표시하고 선택 시 closeModal(true, { value }) 로 결과 반환
- openModal 의 반환값은 ModalTest.vue 참고: { result, data } 형태

** 참고 **
- modalController 을 직접 쓰지 않고 useApp.closeModal 로 닫는다 (백버튼 체인과 연계)
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>{{ t('sample.board.form.category') }}</ion-title>
        <ion-buttons slot="end">
          <ion-button @click="cancel">{{ t('button.cancel') }}</ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content>
      <ion-list>
        <ion-item
          v-for="option in options"
          :key="option"
          button
          :detail="false"
          @click="select(option)"
        >
          <ion-label>{{ option }}</ion-label>
          <ion-icon
            v-if="option === selected"
            slot="end"
            :icon="checkmark"
            color="primary"
          />
        </ion-item>
      </ion-list>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonButton,
  IonList,
  IonItem,
  IonLabel,
  IonIcon
} from '@ionic/vue';
import { checkmark } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';

// 부모에서 전달받는 Props
defineProps<{
  selected?: string;
}>();

const { closeModal, t } = useApp();

// 샘플용 고정 카테고리 - 실 연동 시 Network.requestTr 로 코드 조회 후 치환
const options = ['공지', '자유', '질문'];

const select = (value: string) => {
  // closeModal(result, data) 형태로 결과 반환
  closeModal(true, { value });
};

const cancel = () => {
  closeModal(false);
};
</script>
