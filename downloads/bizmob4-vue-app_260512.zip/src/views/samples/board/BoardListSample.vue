<!--
=== BoardListSample.vue ===
게시판 목록 화면 실사용 샘플

** 이 화면이 시연하는 것 **
- Network.requestTr({ _bMock: true }) 로 목록 전문 호출
- 검색어 + 페이지 번호 파라미터를 _oBody 에 담아 전송
- ion-searchbar 를 이용한 키워드 검색
- ion-refresher 로 pull-to-refresh 동작
- ion-infinite-scroll 로 스크롤 끝에서 추가 로드 (무한 스크롤)
- push('/samples/board/detail', { query: { id } }) 로 상세 화면 이동
- ion-fab 우하단 플로팅 버튼으로 글쓰기 진입

** Mock 주의 **
- public/mock/SAMPLE_BOARD_LIST.json 은 항상 23건을 반환한다.
  실제 서버가 페이징을 해주는 것이 아니므로, 이 샘플에서는 응답 전체 리스트에서
  클라이언트가 [(page-1)*size, page*size] 만큼 잘라서 보여주는 방식으로
  무한 스크롤 패턴을 시연한다. 실 서버 연동 시 이 슬라이싱 로직은 제거하면 된다.

** 확장 포인트 **
- 필터 UI (카테고리/날짜) 는 openModal 또는 openActionSheet 로 분리
- ion-virtual-scroll 로 교체해 대량 리스트 최적화
- onIonViewWillEnter + navigationType === 'back' 분기로 상세에서 복귀 시 재조회 생략

** 참고 **
- 기존 SI: bizMOB4Vue-SI/src/views/BOARD/BOARD0100.vue
- Mock 응답: public/mock/SAMPLE_BOARD_LIST.json
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>{{ t('sample.board.title') }}</ion-title>
      </ion-toolbar>
      <ion-toolbar>
        <ion-searchbar
          v-model="keyword"
          :placeholder="t('sample.board.search_placeholder')"
          :debounce="300"
          @ionInput="onSearch"
          @ionClear="onSearch"
        />
      </ion-toolbar>
    </ion-header>

    <ion-content>
      <!-- pull-to-refresh -->
      <ion-refresher slot="fixed" @ionRefresh="onRefresh($event)">
        <ion-refresher-content />
      </ion-refresher>

      <!-- 목록 비어있음 -->
      <div v-if="displayList.length === 0 && !isFirstLoading" class="empty">
        <p>{{ t('sample.board.empty') }}</p>
      </div>

      <!-- 목록 -->
      <ion-list v-else>
        <ion-item
          v-for="item in displayList"
          :key="item.boardSeq"
          button
          detail
          @click="goDetail(item)"
        >
          <ion-label>
            <h3>[{{ item.category }}] {{ item.title }}</h3>
            <p>{{ item.writer }} · {{ item.regDate }} · 조회 {{ item.viewCount }}</p>
          </ion-label>
        </ion-item>
      </ion-list>

      <!-- 무한 스크롤 -->
      <ion-infinite-scroll
        :disabled="!hasMore"
        @ionInfinite="onLoadMore($event)"
      >
        <ion-infinite-scroll-content :loading-text="t('sample.board.more_loading')" />
      </ion-infinite-scroll>

      <!-- 글쓰기 FAB -->
      <ion-fab slot="fixed" vertical="bottom" horizontal="end">
        <ion-fab-button @click="goWrite">
          <ion-icon :icon="add" />
        </ion-fab-button>
      </ion-fab>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton,
  IonSearchbar,
  IonList,
  IonItem,
  IonLabel,
  IonRefresher,
  IonRefresherContent,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonFab,
  IonFabButton,
  IonIcon,
  onIonViewWillEnter,
  type InfiniteScrollCustomEvent,
  type RefresherCustomEvent
} from '@ionic/vue';
import { add } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';
import Network from '@bizMOB/Xross/Network';

// STEP 1: useApp 기능
const { push, back, t, withLoading } = useApp();

interface BoardItem {
  boardSeq: string;
  category: string;
  title: string;
  writer: string;
  regDate: string;
  viewCount: number;
}

// STEP 2: 상태
const PAGE_SIZE = 8;
const keyword = ref<string>('');
const page = ref<number>(1);
const totalCount = ref<number>(0);
// 서버가 페이징을 하는 척하기 위해 응답 전체를 보관한 뒤 슬라이싱한다.
const fullList = ref<BoardItem[]>([]);
const displayList = ref<BoardItem[]>([]);
const isFirstLoading = ref<boolean>(false);

const hasMore = computed(() => displayList.value.length < fullList.value.length);

const handleBackButtonClick = (event: Event) => {
  event.preventDefault();
  back();
};

// STEP 3: 목록 조회 - 첫 페이지
// withLoading 으로 감싸면 첫 조회 시에만 로딩 오버레이가 뜨도록 한다.
// (pull-to-refresh 나 더보기에는 각 컴포넌트가 자체 인디케이터를 제공)
const fetchList = async (kw: string) => {
  const res: any = await Network.requestTr({
    _bMock: true,
    _sTrcode: 'SAMPLE_BOARD_LIST',
    _oBody: {
      keyword: kw,
      page: 1,
      pageSize: PAGE_SIZE
    }
  });

  if (!res?.header?.result) {
    fullList.value = [];
    totalCount.value = 0;
    displayList.value = [];
    return;
  }

  // Mock 응답은 전체 목록을 반환한다. 실 서버 연동 시에는
  // body.list 를 그대로 displayList 에 넣고 page 기반으로 누적하면 된다.
  const all: BoardItem[] = res.body?.list ?? [];
  // 클라이언트 키워드 필터 (Mock 용 시연)
  const filtered = kw
    ? all.filter((it) => it.title.toLowerCase().includes(kw.toLowerCase()))
    : all;
  fullList.value = filtered;
  totalCount.value = res.body?.totalCount ?? filtered.length;
  page.value = 1;
  displayList.value = filtered.slice(0, PAGE_SIZE);
};

// STEP 4: 화면 진입 시 첫 조회 (초기 진입 + 뒤로가기 복귀 시 최신 상태 갱신)
onIonViewWillEnter(async () => {
  isFirstLoading.value = true;
  await withLoading(async () => {
    await fetchList(keyword.value);
  });
  isFirstLoading.value = false;
});

// STEP 5: 검색 - 디바운스된 ion-searchbar 이벤트에서 호출
const onSearch = async () => {
  await withLoading(async () => {
    await fetchList(keyword.value);
  });
};

// STEP 6: pull-to-refresh - ion-refresher 이벤트에 complete 호출 필요
const onRefresh = async (event: RefresherCustomEvent) => {
  try {
    await fetchList(keyword.value);
  } finally {
    event.target.complete();
  }
};

// STEP 7: 무한 스크롤 - ion-infinite-scroll 이벤트에 complete 호출 필요
const onLoadMore = async (event: InfiniteScrollCustomEvent) => {
  try {
    // 실 서버 연동 시에는 여기서 page + 1 로 추가 요청을 보내고
    // 응답을 displayList 에 concat 한다.
    const nextPage = page.value + 1;
    const start = (nextPage - 1) * PAGE_SIZE;
    const end = nextPage * PAGE_SIZE;
    const next = fullList.value.slice(start, end);
    if (next.length > 0) {
      displayList.value = displayList.value.concat(next);
      page.value = nextPage;
    }
  } finally {
    event.target.complete();
  }
};

// STEP 8: 상세 이동 - query 로 식별자 전달
const goDetail = (item: BoardItem) => {
  push('/samples/board/detail', { query: { id: item.boardSeq } });
};

// STEP 9: 글쓰기 이동
const goWrite = () => {
  push('/samples/board/write');
};
</script>

<style scoped>
.empty {
  padding: 80px 20px;
  text-align: center;
  color: #888;
}

ion-item h3 {
  margin: 0 0 4px 0;
  font-weight: 600;
  color: #222;
}

ion-item p {
  margin: 0;
  font-size: 0.8em;
  color: #888;
}
</style>
