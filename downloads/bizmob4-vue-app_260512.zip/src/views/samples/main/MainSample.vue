<!--
=== MainSample.vue ===
로그인 후 첫 진입 화면(홈/대시보드) 실사용 샘플

** 이 화면이 시연하는 것 **
- onIonViewWillEnter 로 화면 진입 시마다 Storage.get 으로 세션 유저 복원
- 세션이 없을 때 Network.requestTr 로 사용자 정보 재조회하는 패턴
- 카드형 메뉴로 "게시판 이동 / 언어 변경 / 로그아웃" 액션 제공
- changeLocale 로 런타임 i18n 언어 전환 (ko ↔ en)
- confirm 후 Storage.remove + push('root') 로 로그아웃 처리

** 확장 포인트 **
- 홈에 푸시 알림 배지, 미열람 공지 카운트 등 추가 카드 배치
- 다중 로케일 지원 시 changeLocale 선택지를 ActionSheet 로 변경

** 참고 **
- 기존 SI: bizMOB4Vue-SI/src/views/MAIN/MAIN0100.vue
- Mock 응답: public/mock/SAMPLE_USER_INFO.json
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>{{ t('sample.main.title') }}</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="main-container">
        <!-- 사용자 정보 카드 -->
        <div class="user-card">
          <h2>{{ t('sample.main.welcome', { name: user.userName || '-' }) }}</h2>
          <p v-if="user.deptName">{{ t('sample.main.dept', { dept: user.deptName }) }}</p>
          <p v-if="user.email" class="email">{{ user.email }}</p>
          <div v-if="user.noticeCount !== undefined" class="badges">
            <span class="badge">공지 {{ user.noticeCount }}</span>
            <span class="badge">메시지 {{ user.messageCount }}</span>
          </div>
        </div>

        <!-- 메뉴 카드 -->
        <div class="menu-grid">
          <button class="menu-card" @click="goBoard">
            <h3>{{ t('sample.main.go_board') }}</h3>
            <p>Network.requestTr + 무한 스크롤</p>
          </button>

          <button class="menu-card" @click="toggleLocale">
            <h3>{{ t('sample.main.change_locale') }}</h3>
            <p>{{ t('sample.main.current_locale', { locale: locale }) }}</p>
          </button>

          <button class="menu-card danger" @click="handleLogout">
            <h3>{{ t('sample.main.logout') }}</h3>
            <p>confirm → Storage.remove → push(root)</p>
          </button>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { reactive } from 'vue';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  onIonViewWillEnter
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';
import Network from '@bizMOB/Xross/Network';
import Storage from '@bizMOB/Xross/Storage';

// STEP 1: useApp 기능 가져오기
const { confirm, push, t, locale, changeLocale, withLoading } = useApp();

// STEP 2: 사용자 정보 상태
interface SampleUser {
  userId?: string;
  userName?: string;
  deptName?: string;
  email?: string;
  noticeCount?: number;
  messageCount?: number;
}
const user = reactive<SampleUser>({});

// STEP 3: 진입 시 사용자 정보 로드
// onIonViewWillEnter 는 Ionic 페이지가 나타날 때마다 호출되므로
// 뒤로가기로 돌아온 경우에도 최신 상태를 유지할 수 있다.
onIonViewWillEnter(async () => {
  // 3-1. 로그인 직후 저장해둔 세션부터 확인
  const cached = Storage.get({ _sKey: 'sample.user' });
  if (cached && typeof cached === 'object') {
    Object.assign(user, cached);
  }

  // 3-2. 세션이 비어 있거나 추가 필드를 로드해야 할 때 Mock 전문 호출
  if (!user.userName || user.noticeCount === undefined) {
    const res: any = await withLoading(async () =>
      Network.requestTr({
        _bMock: true,
        _sTrcode: 'SAMPLE_USER_INFO'
      })
    );
    if (res?.header?.result && res?.body) {
      Object.assign(user, res.body);
      // 세션에도 반영해 다음 진입 시 재호출을 줄인다.
      Storage.set({ _sKey: 'sample.user', _vValue: { ...user } });
    }
  }
});

// STEP 4: 게시판으로 이동
const goBoard = () => {
  push('/samples/board');
};

// STEP 5: i18n 언어 토글 (ko ↔ en)
const toggleLocale = async () => {
  const next = locale.value === 'ko' ? 'en' : 'ko';
  await changeLocale(next);
};

// STEP 6: 로그아웃 - confirm 후 세션 정리 + 로그인 화면으로 스택 초기화 이동
const handleLogout = async () => {
  const ok = await confirm(t('sample.main.logout_confirm'));
  if (!ok) return;

  Storage.remove({ _sKey: 'sample.user' });
  Storage.remove({ _sKey: 'sample.accessToken' });

  push('/samples/login', { direction: 'root' });
};
</script>

<style scoped>
.main-container {
  max-width: 720px;
  margin: 0 auto;
  padding: 16px;
}

.user-card {
  background: linear-gradient(135deg, #007bff 0%, #2250fc 100%);
  color: white;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
  box-shadow: 0 4px 12px rgba(0, 123, 255, 0.25);
}

.user-card h2 {
  margin: 0 0 6px 0;
  font-size: 1.4em;
}

.user-card p {
  margin: 2px 0;
  opacity: 0.92;
  font-size: 0.95em;
}

.user-card .email {
  font-size: 0.85em;
  opacity: 0.8;
}

.badges {
  margin-top: 12px;
  display: flex;
  gap: 8px;
}

.badge {
  background: rgba(255, 255, 255, 0.2);
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 0.8em;
}

.menu-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 12px;
}

.menu-card {
  appearance: none;
  text-align: left;
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 10px;
  padding: 18px;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
}

.menu-card:hover {
  transform: translateY(-1px);
  border-color: #007bff;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
}

.menu-card h3 {
  margin: 0 0 6px 0;
  color: #222;
  font-size: 1.05em;
}

.menu-card p {
  margin: 0;
  color: #777;
  font-size: 0.85em;
}

.menu-card.danger h3 {
  color: #d9534f;
}
</style>
