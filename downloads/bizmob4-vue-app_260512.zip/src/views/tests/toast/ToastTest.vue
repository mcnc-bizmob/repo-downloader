<!--
=== ToastTest.vue ===
useApp.toast 컴포저블의 주요 기능 테스트 화면

** 테스트 범위 **
- 실제 구현: 기본 Toast, 옵션 Toast, Toast 닫기, 활성 Toast 조회 (4개 핵심 기능)
- 주석 설명: 나머지 고급 기능들의 테스트 케이스
-->

<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button @click="handleBackButtonClick"></ion-back-button>
        </ion-buttons>
        <ion-title>Toast 테스트</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="test-container">

        <h1>Toast 기능 테스트</h1>
        <p class="test-description">
          브라우저 개발자 도구의 Console에서 테스트 결과를 확인하세요.
        </p>

        <!-- 핵심 기능 테스트 버튼들 -->
        <div class="test-section">
          <h2>핵심 기능 테스트</h2>

          <div class="button-group">
            <button @click="testBasicToast" class="test-button">
              기본 Toast 테스트
            </button>

            <button @click="testCustomToast" class="test-button">
              커스텀 Toast 테스트
            </button>

            <button @click="testCloseToast" class="test-button">
              Toast 닫기 테스트
            </button>

            <button @click="testToastStatus" class="test-button">
              활성 Toast 조회 테스트
            </button>
          </div>
        </div>

        <!-- 테스트 안내 -->
        <div class="test-guide">
          <h3>테스트 방법</h3>
          <ul>
            <li>각 버튼을 클릭하여 해당 기능을 테스트하세요</li>
            <li>Toast 알림이 화면에 나타나는지 확인하세요</li>
            <li>Console에서 결과 로그를 확인하세요</li>
            <li>다양한 Toast 옵션들의 동작을 확인해보세요</li>
          </ul>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton
} from '@ionic/vue';
import { checkmarkCircle } from 'ionicons/icons';
import { useApp } from '@bizMOB/vue';

const { back } = useApp();

// ion-back-button 클릭 핸들러
const handleBackButtonClick = (event: Event) => {
  event.preventDefault(); // 기본 동작 방지
  back(); // router 컴포저블의 back 함수 사용
};

// bizMOB.vue 통합 API에서 Toast 기능들 가져오기
const {
  toast,
  closeToast,
  getActiveToastCount,
  getActiveToastIds
} = useApp();

/*
=== 핵심 기능 테스트 구현 ===
*/

// 1. 기본 Toast 테스트
const testBasicToast = async () => {
  console.log('%c📋 기본 Toast 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await toast('저장되었습니다.');
    console.log('%c✅ 기본 Toast 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      id: result.id,
      element: result.element.tagName
    });
  } catch (error) {
    console.log('%c❌ 기본 Toast 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 2. 커스텀 Toast 테스트
const testCustomToast = async () => {
  console.log('%c📋 커스텀 Toast 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    const result = await toast({
      message: '파일 업로드가 완료되었습니다.\n총 3개의 파일이 처리되었습니다.',
      duration: 3000,
      position: 'top',
      color: 'success',
      showCloseButton: true,
      closeButtonText: '닫기',
      icon: checkmarkCircle,
      cssClass: 'custom-toast'
    });

    console.log('%c✅ 커스텀 Toast 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      id: result.id,
      element: result.element.tagName,
      position: 'top',
      color: 'success'
    });
  } catch (error) {
    console.log('%c❌ 커스텀 Toast 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 3. Toast 닫기 테스트
const testCloseToast = async () => {
  console.log('%c📋 Toast 닫기 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    // 먼저 Toast 표시
    const toastResult = await toast({
      message: '이 Toast는 5초 후에 프로그래밍적으로 닫힙니다.',
      duration: 10000, // 10초로 설정하여 닫기 테스트 가능
      position: 'middle',
      color: 'warning'
    });

    console.log('%c📋 Toast 표시됨, 3초 후 닫기 실행', 'color: blue; font-weight: bold;');

    // 3초 후 Toast 닫기
    setTimeout(async () => {
      const closeResult = await closeToast({ id: toastResult.id });
      console.log('%c✅ Toast 닫기 테스트 성공', 'color: green; font-weight: bold;');
      console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
        closedCount: closeResult.closed,
        closedIds: closeResult.ids
      });
    }, 3000);

  } catch (error) {
    console.log('%c❌ Toast 닫기 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

// 4. 활성 Toast 조회 테스트
const testToastStatus = async () => {
  console.log('%c📋 활성 Toast 조회 테스트 시작', 'color: blue; font-weight: bold;');

  try {
    // 현재 활성 Toast 조회
    const activeCount = getActiveToastCount();
    const activeIds = getActiveToastIds();

    console.log('%c📋 현재 상태:', 'color: blue; font-weight: bold;', {
      activeCount,
      activeIds
    });

    // 여러 개의 Toast 생성
    await toast('첫 번째 Toast');
    await toast({
      message: '두 번째 Toast',
      duration: 5000,
      position: 'top'
    });
    await toast({
      message: '세 번째 Toast',
      duration: 5000,
      position: 'middle'
    });

    // 생성 후 상태 조회
    const newActiveCount = getActiveToastCount();
    const newActiveIds = getActiveToastIds();

    console.log('%c✅ 활성 Toast 조회 테스트 성공', 'color: green; font-weight: bold;');
    console.log('%c📊 결과:', 'color: purple; font-weight: bold;', {
      이전상태: { activeCount, activeIds },
      현재상태: {
        activeCount: newActiveCount,
        activeIds: newActiveIds
      },
      증가량: newActiveCount - activeCount
    });

  } catch (error) {
    console.log('%c❌ 활성 Toast 조회 테스트 실패', 'color: red; font-weight: bold;');
    console.error('에러:', error);
  }
};

/*
=== 추가 테스트 필요한 기능들 ===

1. 줄바꿈 포함 메시지 테스트:
   - 테스트 케이스: 메시지에 \n이 포함된 Toast 표시
   - 확인 포인트: \n이 <br> 태그로 정확히 변환되어 줄바꿈 표시되는지
   - 예상 결과: Toast 메시지가 여러 줄로 표시됨

2. 다양한 위치 테스트:
   - 테스트 케이스: position 옵션을 'top', 'middle', 'bottom'으로 각각 테스트
   - 확인 포인트: Toast가 지정된 위치에 정확히 표시되는지
   - 예상 결과: 각각 화면 상단, 중앙, 하단에 Toast 표시

3. 다양한 색상 테스트:
   - 테스트 케이스: color 옵션을 'primary', 'success', 'warning', 'danger' 등으로 테스트
   - 확인 포인트: 각 색상이 올바르게 적용되는지
   - 예상 결과: 지정한 색상으로 Toast 배경색 변경

4. 지속시간 테스트:
   - 테스트 케이스: duration을 0 (무제한), 1000, 5000 등으로 설정
   - 확인 포인트: 설정한 시간만큼 Toast가 표시되는지
   - 예상 결과: duration=0일 때는 수동으로 닫을 때까지 표시

5. 닫기 버튼 테스트:
   - 테스트 케이스: showCloseButton: true, closeButtonText 커스텀 설정
   - 확인 포인트: 닫기 버튼이 표시되고 클릭 시 Toast가 닫히는지
   - 예상 결과: 커스텀 텍스트로 닫기 버튼 표시, 클릭 시 Toast 닫힘

6. 모든 Toast 닫기 테스트:
   - 테스트 케이스: 여러 Toast 표시 후 closeToast({ closeAll: true }) 호출
   - 확인 포인트: 모든 활성 Toast가 한 번에 닫히는지
   - 예상 결과: 모든 Toast 동시에 사라짐

7. Default 설정 변경 테스트:
   - 테스트 케이스: setToastDefaults()로 기본값 변경 후 Toast 호출
   - 확인 포인트: 변경된 기본값이 적용되는지
   - 예상 결과: 설정한 기본값으로 Toast 표시됨

8. CSS 클래스 테스트:
   - 테스트 케이스: cssClass 옵션으로 커스텀 스타일 적용
   - 확인 포인트: 지정한 CSS 클래스가 적용되는지
   - 예상 결과: 커스텀 스타일이 Toast에 적용됨

9. 아이콘 테스트:
   - 테스트 케이스: icon 옵션으로 다양한 Ionic 아이콘 설정
   - 확인 포인트: 지정한 아이콘이 Toast에 표시되는지
   - 예상 결과: Toast 메시지와 함께 아이콘 표시

10. 중복 Toast 관리 테스트:
    - 테스트 케이스: 짧은 시간 내에 여러 Toast를 연속 생성
    - 확인 포인트: Toast 스택이 적절히 관리되는지
    - 예상 결과: 각 Toast가 독립적으로 표시되고 관리됨

11. 에러 상황 테스트:
    - 테스트 케이스: 잘못된 옵션이나 존재하지 않는 Toast ID로 닫기 시도
    - 확인 포인트: 에러가 적절히 처리되는지
    - 예상 결과: Console에 에러 로그 출력, 애플리케이션 크래시 없음
*/
</script>

<style scoped lang="scss">
// ============================================================================
// 화면 스타일
// ============================================================================
.test-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.back-link {
  margin-bottom: 20px;
}

.back-button {
  --color: #007bff;
  --padding-start: 0;
  --padding-end: 0;
  margin: 0;
  font-weight: 500;
  text-decoration: none;
}

.back-button:hover {
  --color: #0056b3;
  text-decoration: underline;
}

.test-container h1 {
  color: #333;
  margin-bottom: 10px;
}

.test-description {
  color: #666;
  margin-bottom: 30px;
  font-style: italic;
}

.test-section {
  margin-bottom: 30px;
}

.test-section h2 {
  color: #333;
  margin-bottom: 15px;
  border-bottom: 2px solid #007bff;
  padding-bottom: 5px;
}

.button-group {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
}

.test-button {
  padding: 12px 20px;
  background: #28a745;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.test-button:hover {
  background: #218838;
}

.test-guide {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #28a745;
}

.test-guide h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.test-guide ul {
  margin: 0;
  padding-left: 20px;
}

.test-guide li {
  margin-bottom: 8px;
  line-height: 1.5;
  color: #555;
}
</style>