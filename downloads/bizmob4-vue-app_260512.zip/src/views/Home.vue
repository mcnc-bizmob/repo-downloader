<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>bizMOB Xross 4.0</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="home-container">
        <h1>bizMOB Xross 4.0</h1>
        <p class="description">베이스 템플릿 개발 가이드</p>

        <div class="home-grid">
          <!-- 컴포저블 테스트 -->
          <div class="home-card" @click="push('/tests')">
            <h3>컴포저블 테스트</h3>
            <p>useApp 컴포저블 단위 기능 검증 화면</p>
            <span class="card-arrow">→</span>
          </div>

          <!-- 실사용 샘플 -->
          <div class="home-card" @click="push('/samples')">
            <h3>실사용 샘플</h3>
            <p>bizMOB Xross 4.0 API 실사용 패턴 화면</p>
            <span class="card-arrow">→</span>
          </div>
        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent
} from '@ionic/vue';
import { useApp } from '@bizMOB/vue';

const { push } = useApp();
</script>

<style scoped>
.home-container {
  max-width: 720px;
  margin: 0 auto;
  padding: 40px 20px;
}

.home-container h1 {
  text-align: center;
  color: #333;
  margin-bottom: 8px;
}

.description {
  text-align: center;
  color: #666;
  margin-bottom: 40px;
}

.home-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
}

.home-card {
  position: relative;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 24px;
  background: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.home-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.home-card h3 {
  margin: 0 0 8px 0;
  color: #333;
  font-size: 1.2em;
}

.home-card p {
  margin: 0;
  color: #666;
  line-height: 1.5;
  font-size: 0.9em;
}

.card-arrow {
  position: absolute;
  top: 24px;
  right: 20px;
  font-size: 1.2em;
  color: #007bff;
}
</style>
